/** @format */

import Constants from "./Constants";

export default [
  Constants.Layout.threeColumn,
  Constants.Layout.threeColumn,
  Constants.Layout.threeColumn,
  Constants.Layout.card,
  Constants.Layout.twoColumn,
  Constants.Layout.twoColumn,
  Constants.Layout.twoColumn,
  Constants.Layout.twoColumn,
  Constants.Layout.twoColumn,
  Constants.Layout.twoColumn,
  Constants.Layout.card,
  Constants.Layout.Blog
];
