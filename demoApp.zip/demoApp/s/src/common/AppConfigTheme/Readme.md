#How to use the template?

Copy the .json file and override to the AppConfig.json file, some template could be not use with the CeBuilder, please try to edit manually via the Editor.