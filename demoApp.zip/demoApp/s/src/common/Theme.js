/** @format */
import { DefaultTheme, DarkTheme } from "react-native-paper";

const dark = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    text: "rgba(255, 255, 255, 0.9)",
    primary: "#b9121b",
    accent: "yellow",
    lineColor: "#383A46",
    background: "#000", // '#242424' // '#232D4C'
  },
};

const light = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: "#b9121b",
    lineColor: "#f9f9f9",
    background: "#ffffff",
    accent: "yellow",
  },
};

export default { dark, light };
