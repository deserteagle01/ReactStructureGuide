/** @format */

import {  PixelRatio } from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AllHtmlEntities } from "html-entities";
import truncate from "lodash/truncate";
import URI from "urijs";
import { Constants, Languages, Images, Config } from "@common";
//import { toast,log } from "@app/Omni";
export default class Tools {

  static trimObjValues(obj) {
    return Object.keys(obj).reduce((acc, curr) => {
      if(curr != 'password' && curr != 'confirm_password'){
        acc[curr] = (obj[curr] && typeof(obj[curr]) == 'string') ? obj[curr].trim() : obj[curr];
      }else{
        acc[curr] = obj[curr];
      }
      return acc;
    }, {});
  }

  static requiredDetailFieldFlow(status) {
    if(status == "action_set_to_booked" || status == "action_set_to_sold"){
        return true
    }
    return false;
  }

  static getParameterByName(name, url) {
    if (!url) url = url;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }

  currency = null;
  static setCurrency(value){
    this.currency = value;
    // alert(value.code);
  }

  static getCurrency(){
    return this.currency;
  }
  /**
   * refresh the tab bar & read later page
   */
  static getImage(data, imageSize) {
    if (typeof data === "undefined" || data == null) {
      return Constants.PlaceHolder;
    }
    if (typeof imageSize === "undefined") {
      imageSize = "medium";
    }

    const getImageSize = (mediaDetail) => {
      let imageURL = "";
      if (typeof mediaDetail.sizes !== "undefined") {
        if (typeof mediaDetail.sizes[imageSize] !== "undefined") {
          imageURL = mediaDetail.sizes[imageSize].source_url;
        }

        if (imageURL == "" && typeof mediaDetail.sizes.medium !== "undefined") {
          imageURL = mediaDetail.sizes.medium.source_url;
        }

        if (imageURL == "" && typeof mediaDetail.sizes.full !== "undefined") {
          imageURL = mediaDetail.sizes.full.source_url;
        }
      }

      if (typeof data.better_featured_image != null) {
        imageURL = data.better_featured_image.source_url;
      }

      return imageURL;
    };

    let imageURL =
      typeof data.better_featured_image !== "undefined" &&
      data.better_featured_image != null
        ? data.better_featured_image.source_url
        : Constants.PlaceHolderURL;

    if (
      typeof data.better_featured_image !== "undefined" &&
      data.better_featured_image !== null
    ) {
      if (typeof data.better_featured_image.media_details !== "undefined") {
        imageURL = getImageSize(data.better_featured_image.media_details);
      }
    }

    if (imageURL == "") {
      return Constants.PlaceHolderURL;
    }

    return imageURL;
  }

  static getProductImage = (uri, containerWidth) => {
    // Enhance number if you want to fetch a better quality image (may affect performance
    const DPI_NUMBER = 0.5; // change this to 1 for high quality image

    if (!Config.ProductSize.enable) {
      return uri;
    }

    if (typeof uri !== "string") {
      return Images.PlaceHolderURL;
    }

    // parse uri into parts
    const index = uri.lastIndexOf(".");
    let editedURI = uri.slice(0, index);
    const defaultType = uri.slice(index);

    const pixelWidth = PixelRatio.getPixelSizeForLayoutSize(containerWidth);

    switch (true) {
      case pixelWidth * DPI_NUMBER < 300:
        editedURI = `${editedURI}-small${defaultType}`;
        break;
      case pixelWidth * DPI_NUMBER < 600:
        editedURI = `${editedURI}-medium${defaultType}`;
        break;
      case pixelWidth * DPI_NUMBER < 1400:
        editedURI = `${editedURI}-large${defaultType}`;
        break;
      default:
        editedURI += defaultType;
    }
    return editedURI;
  };

  /**
   * get image depend on variation and product
   */
  static getImageVariation(product, variation) {
    const defaultImage = Tools.getProductImage(product.images[0].src, 100);

    return variation
      ? variation.image.id === 0
        ? defaultImage
        : Tools.getProductImage(variation.image.src, 100)
      : defaultImage;
  }

  static getDescription(description, limit) {
    if (typeof limit === "undefined") {
      limit = 50;
    }

    if (typeof description === "undefined") {
      return "";
    }

    let desc = description.replace("<p>", "");
    desc = truncate(desc, { length: limit, separator: " " });

    return AllHtmlEntities.decode(desc);
  }

  static getLinkVideo(content) {
    const regExp = /^.*((www.youtube.com\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\??v?=?))([^#&\?\/\ ]*).*/;
    let embedId = "";
    let youtubeUrl = "";

    URI.withinString(content, (url) => {
      const match = url.match(regExp);
      if (match && match[7].length === 11) {
        embedId = match[7];
        youtubeUrl = `www.youtube.com/embed/${embedId}`;
      }
    });
    return youtubeUrl;
  }

  static async getFontSizePostDetail() {
    const data = await AsyncStorage.getItem("@setting_fontSize");
    if (typeof data !== "undefined") {
      return parseInt(data);
    }
    return Constants.fontText.size;
  }

  /**
   * getName user
   * @user
   */
  static getName = (user) => {
    if (user != null) {
      if (
        typeof user.last_name !== "undefined" ||
        typeof user.first_name !== "undefined"
      ) {
        const first = user.first_name != null ? user.first_name : "";
        const last = user.last_name != null ? user.last_name : "";
        return `${first} ${last}`;
      } else if (typeof user.name !== "undefined" && user.name != null) {
        return user.name;
      }
      return Languages.Guest;
    }
    return Languages.Guest;
  };

  /**
   * getAvatar
   * @user
   */
  static getAvatar = (user) => {
    if (user) {
      if (user.avatar_url) {
        return {
          uri: user.avatar_url,
        };
      } else if (user.picture) {
        return {
          uri: user.picture.data.url,
        };
      }
      return Images.defaultAvatar;
    }

    return Images.defaultAvatar;
  };
  
    /**
   * For particular stock if stock has ongoing chat in local,
   *   add stock in ongoing stock list
   */
  static filterOngoingChatList = (mesiboAvailableChatArray, stockList) => {
    filteredList = []
    for (let j=0; j < stockList.length; j++) {      
      stockList[j].mesibo_group_ids.forEach(function(group) {
        // log("%%%%%%%%%%%%%%%%");
        // log(mesiboAvailableChatArray);
        // log("------------------");
        if (mesiboAvailableChatArray.hasOwnProperty(group.mesibo_group_id)) {
          filteredList.push(stockList[j]);
        }
      })
    }
    console.log("Stocklist after filtering Ongoing Chat list: ", filteredList);
    return filteredList;
  }

  

  static get_country_flag_image = (country_code) => {
    const country_flags = {
      BH: require("@images/country-flags/BH.png"),
      IN: require("@images/country-flags/IN.png"),
      KW: require("@images/country-flags/KW.png"),
      OM: require("@images/country-flags/OM.png"),
      QA: require("@images/country-flags/QA.png"),
      SA: require("@images/country-flags/SA.png"),
      AE: require("@images/country-flags/AE.png"),
      AD: require("@images/country-flags/AD.png"),
      AF: require("@images/country-flags/AF.png"),
      AG: require("@images/country-flags/AG.png"),
      AI: require("@images/country-flags/AI.png"),
      AL: require("@images/country-flags/AL.png"),
      AM: require("@images/country-flags/AM.png"),
      AN: require("@images/country-flags/AN.png"),
      AO: require("@images/country-flags/AO.png"),
      AQ: require("@images/country-flags/AQ.png"),
      AR: require("@images/country-flags/AR.png"),
      AS: require("@images/country-flags/AS.png"),
      AT: require("@images/country-flags/AT.png"),
      AU: require("@images/country-flags/AU.png"),
      AW: require("@images/country-flags/AW.png"),
      AX: require("@images/country-flags/AX.png"),
      AZ: require("@images/country-flags/AZ.png"),
      BA: require("@images/country-flags/BA.png"),
      BB: require("@images/country-flags/BB.png"),
      BD: require("@images/country-flags/BD.png"),
      BE: require("@images/country-flags/BE.png"),
      BF: require("@images/country-flags/BF.png"),
      BG: require("@images/country-flags/BG.png"),
      BI: require("@images/country-flags/BI.png"),
      BJ: require("@images/country-flags/BJ.png"),
      BL: require("@images/country-flags/BL.png"),
      BM: require("@images/country-flags/BM.png"),
      BN: require("@images/country-flags/BN.png"),
      BO: require("@images/country-flags/BO.png"),
      BR: require("@images/country-flags/BR.png"),
      BS: require("@images/country-flags/BS.png"),
      BT: require("@images/country-flags/BT.png"),
      BV: require("@images/country-flags/BV.png"),
      BZ: require("@images/country-flags/BZ.png"),
      CA: require("@images/country-flags/CA.png"),
      CC: require("@images/country-flags/CC.png"),
      CD: require("@images/country-flags/CD.png"),
      CF: require("@images/country-flags/CF.png"),
      CG: require("@images/country-flags/CG.png"),
      CH: require("@images/country-flags/CH.png"),
      CI: require("@images/country-flags/CI.png"),
      CK: require("@images/country-flags/CK.png"),
      CL: require("@images/country-flags/CL.png"),
      CM: require("@images/country-flags/CM.png"),
      CN: require("@images/country-flags/CN.png"),
      CO: require("@images/country-flags/CO.png"),
      CR: require("@images/country-flags/CR.png"),
      CU: require("@images/country-flags/CU.png"),
      CV: require("@images/country-flags/CV.png"),
      CW: require("@images/country-flags/CW.png"),
      CX: require("@images/country-flags/CX.png"),
      CY: require("@images/country-flags/CY.png"),
      CZ: require("@images/country-flags/CZ.png"),
      DE: require("@images/country-flags/DE.png"),
      DJ: require("@images/country-flags/DJ.png"),
      DK: require("@images/country-flags/DK.png"),
      DM: require("@images/country-flags/DM.png"),
      DO: require("@images/country-flags/DO.png"),
      DZ: require("@images/country-flags/DZ.png"),
      EC: require("@images/country-flags/EC.png"),
      EE: require("@images/country-flags/EE.png"),
      EG: require("@images/country-flags/EG.png"),
      ER: require("@images/country-flags/ER.png"),
      ES: require("@images/country-flags/ES.png"),
      ET: require("@images/country-flags/ET.png"),
      EU: require("@images/country-flags/EU.png"),
      FI: require("@images/country-flags/FI.png"),
      FJ: require("@images/country-flags/FJ.png"),
      FK: require("@images/country-flags/FK.png"),
      FM: require("@images/country-flags/FM.png"),
      FO: require("@images/country-flags/FO.png"),
      FR: require("@images/country-flags/FR.png"),
      GA: require("@images/country-flags/GA.png"),
      GB: require("@images/country-flags/GB.png"),
      GD: require("@images/country-flags/GD.png"),
      GE: require("@images/country-flags/GE.png"),
      GF: require("@images/country-flags/GF.png"),
      GG: require("@images/country-flags/GG.png"),
      GH: require("@images/country-flags/GH.png"),
      GI: require("@images/country-flags/GI.png"),
      GL: require("@images/country-flags/GL.png"),
      GM: require("@images/country-flags/GM.png"),
      GN: require("@images/country-flags/GN.png"),
      GP: require("@images/country-flags/GP.png"),
      GQ: require("@images/country-flags/GQ.png"),
      GR: require("@images/country-flags/GR.png"),
      GS: require("@images/country-flags/GS.png"),
      GT: require("@images/country-flags/GT.png"),
      GU: require("@images/country-flags/GU.png"),
      GW: require("@images/country-flags/GW.png"),
      GY: require("@images/country-flags/GY.png"),
      HK: require("@images/country-flags/HK.png"),
      HM: require("@images/country-flags/HM.png"),
      HN: require("@images/country-flags/HN.png"),
      HR: require("@images/country-flags/HR.png"),
      HT: require("@images/country-flags/HT.png"),
      HU: require("@images/country-flags/HU.png"),
      ID: require("@images/country-flags/ID.png"),
      IE: require("@images/country-flags/IE.png"),
      IL: require("@images/country-flags/IL.png"),
      IM: require("@images/country-flags/IM.png"),
      IN: require("@images/country-flags/IN.png"),
      IO: require("@images/country-flags/IO.png"),
      IQ: require("@images/country-flags/IQ.png"),
      IR: require("@images/country-flags/IR.png"),
      IS: require("@images/country-flags/IS.png"),
      IT: require("@images/country-flags/IT.png"),
      JE: require("@images/country-flags/JE.png"),
      JM: require("@images/country-flags/JM.png"),
      JO: require("@images/country-flags/JO.png"),
      JP: require("@images/country-flags/JP.png"),
      KE: require("@images/country-flags/KE.png"),
      KG: require("@images/country-flags/KG.png"),
      KH: require("@images/country-flags/KH.png"),
      KI: require("@images/country-flags/KI.png"),
      KM: require("@images/country-flags/KM.png"),
      KN: require("@images/country-flags/KN.png"),
      KP: require("@images/country-flags/KP.png"),
      KR: require("@images/country-flags/KR.png"),
      KW: require("@images/country-flags/KW.png"),
      KY: require("@images/country-flags/KY.png"),
      KZ: require("@images/country-flags/KZ.png"),
      LA: require("@images/country-flags/LA.png"),
      LB: require("@images/country-flags/LB.png"),
      LC: require("@images/country-flags/LC.png"),
      LGBT: require("@images/country-flags/LGBT.png"),
      LI: require("@images/country-flags/LI.png"),
      LK: require("@images/country-flags/LK.png"),
      LR: require("@images/country-flags/LR.png"),
      LS: require("@images/country-flags/LS.png"),
      LT: require("@images/country-flags/LT.png"),
      LU: require("@images/country-flags/LU.png"),
      LV: require("@images/country-flags/LV.png"),
      LY: require("@images/country-flags/LY.png"),
      MA: require("@images/country-flags/MA.png"),
      MC: require("@images/country-flags/MC.png"),
      MD: require("@images/country-flags/MD.png"),
      ME: require("@images/country-flags/ME.png"),
      MF: require("@images/country-flags/MF.png"),
      MG: require("@images/country-flags/MG.png"),
      MH: require("@images/country-flags/MH.png"),
      MK: require("@images/country-flags/MK.png"),
      ML: require("@images/country-flags/ML.png"),
      MM: require("@images/country-flags/MM.png"),
      MN: require("@images/country-flags/MN.png"),
      MO: require("@images/country-flags/MO.png"),
      MP: require("@images/country-flags/MP.png"),
      MQ: require("@images/country-flags/MQ.png"),
      MR: require("@images/country-flags/MR.png"),
      MS: require("@images/country-flags/MS.png"),
      MT: require("@images/country-flags/MT.png"),
      MU: require("@images/country-flags/MU.png"),
      MV: require("@images/country-flags/MV.png"),
      MW: require("@images/country-flags/MW.png"),
      MX: require("@images/country-flags/MX.png"),
      MY: require("@images/country-flags/MY.png"),
      MZ: require("@images/country-flags/MZ.png"),
      NA: require("@images/country-flags/NA.png"),
      NC: require("@images/country-flags/NC.png"),
      NE: require("@images/country-flags/NE.png"),
      NF: require("@images/country-flags/NF.png"),
      NG: require("@images/country-flags/NG.png"),
      NI: require("@images/country-flags/NI.png"),
      NL: require("@images/country-flags/NL.png"),
      NO: require("@images/country-flags/NO.png"),
      NP: require("@images/country-flags/NP.png"),
      NR: require("@images/country-flags/NR.png"),
      NU: require("@images/country-flags/NU.png"),
      NZ: require("@images/country-flags/NZ.png"),
      OM: require("@images/country-flags/OM.png"),
      PA: require("@images/country-flags/PA.png"),
      PE: require("@images/country-flags/PE.png"),
      PF: require("@images/country-flags/PF.png"),
      PG: require("@images/country-flags/PG.png"),
      PH: require("@images/country-flags/PH.png"),
      PK: require("@images/country-flags/PK.png"),
      PL: require("@images/country-flags/PL.png"),
      PM: require("@images/country-flags/PM.png"),
      PN: require("@images/country-flags/PN.png"),
      PR: require("@images/country-flags/PR.png"),
      PS: require("@images/country-flags/PS.png"),
      PT: require("@images/country-flags/PT.png"),
      PW: require("@images/country-flags/PW.png"),
      PY: require("@images/country-flags/PY.png"),
      QA: require("@images/country-flags/QA.png"),
      RE: require("@images/country-flags/RE.png"),
      RO: require("@images/country-flags/RO.png"),
      RS: require("@images/country-flags/RS.png"),
      RU: require("@images/country-flags/RU.png"),
      RW: require("@images/country-flags/RW.png"),
      SA: require("@images/country-flags/SA.png"),
      SB: require("@images/country-flags/SB.png"),
      SC: require("@images/country-flags/SC.png"),
      SD: require("@images/country-flags/SD.png"),
      SE: require("@images/country-flags/SE.png"),
      SG: require("@images/country-flags/SG.png"),
      SH: require("@images/country-flags/SH.png"),
      SI: require("@images/country-flags/SI.png"),
      SJ: require("@images/country-flags/SJ.png"),
      SK: require("@images/country-flags/SK.png"),
      SL: require("@images/country-flags/SL.png"),
      SM: require("@images/country-flags/SM.png"),
      SN: require("@images/country-flags/SN.png"),
      SO: require("@images/country-flags/SO.png"),
      SR: require("@images/country-flags/SR.png"),
      SS: require("@images/country-flags/SS.png"),
      ST: require("@images/country-flags/ST.png"),
      SV: require("@images/country-flags/SV.png"),
      SX: require("@images/country-flags/SX.png"),
      SY: require("@images/country-flags/SY.png"),
      SZ: require("@images/country-flags/SZ.png"),
      TC: require("@images/country-flags/TC.png"),
      TD: require("@images/country-flags/TD.png"),
      TF: require("@images/country-flags/TF.png"),
      TG: require("@images/country-flags/TG.png"),
      TH: require("@images/country-flags/TH.png"),
      TJ: require("@images/country-flags/TJ.png"),
      TK: require("@images/country-flags/TK.png"),
      TL: require("@images/country-flags/TL.png"),
      TM: require("@images/country-flags/TM.png"),
      TN: require("@images/country-flags/TN.png"),
      TO: require("@images/country-flags/TO.png"),
      TR: require("@images/country-flags/TR.png"),
      TT: require("@images/country-flags/TT.png"),
      TV: require("@images/country-flags/TV.png"),
      TW: require("@images/country-flags/TW.png"),
      TZ: require("@images/country-flags/TZ.png"),
      UA: require("@images/country-flags/UA.png"),
      UG: require("@images/country-flags/UG.png"),
      UM: require("@images/country-flags/UM.png"),
      US: require("@images/country-flags/US.png"),
      UY: require("@images/country-flags/UY.png"),
      UZ: require("@images/country-flags/UZ.png"),
      VA: require("@images/country-flags/VA.png"),
      VC: require("@images/country-flags/VC.png"),
      VE: require("@images/country-flags/VE.png"),
      VG: require("@images/country-flags/VG.png"),
      VI: require("@images/country-flags/VI.png"),
      VN: require("@images/country-flags/VN.png"),
      VU: require("@images/country-flags/VU.png"),
      WF: require("@images/country-flags/WF.png"),
      WS: require("@images/country-flags/WS.png"),
      XK: require("@images/country-flags/XK.png"),
      YE: require("@images/country-flags/YE.png"),
      YT: require("@images/country-flags/YT.png"),
      ZA: require("@images/country-flags/ZA.png"),
      ZM: require("@images/country-flags/ZM.png"),
      ZW: require("@images/country-flags/ZW.png"),
    }

    if(country_code == 'US-CA'){
      return require("@images/country-flags/US-CA.png");
    }
    else if(country_code == 'GB-ENG'){
      return require("@images/country-flags/GB-ENG.png");
    }
    else if(country_code == 'GB-NIR'){
      return require("@images/country-flags/GB-NIR.png");
    }
    else if(country_code == 'GB-SCT'){
      return require("@images/country-flags/GB-SCT.png");
    }
    else if(country_code == 'GB-WLS'){
      return require("@images/country-flags/GB-WLS.png");
    }
    else if(country_code == 'GB-ZET'){
      return require("@images/country-flags/GB-ZET.png");
    }
    else{
      return country_flags[country_code];
    }
  };
}
