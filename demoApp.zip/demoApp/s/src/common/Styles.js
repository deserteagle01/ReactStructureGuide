/**
 * Created by InspireUI on 20/12/2016.
 *
 * @format
 */

import { Dimensions, Platform } from "react-native";

import Constants from "./Constants";
import Device from "./Device";
import Color from "./Color";
import Config from "./Config";
import Theme from "./Theme";
const { height, width } = Dimensions.get("window");

let formMarginBottom = 20;
if(Platform.OS == "ios"){
  formMarginBottom = width > 320 ? 15 : 10;
}

let t = require('tcomb-form-native');

const stylesheet = t.form.Form.stylesheet;
stylesheet.formGroup.normal.marginBottom = formMarginBottom;
stylesheet.formGroup.error.marginBottom = formMarginBottom;

stylesheet.textbox.normal.color = Color.inputBoxText;
stylesheet.textbox.normal.borderWidth = 0;
stylesheet.textbox.normal.borderBottomWidth = 1;
stylesheet.textbox.normal.borderBottomColor = '#e6e6e6';
stylesheet.textbox.normal.placeholderTextColor = Color.inputBoxPlaceholder;
stylesheet.textbox.error.color = Color.inputBoxText;
stylesheet.textbox.error.borderWidth = 0;
stylesheet.textbox.error.borderBottomWidth = 1;

stylesheet.pickerContainer.normal.borderColor = '#e6e6e6';
stylesheet.pickerValue.normal.color = '#fff';
stylesheet.pickerValue.error.color = '#fff';
stylesheet.controlLabel.normal.color = 'orange';
stylesheet.select.normal.color = '#fff';
stylesheet.select.normal.borderColor = '#fff';
stylesheet.select.normal.borderWidth = 0;
stylesheet.select.error.borderWidth = 0;
stylesheet.select.error.borderRadius = 0;
stylesheet.select.error.borderColor = '#a94442';
stylesheet.select.error.color = '#fff';
stylesheet.select.error.marginBottom = 0;

const Styles = {
  width: Dimensions.get("window").width,
  height: Platform.OS !== "ios" ? height : height - 20,
  navBarHeight: Platform !== "ios" ? height - width : 0,
  headerHeight: Platform.OS === "ios" ? 40 : 56,
  mainHeaderHeight : Platform.OS === "ios" ? 45 : 56,

  thumbnailRatio: 0.8, // Thumbnail ratio, the product display height = width * thumbnail ratio

  app: {
    flexGrow: 1,
    backgroundColor: Device.isIphoneX ? "#000" : "#000",
    // paddingTop: Device.isIphoneX ? Device.ToolbarHeight : 0,
  },
  FontSize: {
    tiny: 12,
    small: 14,
    medium: 16,
    big: 18,
    large: 20,
  },
  IconSize: {
    TextInput: 25,
    ToolBar: 18,
    Inline: 20,
    SmallRating: 14,
  },
  FontFamily: {},
};

Styles.Common = {
  headerWrapperNav:{
    backgroundColor:Color.white,
    ...Platform.select({
      ios: {
        paddingTop: Device.isIphoneX ? 35 : 15,
      },
      android: {
        paddingTop: 0,
      },
    }),
  },
  headerWrapper:{
    height:Styles.mainHeaderHeight,
    backgroundColor:Color.white,
    flexDirection:'row',
  },

  Column: {},
  ColumnCenter: {
    justifyContent: "center",
    alignItems: "center",
  },
  ColumnCenterTop: {
    alignItems: "center",
  },
  ColumnCenterBottom: {
    justifyContent: "flex-end",
    alignItems: "center",
  },
  ColumnCenterLeft: {
    justifyContent: "center",
    alignItems: "flex-start",
  },
  ColumnCenterRight: {
    justifyContent: "center",
    alignItems: "flex-end",
  },
  Row: {
    flexDirection: "row",

    ...Platform.select({
      ios: {
        top: !Config.showStatusBar
          ? Device.isIphoneX
            ? -20
            : -8
          : Device.isIphoneX
          ? -15
          : 0,
      },
      android: {
        top: 0,
      },
    }),
  },
  RowCenter: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  RowCenterTop: {
    flexDirection: "row",
    justifyContent: "center",
  },
  RowCenterBottom: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "center",
  },
  RowCenterLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  RowCenterRight: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  RowCenterBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  // More traits

  IconSearchView: {
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    marginBottom: 10,
    borderRadius: 50,

    shadowOffset: { width: 0, height: -4 },
    shadowColor: "rgba(0,0,0, .3)",
    elevation: 10,
    shadowOpacity: 0.1,
    zIndex: 9999,
  },
  IconSearch: {
    width: 20,
    height: 20,
    margin: 12,
    zIndex: 9999,
  },

  logo: {
    width: Platform.OS === "ios" ? 180 : 200,
    height: Platform.OS === "ios" ? 30 : 30,
    resizeMode: "contain",
    ...Platform.select({
      ios: {
        marginTop: Device.isIphoneX ? -40 : Config.showStatusBar ? -4 : -15,
      },
      android: {
        marginTop: 2,
        marginLeft: 30,
      },
    }),
  },

  toolbar: (backgroundColor, isDark) => ({
    backgroundColor: isDark ? backgroundColor: '#fff',
    zIndex: 1,
    // paddingLeft: 15,
    // paddingRight: 15,
    borderBottomWidth: isDark ? 0 : 1,
    borderBottomColor: "transparent",

    ...Platform.select({
      ios: {
        height: Config.showStatusBar
        ? Device.isIphoneX
          ? 40
          : 50
        : Device.isIphoneX
        ? 5
        : 25,
        paddingTop: Device.isIphoneX ? 95 : 0,
        paddingBottom :  Device.isIphoneX ? 0 : 10,
      },
      android: {
        height: Styles.headerHeight,
        paddingTop: 0,
        marginTop: 0,
        elevation: 0,
      },
    }),
  }),

  headerStyle: {
    color: Color.category.navigationTitleColor,
    fontSize: 16,
    textAlign: "center",
    alignSelf: "center",
    flex: 1,
    height: 40,
    backgroundColor: "transparent",

    fontFamily: Constants.fontFamily,
    ...Platform.select({
      ios: {
        marginBottom: !Config.showStatusBar ? 14 : 0,
        marginTop: Device.isIphoneX ? -10 : 12,
      },
      android: {
        marginBottom: 4,
        elevation: 0,
      },
    }),
  },
  headerTitleWrapper:{
    flex:1,
    height: 40,
    justifyContent:'center',
    alignItems: "center",
    alignSelf: "center",
    ...Platform.select({
      ios: {
        marginBottom: Device.isIphoneX ? 14 : 0,
        marginTop: Device.isIphoneX ? -25 : 10,
      },
      android: {
        marginTop: 0,
      },
    }),
  },
  headerTitleStyle: {
    color: Config.Theme.isDark
      ? Theme.dark.colors.text
      : Theme.dark.colors.text,
    // fontSize: 18,
    ...Platform.select({
      ios: {
        fontSize:width > 320 ? 18 : 16,
      },
      android: {
        fontSize:width > 360 ? 18 : 16,
      },
    }),
    fontWeight:'500',
    // height: 30,
    textAlign: "center",
    alignSelf:'center',
  },
  boldHeaderTitle: {
    fontSize: 18,
    color: "#000000",
    fontFamily: Constants.fontHeader,
    height: 40,
    textAlign: "center",
    alignSelf: "center",
    ...Platform.select({
      ios: {
        marginBottom: !Config.showStatusBar ? 14 : 0,
        marginTop: Device.isIphoneX ? -10 : 12,
      },
      android: {
        marginTop: 10,
      },
    }),
  },
  headerStyleWishList: {
    color: Color.category.navigationTitleColor,
    fontSize: 16,
    textAlign: "center",
    alignSelf: "center",
    fontFamily: Constants.fontFamily,
    marginBottom: !Config.showStatusBar
      ? Device.isIphoneX
        ? 40
        : 15
      : Device.isIphoneX
      ? 25
      : 5,
  },
  toolbarIcon: {
    resizeMode: "contain",

    // marginRight: 18,
    marginLeft: 15,
    opacity: 0.8,
    ...Platform.select({
      ios: {
        top: Device.isIphoneX
        ? -25
        : 5,
        width: width > 320 ? 20 : 18,
        height: width > 320 ? 20 : 18,
      },
      android: {
        top: 1,
        width: width > 360 ? 20 : 18,
        height: width > 360 ? 20 : 18,
      },
    }),
  },
  toolbarLeftIconTextWarpper:{
    height:40,
    flexDirection:'row',
    // backgroundColor:'pink',
    alignItems: "center",
    justifyContent:'center',
    ...Platform.select({
      ios: {
        top: Device.isIphoneX
        ? 0
        : 0 ,
      },
      android: {
        top: 0,
      },
    }),
  },
  toolbarLeftIconText:{
    color:Color.primary,
    resizeMode: "contain",

    // marginRight: 18,
    marginLeft: 4,
    opacity: 0.8,
    ...Platform.select({
      ios: {
        top: Device.isIphoneX
        ? -22
        : 5,
        fontSize:width > 320 ? 18 : 16,
      },
      android: {
        top: 0,
        fontSize:width > 360 ? 18 : 16,
      },
    }),
  },
  toolbarRightText:{
    ...Platform.select({
      ios: {
        fontSize:width > 320 ? 18 : 16,
      },
      android: {
        fontSize:width > 360 ? 18 : 16,
      },
    }),
    color:Color.primary,
    marginRight: 22,
  },
  toolbarRightTextWarpper: {
    height:40,
    // backgroundColor:'pink',
    alignItems: "center",
    justifyContent:'center',
    ...Platform.select({
      ios: {
        top: Device.isIphoneX
        ? -20
        : 5,
      },
      android: {
        top: 0,
      },
    }),
  },
  toolbarRightIconWarpper: {
    padding:10,
    // backgroundColor:'red',
    marginRight: 8,
    marginLeft: 8,
    opacity: 0.8,
    ...Platform.select({
      ios: {
        top: Device.isIphoneX
        ? -20
        : 5,
      },
      android: {
        top: 0,
      },
    }),
  },
  toolbarRightIcon: {
    resizeMode: "contain",
    // backgroundColor:'pink',
    opacity: 0.8,
    ...Platform.select({
      ios: {
        width: width > 320 ? 20 : 18,
        height: width > 320 ? 20 : 18,
      },
      android: {
        width: width > 360 ? 20 : 18,
        height: width > 360 ? 20 : 18,
      },
    }),
  },

  toolbarFloat: {
    position: "absolute",
    top: 0,
    borderBottomWidth: 0,
    zIndex: 999,
    width,

    ...Platform.select({
      ios: {
        backgroundColor: "transparent",
        marginTop: Config.showStatusBar
          ? Device.isIphoneX
            ? -20
            : -3
          : Device.isIphoneX
          ? -15
          : -3,
      },
      android: {
        backgroundColor: "transparent",
        height: 46,
        paddingTop: Config.showStatusBar ? 24 : 0,
      },
    }),
  },
  viewCover: {
    backgroundColor: "#FFF",
    zIndex: 99999,
    bottom: 0,
    left: 0,
    width,
    height: 20,
    // position: "absolute",
  },
  viewCoverWithoutTabbar: {
    backgroundColor: "#FFF",
    zIndex: 99999,
    bottom: 0,
    left: 0,
    width,
    height: 35,
    position: "absolute",
  },

  viewBack: {
    ...Platform.select({
      ios: {
        marginTop: Device.isIphoneX ? -30 : -5,
      },
    }),
  },
  toolbarIconBack: {
    width: 16,
    height: 16,
    resizeMode: "contain",

    marginRight: 18,
    marginBottom: 12,
    marginLeft: 18,
    opacity: 0.8,
    ...Platform.select({
      ios: {
        top: !Config.showStatusBar ? 4 : Device.isIphoneX ? 4 : 8,
      },
      android: {
        top: 0,
      },
    }),
  },

  loginTextStyle: {
    color: Config.Theme.isDark
    ? Theme.dark.colors.text
    : Theme.dark.colors.text,
  fontSize: 16,
  height: 40,
  textAlign: "center",
  fontFamily: Constants.fontFamily,
  alignSelf: "center",
  marginRight:10,
  ...Platform.select({
    ios: {
      marginBottom: !Config.showStatusBar ? 14 : 0,
      marginTop: Device.isIphoneX ? -10 : 12,
    },
    android: {
      marginTop: 10,
    },
  }),
  },
  headerSearchBar:{
    width: width-110,
    height: 40,
    backgroundColor:Color.searchBarBackground,
    // bottom:16,
    alignItems:'center',
    flexDirection:'row',
    ...Platform.select({
      ios: {
        marginBottom: Device.isIphoneX ? 14 : 0,
        marginTop: Device.isIphoneX ? -25 : 10,
      },
      android: {
        marginTop: 0,
      },
    }),
  },
  headerSearchIcon: {
    width: 16,
    height: 16,
    resizeMode: "contain",
    marginLeft: 10,
    opacity: 0.8
  },
  headerText:{
    color: '#000',
    fontSize: 16,
    height: 40,
    textAlign: "center",
    fontFamily: Constants.fontFamily,
    alignSelf: "center",
    ...Platform.select({
      ios: {
        marginBottom: !Config.showStatusBar ? 14 : 0,
        marginTop: Device.isIphoneX ? -10 : 12,
      },
      android: {
        marginTop: 10,
      },
    }),
  },
  headerSearchText:{
    color:'rgb(149,149,149)',
    marginLeft:8
  },
}

export default Styles;
