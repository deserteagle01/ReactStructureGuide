/** @format */

import React from "react";
import PropTypes from "prop-types";
import { Image } from "react-native";
import { Images } from "@common";
import {CachedImage} from "react-native-img-cache";

const ImageCache = ({ style, defaultSource, uri }) => {
  return <CachedImage style={style} defaultSource={Images.WaterMarkIcon} source={{ uri }} />;
};

ImageCache.propTypes = {
  style: PropTypes.any,
  uri: PropTypes.any,
};

export default ImageCache;
