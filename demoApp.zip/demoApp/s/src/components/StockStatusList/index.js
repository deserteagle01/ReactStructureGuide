import React, { useState, useEffect } from 'react';
import {Text, TouchableOpacity, View, TextInput, Keyboard, SafeAreaView, Image, FlatList} from 'react-native';
import {Color, Languages, Images} from '@common';
import Modal from 'react-native-modal';
import styles from './styles';
import {log, toast} from '@app/Omni';

function InfoPopup(props) {
    const [isPopupVisible, setpopup] = useState(false);
    const [item, setItem] = useState({});

    useEffect(() => {
        setpopup(props.isPopupVisible);
        setItem(props.item)
    }, [props]);

    function cancel(){
        props.cancelInfoPopup(false);
    }

    return(
        <Modal
            hasBackdrop={true}
            isVisible={isPopupVisible}
            hideModalContentWhileAnimating={true}
            useNativeDriver={true}
            style={{margin: 0}}
            onBackButtonPress={cancel}
            onBackdropPress={cancel}>
            <View style={styles.flexContainer}>
                <View style={styles.row}>
                    <Text style={styles.pretxt}>{"Booked by: "}</Text>
                    <Text style={styles.endtxt}>{item.stock_booked_company_id && item.stock_booked_company_id[1]}</Text>
                </View>
                <View style={styles.row}>
                    <Text style={styles.pretxt}>{"Booked till: "}</Text>
                    <Text style={styles.endtxt}>{item.booked_till}</Text>
                </View>
                <View style={styles.row}>
                    <Text style={styles.pretxt}>{"Booked price: "}</Text>
                    <Text style={styles.endtxt}>{item.price+" "+item.currency_symbol}</Text>
                </View>
            </View>
        </Modal>
    );
}

export default function StockStatusList(props) {
    const [StockList, setStockList] = useState([]);
    const [isinfoPopupVisible, setInfopopup] = useState(false);
    const [selectedItem, setItem] = useState({});
    
    useEffect(() => {
        setStockList(props.stockList);
        props.updatedList(props.stockList);
    }, [props.stockList]);
    
    function rowSelected(selectItem, index){
        let tempContactList = [...StockList];
        tempContactList[index] = { ...tempContactList[index], isSelected: !selectItem.isSelected };
        setStockList(tempContactList);
        props.updatedList(tempContactList);
    }

    _renderItem = ({ item ,index}) => {
        return(
            <TouchableOpacity onPress={()=>  !props.isReadOnly && rowSelected(item, index)} disabled={props.isReadOnly}>
                <View style={[styles.accordianContentContainer, item.isSelected ? {backgroundColor: Color.primary}:{}]}>
                    <View style={styles.accordianContent}>
                    <View style={styles.subContainer}>
                            <Text style={styles.accordianContentText}>{item.pack_no}</Text>
                        </View>
                        <View style={styles.subContainer}>
                            <Text style={[styles.accordianContentText,{textAlign:'right', width:'100%'}]}>{item.invoice_width + "  x"}</Text>
                        </View>
                        <View style={styles.subContainer}>
                        <Text style={[styles.accordianContentText,{textAlign:'left', width:'100%'}]}>{"  "+item.invoice_length + " " + Languages.mm}</Text>
                        </View>
                        <View style={styles.subContainer}>
                            <Text style={styles.accordianContentText}>{item.total_quantity + " " + Languages.pcs}</Text>
                        </View>
                        <View style={styles.subContainer}>
                            <Text style={styles.accordianContentText}>{item.total_quantity_sqm + " " + Languages.SQM}</Text>
                        </View>
                        {props.selectedIndex == 3 &&
                            <TouchableOpacity style={{alignSelf: 'center',marginRight:5}} onPress={() => {
                                setItem(item);
                                setInfopopup(true);
                            }}>
                                <Image source={Images.icons.infoIcon} style={{tintColor: "white",height: 16, width:16}}/>
                            </TouchableOpacity>
                        }
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    function renderFixedHeader(){
        return(
        <View style={styles.topSubHeaderContainer}>
            <View style={styles.subContainer}>
                <Text style={styles.headerText}>{Languages.packno}</Text>
            </View>
            <View style={styles.headerDivider}/>
            <View style={styles.subContainer}>
                <Text style={styles.headerText}>{Languages.height}</Text>
            </View>
            <View style={styles.headerDivider}/>
            <View style={styles.subContainer}>
                <Text style={styles.headerText}>{Languages.length}</Text>
            </View>
            <View style={styles.headerDivider}/>
            <View style={styles.subContainer}>
                <Text style={styles.headerText}>{Languages.pieces}</Text>
            </View>
            <View style={styles.headerDivider}/>
            <View style={styles.subContainer}>
                <Text style={styles.headerText}>{Languages.quantity}</Text>
            </View>
        </View>
        );
    }
    
    return (
        <View style={styles.container}>
            {renderFixedHeader()}
            <View style={{flex:1}}>
                <FlatList
                    style={styles.stocklist}
                    showsVerticalScrollIndicator={false}
                    data={StockList}
                    renderItem={(item, index) => this._renderItem(item, index)}
                    keyExtractor={(item, index) => index.toString()}
                    extraData={StockList}
                    onRefresh={() => props.onRefresh()}
                    refreshing={props.isFetching} /> 
                    <InfoPopup 
                        isPopupVisible={isinfoPopupVisible}
                        item={selectedItem}
                        cancelInfoPopup={(flag) => setInfopopup(flag)} />
                    {StockList.length <= 0 && 
                        <View style={{position: "absolute",height:"100%", width:"100%",alignItems:'center', justifyContent:'center'}}>
                            <Text style={styles.txtempty}>{"No results found!"}</Text>
                        </View>
                    }
            </View>
        </View>
    );
}