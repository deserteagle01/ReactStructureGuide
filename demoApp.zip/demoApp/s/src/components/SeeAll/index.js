/** @format */

import React, { PureComponent } from "react";
import {
  Text,
  View,
  TouchableOpacity,
} from "react-native";
import { Color, Languages, withTheme } from "@common";

class SeeAll extends PureComponent {
  constructor(props) {
    super(props);
  }

  render(){
      return (
        <View style={{flex:1, alignItems:"center", alignContent:"center"}}>
        <TouchableOpacity style={{alignSelf:"center", padding:10,  justifyContent:"center", alignItems:"center"}} onPress={()=>{this.props.showAllProducts()}}>
          <Text style={{fontSize:16, color:Color.primary}}>{Languages.seeAll}</Text>
        </TouchableOpacity>
      </View>
      );
  }
}

export default withTheme(SeeAll);