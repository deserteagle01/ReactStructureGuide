/** @format */

import { StyleSheet, Platform } from "react-native";
import { Color } from "@common";

export default StyleSheet.create({
  safeViewContainer:{
    flex:1,
    backgroundColor: Color.homeHeader
  },
  container: {
    flex: 1,
    backgroundColor: Color.black,
  },
});
