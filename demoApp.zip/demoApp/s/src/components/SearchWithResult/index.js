import React, { PureComponent } from "react";
import { View, SafeAreaView } from "react-native";
import { connect } from "react-redux";
import { withTheme } from "@common";
import { StoneList, SearchTagsList } from "@components";
import styles from "./styles";
import { log } from "@app/Omni";

class SearchWithResult extends PureComponent {

  constructor(props){
    super(props);
    this.state = {
      searchText : "",
      filtersObj : {},
      showSearchResult: false,
    }
  }

  componentWillReceiveProps(nextProps) {
    // log(' ============= nextProps componentWillReceiveProps SearchWithResult=========')
    // log(nextProps)
    if(this.props != nextProps){
      let filterObj = nextProps.filterData || {};
      this.setState({filtersObj : filterObj});

      for (var key of Object.keys(filterObj)) {
        if(filterObj[key].length > 0){
          this.setState({showSearchResult:true})
          break;
        }else{
         this.setState({showSearchResult:false})
       }
      }
    }
  }

  onSubmitSearchData(text){
    text = text.trim();
    this.setState({searchText : text});
    if(text.length > 0){
      this.setState({showSearchResult:true})
    }else{
      this.setState({showSearchResult:false})
    }
  }

  render() {
    const { navigation } = this.props;
    return (
      <SafeAreaView style={styles.safeViewContainer}>
        <View style={styles.container}>
          {/* header part */}
          <SearchTagsList
            onSubmitSearchData={(text) => this.onSubmitSearchData(text)}
            navigation={navigation} />

            {/* content part */}
            {(!this.props.children || this.state.showSearchResult) ?
              <StoneList company_id={""} searchText={this.state.searchText} filtersObj={this.state.filtersObj} navigation={navigation}/>
              :
              this.props.children
            }
        </View>
       </SafeAreaView>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    filterData: state.filterTagList.selectedFilter,
  };
};

export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    null
  )(SearchWithResult)
);
