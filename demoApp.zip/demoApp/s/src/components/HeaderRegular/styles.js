import { StyleSheet, Platform } from "react-native";
import { Color, Styles } from "@common";

export default StyleSheet.create({
  leftIconHeaderContainer:{
    // backgroundColor:'orange',
    flex:0.1,
    justifyContent:'center',
    alignItems:'center',
    paddingRight:16,
  },
  leftIconHeaderContainerTouchable:{
    // backgroundColor:'orange',
    flex:1,
    justifyContent:'center',
    paddingRight:10,
  },
  toolbarIcon:{
    resizeMode: "contain",
    marginLeft: 18,
    opacity: 0.8,
    ...Platform.select({
      ios: {
        width: Styles.width > 320 ? 22 : 20,
        height: Styles.width > 320 ? 22 : 20,
      },
      android: {
        width: Styles.width > 360 ? 22 : 20,
        height: Styles.width > 360 ? 22 : 20,
      },
    }),
  },
  centerHeaderContainer:{
    // backgroundColor:'blue',
    flex:0.9,
    justifyContent:'center',
    alignItems:'center',
  },
  logoIcon:{
    height:40,
    ...Platform.select({
      ios: {
        width: Styles.width > 320 ? 220 : 160,
      },
      android: {
        width: Styles.width > 360 ? 220 : 190,
      },
    }),
    marginBottom:8,
  },
  rightIconHeaderContainer:{
    // backgroundColor:'red',
    flex:0.1,
    justifyContent:'center',
    alignItems:'center',
    opacity: 0.8,
  },
  headerTitleStyle:{
    color: Color.black,
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 18 : 15,
      },
      android: {
        fontSize: Styles.width > 360 ? 18 : 16,
      },
    }),
    fontWeight:'500',
    textAlign: "center",
    alignSelf:'center',
  },
  toolbarRightIcon:{
    resizeMode: "contain",
    marginRight: 18,
    opacity: 0.8,
    ...Platform.select({
      ios: {
        width: Styles.width > 320 ? 20 : 18,
        height: Styles.width > 320 ? 20 : 18,
      },
      android: {
        width: Styles.width > 360 ? 20 : 18,
        height: Styles.width > 360 ? 20 : 18,
      },
    }),
  }
});
