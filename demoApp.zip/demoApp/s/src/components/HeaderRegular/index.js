import React, { PureComponent } from "react";
import { View, TouchableOpacity, I18nManager, Image, Text, StatusBar, Platform } from "react-native";
import styles from "./styles";
import {
  Styles,
  Images,Color,Config
} from "@common";

export default class HeaderRegular extends PureComponent {
  render() {
    const {title , navigation , moreOptionIcon, onMoreOptionPress, onBack, isDark, showLogo, disableBackBtn} = this.props;
    let onBackClick = () => { navigation.pop(); };
    if(onBack){
      onBackClick = onBack;
    }
    return (
      <View style={[Styles.Common.headerWrapper,{backgroundColor: isDark ? Color.black : Color.white}]}>
        {Platform.OS == 'ios' &&
          <StatusBar translucent barStyle="dark-content" />
        }
          {/* left icon */}
          <View style={styles.leftIconHeaderContainer}>
            {!disableBackBtn &&
              <TouchableOpacity style={styles.leftIconHeaderContainerTouchable}
                onPress={onBackClick}>
                <Image source={Images.icons.back}
                  style={[
                    styles.toolbarIcon,
                    I18nManager.isRTL && {
                      transform: [{ rotate: "180deg" }],
                    },
                    {tintColor: isDark ? Color.white : Color.black}
                  ]}/>
              </TouchableOpacity>
            }
          </View>

          {/* center icon */}
          <View style={styles.centerHeaderContainer}>
            {showLogo ?
              <Image source={Config.LogoWithText} style={styles.logoIcon} resizeMode="stretch"/>
            :
              <Text style={[styles.headerTitleStyle,{color: isDark ? Color.white : Color.black}]}>
                {title}
              </Text>
            }
          </View>

          {/* right icon */}
          <View style={styles.rightIconHeaderContainer}>
            {moreOptionIcon &&
              <TouchableOpacity onPress={onMoreOptionPress} >
                <Image
                  source={moreOptionIcon}
                  style={[styles.toolbarRightIcon,{color: isDark ? Color.white : Color.black}]}
                />
              </TouchableOpacity>
            }
          </View>
      </View>
    );
  }
}
