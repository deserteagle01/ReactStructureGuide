/** @format */

import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Styles } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  listContainer:{
    marginTop:20,
    marginBottom:10,
    marginHorizontal : 16,
  },
  listTitleContainer:{
    flexDirection:'row',
    marginTop:20,
    marginBottom:5,
  },
  listLeftTextContainer:{
    flex:0.7,
    flexDirection:"row",
    alignItems:"center",
    // marginHorizontal : 6,
  },
  listLeftTextContainerShimmer:{
    flex:0.7,
    flexDirection:"row",
    alignItems:"center",
    height:25,
    // marginHorizontal : 6,
  },
  listIcon:{
    width:22,
    height:22,
    tintColor:Color.primary,
    marginRight:8,
    ...Platform.select({
      ios: {
        width:width > 320 ? 22 : 18,
        height:width > 320 ? 22 : 18,
      },
      android: {
        width:width > 320 ? 22: 18,
        height:width > 320 ? 22: 18,
      },
    }),
  },
  listLeftText:{
    color:Color.white,
    fontWeight:'600',
    ...Platform.select({
      ios: {
        fontSize: width > 320 ? 17 : 15,
      },
      android: {
        fontSize: width > 360 ? 17 : 15,
      },
    }),
  },
  listRightTextContainer:{
    flex:0.3,
    flexDirection:"row",
    alignItems:"center",
    justifyContent:'flex-end',
    marginHorizontal : 6,
  },
  listRightTextContainerShimmer:{
    flex:0.3,
    flexDirection:"row",
    alignItems:"center",
    justifyContent:'flex-end',
    marginHorizontal : 6,
  },
  listRightText:{
    color:Color.white,
    fontWeight:'600',
    marginLeft:8,
    ...Platform.select({
      ios: {
        fontSize: width > 320 ? 17 : 15,
      },
      android: {
        fontSize: width > 360 ? 17 : 15,
      },
    }),
  },
  listItemContainer:{
    marginHorizontal:1.2
  },
  loadingSpinner: {
    flex: 1,
    marginTop: 130,
  },
  blankListMsgTextContainerShimmer:{
    height:30,
    marginLeft:6,
    marginVertical:6
  },
  blankListMsgTextContainer:{
    paddingVertical:6,
  },
  blankListMsgText:{
    color:Color.white,
    // marginLeft:6,
    ...Platform.select({
      ios: {
        fontSize: width > 320 ? 15 : 15,
      },
      android: {
        fontSize: width > 360 ? 15 : 15,
      },
    }),
  },
});
