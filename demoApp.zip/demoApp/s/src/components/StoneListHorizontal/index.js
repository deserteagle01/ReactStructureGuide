import React, { PureComponent } from "react";
import { View, FlatList, TouchableOpacity, Image, Text, ActivityIndicator } from "react-native";
import { withTheme, Languages, Images } from "@common";
import { Shimmer, ProductRowHorizontal } from "@components";
import styles from "./styles";
import { connect } from "react-redux";
import { toast,log } from "@app/Omni";

class StoneListHorizontal extends PureComponent {
  constructor(props){
    super(props);
    this.state = {
      showList : this.props.isToggleList ? false : true,
    };
  }

  onShowList = () => {
    if(this.props.isToggleList){
      this.setState({showList : !this.state.showList})
    }
    if(this.props.from == "home"){
      this.props.navigation.push("ShowAllBrowseScreen", {"title": this.props.title, "tags" : this.props.tags, "index" : 0});
    }
  }
  onShowAll = () => {
    if(this.props.company_id && this.props.company_id != ""){
      this.props.navigation.push("ShowAllListScreen", {"title": this.props.title, "company_id" : this.props.company_id});
    }else if(this.props.tags && this.props.tags != ""){
      this.props.navigation.push("ShowAllBrowseScreen", {"title": this.props.title, "tags" : this.props.tags});
    }
  }

  renderRow = ({item, index}) => {
    return (
      <ProductRowHorizontal
        product={item}
        navigation={this.props.navigation}
        onPress={() => this.onRowClickHandle(item, index)}
        tags={this.props.tags}
      />
    );
  }
  onRowClickHandle = (product, index) => {
    if((["recently_submitted", "owner_stock", "owner_not_live_stock"].indexOf(this.props.tags) !== -1) && product && product.stone_ids && product.stone_ids.length > 1){
      this.props.navigation.push("StoneGroupListScreen", {"product" : product});
    }else{
      this.props.navigation.push("DetailScreen", {"product" : product});
    }
  }

  onEndReached = () => {
    const { tags, fetchBrowseShowAll, stillFetch, pageNumber } = this.props;
    log("On End Reached called for tag -  " + tags + "  page number - " +  pageNumber);
    if (stillFetch && tags && tags != "") {
        fetchBrowseShowAll(pageNumber + 1, tags);
    }
  }

  renderFooter = () => {
    //it will show indicator at the bottom of the list when data is loading otherwise it returns null
    const { stillFetch } = this.props;
    if ( stillFetch ) {
      return (
        <View style={styles.loadingSpinner}>
          <ActivityIndicator size='large' />
        </View>
      );
    } else {
      return null;
    }
  };

  render() {
    const { isFetching, stockList, showImage, title, hideListTitle, isToggleList,
      listContainer, listTitleContainer, listLeftTextContainer, listLeftText, listIcon,
      listRightTextContainer, listRightText, isShowAll } = this.props;

    return (
      <View style={[styles.listContainer,listContainer]}>
          {isFetching ?
            <View style={[styles.listTitleContainer,listTitleContainer]}>
                <Shimmer style={styles.listLeftTextContainerShimmer} visible={!isFetching} />
                {isShowAll &&
                  <Shimmer style={styles.listRightTextContainerShimmer} visible={!isFetching} />
                }
            </View>
            :
            <View style={[styles.listTitleContainer,listTitleContainer]}>
                <TouchableOpacity style={[styles.listLeftTextContainer,listLeftTextContainer,{flex:isShowAll ? 0.7 : 1}]} onPress={this.onShowList} disable={!isToggleList}>
                        {showImage &&
                          <Image source={Images.icons.list} style={[styles.listIcon,listIcon]}/>
                        }
                        <Text style={[styles.listLeftText,listLeftText]}>{!isToggleList ? title : (this.state.showList ? title : hideListTitle)}</Text>

                </TouchableOpacity>
                {isShowAll &&
                  <TouchableOpacity style={[styles.listRightTextContainer, listRightTextContainer]} onPress={this.onShowAll}>

                          <Text style={[styles.listRightText,listRightText]}>{Languages.ShowAll}</Text>
                  </TouchableOpacity>
                }
            </View>
          }
          {this.state.showList &&
            <View style={styles.listItemContainer}>
              <FlatList
                horizontal={true}
                keyExtractor={(item, index) => `${index.toString()}`}
                data={stockList}
                renderItem={this.renderRow}
                onEndReached={this.onEndReached}
                onEndReachedThreshold={0.5}
                ListFooterComponent={this.renderFooter.bind(this)}
              />
            </View>
          }
          {stockList && stockList.length == 0 &&
            <Shimmer style={styles.blankListMsgTextContainerShimmer} visible={!isFetching}>
              <View style={styles.blankListMsgTextContainer}>
                <Text style={styles.blankListMsgText}>{Languages.blankListMsgHomeScreen}</Text>
              </View>
            </Shimmer>
          }
      </View>
    );
  }
}

const mapStateToProps = (state, ownprops) => {
  let stillFetch = undefined;
  for( let i=0; i<state.browse.list.length; i++ ){
    if(state.browse.list[i].tag == ownprops.tags){
      stillFetch = state.browse.list[i].stillFetch;
      pageNumber = state.browse.list[i].pageNumber;
    }; 
  };
  return {
    isFetching:state.stockOwner.isFetching || state.browse.isFetching,
    isConnected: state.netInfo.isConnected,
    stillFetch: stillFetch,
    pageNumber: pageNumber,
  };
};
function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  const { actions } = require("@redux/BrowseRedux");
  const { isConnected } = stateProps;
  return {
    ...ownProps,
    ...stateProps,
    fetchBrowseShowAll: (pageNumber, tags) => {
      if(isConnected){
        actions.fetchBrowseShowAll(dispatch, pageNumber, tags, 'home')
      }else{
        toast(Languages.InternetError)
      }
    },
  };
}
export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    mergeProps
  )(StoneListHorizontal)
);
