import React, { PureComponent } from "react";
import PropTypes from "prop-types";
import { View, TouchableOpacity, Text, Image, ImageBackground,InteractionManager } from "react-native";

import { withTheme, Languages, Images } from "@common";
import { getProductImage, log, toast } from "@app/Omni";
import { ImageCache, Shimmer, SaveHideStoneModal } from "@components";
import styles from "./styles";
import { connect } from "react-redux";
import { firebase } from '@react-native-firebase/analytics';

class ProductRowHorizontal extends PureComponent {
  constructor(props){
    super(props);
  }

  onSaveClick = (item) => {
    this._saveHideStoneModal.saveClick(item, this.props.tags != undefined ? "homeList" : "ownerList");
  }
  onHideClick = (item) => {
    this._saveHideStoneModal.open(item, this.props.tags != undefined ? "homeList" : "ownerList");
  }

  render() {
    const { product, onPress, isFetching, tags } = this.props;
    const image_width = 250;
    if(tags == "my_watchlist"){
      product.is_add_to_watchlist = true;
    }
    let materialDetail = product.material_detail, qualityDetail = product.quality_detail, totalLiveBundle = product.total_stocks_bundle, stock_id = product.stone_detail_id, stock_number = product.stock_number,
      quantitySqm = product.quantity_stocks_sqm, sizeDetail = product.size_detail, finishingDetail = product.finishing_detail, showOverlayBtn = true, block_no = product.block_no;

    if((["recently_submitted", "owner_stock"].indexOf(tags) !== -1) && product && product.stone_ids && product.stone_ids.length > 1){
        materialDetail = product.material_string;
        qualityDetail = product.quality_string;
        totalLiveBundle = product.total_live_number_of_bundle;
        quantitySqm = product.total_quantity_sqm;
        sizeDetail = product.size_string.includes(',') ? null : product.size_string;
        finishingDetail = product.finishing_string.includes(',') ? null : product.finishing_string;
        showOverlayBtn = false;
    }
    return (
      <View>
        <TouchableOpacity
          activeOpacity={0.9}
          onPress={onPress}
          style={styles.container_product}>
          <Shimmer style={styles.image} visible={!isFetching}>
            <ImageCache
              uri={product.images.length > 0 ? getProductImage(product.images[0].src, image_width) : ""}
              style={styles.image}
            />
            {/*overlay icon*/}
            {showOverlayBtn &&
              <View style={styles.overlayBtnContainer}>
                <ImageBackground source={Images.icons.icon_overlay} style={{ width: '100%', height: '100%', backgroundColor:"transparent"}} resizeMode={'stretch'}>
                {tags != "owner_stock" && tags != "owner_not_live_stock" && tags != "owner_draft_stock" && tags != "owner_booked_stock" &&
                  <View style={styles.overlayBtnInnerTopContainer}>
                      <TouchableOpacity style={styles.saveIconWrapper} onPress={() => this.onSaveClick(product)}>
                        <Image source={product.is_add_to_watchlist ? Images.icons.heartFilled : Images.icons.heart} style={styles.overlayIcon} resizeMode={'contain'} />
                      </TouchableOpacity>
                  </View>
                }
                {tags != "my_watchlist" && tags != "owner_stock" && tags != "owner_not_live_stock" && tags != "owner_draft_stock" && tags != "owner_booked_stock" &&
                  <View style={styles.overlayBtnInnerBottomContainer}>
                      <TouchableOpacity style={styles.hideIconWrapper} onPress={() => this.onHideClick(product)}>
                        <Image source={product.is_hidden ? Images.icons.eye : Images.icons.hide} style={styles.overlayIcon} resizeMode={'contain'} />
                      </TouchableOpacity>
                  </View>
                }
                </ImageBackground>
              </View>
            }
          </Shimmer>
          <View style={styles.textContainer}>
            <View style={styles.mainTextWarpper}>
              <Shimmer style={styles.listViewNameTextShimmer} visible={!isFetching} >
                <View style={styles.viewFirstRow}>
                <Text
                  style={styles.listViewPrimaryText}
                  numberOfLines={1}>
                  {product.display_name}</Text>
                <Text style={styles.dividerText}>{'  /  '}</Text>
                <Text style={styles.listViewSecondaryText2}>{materialDetail}</Text>
                </View>
              </Shimmer>
            </View>

            {(finishingDetail || sizeDetail) ?
              <Shimmer style={styles.listViewSecondaryShimmerText} visible={!isFetching} >
                <Text
                style={styles.listViewSecondaryText}
                numberOfLines={1}>
                  {finishingDetail}
                  {(finishingDetail && sizeDetail) &&
                    <Text style={styles.dividerText}>{'  /  '}</Text>
                  }
                  {sizeDetail}
                </Text>
              </Shimmer>
              : null
            }

                <Shimmer style={styles.listViewSecondaryShimmerText} visible={!isFetching} >
                  <Text
                    style={styles.listViewSecondaryText}
                    numberOfLines={1}>
                    {totalLiveBundle + ' ' + Languages.BUNDLES}
                    <Text style={styles.dividerText}>{'  /  '}</Text>
                    {quantitySqm + ' ' + Languages.SQM}
                  </Text>
                </Shimmer>

            <View style={styles.subTextContainer}>
              <View style={styles.subtext_wrapper}>
                <Shimmer style={styles.listViewSecondaryText} visible={!isFetching} >
                  {showOverlayBtn ?
                    <Text
                    style={styles.listViewSecondaryText}
                    numberOfLines={1}>
                      {Languages.txtBlockNumber+":"} {block_no}
                      <Text style={styles.dividerText}>{'  /  '}</Text>
                      {Languages.StockId+":"} {stock_number}
                    </Text> :
                    <Text
                    style={styles.listViewSecondaryText}
                    numberOfLines={1}>
                      {Languages.multipleBlocks}
                    </Text>
                  }
                </Shimmer>
              </View>
            </View>
            
          </View>
        </TouchableOpacity>
        <SaveHideStoneModal onRef={(com) => (this._saveHideStoneModal = com)} tags={tags} navigation={this.props.navigation} />
      </View>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    isFetching:state.stockOwner.isFetching || state.browse.isFetching,
  };
};
export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    undefined
  )(ProductRowHorizontal)
);
