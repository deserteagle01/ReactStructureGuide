/** @format */

import { StyleSheet, Platform } from "react-native";
import { Styles, Color } from "@common";

export default StyleSheet.create({
  container_product: {
      // backgroundColor: 'rgb(25,25,25)',
      // paddingBottom: 10,
      marginRight: 12,
      marginTop: 15,
      ...Platform.select({
        ios: {
          width: Styles.width > 320 ? 280 : 250,
          //height: Styles.width > 320 ? 310 : 280,
        },
        android: {
          width: Styles.width > 320 ? 280 : 250,
          //height: Styles.width > 320 ? 310 : 280,
        },
      }),
    },
    image: {
      ...Platform.select({
        ios: {
          width: Styles.width > 320 ? 280 : 250,
          height: Styles.width > 320 ? 200 : 180,
        },
        android: {
          width: Styles.width > 320 ? 280 : 250,
          height: Styles.width > 320 ? 200 : 180,
        },
      }),
    },
    textContainer:{
      paddingHorizontal: 2,
      flex:1,
      justifyContent:"center",
      marginVertical: 10
    },
    mainTextWarpper:{
      flexDirection: 'row',
    },
    listViewPrimaryText:{
      fontWeight: "700",
      color: Color.listPrimaryText,
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 16 : 15,
        },
        android: {
          fontSize: Styles.width > 360 ? 16 : 15,
        },
      }),
      textAlign: "left",
    },
    subTextContainer:{
      marginTop:1,
    },
    subtext_wrapper: {
      flexDirection: "row",
      flexDirection:"column",
    },
    listViewSecondaryText:{
      color: Color.listSecondaryText,
      textAlign: "left",
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 14 : 13,
        },
        android: {
          fontSize: Styles.width > 360 ? 14 : 13,
        },
      }),
      marginTop:1,
      // textTransform:'uppercase'
    },
    listViewSecondaryText2:{
      color: Color.listSecondaryText,
      textAlign: "left",
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 14 : 13,
        },
        android: {
          fontSize: Styles.width > 360 ? 14 : 13,
        },
      }),
      marginTop:3,
      // textTransform:'uppercase'
    },
    dividerText:{
      color: Color.white,
      fontSize:16,
      fontWeight:'500',
    },
    listViewTextDivider:{
      color: Color.listSecondaryText,
      fontSize: Styles.FontSize.tiny,
    },
    listViewSecondaryShimmerText:{
      // flex:1,
      marginTop:1,
      flexDirection:'column',
      width: 200,
    },
    listViewNameTextShimmer:{
      width: 200,
    },

    overlayBtnContainer:{
      position:'absolute',
      right:0,
      bottom:0,
      top:0,
    },
    viewFirstRow: {
      flexDirection:'row',
      flexWrap: 'wrap'
    },
    overlayBtnInnerTopContainer:{
      padding:6,
      flex:0.5,
    },
    overlayBtnInnerBottomContainer:{
      padding:6,
      flex:0.5,
      justifyContent:"flex-end"
    },
    saveIconWrapper:{
      backgroundColor:"transparent"
    },
    hideIconWrapper:{
      backgroundColor:"transparent",
    },
    overlayIcon:{
      width:30,
      height:30,
      tintColor:Color.primary,
    },
    //------ hide stock modal style -----
    modalStyle:{
      width:'90%',
      // ...Platform.select({
      //   ios: {
      //     height : Styles.width > 320 ? 205 : 210,
      //   },
      //   android: {
      //     height : Styles.width > 360 ? 205 : 220,
      //   },
      // }),
    },
});
