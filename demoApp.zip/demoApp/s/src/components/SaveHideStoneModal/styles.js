/** @format */

import { StyleSheet } from "react-native";
import { Color } from "@common";

export default StyleSheet.create({
  checkBoxStyle:{
    marginLeft: 0,
    padding: 0,
    marginRight: 0,
    backgroundColor:'transparent',
    borderWidth:0,
    paddingHorizontal:35,
  },
  checkBoxIcon:{
    width: 20,
    height: 20,
  },
  checkboxTextStyle:{
    color: Color.black,
    fontWeight:'normal'
  },
  modalStyle:{
    width:'90%',
  },
});
