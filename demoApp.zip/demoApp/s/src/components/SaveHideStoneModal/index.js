import React, { PureComponent } from "react";
import { View, Image,InteractionManager } from "react-native";
import { withTheme, Languages, Images } from "@common";
import { log, toast } from "@app/Omni";
import { Spinner, StonestockDialog, UpgradeMemberShipDialog, LandbotPopup} from "@components";
import styles from "./styles";
import { connect } from "react-redux";
import { firebase } from '@react-native-firebase/analytics';
import { CheckBox } from 'react-native-elements';

let btnclicked = false;
class SaveHideStoneModal extends PureComponent {
  constructor(props){
    super(props);
    this.state = {
      selectedItem : {},
      from: "",
      isFetchingBtnClick : false,
      is_show_hide_all_stocks : false,
    };
    this.callMainApi = false;
  }
  componentDidMount() {
		if (this.props.onRef) {
			this.props.onRef(this);
		}
	}
	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}
  open = (item, from) => {
    this.setState({selectedItem : item, from: from}, () => {
      this._hideStone.open();
    });
  }
  saveClick = (item, from) => {
    btnclicked = true;
    this.callMainApi = true;
    this.setState({isFetchingBtnClick : true, selectedItem:item }, () => {
      const { addToWatchList} = this.props;
      addToWatchList(item.stone_detail_id, !item.is_add_to_watchlist, from)
      firebase.analytics().logEvent("FollowStock", {"isFollow": this.is_added_to_watchlist, "ITEM_LIST_ID": item.stone_detail_id, "ITEM_LOCATION_ID": item.stock_id, "ITEM_ID": item.product_id, "ITEM_NAME": item.product_name });
    });
  }

  componentWillReceiveProps(nextProps) {
    // log('--------------------------componentWillReceiveProps homelist-- ')
    // log(nextProps)
    if(this.props !== nextProps){
      if(nextProps.errorStock != null && (nextProps.typeStock == 'ADD_TO_WATCHLIST_FAILURE' || nextProps.typeStock == 'HIDE_STOCK_FAILURE') && this.state.isFetchingBtnClick){
        this.setState({isFetchingBtnClick : false});
        if(nextProps.code == 300) {
          if(nextProps.landbot_url && nextProps.landbot_url != false){
            this.landbotModal.open(nextProps.landbot_url, nextProps.landbot_accent);
          }else{
            this.upgradeModal.open();
          }
        }else{
          toast(nextProps.errorStock);
        }
      }else{
        this.upgradeModal.close();
      }
      if(this.props.tags != undefined && btnclicked && (nextProps.typeBrowse == 'ADD_TO_WATCHLIST_SUCCESS_BROWSE' || nextProps.typeBrowse == 'HIDE_STOCK_SUCCESS_BROWSE' || nextProps.typeBrowse == 'ADD_TO_WATCHLIST_SUCCESS_BROWSE_SHOWALL' || nextProps.typeBrowse == 'HIDE_STOCK_SUCCESS_BROWSE_SHOWALL')){
          this.setState({isFetchingBtnClick : false, is_show_hide_all_stocks: false}, () => {
            btnclicked = false;
            if(this.callMainApi){
              if(this.props.tags == "recently_submitted" || this.props.tags == 'my_watchlist'){
                this.props.fetchBrowseShowAll(1,"recently_submitted");
              }
              this.props.fetchBrowseList();
              setTimeout(() => {
                this.mainApiCalled = false;
              },3000);
            }
          });
      }
      if(this.props.tags == undefined && this.state.isFetchingBtnClick && (nextProps.typeOwner == 'ADD_TO_WATCHLIST_SUCCESS_OWNER' || nextProps.typeOwner == 'HIDE_STOCK_SUCCESS_OWNER')){
        this.setState({isFetchingBtnClick : false, is_show_hide_all_stocks: false}, () => {
          this.props.clearOwnerType();
        });
      }
      if(this.state.isFetchingBtnClick && (nextProps.typeStock == 'ADD_TO_WATCHLIST_SUCCESS_SEARCHLIST' || nextProps.typeStock == 'HIDE_STOCK_SUCCESS_SEARCHLIST')){
        this.setState({isFetchingBtnClick : false, is_show_hide_all_stocks: false}, () => {
          this.props.clearDetailReduxError();
        });
      }
      if(this.state.isFetchingBtnClick && nextProps.typeStock == 'HIDE_STOCK_SUCCESS'){
        if(this.props.onHideSuccess){
          this.props.onHideSuccess();
        }
        this.setState({isFetchingBtnClick : false, is_show_hide_all_stocks: false}, () => {
          this.props.clearDetailReduxError();
        });
      }
    }
  }

  _onHideCall(){
    this._hideStone.close();
    InteractionManager.runAfterInteractions(() => {
      this.setState({isFetchingBtnClick : true}, () => {
        const { selectedItem } = this.state;
        this.props.hideStock(selectedItem.stone_detail_id, !selectedItem.is_hidden, this.state.is_show_hide_all_stocks, this.state.from);
        firebase.analytics().logEvent("HideStock", {"isHide": !selectedItem.is_hidden, "ITEM_LIST_ID": selectedItem.stone_detail_id, "ITEM_LOCATION_ID": selectedItem.stock_id, "ITEM_ID": selectedItem.product_id, "ITEM_NAME": selectedItem.product_name });
      });
    });
  }

  onChangePreferanceValue = () => {
    this.setState({is_show_hide_all_stocks : !this.state.is_show_hide_all_stocks});
  }

  render() {
    const { isFetchingBtnClick, selectedItem } = this.state;
    return (
      <View>
        {isFetchingBtnClick ? <Spinner mode="overlay" /> : null}
        <StonestockDialog ref={(com) => (this._hideStone = com)}
          titleText={selectedItem.is_hidden ? Languages.UnhideThisStock : Languages.hideStockTitle}
          primaryText={selectedItem.is_hidden ? Languages.unhideConfirmMsg : Languages.hideStockMsg}
          primaryBtnText={selectedItem.is_hidden ? Languages.Unhide : Languages.Hide}
          secondaryBtnText={Languages.Cancel}
          modalStyle={styles.modalStyle}
          primaryButtonCallback={() => this._onHideCall()}
          scondaryButtonCallback={() => this._hideStone.close()}
        >
          <CheckBox
            containerStyle={styles.checkBoxStyle}
            checked={this.state.is_show_hide_all_stocks}
            onPress={() => this.onChangePreferanceValue()}
            title={selectedItem.is_hidden ? Languages.unHideCurrentFutureStock : Languages.HideCurrentFutureStock}
            textStyle={styles.checkboxTextStyle}
            checkedIcon={<Image style={styles.checkBoxIcon} source={Images.icons.checkbox_selected_filter} resizeMode={'contain'}/>}
            uncheckedIcon={<Image style={styles.checkBoxIcon} source={Images.icons.checkbox_filter} resizeMode={'contain'}/>}
          />
        </StonestockDialog>
        <UpgradeMemberShipDialog navigation={this.props.navigation} onRef={(com) => (this.upgradeModal = com)} stone_detail_id={selectedItem.stone_detail_id} />
        <LandbotPopup ref={(com) => (this.landbotModal = com)} navigation={this.props.navigation} onLandboatClose={() => log()}/>
      </View>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    isFetching:state.stockOwner.isFetching || state.browse.isFetching,
    isConnected: state.netInfo.isConnected,
    typeBrowse:state.browse.type,
    typeOwner:state.stockOwner.type,
    errorStock:state.stockList.error,
    typeStock:state.stockList.type,
    code:state.stockList.code,
    landbot_url:state.stockList.landbot_url,
    landbot_accent:state.stockList.landbot_accent,
  };
};
function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  const { actions: stockListAction } = require("@redux/StockListRedux");
  const { actions: browseAction } = require("@redux/BrowseRedux");
  const { actions: ownerAction } = require("@redux/StockOwnerRedux");
  const { isConnected } = stateProps;
  return {
    ...ownProps,
    ...stateProps,
    addToWatchList: (stone_detail_id, is_save, from) => {
      if(isConnected){
        stockListAction.addToWatchList(dispatch, stone_detail_id, is_save, from)
      }else{
        toast(Languages.InternetError)
      }
    },
    hideStock: (stone_detail_id, is_hide, show_hide_all_stocks, from) => {
      if(isConnected){
        stockListAction.hideStock(dispatch, stone_detail_id, is_hide, show_hide_all_stocks, from)
      }else{
        toast(Languages.InternetError)
      }
    },
    clearBrowseType: () => {
      browseAction.clearBrowseType(dispatch);
    },
    clearOwnerType: () => {
      ownerAction.clearOwnerType(dispatch);
    },
    clearDetailReduxError: () => {
      stockListAction.clearDetailReduxError(dispatch);
    },
    fetchBrowseShowAll: (pageNumber, tags) => {
      if(isConnected){
        browseAction.fetchBrowseShowAll(dispatch, pageNumber, tags)
      }else{
        toast(Languages.InternetError)
      }
    },
    fetchBrowseList: () => {
      if(isConnected){
        browseAction.fetchBrowseList(dispatch);
      }else{
        toast(Languages.InternetError)
      }
    }
  };
}
export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    mergeProps
  )(SaveHideStoneModal)
);
