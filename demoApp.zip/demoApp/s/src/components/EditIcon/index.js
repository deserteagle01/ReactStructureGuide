import React, { PureComponent } from "react";
import { connect } from "react-redux";
import { View, } from "react-native";
import { Styles, Constants, withTheme, } from "@common";
import { Icon } from 'react-native-elements';
import styles from "./style";
class EditIcon extends PureComponent {
    constructor(props) {
        super(props);
    }
    render(){
        const { userProfile, onPress } = this.props;

        if(!userProfile || !userProfile.user){
            return null;
        }

        return (
            <View style={[ Styles.Common.Row, Constants.RTL ? { left: -10 } : { right: 5 }, ]}>
                <Icon onPress={() => onPress()} size={18} name='pencil' type='octicon' iconStyle={styles.Icon}/>
            </View>
        );
    }
}
const mapStateToProps = ({ user }) => ({
    userProfile: user,
});
  
function mergeProps(stateProps, dispatchProps, ownProps) {
    const { dispatch } = dispatchProps;

    return {
        ...ownProps,
        ...stateProps,
    };
}
  
export default connect(
    mapStateToProps,
    null,
    mergeProps
)(withTheme(EditIcon));