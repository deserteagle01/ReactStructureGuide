/** @format */

import React, { StyleSheet } from "react-native";
import { Styles, } from "@common";
  
export default StyleSheet.create({
    Icon: {
        opacity: 0.8,
        width: Styles.IconSize.ToolBar,
        height: Styles.IconSize.ToolBar,
        marginRight: 10
    },
});