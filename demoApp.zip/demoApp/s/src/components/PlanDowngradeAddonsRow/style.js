/** @format */

import { StyleSheet,Platform } from "react-native";
import { Color, Styles } from "@common";

export default StyleSheet.create({
  addonsContentWrapper:{
    paddingHorizontal:16,
    flexDirection:'row',
    borderBottomWidth:1,
    borderColor:Color.white,
    ...Platform.select({
      ios: {
        paddingVertical:Styles.width > 320 ? 14 : 12,
      },
      android: {
        paddingVertical:Styles.width > 360 ? 14 : 12,
      },
    }),
  },
  headerTextWrapper:{
    flex:0.7,
    justifyContent:'center'
    // backgroundColor:'pink'
  },
  addonsContentText:{
    color:'#fff',
    ...Platform.select({
      ios: {
        fontSize:Styles.width > 320 ? 16 : 14,
      },
      android: {
        fontSize:Styles.width > 360 ? 16 : 14,
      },
    }),
    marginRight:16,
  },

  addonsAddRemoveContainer:{
    flexDirection:"row",
    flex:0.3,
    justifyContent:'center',
    alignItems:'center'
  },
  addRemoveIconWrapper:{
    justifyContent:'center',
    alignItems:'center',
  },
  addRemoveIcon:{
    tintColor:'#ab610f', //Color.primary, //'#77440c',
    ...Platform.select({
      ios: {
        height: Styles.width > 320 ? 35 : 30,
        width: Styles.width > 320 ? 35 : 30,
      },
      android: {
        height: Styles.width > 360 ? 35 : 35,
        width: Styles.width > 360 ? 35 : 35,
      },
    }),
  },
  addonsQtyWrapper:{
    // backgroundColor:'rgba(207, 207, 207,0.5)',
    justifyContent:'center',
    alignItems:'center',
    paddingHorizontal:10,
  },
  addonsQtyText:{
    color:Color.white,
    fontWeight:'300',
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 30 : 20,
        marginBottom:Styles.width > 320 ? 5 : 0,
      },
      android: {
        fontSize: Styles.width > 360 ? 30 : 25,
        marginBottom:Styles.width > 360 ? 5 : 0,
      },
    }),
  },
});
