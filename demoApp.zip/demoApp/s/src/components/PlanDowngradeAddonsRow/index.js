/** @format */

import React from "react";
import { View, Image, Text, TouchableOpacity } from "react-native";

import { Images } from "@common";
import styles from "./style";
import { log } from "@app/Omni";

export default class PlanDowngradeAddonsRow extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      item:this.props.item,
      main_limit: this.props.item.limit,
      remaining_limit: this.props.item.remaining_limit,
    };
  }

  componentDidMount() {
    if (this.props.onRef) {
			this.props.onRef(this);
    }
  }

	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

  onRemoveAddons = () => {
    let tempQty = this.state.remaining_limit;
    if(tempQty > 0){
      tempQty = tempQty - 1;
    } else if(tempQty == -1){
      tempQty = 0;
    }
    this.changeQty(tempQty)
  }
  onAddAddons = () => {
    let tempQty = this.state.remaining_limit;
    if(tempQty < this.state.main_limit){
      tempQty = tempQty + 1;
    }else if(this.state.main_limit == -1){
      tempQty = tempQty + 1;
    }
    this.changeQty(tempQty)
  }
  changeQty(tempQty){
    let tempItem = this.state.item;
    tempItem.remaining_limit = tempQty;
    this.setState({remaining_limit : tempQty});
  }

  render() {
    const { item, main_limit } = this.state;
    let disableRemove = false, disableAdd = true;
    if(item.remaining_limit == 0){
      disableRemove = true;
    }
    if(item.remaining_limit < main_limit || main_limit == -1){
      disableAdd = false;
    }
    return (
      <View style={styles.addonsContentWrapper}>
          <View style={styles.headerTextWrapper}>
              <Text style={styles.addonsContentText}>{item.name}</Text>
          </View>
          <View style={styles.addonsAddRemoveContainer}>
              <TouchableOpacity style={styles.addRemoveIconWrapper} onPress={this.onRemoveAddons} disabled={disableRemove}>
                  <Image source={Images.icons.minus} style={[styles.addRemoveIcon,{tintColor : disableRemove ? '#363636' : '#ab610f'}]} />
              </TouchableOpacity>
              <View style={styles.addonsQtyWrapper}>
                  <Text style={styles.addonsQtyText}>{item.remaining_limit == -1 ? "∞" : item.remaining_limit}</Text>
              </View>
              <TouchableOpacity style={styles.addRemoveIconWrapper} onPress={this.onAddAddons} disabled={disableAdd}>
                  <Image source={Images.icons.add} style={[styles.addRemoveIcon,{tintColor : disableAdd ? '#363636' : '#ab610f'}]} />
              </TouchableOpacity>
          </View>
      </View>
    );
  }
}
