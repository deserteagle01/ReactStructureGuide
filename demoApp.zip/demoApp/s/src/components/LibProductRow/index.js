import React, { PureComponent } from "react";
import { View, TouchableOpacity, Text, Image } from "react-native";
import { Languages } from "@common";
import { Shimmer, ImageCache } from "@components";
import styles from "./styles";

export default class LibProductRow extends PureComponent {
  render() {
    const { product, onProductPress, onIconPress, isFetching, icon, secondIcon, onSecondIconPress, isForHiddenStock } = this.props;
    return (
      <TouchableOpacity activeOpacity={0.9} onPress={onProductPress} style={styles.container_product}>
        {isForHiddenStock && 
          <View style={{flex:0.3}}>
              <ImageCache
                  uri={product.images.length > 0 ? product.images[0].src : ""}
                  style={{flex: 1}} />
          </View>
        }
        
        <View style={[styles.textContainer,{flex: secondIcon ? 0.8 : isForHiddenStock ? 0.6 : 0.9, marginHorizontal: isForHiddenStock ? '3%' : 0  }]}>
          <View style={styles.mainTextWarpper}>
            <Shimmer style={styles.listViewNameTextShimmer} visible={!isFetching} >
              <Text style={styles.listViewPrimaryText}>
                {product.display_name}
              </Text>
            </Shimmer>
          </View>

          <View style={styles.subTextContainer}>
              <View style={styles.subtext_wrapper}>
                  <Text style={styles.subTextTitleText}>{Languages.Quality + ": "}</Text>
                  <Shimmer style={styles.listViewSecondaryShimmerText} visible={!isFetching} >
                    <Text style={styles.listViewSecondaryText}>
                      {typeof(product.quality_detail) == "object" ? product.quality_detail.join(', ') : product.quality_detail}
                    </Text>
                  </Shimmer>
              </View>
              <View style={styles.subtext_wrapper}>
                  <Text style={styles.subTextTitleText}>{Languages.Size + ": "}</Text>
                  <Shimmer style={styles.listViewSecondaryShimmerText} visible={!isFetching} >
                    <Text style={styles.listViewSecondaryText}>
                      {typeof(product.size_detail) == "object" ? product.size_detail.join(', ') : product.size_detail}
                    </Text>
                  </Shimmer>
              </View>
              <View style={styles.subtext_wrapper}>
                  <Text style={styles.subTextTitleText}>{Languages.Finishing + ": "}</Text>
                  <Shimmer style={styles.listViewSecondaryShimmerText} visible={!isFetching} >
                    <Text style={styles.listViewSecondaryText}>
                      {typeof(product.finishing_detail) == "object" ? product.finishing_detail.join(', ') : product.finishing_detail}
                    </Text>
                  </Shimmer>
              </View>
          </View>
        </View>

        <TouchableOpacity activeOpacity={0.9} onPress={onIconPress} style={styles.iconContainer}>
            <Shimmer style={styles.icon} visible={!isFetching} >
                <Image source={icon} style={styles.icon} resizeMode={"contain"}/>
            </Shimmer>
        </TouchableOpacity>
        {secondIcon &&
          <TouchableOpacity activeOpacity={0.9} onPress={onSecondIconPress} style={styles.iconContainer}>
              <Shimmer style={styles.icon} visible={!isFetching} >
                  <Image source={secondIcon} style={styles.icon} resizeMode={"contain"}/>
              </Shimmer>
          </TouchableOpacity>
        }
      </TouchableOpacity>
    );
  }
}
