/** @format */

import { StyleSheet, Platform } from "react-native";
import { Styles, Color } from "@common";

export default StyleSheet.create({
  container_product: {
      paddingHorizontal:16,
      paddingVertical:14,
      borderBottomColor: '#e9e9e9',
      borderBottomWidth: 0.5,
      flexDirection:'row'
  },
  textContainer:{
      flex:0.9,
      justifyContent:"center"
  },
  mainTextWarpper:{
      flexDirection: 'row',
  },
  listViewPrimaryText:{
      fontWeight: "700",
      color: Color.listPrimaryText,
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 19 : 18,
        },
        android: {
          fontSize: Styles.width > 360 ? 19 : 18,
        },
      }),
      textAlign: "left",
  },
  subTextContainer:{
    marginTop:4,
  },
  subtext_wrapper: {
    flexDirection: "row",
    marginTop:2,
  },
  subTextTitleText:{
    width:80,
    color: Color.white,
    fontWeight:'500',
    textAlign: "left",
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 17 : 14,
      },
      android: {
        fontSize: Styles.width > 360 ? 17 : 14,
      },
    }),
  },
  listViewSecondaryText:{
      color: Color.listSecondaryText,
      textAlign: "left",
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 16 : 15,
        },
        android: {
          fontSize: Styles.width > 360 ? 16 : 15,
        },
      }),
      marginRight:80,
  },

  listViewSecondaryShimmerText:{
      marginTop:1,
      flexDirection:'column',
      width: 200,
      ...Platform.select({
        ios: {
          height: Styles.width > 320 ? 20 : 20,
        },
        android: {
          height: Styles.width > 360 ? 19 : 19,
        },
      }),
  },
  listViewNameTextShimmer:{
      width: 200,
      ...Platform.select({
        ios: {
          height: Styles.width > 320 ? 22 : 22,
        },
        android: {
          height: Styles.width > 360 ? 26 : 25,
        },
      }),
  },

  iconContainer:{
    flex:0.1,
    justifyContent:'center',
    alignItems:'center',
    // backgroundColor:'pink'
  },
  icon: {
    width:30,
    height:30,
    tintColor:Color.primary,
  },
});
