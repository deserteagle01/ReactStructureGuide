/** @format */

import { StyleSheet,Platform } from "react-native";
import { Color, Styles } from "@common";

export default StyleSheet.create({
  mainWrapper: {
    flexDirection:'row',
    justifyContent:'center',
    alignItems:'center',
    backgroundColor:'#2e2e2e',
    paddingHorizontal:10,
    height:60,
  },
  textContainer:{
    flex:0.9
  },
  avilableAddonsText: {
    color:Color.white,
    textTransform:'uppercase',
    fontWeight:'500',
    ...Platform.select({
      ios: {
        fontSize : Styles.width > 320 ? 18 : 13,
      },
      android: {
        fontSize : Styles.width > 360 ? 18 : 14,
      },
    }),
  },
  iconContainer:{
    flex:0.1,
    alignItems:'flex-end'
  },
  arrowIcon:{
    width:20,
    height:20,
    tintColor:Color.primary
  },


});
