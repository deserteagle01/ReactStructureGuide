/** @format */

import React from "react";
import { TouchableOpacity, View, Image, Text } from "react-native";

import { Images } from "@common";
import styles from "./style";

export default class PlanUpgradeButtons extends React.PureComponent {

  render() {
    const { text, onPress } = this.props;
    return (
      <TouchableOpacity style={styles.mainWrapper} onPress={onPress}>
          <View style={styles.textContainer}>
              <Text style={styles.avilableAddonsText}>{text}</Text>
          </View>
          <View style={styles.iconContainer}>
             <Image source={Images.icons.rightArrow} style={styles.arrowIcon} />
          </View>
      </TouchableOpacity>
    );
  }
}
