/** @format */

import React, { PureComponent } from "react";
import PropTypes from "prop-types";
import {
  View,
  Platform,
  StyleSheet,
  TouchableWithoutFeedback,Text,Dimensions
} from "react-native";
import { StackActions } from "react-navigation";
import * as Animatable from "react-native-animatable";
import { connect } from "react-redux";

import { log, toast } from "@app/Omni";
import { Device, withTheme, Color, Languages, MesiboModule } from "@common";//MesiboModule
import { Chat } from "@containers";

const { width } = Dimensions.get("window");

const styles = StyleSheet.create({
  tabbar: {
    height: Device.isIphoneX ? 70 : 49,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  tab: {
    alignSelf: "stretch",
    flex: 1,
    alignItems: "center",
    backgroundColor: Color.tabbar,
    borderTopColor:Color.tabbarDivider,
    borderTopWidth:1,
    ...Platform.select({
      ios: {
        justifyContent: Device.isIphoneX ? "flex-start" : "center",
        paddingTop: Device.isIphoneX ? 12 : 0,
      },
      android: {
        justifyContent: "center",
      },
    }),
  },
  tabText: {
    ...Platform.select({
      ios: {
        fontSize: width > 320 ? 12 : 9,
        marginTop: width > 320 ? 0 : 2,
      },
      android: {
        fontSize: width > 360 ? 12 : 9,
        marginTop: width > 320 ? 0 : 2,
      },
    }),
  }
});

class TabBar extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      mesiboUI: true
    };
    this.chatScreen = React.createRef();
  }
  onPress = (index, route) => {
    // Animate Tab bar Icons
    // this.refs[`tabItem${index}`].flipInY(900);

    // back to main screen when is staying child route
    this.props.clearSearchFilterData();
    if(route.key == "Chat"){
        this.handleChatBarClick();
        return;
        
    }
    if (route.routes && route.routes.length > 1) {
      log(route);
      // this.props.navigation.dispatch(
      //   StackActions.popToTop({ key: route.key, immediate: true })
      // );

      this.props.navigation.navigate(route.routes[0].routeName);
    } else {
      this.props.navigation.navigate(route.key);
    }
  };

  handleChatBarClick() {
    this.chatScreen.current.initiateChat();
  }
  render() {
    const {
      navigation,
      renderIcon,
      activeTintColor,
      inactiveTintColor,
      theme: {
        colors: { background },
      },
    } = this.props;

    const { routes } = navigation.state;

    const ignoreScreen = [
      "DetailScreen",
      "SearchScreen",
      "Detail",
      "NewsScreen",
      "LoginScreen",
      "SignUpScreen",
      "SetPasswordScreen",
      "CustomPage",
      "CategoryDetail",
      "SettingScreen",
      "WishListScreen",
      "LoginStack",
      "UserProfileStack",
      "MyOrderStack",
      "ProductStack",
      "SellerDetailStack",
      "MyAccountStack",
      "HistoryStack"
    ];

    return (
      <View
        style={[
          styles.tabbar,
          { backgroundColor: background, borderTopColor: background },
        ]}>
        {routes &&
          routes.map((route, index) => {
            if(this.props.profile && this.props.profile.membership.is_first_free_plan && route.key == "Account"){
              return;
            }

            const focused = index === navigation.state.index;
            const tintColor = focused ? activeTintColor : inactiveTintColor;

            if (ignoreScreen.indexOf(route.key) > -1) {
              return <View key={route.key} />;
            }

            if (this.props.user === null && route.key === "MyOrders") {
              return <View key={route.key} />;
            }

            return (
              <TouchableWithoutFeedback
                key={route.key}
                style={styles.tab}
                onPress={() => this.onPress(index, route)}>
                <Animatable.View ref={`tabItem${index}`} style={styles.tab}>
                  {renderIcon({
                    route,
                    index,
                    focused,
                    tintColor,
                  })}
                  <Text style={[styles.tabText, { color : tintColor }]} >{route.params.name}</Text>
                </Animatable.View>
              </TouchableWithoutFeedback>
            );
          })}
          <View style={{height: 0, width:0}}>
              <Chat
                ref={this.chatScreen}/>
          </View>      
      </View>
    );
  }
}

TabBar.propTypes = {
  user: PropTypes.object,
  navigation: PropTypes.object,
  renderIcon: PropTypes.any,
  activeTintColor: PropTypes.string,
  inactiveTintColor: PropTypes.string,
  jumpTo: PropTypes.func,
};
const mapStateToProps = (state) => {
  return {
    user: state.user.user,
    profile: state.user.profile,
  };
};
function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  const { actions } = require("@redux/FilterTagRedux");
  return {
    ...ownProps,
    ...stateProps,
    clearSearchFilterData: () => {
      actions.clearSearchFilterData(dispatch);
    },
  };
}
export default withTheme(connect(mapStateToProps,null,mergeProps)(TabBar));
