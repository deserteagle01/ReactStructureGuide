/** @format */

import React, { StyleSheet } from "react-native";
import { Color, Constants } from "@common";
  
export default StyleSheet.create({
    buttonContainer: {
        alignItems: "center",
        marginTop: 5,
        padding: 5,
    },
    button: {
        height: 40,
        width: "100%",
        borderRadius: 20,
        backgroundColor: Color.primary,
    },
    buttonText: {
        fontSize: 15,
        fontFamily: Constants.fontHeader,
        marginTop: 0,
    },
});
  