/** @format */

"use strict";
import React, { Component } from "react";
import { View } from "react-native";
import styles from "./styles";
import { Button } from "@components";

export default class AppButton extends Component {
  render() {
    return (
      <View style={styles.buttonContainer}>
        <Button
          text={this.props.text}
          style={[styles.button, this.props.buttonStyle]}
          textStyle={[styles.buttonText, this.props.textStyle]}
          onPress={this.props.onPress}
        />
      </View>
    );
  }
}
