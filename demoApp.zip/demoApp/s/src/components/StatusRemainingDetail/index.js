/** @format */

import React, {PureComponent} from 'react';
import {
  Text,
  TouchableOpacity,
  View,
  TextInput,
  Keyboard,
  Image,
  ScrollView,
  SafeAreaView,
  ActivityIndicator,
  Platform,
  TouchableWithoutFeedback,
} from 'react-native';
import {Color, Languages, Images} from '@common';
import styles from './styles';
import {log, toast} from '@app/Omni';
import Modal from 'react-native-modal';
import {ContactSelection} from '..';
import {connect} from 'react-redux';
let device = Platform.OS;
import RNPickerSelect, {defaultStyles} from 'react-native-picker-select';
import DatePicker from 'react-native-datepicker'
const commonStyle = {
  width: 0,
  height: 0,
};
const android = {
  color: 'green',
  height: '100%',
  width: '100%',
  height: 36,
  paddingVertical: 0,
  color: 'clear',
  opacity: 0.0,
};
const pickerStyle1 = {
  chevron: commonStyle,
  inputIOS: commonStyle,
  inputAndroid: android,
  iconContainer: {top: 10, right: 7},
  inputAndroidContainer: {flexDirection: 'row'},
};

class StatusRemainingDetail extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isKeyboardShown: false,
      visible: false,
      price: '',
      priceError: undefined,

      currency: '',
      currency_id: '',
      currencyError: undefined,
      currencyList: [],

      paymentTerm: '',
      paymentTerm_id: '',
      paymentTermError: undefined,
      termPaymentList: [],

      shipmentTerm: '',
      shipmentTerm_id: '',
      shipmentTermError: undefined,
      termShipmentList: [],

      selectedContactList: [],
      title_popup: "",
      actionTitle: "",
      status_key: "",
      booked_untill: this.addDays(new Date(), 2),
      booked_untillError: undefined,

    };
  }

    addDays(theDate, days) {
      return new Date(theDate.getTime() + days*24*60*60*1000);
    }

  componentWillMount() {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow.bind(this),
    );
    this.keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      this._keyboardDidHide.bind(this),
    );
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  _keyboardDidShow() {
    this.setState({isKeyboardShown: true});
  }

  _keyboardDidHide() {
    this.setState({isKeyboardShown: false});
  }

  open = (key, value) => {
    let tempCurrency = "";
    let tempcurrency_id = "";
    if(this.props.preference && this.props.preference.currency_id){
        let filterResult = this.props.currencyList.filter((e) => e.value === this.props.preference.currency_id);
        if(filterResult.length > 0){
          tempCurrency = filterResult[0].label;
          tempcurrency_id = filterResult[0].value;
        }
    }

    let temppaymentTerm = "";
    let temppaymentTerm_id = "";
    if(this.props.preference && this.props.preference.payment_terms_id){
        let filterResult = this.props.paymentList.filter((e) => e.value === this.props.preference.payment_terms_id);
        if(filterResult.length > 0){
          temppaymentTerm = filterResult[0].label;
          temppaymentTerm_id = filterResult[0].value;
        }
    }

    let tempshipTerm = "";
    let tempshipmenTerm_id = "";
    if(this.props.preference && this.props.preference.shipment_terms_id){
        let filterResult = this.props.shipmentList.filter((e) => e.value === this.props.preference.shipment_terms_id);
        if(filterResult.length > 0){
          tempshipTerm = filterResult[0].label;
          tempshipmenTerm_id = filterResult[0].value;
        }
    }


    let tempDict = {
      visible: true,
      selectedContactList: [],
      currencyList: this.props.currencyList,
      termShipmentList: this.props.shipmentList,
      termPaymentList: this.props.paymentList,
      price: '',
      priceError: undefined,
      currency: tempCurrency,
      currency_id: tempcurrency_id,
      currencyError: undefined,
      paymentTerm: temppaymentTerm,
      paymentTerm_id: temppaymentTerm_id,
      paymentTermError: undefined,
      shipmentTerm: tempshipTerm,
      shipmentTerm_id: tempshipmenTerm_id,
      shipmentTermError: undefined,
      title_popup: key == "action_set_to_sold" ? value: "Reserve Stocks",
      status_key: key,
      booked_untill: this.addDays(new Date(), 2),
      booked_untillError: undefined,
      actionTitle: key == "action_set_to_sold" ? "SOLD" : "RESERVE",
    };
    this.setState(tempDict);
  };

  cancel = () => {
    this.setState({visible: false});
  };

  sendOffer = () => {
    if (this.state.selectedContactList.length > 0) {
      if (this.isValidated()) {
        let tempselectedContact = [...this.state.selectedContactList];
        let contact_ids = [];
        for(let i = 0; i < tempselectedContact.length; i++) {
          let tempDict = {
            parent_id: tempselectedContact[i].company_id,
            partner_id: tempselectedContact[i].id,
            email: tempselectedContact[i].email
          }
          contact_ids.push(tempDict);
        }
          
        this.props.changeStatus(contact_ids, this.state.price, this.state.currency_id, this.state.paymentTerm_id, this.state.shipmentTerm_id, this.state.status_key, this.state.booked_untill);
      }
    } 
    else {
      alert(Languages.txtShareWarning);
    }
  };

  isValidated = () => {
    const {price, currency, paymentTerm, shipmentTerm, booked_untill} = this.state;
    let requiredValid = this.checkRequiredFieldValidation(
      price,
      currency,
      paymentTerm,
      shipmentTerm,
      booked_untill
    );
    if (
      requiredValid.priceError == undefined &&
      requiredValid.shipmentTermError == undefined &&
      requiredValid.currencyError == undefined &&
      requiredValid.paymentTermError == undefined &&
      requiredValid.booked_untillError == undefined
    ) {
      this.setState(requiredValid);
      return true;
    } else {
      this.setState(requiredValid);
      return false;
    }
  };

  checkRequiredFieldValidation(price, currency, paymentTerm, shipmentTerm, booked_untill) {
    let tempState = {
      priceError: undefined,
      currencyError: undefined,
      paymentTermError: undefined,
      shipmentTermError: undefined,
      booked_untillError: undefined
    };
    if (price.trim().length <= 0 || parseFloat(price) <= 0) {
      tempState.priceError = Languages.ErrSalePriceReq;
    }
    if (currency.trim().length <= 0) {
      tempState.currencyError = Languages.ErrSaleCurrency;
    }
    if (paymentTerm.trim().length <= 0) {
      tempState.paymentTermError = Languages.ErrPayment;
    }
    if (shipmentTerm.trim().length <= 0) {
      tempState.shipmentTermError = Languages.ErrShipment;
    }
    if(this.state.status_key == "action_set_to_booked" && booked_untill.length <= 0){
        tempState.booked_untillError = Languages.ErrBookUntilReq;
    }
    return tempState;
  }

  closeAddEditModal = () => {
    this._contactselection.closeAddEditModal(this.state.selectedContactList);
  };

  refreshSelectedContact = (contactList) => {
    this._contactselection.refreshSelectedContact(
      this.state.selectedContactList,
      contactList,
    );
  };

  deleteTag(data) {
    this.setState({
      selectedContactList: this.state.selectedContactList.filter(function (
        contact,
      ) {
        return contact.id !== data.id;
      }),
    });
  }

  renderTags() {
    return this.state.selectedContactList.map((data, index) => {
      return (
        <TouchableOpacity
          style={styles.tabt}
          onPress={() => this.deleteTag(data)}>
          <Text style={styles.txttag}>{data.first_name+" "+data.surname}</Text>
          <Image source={Images.icons.closeNew} style={styles.canceltag} />
        </TouchableOpacity>
      );
    });
  }

  render() {
    return (
      <Modal
        hasBackdrop={true}
        isVisible={this.state.visible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={{margin: 0}}
        onBackButtonPress={this.cancel}
        onBackdropPress={this.cancel}>
        <View style={{backgroundColor: 'white', marginHorizontal: 20}}>
          <View style={styles.headerContainer}>
            <Text style={styles.shareTitle}>{this.state.title_popup}</Text>
          </View>
          <TouchableOpacity
            style={styles.emailInput}
            onPress={() =>
              this._contactselection.open(this.state.selectedContactList)
            }>
            <Text style={styles.txtSelectContact}>
              {Languages.txtSelectContact}
            </Text>
          </TouchableOpacity>
          <ScrollView style={{marginVertical: 10, maxHeight: '30%'}}>
            {this.state.selectedContactList.length > 0 && (
              <View
                style={{
                  marginVertical: 10,
                  width: '90%',
                  alignSelf: 'center',
                  flexDirection: 'row',
                  flexWrap: 'wrap',
                }}>
                {this.renderTags()}
              </View>
            )}
          </ScrollView>
          <TextInput
            style={styles.searchInput}
            placeholderTextColor={Color.inputBoxPlaceholder}
            autoCapitalize="none"
            multiline={false}
            underlineColorAndroid="transparent"
            placeholder={this.state.status_key == "action_set_to_booked" ? Languages.txtPlaceholderBookedPrice  : Languages.txtPlaceholderSoldPrice}
            keyboardType={'decimal-pad'}
            returnKeyType={'done'}
            onChangeText={(text) =>
              //this.setState({price: text.replace(/[^0-9]/g, '')}
              this.setState({price: text})
            }
            value={this.state.price}
          />
          {this.state.priceError && (
            <Text style={styles.errorStyle}>{this.state.priceError}</Text>
          )}

          <TouchableWithoutFeedback
            onPress={() => this._refcurrencyPicker.togglePicker(true)}>
            <View style={styles.dropDownContainer}>
              <TextInput
                editable={false}
                pointerEvents="none"
                style={styles.searchInput2}
                autoCapitalize="none"
                multiline={false}
                underlineColorAndroid="transparent"
                placeholder={Languages.txtCurrencyPlaceholder}
                placeholderTextColor={Color.inputBoxPlaceholder}
                value={this.state.currency}
              />
              {device == 'android' ? (
                <View style={styles.btDropdowna}>
                  {this.renderCurrencyPicker()}
                </View>
              ) : (
                <View style={styles.btDropdown}>
                  <TouchableOpacity
                    onPress={() =>
                      this.state.currencyList.length > 0 &&
                      this._refcurrencyPicker.togglePicker(true)
                    }>
                    <Image
                      source={Images.icons.DropDown}
                      style={{height: 20, width: 20, marginRight: 0}}
                    />
                  </TouchableOpacity>
                  {this.renderCurrencyPicker()}
                </View>
              )}
            </View>
          </TouchableWithoutFeedback>
          {this.state.currencyError && (
            <Text style={styles.errorStyle}>{this.state.currencyError}</Text>
          )}

          <TouchableWithoutFeedback
            onPress={() => this._refpaymentpicker.togglePicker(true)}>
            <View style={styles.dropDownContainer}>
              <TextInput
                editable={false}
                pointerEvents="none"
                style={styles.searchInput2}
                autoCapitalize="none"
                multiline={false}
                underlineColorAndroid="transparent"
                placeholder={Languages.txtPaymentTermPlaceholder}
                placeholderTextColor={Color.inputBoxPlaceholder}
                value={this.state.paymentTerm}
              />
              {device == 'android' ? (
                <View style={styles.btDropdowna}>
                  {this.renderPaymentTermPicker()}
                </View>
              ) : (
                <View style={styles.btDropdown}>
                  <TouchableOpacity
                    onPress={() =>
                      this.state.termPaymentList.length > 0 &&
                      this._refpaymentpicker.togglePicker(true)
                    }>
                    <Image
                      source={Images.icons.DropDown}
                      style={{height: 20, width: 20, marginRight: 0}}
                    />
                  </TouchableOpacity>
                  {this.renderPaymentTermPicker()}
                </View>
              )}
            </View>
          </TouchableWithoutFeedback>
          {this.state.paymentTermError && (
            <Text style={styles.errorStyle}>{this.state.paymentTermError}</Text>
          )}

          <TouchableWithoutFeedback
            onPress={() => this._refshipmentpicker.togglePicker(true)}>
            <View style={styles.dropDownContainer}>
              <TextInput
                editable={false}
                pointerEvents="none"
                style={styles.searchInput2}
                autoCapitalize="none"
                multiline={false}
                underlineColorAndroid="transparent"
                placeholder={Languages.txtshipmentTermPlaceholder}
                placeholderTextColor={Color.inputBoxPlaceholder}
                value={this.state.shipmentTerm}
              />
              {device == 'android' ? (
                <View style={styles.btDropdowna}>
                  {this.renderShipmentTermPicker()}
                </View>
              ) : (
                <View style={styles.btDropdown}>
                  <TouchableOpacity
                    onPress={() =>
                      this.state.termShipmentList.length > 0 &&
                      this._refshipmentpicker.togglePicker(true)
                    }>
                    <Image
                      source={Images.icons.DropDown}
                      style={{height: 20, width: 20, marginRight: 0}}
                    />
                  </TouchableOpacity>
                  {this.renderShipmentTermPicker()}
                </View>
              )}
            </View>
          </TouchableWithoutFeedback>
          {this.state.shipmentTermError && (
            <Text style={styles.errorStyle}>
              {this.state.shipmentTermError}
            </Text>
          )}

        {this.state.status_key == "action_set_to_booked" &&
            <View style={styles.pickerContainer}>
            <DatePicker
                minDate = {new Date()}
                style={styles.pickerStyle}
                date={this.state.booked_untill}
                mode={"date"}
                placeholder={Languages.SelectbookedUntill}
                format={"YYYY-MM-DD"}
                confirmBtnText={Languages.confirm}
                cancelBtnText={Languages.Cancel}
                showIcon={true}
                customStyles={{
                    dateIcon: {
                        position: 'absolute',
                        right: 0,
                        top: 4,
                        marginLeft: 0
                    },
                    datePicker: styles.datePicker,
                    dateInput: styles.dateInput,
                    placeholderText: styles.placeholderText,
                    dateText: styles.dateText
                }}
                onDateChange={(date) => this.setState({booked_untill: date})} />
            </View>
        }
        {this.state.booked_untillError && (
            <Text style={styles.errorStyle}>{this.state.booked_untillError}</Text>
        )}
        

        <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.buttonWrapper}
              onPress={this.cancel}>
              <Text style={styles.cancelBtnText}>{Languages.CANCEL}</Text>
            </TouchableOpacity>
            <View style={styles.verticalDivider} />
            <TouchableOpacity
              style={styles.buttonWrapper2}
              onPress={this.sendOffer}>
              <Text style={styles.shareBtnText}>{this.state.actionTitle}</Text>
            </TouchableOpacity>
          </View>
        </View>
        <ContactSelection
          isSingleSelect={true}
          ref={(com) => (this._contactselection = com)}
          selectionWarning={Languages.contactSelectionWarningStatusChange}
          contactList={this.props.contact_list}
          companyList={this.props.company_list}
          contactSelected={(items) => {
            this.setState({selectedContactList: items});
            this._contactselection.cancel();
          }}
          addEditContactClick={(params) => this.props.addEditContact(params)}
        />
        {this.props.isFetching ? (
          <View style={{position: 'absolute', alignSelf: 'center', flex: 1}}>
            <ActivityIndicator size="small" color="gray" />
          </View>
          ) : null}
      </Modal>
    );
  }

  renderCurrencyPicker() {
    return this.state.currencyList.length > 0 ? (
      <RNPickerSelect
        Icon={() => {
          return device == 'android' ? (
            <Image
              style={{height: 20, width: 20, marginRight: 0}}
              source={Images.icons.DropDown}
            />
          ) : null;
        }}
        ref={(el) => {
          this._refcurrencyPicker = el;
        }}
        style={pickerStyle1}
        placeholder={{label: Languages.txtPickerPlaceholder, value: null}}
        useNativeAndroidPickerStyle={false}
        items={this.state.currencyList}
        onValueChange={(text) => {
          if (text && text != this.state.currency) {
            let tempSource = [...this.state.currencyList];
            let filteredAttribs = tempSource.filter((e) => e.value === text);
            this.setState({
              currency: filteredAttribs[0].label,
              currency_id: filteredAttribs[0].value,
            });
          }
        }}
      />
    ) : null;
  }

  renderPaymentTermPicker() {
    return this.state.termPaymentList.length > 0 ? (
      <RNPickerSelect
        Icon={() => {
          return device == 'android' ? (
            <Image
              style={{height: 20, width: 20, marginRight: 0}}
              source={Images.icons.DropDown}
            />
          ) : null;
        }}
        ref={(el) => {
          this._refpaymentpicker = el;
        }}
        style={pickerStyle1}
        placeholder={{label: Languages.txtPickerPlaceholder, value: null}}
        useNativeAndroidPickerStyle={false}
        items={this.state.termPaymentList}
        onValueChange={(text) => {
          if (text && text != this.state.paymentTerm) {
            let tempSource = [...this.state.termPaymentList];
            let filteredAttribs = tempSource.filter((e) => e.value === text);
            this.setState({
              paymentTerm: filteredAttribs[0].label,
              paymentTerm_id: filteredAttribs[0].value,
            });
          }
        }}
      />
    ) : null;
  }

  renderShipmentTermPicker() {
    return this.state.termShipmentList.length > 0 ? (
      <RNPickerSelect
        Icon={() => {
          return device == 'android' ? (
            <Image
              style={{height: 20, width: 20, marginRight: 0}}
              source={Images.icons.DropDown}
            />
          ) : null;
        }}
        ref={(el) => {
          this._refshipmentpicker = el;
        }}
        style={pickerStyle1}
        placeholder={{label: Languages.txtPickerPlaceholder, value: null}}
        useNativeAndroidPickerStyle={false}
        items={this.state.termShipmentList}
        onValueChange={(text) => {
          if (text && text != this.state.shipmentTerm) {
            let tempSource = [...this.state.termShipmentList];
            let filteredAttribs = tempSource.filter((e) => e.value === text);
            this.setState({
              shipmentTerm: filteredAttribs[0].label,
              shipmentTerm_id: filteredAttribs[0].value,
            });
          }
        }}
      />
    ) : null;
  }
}

const mapStateToProps = (state) => {
  return {
    isFetching: state.status.type == "CHANGE_STOCKLINE_PENDING" ? true : false,
  };
};

export default connect(mapStateToProps, undefined, undefined, {
  forwardRef: true,
})(StatusRemainingDetail);
