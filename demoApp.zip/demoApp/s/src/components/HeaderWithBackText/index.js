import React, { PureComponent } from "react";
import { View, TouchableOpacity, I18nManager, Image, Text, StatusBar, Platform } from "react-native";
import styles from "./styles";
import {
  Styles,
  Images,
  Languages
} from "@common";

export default class HeaderWithBackText extends PureComponent {
  render() {
    const {showBack = true, title , navigation , moreOptionText, onMoreOptionPress, disabledBtn=false } = this.props;
    return (
      <View style={Styles.Common.headerWrapper}>
        {Platform.OS == 'ios' &&
          <StatusBar translucent barStyle="dark-content" />
        }
          {/* left icon */}
          <View style={styles.leftIconHeaderContainer}>
            {showBack &&
              <TouchableOpacity
                style={styles.leftIconHeaderContainerTouchable}
                onPress={() => {
                  navigation.pop();
                }}>
                <View style={styles.toolbarLeftIconTextWarpper}>
                  <Image source={Images.icons.back}
                    style={[
                      styles.toolbarIcon,
                      I18nManager.isRTL && {
                        transform: [{ rotate: "180deg" }],
                      },
                    ]}/>
                    {/*<Text style={styles.toolbarLeftIconText}>{Languages.Back}</Text>*/}
                </View>
              </TouchableOpacity>
            }
          </View>

          {/* center icon */}
          <View style={styles.centerHeaderContainer}>
            <Text style={styles.headerTitleStyle}>
              {title}
            </Text>
          </View>

          {/* right icon */}
          <View style={styles.rightIconHeaderContainer}>
            {moreOptionText &&
              <TouchableOpacity onPress={onMoreOptionPress} style={styles.toolbarRightTextWarpper} disabled={disabledBtn}>
                <Text style={styles.toolbarRightText}>{moreOptionText}</Text>
              </TouchableOpacity>
            }
          </View>
      </View>
    );
  }
}
