import { StyleSheet, Platform } from "react-native";
import { Color, Styles, Device } from "@common";

export default StyleSheet.create({
  leftIconHeaderContainer:{
    // backgroundColor:'orange',
    flex:0.25,
    justifyContent:'center',
    alignItems:'flex-start',
  },
  leftIconHeaderContainerTouchable:{
    // backgroundColor:'orange',
    flex:1,
    justifyContent:'center',
    paddingRight:10,
  },
  toolbarIcon:{
    resizeMode: "contain",
    opacity: 0.8,
    ...Platform.select({
      ios: {
        width: Styles.width > 320 ? 22 : 20,
        height: Styles.width > 320 ? 22 : 20,
        marginLeft: Styles.width > 320 ? 15 : 10,
      },
      android: {
        width: Styles.width > 360 ? 22 : 20,
        height: Styles.width > 360 ? 22 : 20,
        marginLeft: Styles.width > 360 ? 15 : 15,
      },
    }),
    tintColor:Color.black,
  },
  toolbarLeftIconTextWarpper:{
    ...Platform.select({
      ios: {
        marginLeft:Styles.width > 320 ? 0 : 4,
      },
      android: {
        marginLeft:Styles.width > 360 ? 1 : 1,
      },
    }),
    flexDirection:'row',
    alignItems: "center",
    justifyContent:'center',
  },
  toolbarLeftIconText:{
    color:Color.primary,
    resizeMode: "contain",

    marginLeft: 4,
    opacity: 0.8,
    ...Platform.select({
      ios: {
        fontSize:Styles.width > 320 ? 18 : 16,
      },
      android: {
        fontSize:Styles.width > 360 ? 18 : 16,
      },
    }),
  },

  centerHeaderContainer:{
    // backgroundColor:'blue',
    flex:0.5,
    justifyContent:'center',
    alignItems:'center',
  },
  headerTitleStyle:{
    color: Color.black,
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 18 : 15,
      },
      android: {
        fontSize: Styles.width > 360 ? 18 : 16,
      },
    }),
    fontWeight:'500',
    textAlign: "center",
    alignSelf:'center',
  },

  rightIconHeaderContainer:{
    // backgroundColor:'red',
    flex:0.25,
    opacity: 0.8,
    justifyContent:'center',
    alignItems:'flex-end',
  },
  toolbarRightTextWarpper: {
    // backgroundColor:'pink',
    marginRight: 18,
    alignItems: "center",
    justifyContent:'center',
  },
  toolbarRightText:{
    ...Platform.select({
      ios: {
        fontSize:Styles.width > 320 ? 18 : 16,
      },
      android: {
        fontSize:Styles.width > 360 ? 18 : 16,
      },
    }),
    color:Color.primary,
    fontWeight:'600'
    // marginRight: 22,
  },
});
