/** @format */

import { StyleSheet,Platform } from "react-native";
import { Color, Styles } from "@common";

export default StyleSheet.create({
  mainWrapper: {
    flexDirection:'row',
    justifyContent:'center',
    paddingVertical:16,
    paddingHorizontal:16,
    borderColor:Color.white,
  },
  addonsDetailContainer: {
    flex:0.6,
    flexDirection:'column',
    justifyContent:'center',
    // paddingVertical:8,
  },
  titleText: {
    color:Color.white,
    fontWeight:'500',
    ...Platform.select({
      ios: {
        fontSize : Styles.width > 320 ? 20 : 16,
      },
      android: {
        fontSize : Styles.width > 360 ? 20 : 16,
      },
    }),
  },
  descText: {
    color:'#c2c2c2',
    marginTop:4,
    ...Platform.select({
      ios: {
        fontSize : Styles.width > 320 ? 14 : 12,
      },
      android: {
        fontSize : Styles.width > 360 ? 14 : 13,
      },
    }),
  },
  priceText: {
    color:Color.primary,
    marginTop:4,
    ...Platform.select({
      ios: {
        fontSize : Styles.width > 320 ? 18 : 13,
      },
      android: {
        fontSize : Styles.width > 360 ? 18 : 13,
      },
    }),
  },

  addonsAddRemovePriceContainer:{
    flex:0.4,
    alignItems:'flex-end',
  },
  addonsAddRemoveContainer:{
    flexDirection:"row",
  },
  addRemoveIconWrapper:{
    justifyContent:'center',
    alignItems:'center',
  },
  addRemoveIcon:{
    tintColor:'#ab610f', //Color.primary, //'#77440c',
    ...Platform.select({
      ios: {
        height: Styles.width > 320 ? 35 : 30,
        width: Styles.width > 320 ? 35 : 30,
      },
      android: {
        height: Styles.width > 360 ? 35 : 35,
        width: Styles.width > 360 ? 35 : 35,
      },
    }),
  },
  addonsQtyWrapper:{
    // backgroundColor:'rgba(207, 207, 207,0.5)',
    justifyContent:'center',
    alignItems:'center',
    paddingHorizontal:10,
  },
  addonsQtyText:{
    color:Color.white,
    fontWeight:'300',
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 30 : 20,
        marginBottom:Styles.width > 320 ? 5 : 0,
      },
      android: {
        fontSize: Styles.width > 360 ? 30 : 25,
        marginBottom:Styles.width > 360 ? 5 : 0,
      },
    }),
  },
  addonsPriceContainer:{
    // backgroundColor:'orange',
    alignItems:'center',
    marginTop:6,
    ...Platform.select({
      ios: {
        marginRight: Styles.width > 320 ? 30 : 20,
      },
      android: {
        marginRight: Styles.width > 360 ? 30 : 30,
      },
    }),
  },
  addonsPriceText:{
    color:Color.white,
    // fontWeight:'500',
    // textAlign:'center',
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 20 : 20,
      },
      android: {
        fontSize: Styles.width > 360 ? 20 : 20,
      },
    }),
  },

});
