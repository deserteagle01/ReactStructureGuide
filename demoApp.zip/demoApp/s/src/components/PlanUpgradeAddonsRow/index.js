/** @format */

import React from "react";
import { View, Image, Text, TouchableOpacity } from "react-native";

import { Images } from "@common";
import styles from "./style";
import { log } from "@app/Omni";

export default class PlanUpgradeAddonsRow extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      item:this.props.item,
      count:0,
      price:0,
    };
  }

  componentDidMount() {
    if (this.props.onRef) {
			this.props.onRef(this);
    }
  }

	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

  onRemoveAddons = () => {
    let tempCount = this.state.count;
    if(tempCount > 0){
      tempCount = tempCount - 1;
    }
    this.changeQty(tempCount);
  }
  onAddAddons = () => {
    let tempCount = this.state.count;
    tempCount = tempCount + 1;

    this.changeQty(tempCount);
  }
  changeQty(tempCount){
    let tempPrice = this.state.price;
    let tempItem = this.state.item;
    tempPrice = tempCount * this.props.item.price;
    tempItem.total_price = tempPrice;
    tempItem.total_qty = tempCount;

    this.setState({count : tempCount, price: tempPrice},() => {
      this.props.onChangeAddons();
    });
  }

  render() {
    const { item, count, price } = this.state;
    return (
      <View style={[styles.mainWrapper,{borderBottomWidth : this.props.isLastItem ? 0 : 1}]}>
        <View style={styles.addonsDetailContainer}>
            <Text style={styles.titleText}>{item.name}</Text>
            <Text style={styles.descText}>{item.description}</Text>
            <Text style={styles.priceText}>
            {item.bundle == 0 ?
              "$"+(item.price != undefined ? item.price.toFixed(2) : item.price)+ "/" + (!item.bundle_text ? "" : item.bundle_text) + "/" + item.unit
              :
              "$"+(item.price != undefined ? item.price.toFixed(2) : item.price)+ " per " + item.bundle + " " + item.bundle_text
            }
            </Text>
        </View>
        <View style={styles.addonsAddRemovePriceContainer}>
            <View style={styles.addonsAddRemoveContainer}>
                <TouchableOpacity style={styles.addRemoveIconWrapper} onPress={this.onRemoveAddons}>
                    <Image source={Images.icons.minus} style={styles.addRemoveIcon} />
                </TouchableOpacity>
                <View style={styles.addonsQtyWrapper}>
                    <Text style={styles.addonsQtyText}>{count}</Text>
                </View>
                <TouchableOpacity style={styles.addRemoveIconWrapper} onPress={this.onAddAddons}>
                    <Image source={Images.icons.add} style={styles.addRemoveIcon} />
                </TouchableOpacity>
            </View>
            <View style={styles.addonsPriceContainer}>
              <Text style={styles.addonsPriceText}>{"$"+ (price != undefined ? price.toFixed(2) : price)}</Text>
            </View>
        </View>

      </View>
    );
  }
}
