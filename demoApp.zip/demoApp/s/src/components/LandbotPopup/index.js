import React, { Component } from "react";
import { View, SafeAreaView, TouchableOpacity, Image } from "react-native";
import { Images } from "@common";
import styles from "./styles";
import { log } from "@app/Omni";
import AnimatedModal from "react-native-root-modal";
import { WebView } from 'react-native-webview';
import { AppConfig } from "@common";

export default class LandbotPopup extends Component {

  constructor(props){
    super(props);
    this.state = {
      visible : false,
      landbot_url : "",
      landbot_accent: "",
    }
  }

  open = (landbot_url, landbot_accent) => {
    this.setState({landbot_url: landbot_url, landbot_accent:landbot_accent},() => {
      this.setState({ visible : true });
    });
  }

  close = () => {
    this.setState({ visible: false });
    this.props.onLandboatClose();
  }

  _onNavigationStateChange(status) {
    log(status.url)
    if(status.url.includes("/?call=1")){
      this.close();
    } else if(status.url.includes("compare-plans")){
      this.close();
      this.props.navigation.push("PlanListScreen");
    } else if(status.url.includes("upgrade-addons")){
      this.close();
      this.props.navigation.push("PlanUpgradeAddonsScreen");
    }
  }

  render() {
    return (
      <SafeAreaView style={{ flex:1, backgroundColor: 'transparent' }}>
      <AnimatedModal visible={this.state.visible}
        style={styles.modalBoxWrap}
        backdropPressToClose={false}>
            <View style={styles.mainContainer} >
                <WebView
                      source={{ uri: this.state.landbot_url }}
                      startInLoadingState
                      style={styles.webviewContainer}
                      onNavigationStateChange={(status) =>
                          this._onNavigationStateChange(status)
                      }
                      javaScriptEnabled={true}
                      scalesPageToFit={true}
                      allowsInlineMediaPlayback={true}  //for android to play video in webview -> android:hardwareAccelerated="true"
                      bounces={false}
                  />
                  <TouchableOpacity style={styles.backBtnContainer} onPress={this.close}>
                      <Image source={Images.icons.close} style={styles.backIcon} resizeMode={"contain"}/>
                  </TouchableOpacity>
            </View>
      </AnimatedModal>
      </SafeAreaView>
    );
  }
}
