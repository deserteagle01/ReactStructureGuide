/** @format */

import { StyleSheet, Dimensions, Platform } from "react-native";
import { Styles, Device } from "@common";
const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  modalBoxWrap: {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    position:'absolute',
    backgroundColor:'white',
  },
  safeAreaViewContainer:{
    flex:0,
    backgroundColor:'black'
  },
  mainContainer:{
    flex: 1,
    backgroundColor:'white',
  },

  backBtnContainer:{
    // top: 40,
    ...Platform.select({
      ios: {
        top: Device.isIphoneX ? 40 : 10,
      },
      android: {
        top: 0,
      },
    }),
    right: 5,
    // bottom: 0,
    position:'absolute',
    padding:15,
  },
  backIcon:{
    width:25,
    height:25,
    tintColor:'#858585'
  },
  webviewContainer: {
    flex: 1,
    backgroundColor:'transparent',
  },

});
