import React, { PureComponent } from "react";
import PropTypes from "prop-types";
import { View, FlatList, Image, Text, ScrollView, ActivityIndicator } from "react-native";
import { connect } from "react-redux";
import { withTheme, Languages, Images } from "@common";
import { ProductRow } from "@components";
import { toast,log } from "@app/Omni";
import styles from "./styles";
import { firebase } from '@react-native-firebase/analytics';
class StoneList extends PureComponent {
  static propTypes = {
    onViewProductScreen: PropTypes.func,
    navigation: PropTypes.object,
  };

  constructor(props){
    super(props);
    this.state = {
      isRefreshFetch : false,
    }
    this.pageNumber = 1;
  }

  componentDidMount() {
    const { fetchStockList, navigation, filtersObj, fetchFilterTags, searchText} = this.props;
    fetchFilterTags();

    this.pageNumber = 1;
    let stoneFilter = {
      "search":searchText,
      "filter":filtersObj,
    }
    fetchStockList(this.pageNumber, stoneFilter);
    firebase.analytics().setCurrentScreen("StoneList Screen");
    this.didBlurSubscription = navigation.addListener('didBlur',() => {
      this.pageNumber = 1;
      this.didBlurSubscription.remove();
    });
  }

  componentWillReceiveProps(nextProps) {
    // log("----------------------- componentWillReceiveProps stone listlist ================= ");
    // log(nextProps)
    if(nextProps.error != null && nextProps.type == 'FETCH_STOCKLIST_FAILURE'){
      toast(nextProps.error)
    }
    const { fetchStockList, type,} = this.props;
    if(this.props != nextProps){
      if((nextProps.filtersObj && this.props.filtersObj !== nextProps.filtersObj) || (this.props.searchText != nextProps.searchText)){
       this.pageNumber = 1;
        let stoneFilter = {
          "search":nextProps.searchText,
          "filter":nextProps.filtersObj,
        }
        fetchStockList(this.pageNumber, stoneFilter);
      }
    }
  }

  renderRow = (product) => {
    return (
      <ProductRow
        product={product.item}
        navigation={this.props.navigation}
        onPress={() => this.onRowClickHandle(product.item)}
        from={"searchList"}
        tags={"recently_submitted"}
      />
    );
  }

  onRowClickHandle = (product) => {
    if(product && product.stone_ids && product.stone_ids.length > 1){
      this.props.navigation.push("StoneGroupListScreen", {"product" : product});
    }else{
      this.props.navigation.push("DetailScreen", {"product" : product, "from" : "home"});
    }
  }

  onEndReached = () => {
    const { isFetchingOwnerList, stillFetch, fetchStockList, isConnected, filtersObj, searchText } = this.props;

    if (isConnected && !isFetchingOwnerList && stillFetch) {
      this.pageNumber = this.pageNumber + 1;
      let stoneFilter = {
        "search":searchText,
        "filter":filtersObj,
      }
      fetchStockList(this.pageNumber, stoneFilter);
    }
    else {
      this.setState({isShowLoadingSpinner: false});
    }
  }

  onRefreshHandle = () => {
    const { fetchStockList, isConnected, filtersObj, searchText } = this.props;
    this.pageNumber = 1;
    if(isConnected){
      let stoneFilter = {
        "search":searchText,
        "filter":filtersObj,
      }
      fetchStockList(this.pageNumber, stoneFilter);
    }else{
      toast(Languages.InternetError)
    }
  }

  renderFooter = () => {
    //it will show indicator at the bottom of the list when data is loading otherwise it returns null
    const { stillFetch } = this.props;
    if ( stillFetch ) { 
      return (
        <View style={styles.loadingSpinner}>
          <ActivityIndicator size='large' />
        </View>
      );
    } else {
      return null;
    }
  };

  render() {
    const { stockList, isFetching } = this.props;
    
    return (
      <View style={styles.mainContainer}>
      {isFetching ?
        <View style={styles.loaderContainer}>
            <View style={styles.loaderImageContainer}>
                <Image style={styles.loaderImageIcon} source={Images.icons.loader}/>
            </View>
            <View style={styles.loaderTextContainer}>
                <Text style={styles.loaderText}>{Languages.loading}</Text>
            </View>
        </View>
        :
        <View>
          {stockList.length > 0 ?
            <FlatList
              keyExtractor={(item, index) => `${item.stone_detail_id}`}
              data={stockList}
              renderItem={this.renderRow}
              onEndReached={this.onEndReached}
              refreshing={this.state.isRefreshFetch}
              onRefresh={this.onRefreshHandle}
              initialListSize={4}
              onEndReachedThreshold={0.5}
              ListFooterComponent={this.renderFooter.bind(this)}
            />
            :
            <View style={styles.notFoundContainer}>
                <View style={styles.imageContainer}>
                    <Image style={styles.imageIcon} source={Images.icons.attention}/>
                </View>
                <View style={styles.textContainer}>
                    <Text style={styles.text}>{Languages.recordsNotFound}</Text>
                </View>
            </View>
          }
        </View>
      }
      </View>

    );
  }
}

const mapStateToProps = (state) => {
  // log('--------- mapStateToProps stone listlist-------------')
  // log(state)
  return {
    isConnected: state.netInfo.isConnected,
    userData: state.user.user,
    stockList: state.stockList.list,
    isFetching:state.stockList.isFetchingList,
    stillFetch:state.stockList.stillFetch,
    error:state.stockList.error,
    type:state.stockList.type,
  };
};

function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  const StockListRedux = require("@redux/StockListRedux");
  const FilterTagRedux = require("@redux/FilterTagRedux");
  const { isConnected } = stateProps;
  return {
    ...ownProps,
    ...stateProps,
    fetchStockList: (pageNumber, stoneFilter) => {
      if(isConnected){
        StockListRedux.actions.fetchStockList(dispatch, pageNumber, stoneFilter)
      }else{
        toast(Languages.InternetError)
      }
    },
    fetchFilterTags: () => {
      if(isConnected){
        FilterTagRedux.actions.fetchFilterTags(dispatch);
      }else{
        toast(Languages.InternetError)
      }
    },
  };
}

export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    mergeProps
  )(StoneList)
);
