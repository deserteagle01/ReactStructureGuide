import React, {PureComponent} from 'react';
import {
  Text,
  TouchableOpacity,
  View,
  TextInput,
  Keyboard,
  SafeAreaView,
  Image,
  FlatList,
} from 'react-native';
import {Color, Languages, Images} from '@common';
import Modal from 'react-native-modal';
import styles from './styles';
import {log, toast} from '@app/Omni';
import {connect} from 'react-redux';
import moment from "moment";
class OfferList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      displayOfferList: [],
    };
  }

  componentWillMount() {}

  componentWillUnmount() {}

  open = () => {
    this.setState({visible: true, displayOfferList: this.props.offerList});
  };

  cancel = () => {
    this.setState({visible: false});
  };

  renderHeader() {
    return (
      <View style={styles.headerContainer}>
        <TouchableOpacity style={{marginLeft: '5%'}} onPress={this.cancel}>
          <Image source={Images.icons.closeNew} style={styles.backIcon} />
        </TouchableOpacity>
        <Text style={styles.txttitle}>{Languages.txtTitleOfferList}</Text>
      </View>
    );
  }

  _renderItem = ({item, index}) => {
    return (
      <View style={{width: '100%'}}>
        <View style={{marginLeft: '5%', width: '95%', marginVertical: 10}}>
          <Text style={styles.contactname}>
            {item.contact_name}
            <Text style={styles.email}>{' (' + item.email + ')'}</Text>
          </Text>

          <View style={{flexDirection:'row', alignItems:'center'}}>
            <View style={styles.tagContainer}>
              <Text style={styles.contactname}>
                {item.price + ' ' + item.currency_name}
              </Text>
            </View>
            <View style={styles.shipContainer}>
              <Text style={styles.contactname}>{' ' + item.shipment_terms_id }</Text>
            </View>
          </View>
          <Text style={styles.txtdate}>{ moment.parseZone(item.date).format("MMMM DD, YYYY, HH:mm") }</Text>

        </View>
        <View style={styles.seprator1}>
          <View style={styles.sepratorContainer}></View>
        </View>
      </View>
    );
  };

  render() {
    return (
      <Modal
        hasBackdrop={true}
        isVisible={this.state.visible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={{margin: 0}}
        onBackButtonPress={this.cancel}
        onBackdropPress={this.cancel}>
        {/* <View style={{flex:1, backgroundColor:'white'}}> */}
        <SafeAreaView style={styles.flexContainer} />
        <SafeAreaView style={styles.customSafearea}>
          <View style={styles.viewContainer}>
            {this.renderHeader()}
            <FlatList
              style={styles.contactlist}
              showsVerticalScrollIndicator={false}
              data={this.state.displayOfferList}
              renderItem={(item, index) => this._renderItem(item, index)}
              keyExtractor={(item, index) => index.toString()}
              extraData={this.state.displayOfferList}
            />
          </View>
        </SafeAreaView>
      </Modal>
    );
  }
}
export default connect(undefined, undefined, undefined, {forwardRef: true})(
  OfferList,
);
