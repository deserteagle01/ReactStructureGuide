
import React, {PureComponent, useRef} from 'react';
import {Text, TouchableOpacity, View, TextInput,ScrollView, Keyboard,Dimensions, SafeAreaView, Image, ActivityIndicator} from 'react-native';
import {Color, Languages, Images} from '@common';
import Modal from 'react-native-modal';
import styles from './styles';
import {log, toast} from '@app/Omni';
import { connect } from "react-redux";
import ImagePicker from 'react-native-image-picker';
const { width, height } = Dimensions.get("window");

class ImageUpload extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      selectedList: this.props.selectedList
    };
  }

  componentWillMount() {}

  componentWillUnmount() {}

  componentWillReceiveProps(nextProps) {
    if(nextProps != this.props){
        if(nextProps.stockLineType == "UPLOAD_LINEIMAGES_SUCCESS" && this.props.stockLineType == "UPLOAD_LINEIMAGES_PENDING"){
            this.cancel();
            this.props.changeButton();
        }
        if(nextProps.stockLineType == "UPLOAD_LINEIMAGES_FAILURE" && this.props.stockLineType == "UPLOAD_LINEIMAGES_PENDING"){
            alert("Image upload failed");
        }
    }
  }

  open = () => {
    this.setState({
      visible: true,
      selectedList: this.props.selectedList
    });
  };

  cancel = () => {
    this.setState({visible: false});
  };

  selectImages(data, index) {
    const options = {
        quality: 1.0,
        storageOptions: {
          skipBackup: true,
        },
    };
    ImagePicker.showImagePicker(options, response => {
        if (response.didCancel) {
          console.log('User cancelled photo picker');
        } else if (response.error) {
          console.log('ImagePicker Error: ', response.error);
        } else if (response.customButton) {
          console.log('User tapped custom button: ', response.customButton);
        } else {
          let fileSize = ((response.fileSize/1024)/1024);
          if(fileSize > 5){
            alert(Languages.txtImageAlert);
          }else{
            let tempResponse = {
              data: response.data,
              uri: response.uri,
            };
            tempResponse.filename = Date.parse(new Date())+".png";
            let imgArray = data.hasOwnProperty("images") ? data.images : [];
            imgArray.push(tempResponse);
            const temp_list = [...this.state.selectedList];
            temp_list[index] = { ...temp_list[index], images: imgArray };
            this.setState({selectedList: temp_list});
          }
        }
      });
  }

  removeImage(listIndex, index) {
    const temp_list = [...this.state.selectedList];
    let imgArray = temp_list[listIndex].images;
    imgArray.splice(index, 1);
    temp_list[listIndex] = { ...temp_list[listIndex], images: imgArray };
    this.setState({selectedList: temp_list});
  }

  uploadPress() {
   let remianingArray =  this.state.selectedList.filter((e) => !e.hasOwnProperty("images") || e.images.length <= 0);
   if(remianingArray.length > 0){
        alert(Languages.imageEmptyError)
    }
    else{
        let params = {
            model: "vendor.stock.line"
       };
        var line_values = []; 
        for (var i = 0; i < this.state.selectedList.length; i++) {
            let currentObj = this.state.selectedList[i];
            let tempobj = { stock_line_id: currentObj.id };
            tempobj.images = currentObj.images
            line_values.push(tempobj);
        }
        params.line_values = line_values
        this.props.startUpload(params);   
   }
  }

  renderHeader(){
    return(
      <View style={styles.headerContainer}>
        <TouchableOpacity  style={{marginLeft: 20}} onPress={this.cancel}>
          <Image
            source={Images.icons.closeNew}
            style={styles.backIcon} />
        </TouchableOpacity>
        <Text style={styles.txttitle}>{this.props.display_name}</Text>
        {this.state.isReadOnly  ?
          <View style={{marginRight: 20}}>
          </View>
        :
          <TouchableOpacity style={{marginRight: 20}} onPress={() => this.uploadPress()}>
            <Image
                source={Images.icons.check_mark}
                style={styles.checkIcon} />
          </TouchableOpacity>
        }
      </View>
    )
  }

  render() {
    return (
      <Modal
        hasBackdrop={true}
        isVisible={this.state.visible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={{margin: 0}}
        onBackButtonPress={this.cancel}
        onBackdropPress={this.cancel}>

        <SafeAreaView style={styles.flexContainer} />
        <SafeAreaView style={styles.customSafearea}>
            <View style={styles.viewContainer}>
                {this.renderHeader()}
                <ScrollView horizontal={false}>
                    {this.renderLines()}
                </ScrollView>
            </View>
            {this.props.isUploading ?  
            <View style={{position:'absolute',top: height/2,alignSelf:'center'}}>
                <ActivityIndicator size="small" color="black" /> 
            </View>        
            : null}
        </SafeAreaView>
      </Modal>
    );
  }

  renderLines() {
      return this.state.selectedList.map((data, index) => {
      if(!data.image_uploaded){
        return (
            <View style={styles.lineView}>
                <View style={styles.lineContainer}>
                    <View style={{flex:0.5}}>
                        <Text style={styles.title}>{Languages.PackNo+": "}<Text style={styles.subText}>{data.pack_no}</Text></Text>
                        <Text style={styles.title}>{Languages.block+": "}<Text style={styles.subText}>{data.block_no}</Text></Text>
                        <Text style={styles.title}>{Languages.Finishing+": "}<Text style={styles.subText}>{data.finishing}</Text></Text>
                    </View>
                    <View style={styles.selectbt}>
                        <TouchableOpacity style={styles.firstButtonContainer} onPress={() => this.selectImages(data, index)}>
                            <Text style={styles.firstButtonText} numberOfLines={1}>{ Languages.txtImageUplaodbt }</Text>
                        </TouchableOpacity>
                        <Text style={styles.subTextnote}>{Languages.maxSizeNote}</Text>
                    </View>
                </View>
                <ScrollView style={{marginTop:5}} horizontal={true}>
                    {this.renderImages(data, index)}
                </ScrollView>
            </View>
          );
      }else{
          return (null);
      }
      });
  }

  renderImages(data, listIndex) {
    if(data.hasOwnProperty("images") && data.images.length > 0){
        return data.images.map((data, index) => {
            let source = {uri: data.uri};
            return (
                <View style={styles.imageContainer}>
                    <Image
                    source={source}
                    style={{height:"100%", width:"100%"}} />

                    <TouchableOpacity style={{position:"absolute", height:25, width:25,top:0,right:0}} onPress={() => this.removeImage(listIndex, index)}>
                        <Image
                        source={Images.icons.delete_black}
                        style={{height:"100%", width:"100%",backgroundColor:'black'}} />
                    </TouchableOpacity>  
                </View>
            );
        });
      }else{
          return(null);
      }
  }

}

const mapStateToProps = (state) => {
    return {
        stockLineType: state.status.type,
        isUploading: state.status.type == "UPLOAD_LINEIMAGES_PENDING" ? true : false,
   };
  };

export default connect(
  mapStateToProps,
  undefined,
  undefined,
  { forwardRef: true }
)(ImageUpload);