/** @format */

import { StyleSheet, Dimensions } from "react-native";
const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  modalBoxWrap: {
    position: "absolute",
    // width:'100%',
    // height:'100%',
    flex:1,
    zIndex: 9999,
    backgroundColor:'#fff',
  },
  mainContainer:{
    flex:1,
    borderTopWidth:1,
    borderColor:'#e6e6e6',
    marginBottom:140,
  },
});
