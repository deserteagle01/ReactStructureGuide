  /** @format */

import React, { PureComponent } from "react";
import { BackHandler, View } from "react-native";
import { Languages, Images } from "@common";
import Modal from "react-native-modalbox";
import styles from "./styles";
import { log } from "@app/Omni";
import { FilterCollapseList, HeaderRegular } from "@components";
import cloneDeep from 'lodash/cloneDeep';

export default class FilterWidgetModal extends PureComponent {

  constructor(props){
      super(props);
      this.state = {
        listVal : {},
        isOpen : false,
      };
      BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
  }
  handleBackButton = () => {
      if(this.state.isOpen){
        this.setState({isOpen : false});
        this._modalWidget.close()
        return true;
      }
  }
  componentWillUnmount() {
      BackHandler.removeEventListener("hardwareBackPress", this.handleBackButton);
  }

  open = (listVal) => {
      this.setState({listVal: cloneDeep(listVal), isOpen : true},()=>{
        this._modalWidget.open();
      });
  }

  close = () => {
      this._modalWidget.close();
      this.setState({isOpen : false});
  }

  onSaveClick = () => {
      this._modalWidget.close();
      this.props.onSaveWidgetFilter(this.filterlist.state);
  }

  render() {
      const { listVal } = this.state;
      return (
        <Modal
          ref={(com) => (this._modalWidget = com)}
          style={styles.modalBoxWrap}
          keyboardTopOffset={0}
          position="top"
          backdropPressToClose={false}
          swipeToClose={false}
          >
            {/* header */}
            <HeaderRegular navigation={this.props.navigation}
              title={Languages.Filter + ": " + listVal.display_name}
              onBack={this.close}
              moreOptionIcon={Images.icons.check_mark}
              onMoreOptionPress={this.onSaveClick}/>

            {/* content */}
            <View style={styles.mainContainer}>
              <FilterCollapseList
                onRef={el => this.filterlist = el}
                keyVal={listVal.field_name} listVal={listVal} isCollapse={false} isSearch={true} />
            </View>
        </Modal>
      );
  }
}
