/** @format */

import { StyleSheet, Platform, Dimensions, I18nManager } from "react-native";
const { width, height } = Dimensions.get("window");
import { Color, Config, Constants, Device, Styles } from "@common";

export default StyleSheet.create({
  container: {
    marginBottom: 2,
  },
  fullName: {
    fontWeight: "600",
    color: Color.blackTextPrimary,
    backgroundColor: "transparent",
    fontSize: 30,
    marginBottom: 6,
  },
  address: {
    backgroundColor: "transparent",
    fontSize: 15,
    color: "#9B9B9B",
    fontWeight: "600",
    marginBottom: 6,
  },
  textContainer: {
    marginLeft: 10,
    justifyContent: "center",
    width: width*0.65,
    marginRight: 10,
  },
  header: {
    flexDirection: "row",
    //backgroundColor: "#FFF",
    margin: 10,
  },
  avatar: {
    height: width / 4,
    width: width / 4,
    borderRadius: 4,
  },
  loginText: {
    color: "#666",
  },
  textDirection: {
    writingDirection: I18nManager.isRTL ? 'rtl' : 'ltr',
  },
});
