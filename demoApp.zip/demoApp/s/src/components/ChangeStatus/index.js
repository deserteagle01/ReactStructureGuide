
import React, {PureComponent, useRef} from 'react';
import {Text, TouchableOpacity, View, TextInput, Keyboard, SafeAreaView, Image, FlatList} from 'react-native';
import {Color, Languages, Images} from '@common';
import Modal from 'react-native-modal';
import styles from './styles';
import {log, toast} from '@app/Omni';
import { connect } from "react-redux";
import SegmentedControlTab from "react-native-segmented-control-tab";
import { StockStatusList,StatusModal, StatusRemainingDetail } from "@components";
import { Tools } from "@common";
const fullMenu = [Languages.Draft ,Languages.txtTabLive, Languages.txtTabNotLive, Languages.txtTab, Languages.txtTitleStocks];
const liveNotLiveMenu = [Languages.txtTabLive, Languages.txtTabNotLive];
const statusMenu = [Languages.Draft, Languages.txtTab, Languages.txtTitleStocks];
class ChangeStatus extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      isSelectionModalVisible: false,
      selectedIndex: 0,
      stockList: [],
      selectedList: [],
      statusArray: {},
      option: "",
      menu: [],
      openFrom: "",
      isReadOnly: false
    };
  }

  componentWillMount() {}

  componentWillUnmount() {}

  open = (openFrom, isReadOnly) => {
    let stockListWithValue = this.findStocklineStatusWithValue(this.props.stockline_status, openFrom);
    this.setState({
      visible: true,
      option: "",
      selectedIndex: stockListWithValue.selectedIndex,
      stockList: stockListWithValue.stockList,
      statusArray: stockListWithValue.statusArray,
      menu: stockListWithValue.menu,
      openFrom: openFrom,
      isReadOnly: isReadOnly
    });
  };

  findStocklineStatusWithValue(stockline_status, openFrom){
    let draftList = stockline_status && stockline_status.Draft ? stockline_status.Draft.lines : [];
    let liveList = stockline_status && stockline_status.Live ? stockline_status.Live.lines : [];
    let notliveList = stockline_status && stockline_status.Not_Live ? stockline_status.Not_Live.lines : [];
    let bookedList = stockline_status && stockline_status.Booked ? stockline_status.Booked.lines : [];
    let availableList = stockline_status && stockline_status.Available ? stockline_status.Available.lines : [];
    let draftOptions  = stockline_status && stockline_status.Draft ? stockline_status.Draft.options : {};
    let liveOptions = stockline_status && stockline_status.Live ? stockline_status.Live.options : {};
    let notliveOptions = stockline_status && stockline_status.Not_Live ? stockline_status.Not_Live.options : {};
    let bookedOptions = stockline_status && stockline_status.Booked ? stockline_status.Booked.options : {};
    let availableOptions = stockline_status && stockline_status.Available ? stockline_status.Available.options : {};
    let tempDict = {};

    if(openFrom == "liveNotLiveStatus"){
        let data = this.getDataSorted([liveList, notliveList], [liveOptions, notliveOptions]);  
        tempDict.menu = liveNotLiveMenu;
        tempDict = {...tempDict,...data};
        return tempDict;
    }else if(openFrom == "changeStatus"){
        let data = this.getDataSorted([draftList, bookedList, availableList], [draftOptions, bookedOptions, availableOptions]);  
        tempDict.menu = statusMenu;
        tempDict = {...tempDict,...data};
        return tempDict;
    }else{
        //changeStatusMenu
        let data = this.getDataSorted([draftList, liveList, notliveList, bookedList, availableList], [draftOptions, liveOptions, notliveOptions, bookedOptions, availableOptions]);  
        tempDict.menu = fullMenu;
        tempDict = {...tempDict,...data};
        return tempDict;
    }
  }

  getDataSorted(dataArray,statusArray) {
    let tempDict = {};
    for (var i = 0; i < dataArray.length; i++) {
        if(dataArray[i].length > 0){
            tempDict.selectedIndex = i;
            tempDict.stockList = dataArray[i];
            tempDict.statusArray = statusArray[i];
            return tempDict;
        }
        if(i == (dataArray.length - 1)){
          tempDict.selectedIndex = 0;
          tempDict.stockList = dataArray[0];
          tempDict.statusArray = statusArray[0];
          return tempDict;
        }
    }
  }

  cancel = () => {
    this.setState({visible: false});
  };

  closeAddEditModal = () => {
    this._statusRemainingdetail.closeAddEditModal();
  };

  refreshSelectedContact = (contactList) => {
    this._statusRemainingdetail.refreshSelectedContact(contactList);
  };

  selectContact = () => {
    if(this.state.selectedList.length > 0){
        this.setState({isSelectionModalVisible: true});
    }else{
      alert(Languages.txtWarningStatus);
    }
  }

  closeStatusModal(stockline_status) {
    if(Tools.requiredDetailFieldFlow(this.state.option)){
        this._statusRemainingdetail.cancel();
    }
    else{
      this.setState({isSelectionModalVisible: false});
    }
  }

  refreshStockLineData(stockline_status) {
    this.handleIndexChange(this.state.selectedIndex, stockline_status);
  }

  renderHeader(){
    return(
      <View style={styles.headerContainer}>
        <TouchableOpacity  style={{marginLeft: 20}} onPress={this.cancel}>
          <Image
            source={Images.icons.closeNew}
            style={styles.backIcon} />
        </TouchableOpacity>
        <Text style={styles.txttitle}>{this.state.isReadOnly ? Languages.txtViewStatus :Languages.txtTitleStatus}</Text>
        {this.state.isReadOnly  ?
          <View style={{marginRight: 20}}>
          </View>
        :
          <TouchableOpacity style={{marginRight: 20}} onPress={this.selectContact}>
            <Text style={styles.txttitle}>{Languages.txtSelct}</Text>
          </TouchableOpacity>
        }
      </View>
    )
  }
  
  updatedList = (newList) => {
    let tempList = newList.filter((e) => e.isSelected === true);
    this.setState({selectedList: tempList});
  }

  statusSelected = (selectedStatus, value) => {
    this.setState({option: selectedStatus});
    if(Tools.requiredDetailFieldFlow(selectedStatus)){
        this.setState({isSelectionModalVisible: false});
        setTimeout(() => {
          this._statusRemainingdetail.open(selectedStatus, value);
        }, 500)
    }else{
      let tempSelected = [];
      for (var i = 0; i < this.state.selectedList.length; i++) {
        tempSelected.push(this.state.selectedList[i].id)
      } 
      let params = {
        lines: tempSelected,
        option: selectedStatus
      };
      this.props.changeStatus(params);
    }
  }

  changeStatusFromPopup = (contact_ids,price,currency_id, paymentTerm_id, shipmentTerm_id, status_key, booked_untill) => {
    this.setState({option: status_key});
    let tempSelected = [];
    for (var i = 0; i < this.state.selectedList.length; i++) {
      tempSelected.push(this.state.selectedList[i].id)
    }
    let params = {};
    params.lines = tempSelected;
    params.option = status_key;
    params.price = price;
    params.contact_id = contact_ids[0].partner_id;
    params.company_contact_id = contact_ids[0].parent_id;
    params.currency_id = currency_id;
    params.payment_terms_id = paymentTerm_id;
    params.shipment_terms_id = shipmentTerm_id;
    if(status_key == "action_set_to_booked"){
      params.booked_till = booked_untill;
    }
    this.props.changeStatus(params);
  }

  handleIndexChange = (index, stockline_status) => {
    let tempDict = {
      selectedList: [],
      selectedIndex: index
    };
    const { openFrom } = this.state;
    switch (index) {
    case 0 :
      if(openFrom == "liveNotLiveStatus"){
        tempDict.statusArray = stockline_status.Live ? stockline_status.Live.options : {};
        tempDict.stockList = stockline_status.Live ? stockline_status.Live.lines : [];
      }
      else{
        tempDict.statusArray = stockline_status.Draft ? stockline_status.Draft.options : {};
        tempDict.stockList = stockline_status.Draft ? stockline_status.Draft.lines : [];
      }
      break;  
    case 1 :
      if(openFrom == "liveNotLiveStatus"){
        tempDict.statusArray = stockline_status.Not_Live ? stockline_status.Not_Live.options : {};
        tempDict.stockList = stockline_status.Not_Live ? stockline_status.Not_Live.lines : [];
      }else if(openFrom == "changeStatus"){
        tempDict.statusArray = stockline_status.Booked ? stockline_status.Booked.options: {};
        tempDict.stockList = stockline_status.Booked ? stockline_status.Booked.lines : [];
      }
      else{
        tempDict.statusArray = stockline_status.Live ? stockline_status.Live.options: {};
        tempDict.stockList = stockline_status.Live ? stockline_status.Live.lines : [];
      }
      break;
    case 2 :
      if(openFrom == "changeStatus"){
        tempDict.statusArray = stockline_status.Available ? stockline_status.Available.options : {};
        tempDict.stockList = stockline_status.Available ? stockline_status.Available.lines : [];
      }
      else{
        tempDict.statusArray = stockline_status.Not_Live ? stockline_status.Not_Live.options : {};
        tempDict.stockList = stockline_status.Not_Live ? stockline_status.Not_Live.lines : [];
      }
      break;
    case 3 :
        tempDict.statusArray = stockline_status.Booked ? stockline_status.Booked.options : {};
        tempDict.stockList = stockline_status.Booked ? stockline_status.Booked.lines:[];
        break;
    case 4 :
      tempDict.statusArray = stockline_status.Available ? stockline_status.Available.options : {};
      tempDict.stockList = stockline_status.Available ? stockline_status.Available.lines:[];
      break;
      
    default:
        break;
	  }
    this.setState(tempDict);
  };
  
  render() {
    return (
      <Modal
        hasBackdrop={true}
        isVisible={this.state.visible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={{margin: 0}}
        onBackButtonPress={this.cancel}
        onBackdropPress={this.cancel}>

        <SafeAreaView style={styles.flexContainer} />
        <SafeAreaView style={styles.customSafearea}>
            <View style={styles.viewContainer}>
                {this.renderHeader()}
                <SegmentedControlTab
                    borderRadius={6}
                    values={this.state.menu}
                    tabsContainerStyle={styles.segment}
                    tabStyle={styles.tabstyle}
                    activeTabStyle={{backgroundColor: Color.primary}}
                    activeTabTextStyle={styles.activeTabTextStyle}
                    tabTextStyle={styles.tabTextStyle}
                    selectedIndex={this.state.selectedIndex}
                    onTabPress={(index) => this.handleIndexChange(index, this.props.stockline_status)} />
                <View style={{flex:1}}>
                    <StockStatusList
                        isReadOnly={this.state.isReadOnly}
                        updatedList={this.updatedList}
                        stockList={this.state.stockList}
                        selectedIndex={this.state.selectedIndex}
                        onRefresh={() => this.props.onRefresh()}
                        isFetching={this.props.isFetching} />
                </View>

                <StatusModal 
                  startUpload={this.props.startUpload}
                  isUploading={this.props.isUploading}
                  statusSelected={this.statusSelected}
                  selectedList={this.state.selectedList}
                  isLoading={this.props.isLoading}
                  display_name={this.props.display_name}
                  setModalFlag={(isModalVisible) => this.setState({isSelectionModalVisible: isModalVisible})}
                  isSelectionModalVisible={this.state.isSelectionModalVisible}
                  statusArray={this.state.statusArray} />

                <StatusRemainingDetail 
                  preference={this.props.preference}
                  ref={(com) => (this._statusRemainingdetail = com)} 
                  contact_list={[...this.props.contact_list]}
                  currencyList={[...this.props.currencyList]}
                  paymentList={[...this.props.paymentList]}
                  shipmentList={[...this.props.shipmentList]}
                  company_list={[...this.props.company_list]}
                  changeStatus={this.changeStatusFromPopup} 
                  addEditContact={(params) => this.props.addEditContact(params)} />
            </View>
        </SafeAreaView>
      </Modal>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    isLoading: state.status.type == "CHANGE_STOCKLINE_PENDING" ? true : false,
    isFetching: state.status.type == "FETCH_STOCKLINE_PENDING" ? true : false,
    contact_list: state.Contacts.result && state.Contacts.result.contact_list ? state.Contacts.result.contact_list : [],
    company_list: state.Contacts.result && state.Contacts.result.company_list ? state.Contacts.result.company_list : [],
    currencyList: state.Offer.result && state.Offer.result.currency_list ? state.Offer.result.currency_list : [],
    paymentList: state.Offer.result && state.Offer.result.payment_terms_list ? state.Offer.result.payment_terms_list : [],
    shipmentList: state.Offer.result && state.Offer.result.shipment_terms_list ? state.Offer.result.shipment_terms_list : [],
  };
};

export default connect(
  mapStateToProps,
  undefined,
  undefined,
  { forwardRef: true }
)(ChangeStatus);