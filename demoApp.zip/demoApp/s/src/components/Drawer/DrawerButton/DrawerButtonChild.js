/**
 * Created by InspireUI on 27/02/2017.
 *
 * @format
 */

import React, { PureComponent } from "react";
import PropTypes from "prop-types";
import { StyleSheet, View, I18nManager, Text } from "react-native";
import { Styles, Color, Constants, Languages } from "@common";
import { Icon, IconIO } from "@app/Omni";

class DrawerButtonChild extends PureComponent {
  render() {
    const { icon, onPress, text, iconRight, uppercase, colorText } = this.props;
    const transText = this._getText();
    return (
      <View style={[styles.container]}>
        {/* {icon && <Icon name={icon} color={Color.lightTextPrimary} size={20} />} */}
        <Text
          style={[
            styles.text,
            I18nManager.isRTL && { paddingRight: 20 },
            colorText && {
              color: colorText,
            },
          ]}>
          {uppercase ? transText.toUpperCase() : transText}
        </Text>
        {iconRight && <IconIO name={iconRight} color={colorText} size={24} />}
      </View>
    );
  }

  // This method used to translate workds with space beetween them 
  // because key can't have space.
  _getText = () => {
    const { text } = this.props;
    if(!text || text == ""){
      return null;
    }
    else if(text == 'Recently Added'){
      return Languages.Recently_Added;
    }
    else if(text == 'Most Viewed'){
      return Languages.Most_Viewed;
    }
    else if(text == 'Certified Sellers'){
      return Languages.Certified_Sellers;
    }
    else if(text == 'Ladies Watches'){
      return Languages.Ladies_Watches;
    }
    else if(text == 'Latest Deal'){
      return Languages.Latest_Deal;
    }
    else if(text == 'Top Products'){
      return Languages.Top_Products;
    }
    else if(text == 'High Demand'){
      return Languages.High_Demand;
    }
    else{
      return Languages[text] ? Languages[text] : text;
    }
  };
}

const styles = StyleSheet.create({
  container: {
    ...Styles.Common.RowCenterBetween,
    paddingHorizontal: 25,
    paddingVertical: 10,
    flex: 1,
  },
  text: {
    color: Color.blackTextPrimary,
    fontSize: Styles.FontSize.tiny,
    fontFamily: Constants.fontFamily,
  },
});

DrawerButtonChild.propTypes = {
  text: PropTypes.string,
  icon: PropTypes.string,
  iconRight: PropTypes.string,
  uppercase: PropTypes.bool,
  colorText: PropTypes.string,
  onPress: PropTypes.func.isRequired,
};

DrawerButtonChild.defaultProps = {
  text: "Default button name",
  uppercase: false,
  colorText: Color.blackTextPrimary,
  onPress: () => console.log("Pressed"),
};

export default DrawerButtonChild;
