/** @format */

import { Config } from "@common";
import DrawerDefault from "./DrawerDefault";


export default (DrawerDefault);
