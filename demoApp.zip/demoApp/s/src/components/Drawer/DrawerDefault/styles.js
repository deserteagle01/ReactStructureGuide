/** @format */

import { StyleSheet, Platform } from "react-native";
import { Color, Styles, Device } from "@common";

export default StyleSheet.create({
  container: {
    flexGrow: 1,
    flex: 1,
    paddingBottom: 10,
    backgroundColor: "#FFF",
  },
  avatarBackground: {
    flexDirection: "row",
    backgroundColor: "#FFF",
    flexWrap: "wrap",
    padding: 20,
    paddingBottom: 10,
    ...Platform.select({
      ios: {
        paddingTop: Device.isIphoneX ? 50 : 20,
      },
      android: {
        paddingTop: 20,
      },
    }),
  },
  avatar: {
    height: 50,
    width: 50,
    borderRadius: 25,
    borderWidth: 0.5,
    borderColor: Color.DirtyBackground,
    marginBottom: 5,
  },
  fullName: {
    fontWeight: "600",
    color: Color.blackTextPrimary,
    backgroundColor: "transparent",
    fontSize: Styles.FontSize.medium,
    textAlign: "left",
  },
  accountDetail: {
    backgroundColor: "transparent",
    fontSize: 13,
    textAlign: "left",
  },
  textItem: {
    color: Color.blackTextPrimary,
    fontSize: Styles.FontSize.small,
  },
  textContainer: {
    marginLeft: 10,
    justifyContent: "center",
    flex: 1,
  },
});
