/**
 * Created by InspireUI on 27/02/2017.
 *
 * @format
 */

import React, { PureComponent } from "react";
import { View, ScrollView, Image, I18nManager } from "react-native";
import { connect } from "react-redux";
import { Styles, Config, Tools } from "@common";
import { Text } from "@components";
import { DrawerButton } from "../DrawerButton";
import styles from "./styles";
import { toast, toggleDrawer } from "@app/Omni";

class DrawerDefault extends PureComponent {
  constructor(props) {
    super(props);

    const { user } = props.userProfile;
    const current_business_identity = this.props.user.profile?.membership?.current_business_identity;
    // Config Menu
    if (user) {
      this.buttonList = [
        ...Config.menu.listMenu,
        ...Config.menu.listMenuLogged,
      ];
      if(current_business_identity == "Sell Stone" || current_business_identity == "Buy and Sell Stone"){
        this.buttonList = [
          ...Config.menu.listMenu,
          ...Config.menu.sellerMenu,
          ...Config.menu.listMenuLogged,
        ];
      }
    } else {
      this.buttonList = [
        ...Config.menu.listMenu,
        ...Config.menu.listMenuUnlogged,
      ];
    }

    this.state = {
      reload: false,
    };
  }

  /**
   * Update when logged in
   */
  componentWillReceiveProps(props) {
    const { userProfile } = props;
    const current_business_identity = props.user.profile?.membership?.current_business_identity;

    if (userProfile && userProfile.user) {
      this.buttonList = [
        ...Config.menu.listMenu,
        ...Config.menu.listMenuLogged,
      ];
      if(current_business_identity == "Sell Stone" || current_business_identity == "Buy and Sell Stone"){
        this.buttonList = [
          ...Config.menu.listMenu,
          ...Config.menu.sellerMenu,
          ...Config.menu.listMenuLogged,
        ];
      }
    } else {
      this.buttonList = [
        ...Config.menu.listMenu,
        ...Config.menu.listMenuUnlogged,
      ];
    }
  }

  _handlePress = (item) => {
    const { goToScreen, userProfile } = this.props;
    const landbot_seller_url = userProfile.profile?.membership?.landbot_seller_url;

    if(item.routeName == "ShareYourStockScreen"){
      if(landbot_seller_url){
        goToScreen(item.routeName, item.params, item.isReset);
      }else{
        toast("No stock url available for share!");
        toggleDrawer();
      }
    }else{
      goToScreen(item.routeName, item.params, item.isReset);
    }
  };

  render() {
    const { userProfile } = this.props;
    const user = userProfile.user;
    const avatar = Tools.getAvatar(user);
    const name = Tools.getName(user);
    const account_name =  user  && user.account_name? user.account_name : "";
    return (
      <View style={styles.container}>
        <View style={[styles.avatarBackground, Styles.Common.ColumnCenter]}>
          <Image
            source={avatar}
            style={[styles.avatar, I18nManager.isRTL && { left: -20 }]}
          />

          <View style={styles.textContainer}>
            <Text style={styles.fullName}>{name}</Text>
            <Text style={styles.accountDetail}>{account_name}</Text>
            <Text style={styles.accountDetail}>{user ? user.email : ""}</Text>
          </View>
        </View>
        <ScrollView>
          {this.buttonList.map((item, index) => (
            <DrawerButton
              onPress={() => this._handlePress(item)}
              key={index}
              {...item}
            />
          ))}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = ({ user, netInfo }) => ({
  userProfile: user,
  netInfo, // auto reload when netInfo change, also fix reload menu to change language
  user
});

export default connect(mapStateToProps)(DrawerDefault);
