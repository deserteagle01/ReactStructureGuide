/** @format */

import React from "react";
import { StyleSheet, Text, I18nManager, View } from "react-native";
import { Color, Styles } from "@common";



class Circle extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            viewStatus: "false",
        }
    }    

    render() {
        let { status, defaultSize } = this.props;
        
        return (
            
            // <View>
            //     { defaultSize == "detail" ? 
            //         <View style={status=="not_available" ? styles.circleRedDetail : styles.circleGreenDetail}></View>
            //         : 
            //         <View style={status=="not_available" ? styles.circleRed : styles.circleGreen}></View>
            //     }
            // </View>

            
            <View>
                {defaultSize == "detail" ? 
                    <View>
                        { (status=="not_available" || status=="available_on_req") && 
                            <View style={styles.circleRedDetail}></View>
                        }
                        { status=="available" && 
                            <View style={styles.circleGreenDetail}></View>
                        }
                        { status=="reserved" && 
                            <View style={styles.circleYellowDetail}></View>
                        }
                    </View> 
                    :
                    <View>
                        { (status=="not_available" || status=="available_on_req") && 
                            <View style={styles.circleRed}></View>
                        }
                        { status=="available" && 
                            <View style={styles.circleGreen}></View>
                        }
                        { status=="reserved" && 
                            <View style={styles.circleYellow}></View>
                        }
                    </View> 
                }
            </View>
            
        )
    }
}
const styles = StyleSheet.create({
    circleRed: {
        marginTop: 3.5,
        height: 8,
        width: 8,
        backgroundColor: "#b9121b",
        borderRadius: 4,
        justifyContent: "center",
        alignItems: "center"
    },
    circleGreen: {
        marginTop: 3.5,
        height: 8,
        width: 8,
        backgroundColor: "#008000",
        borderRadius: 4,
        justifyContent: "center",
        alignItems: "center"
    },
    circleYellow: {
        marginTop: 3.5,
        height: 8,
        width: 8,
        backgroundColor: "rgb(255, 165, 0)",
        borderRadius: 4,
        justifyContent: "center",
        alignItems: "center"
    },

    circleRedDetail: {
        height: 12,
        width: 12,
        backgroundColor: "#b9121b",
        borderRadius: 6,
        justifyContent: "center",
        alignItems: "center"
    },
    circleGreenDetail: {
        height: 12,
        width: 12,
        backgroundColor: "#008000",
        borderRadius: 6,
        justifyContent: "center",
        alignItems: "center"
    },
    circleYellowDetail: {
        height: 12,
        width: 12,
        backgroundColor: "rgb(255, 165, 0)",
        borderRadius: 6,
        justifyContent: "center",
        alignItems: "center"
    },
});


export default Circle;