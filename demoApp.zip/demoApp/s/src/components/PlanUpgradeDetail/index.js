/** @format */

import React from "react";
import { View, Text } from "react-native";
import { Shimmer } from "@components";
import { connect } from "react-redux";
import { withTheme } from "@common";
import styles from "./style";

class PlanUpgradeDetail extends React.PureComponent {

  render() {
    const { titleText, descText, isLoading } = this.props;
    return (
      <View style={styles.mainWrapper}>
        <Text style={styles.titleText}>{titleText}</Text>
        <Shimmer style={styles.descTextShimmer} visible={!isLoading}>
          <Text style={styles.descText}>{descText}</Text>
        </Shimmer>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    isLoading:state.user.isLoading,
  };
};

export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    null
  )(PlanUpgradeDetail)
);
