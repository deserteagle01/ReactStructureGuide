/** @format */

import { StyleSheet,Platform } from "react-native";
import { Color, Styles } from "@common";

export default StyleSheet.create({
  mainWrapper: {
    flexDirection:'column',
    justifyContent:'center',
    paddingVertical:8,
  },
  titleText: {
    color:Color.white,
    fontWeight:'500',
    ...Platform.select({
      ios: {
        fontSize : Styles.width > 320 ? 18 : 16,
      },
      android: {
        fontSize : Styles.width > 360 ? 18 : 16,
      },
    }),
  },
  descTextShimmer:{
    ...Platform.select({
      ios: {
        marginTop: Styles.width > 320 ? 4 : 4,
        height: Styles.width > 320 ? 17 : 16,
      },
      android: {
        marginTop: Styles.width > 360 ? 5.5 : 4,
        height: Styles.width > 360 ? 18 : 18,
      },
    }),
  },
  descText: {
    color:Color.white,
    marginTop:4,
    ...Platform.select({
      ios: {
        fontSize : Styles.width > 320 ? 14 : 13,
      },
      android: {
        fontSize : Styles.width > 360 ? 14 : 13,
      },
    }),
  },

});
