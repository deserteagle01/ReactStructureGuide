import React, { PureComponent } from "react";
import { View, FlatList, TouchableOpacity, Text, BackHandler, Keyboard} from "react-native";
import { connect } from "react-redux";
import { withTheme, Languages } from "@common";
import { HeaderWithSearch } from "@components";
import styles from "./styles";
import { toast,log } from "@app/Omni";

// let staticData = [{"id":'size-1',"name":"20 mm"},{"id":'size-2',"name":"30 mm"},{"id":'size-3',"name":"40 mm"},{"id":'size-4',"name":"50 mm"},{"id":'color-1',"name":"Red"},{"id":'color-2',"name":"White"},{"id":'color-3',"name":"Pink"},{"id":'color-4',"name":"Beige"},{"id":'color-5',"name":"black"},{"id":'location-1',"name":"multi"},{"id":'location-2',"name":"anywhere 123"},{"id":'location-3',"name":"nearest 123"},{"id":'location-2',"name":"anywhere anywhere"},{"id":'location-3',"name":"nearest anywhere"}];

class SearchTagsList extends PureComponent {

  constructor(props){
    super(props);
    this.state={
      isSearchOpen : false,
      selectedTags : [],
      refresh : false,
      tagData : {},
      keyboardHeight : 50,
      searchText: '',
    }
    Keyboard.addListener('keyboardDidShow', this._keyboardDidShow);
    Keyboard.addListener('keyboardDidHide', this._keyboardDidHide);
    BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
    that = this;
  }

  componentDidMount() {
    const { filterTagList } = this.props;
    this.setTagData(filterTagList);
  }
  componentWillReceiveProps(nextProps) {
    if(this.props.filterTagList != nextProps.filterTagList){
      this.setTagData(nextProps.filterTagList);
    }
  }
  setTagData(filterTagList){
    if(Object.keys(filterTagList).length > 0 && filterTagList.hasOwnProperty('tags')){
      let tagList = filterTagList['tags'].data;

      for(let i=0; i< tagList.length ; i++){
        tagList[i]['is_checked'] = false;
      }
      this.setState({tagData : tagList});
    }
  }

  handleBackButton = () => {
    if(this.state.isSearchOpen){
      this.onCloseSearch();
      this.headerWithSearch.onCloseSearch();
      return true;
    }else{
      return false;
    }
  }
  _keyboardDidShow(e) {
    const { height, screenX, screenY, width } = e.endCoordinates
    that.setState({keyboardHeight : height + 85})
  }
  _keyboardDidHide(e){
    that.setState({keyboardHeight : 0})
  }

  componentWillUnmount() {
    // BackHandler.removeEventListener("hardwareBackPress", this.handleBackButton);
    // Keyboard.removeEventListener('keyboardDidShow', this._keyboardDidShow);
    // Keyboard.removeEventListener('keyboardDidHide', this._keyboardDidShow);
  }

  onSearchClick(){
    this.setState({isSearchOpen : true})
  }
  onClearSearch(){
    let tagList = this.state.tagData;
    for(let i=0; i< tagList.length ; i++){
      tagList[i]['is_checked'] = false;
    }
    this.setState({tagData : tagList, searchText:""})
  }
  onChangeSearchText(text){
    let tagData = this.state.tagData;
    for(let i=0; i< tagData.length ; i++){
      if(tagData[i].is_checked){
        if(!text.includes(tagData[i].name)){
          tagData[i]['is_checked'] = false;
        }
      }
    }
    this.setState({...this.state, searchText : text, tagData: [...tagData] });
  }

  onCloseSearch(){
    let tagData = this.state.tagData;
    for(let i=0; i< tagData.length ; i++){
      tagData[i]['is_checked'] = false;
    }
    this.setState({isSearchOpen : false, tagData : tagData, searchText : ""})
    this.props.onSubmitSearchData("");
  }
  onSubmitSearch(text){
    this.setState({isSearchOpen : false})
    this.props.onSubmitSearchData(text);
  }

  onTagRowClick(item){
    let tagsText = this.headerWithSearch.state.searchText;
    if(item.is_checked){
      item.is_checked = false;
      tagsText = tagsText.replace(new RegExp(item.name+'[ ]?', 'g'),'');

    }else{
      item.is_checked = true;
      if(tagsText == ""){
        tagsText = item.name;
      }else{
        tagsText = tagsText + " " + item.name;
      }
    }
    this.setState({...this.state, searchText : tagsText,tagData: [...this.state.tagData] });
  }

  renderTagItem = (item, index) => {
    return (
      <TouchableOpacity style={item.is_checked ? [styles.tagViewContainer,styles.tagViewSelectedContainer,] : [styles.tagViewContainer,styles.tagViewNotSelectedContainer]} onPress={() => this.onTagRowClick(item)} >
        <Text style={item.is_checked ? [styles.tagText,styles.tagSelectedText] : [styles.tagText,styles.tagNotSelectedText]}>{item.name}</Text>
      </TouchableOpacity>
    );
  }

  render() {
    const { navigation } = this.props;
    return (
        <View style={styles.container}>
            {/* header part */}
            <HeaderWithSearch
              onRef={(el) => {this.headerWithSearch = el}}
              navigation={navigation}
              searchText={this.state.searchText}
              onSubmitSearch={(text) => this.onSubmitSearch(text)}
              onCloseSearch={() => this.onCloseSearch()}
              onSearchClick={() => this.onSearchClick()}
              onClearSearch={() => this.onClearSearch()}
              onChangeSearchText={(text) => this.onChangeSearchText(text)}
              />

            {/* content part */}
            {this.state.isSearchOpen &&
              <View style={styles.tagContainer}>
                <FlatList
                  style={{ marginBottom: this.state.keyboardHeight}}
                  columnWrapperStyle={styles.tagListWrapper}
                  keyboardShouldPersistTaps={'always'}  // prevent keyboard dismiss on click of tags
                  keyExtractor={(item, index) => `${item.stone_detail_id}`}
                  data={this.state.tagData}
                  renderItem={({item, index}) => this.renderTagItem(item, index)}
                  numColumns={20}
                  horizontal={false}
                  showsVerticalScrollIndicator={false}
                />
              </View>
            }
        </View>
    );
  }
}

const mapStateToProps = (state) => {
  // log('--------- mapStateToProps SearchTagsList -------------')
  // log(state.filterTagList)
  return {
    filterTagList: state.filterTagList.result,
  };
};
export default withTheme(
  connect(
    mapStateToProps,
  )(SearchTagsList)
);
