/** @format */

import { Platform, StyleSheet } from "react-native";
import { Device, Color, Styles } from "@common";

export default StyleSheet.create({
  container: {
    // flex: 1,
    backgroundColor: Color.homeHeader,
  },

  tagContainer:{
    // flex:1,
    height:'100%',
    backgroundColor:Color.white,
    paddingHorizontal:12,
    marginTop:8,
    paddingTop:4,
    zIndex:9999,
  },
  tagListWrapper:{
    flexWrap: 'wrap',
    flex: 1
  },
  tagViewContainer:{
    backgroundColor:'#ebebeb',
    marginHorizontal:5,
    marginVertical:5,
    ...Platform.select({
      ios: {
        padding: Styles.width > 320 ? 12 : 6,
      },
      android: {
        padding: Styles.width > 360 ? 12 : 8,
      },
    }),
  },
  tagViewNotSelectedContainer:{
    backgroundColor:'#ebebeb',
  },
  tagViewSelectedContainer:{
    backgroundColor:Color.black,
  },
  tagText:{
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 18 : 13,
      },
      android: {
        fontSize: Styles.width > 360 ? 18 : 15,
      },
    }),
  },
  tagNotSelectedText:{
    color:Color.black,
  },
  tagSelectedText:{
    color:Color.white,
  },
});
