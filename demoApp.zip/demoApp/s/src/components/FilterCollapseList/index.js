/** @format */

import React from "react";
import { View, Text, TouchableOpacity, FlatList, Image, TextInput, Keyboard } from "react-native";
import { log, toast } from "@app/Omni";
import { Languages, Images } from "@common";
import { FilterRaw } from "@components";
import styles from "./styles";
import Collapsible from 'react-native-collapsible';

export default class FilterCollapseList extends React.PureComponent {
  constructor(props) {
    super(props);
    this.filter = {};
    this.state = {
      keyVal : this.props.keyVal,
      listVal : this.props.listVal,
      originalListVal : this.props.listVal,
      showSearch: false,
      searchText: "",
      isSelected : false,
    };
  }

  componentDidMount() {
    if (this.props.onRef) {
			this.props.onRef(this);
		}
  }
  componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

  componentWillReceiveProps(nextProps){
    // log(' ============= nextProps =========')
    // log(nextProps)
    if(this.props != nextProps && this.props.listVal != nextProps.listVal){
      this.setState({keyVal:nextProps.keyVal ,listVal: nextProps.listVal});
    }
  }

  onClick(key){
    if(this.props.onClick != null){
      this.props.onClick(key);
    }else{
      let listVal = this.state.listVal;
      listVal.isCollapse = !listVal.isCollapse;
      this.setState({listVal: { ...listVal } });
    }
  }

  onClearSearch = () => {
    this.setState({searchText : "", listVal: this.state.originalListVal });
  }
  onChangeSearchText = (text) => {
    if(text.trim().length > 0){
      let listVal= {...this.state.originalListVal};
      if(listVal.data && listVal.data.length > 0){
        const result = listVal.data.filter(item => item.name.toLowerCase().includes(text.toLowerCase()));
        if(result.length > 0){
          listVal.data = result;
        }
        this.setState({listVal: listVal});
      }
      this.setState({searchText : text})
    } else {
      this.setState({searchText : text, listVal: this.state.originalListVal});
    }
  }
  onSubmitSearch = () => {
    Keyboard.dismiss();
  }

  onCheckAll(){
    let listVal = this.state.listVal;
    for(let i = 0 ; i < listVal.data.length ; i++){
      listVal.data[i].is_selected = true;
    }
    this.setState({isSelected:true, listVal: {...listVal}}, () => {
      if(this.props.valueChange){
        this.props.valueChange();
      }
    });
  }
  onCheckNone(){
    let listVal = this.state.listVal;
    for(let i = 0 ; i < listVal.data.length ; i++){
      listVal.data[i].is_selected = false;
    }
    this.setState({isSelected:false, listVal: {...listVal} }, () => {
      if(this.props.valueChange){
        this.props.valueChange();
      }
    });
  }
  onChangePreferanceValue(item) {
    let listVal = this.state.listVal;
    let selectedItems = listVal.data.filter(item => item.is_selected);
    this.setState({isSelected: (selectedItems.length > 0),listVal: listVal }, () => {
      if(this.props.valueChange) {
        this.props.valueChange();
      }
    });
  }

  _renderInnerItem = ({ index, item }) => {
		return (
      <View>
        <FilterRaw item={item} isLastItem={index == (this.state.listVal.data.length - 1) ? true : false} is_selected={item.is_selected} onChangePreferanceValue={(item) => this.onChangePreferanceValue(item)}/>
      </View>
		);
	}

  render() {
    const { keyVal, listVal } = this.state;
    let condition = (this.props.isCollapse && listVal.type == 'widget');
    let selectedItems = listVal.data.filter(item => item.is_selected == true);

    return (
      <View style={styles.mainContainer}>
        {this.props.isSearch &&
          <View style={styles.searchMainContainer}>
            <View style={styles.searchContainer} >
                <Image
                  source={Images.icons.search}
                  style={styles.searchIcon}
                />
                <TextInput
                  onTouchStart={this.onSearchClick}
                  style={styles.searchInput}
                  autoCapitalize="none"
                  underlineColorAndroid="transparent"
                  placeholder={Languages.Search}
                  onChangeText={this.onChangeSearchText}
                  onSubmitEditing={this.onSubmitSearch}
                  returnKeyType="done"
                  value={this.state.searchText}
                />
                {this.state.searchText.length > 0 &&
                  <TouchableOpacity style={styles.clearSearchContainer} onPress={this.onClearSearch}>
                    <Image
                      source={Images.icons.close}
                      style={styles.clearSearchIcon}
                    />
                  </TouchableOpacity>
                }
            </View>
          </View>
        }

        <View style={styles.mainTextView}>
          <TouchableOpacity style={styles.headerContainer} onPress={() => this.onClick(keyVal)} disabled={!this.props.isCollapse}>
    			   <Text style={styles.headerTitle}>{listVal.display_name}</Text>
             {!condition ?
               <View style={styles.headerSubTextContainer}>
                   <Text style={styles.headerDividerText}>{' ('}</Text>
                   <TouchableOpacity onPress={() => this.onCheckAll()}>
                      <Text style={styles.headerSubText}>{Languages.CheckAll}</Text>
                   </TouchableOpacity>
                   <Text style={styles.headerDividerText}>{' / '}</Text>
                   <TouchableOpacity style={styles.imageLeftContainer} onPress={() => this.onCheckNone()}>
                      <Text style={styles.headerSubText}>{Languages.None}</Text>
                   </TouchableOpacity>
                   <Text style={styles.headerDividerText}>{')'}</Text>
               </View>
               :
               <View style={styles.headerWidgetContainer}>
                  <View style={styles.headerWidgetTextContainer}>
                    {selectedItems.length > 0 &&
                      <Text style={styles.headerWidgetText}>{' ( ' + selectedItems.length + " " + Languages.Selected + " )"}</Text>
                    }
                  </View>
                  <View style={styles.iconContainer}>
                     <Image source={Images.icons.rightArrow} style={styles.arrowIcon} />
                  </View>
               </View>
             }
          </TouchableOpacity>

          <View style={styles.divider}/>
        </View>

        {!condition &&
            <Collapsible collapsed={listVal.isCollapse}>
              <FlatList
                style={{}}
                showsVerticalScrollIndicator={false}
                scrollEnabled={true}
                data={listVal.data}
                extraData={this.state}
                keyExtractor={(item, index) => index.toString()}
                renderItem={this._renderInnerItem}
              />
            </Collapsible>
        }
      </View>
    );
  }
}
