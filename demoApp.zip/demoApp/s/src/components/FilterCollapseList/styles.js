/** @format */

import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Device, Styles } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  mainContainer:{
    flex:1,
    // borderTopWidth:1,
    borderColor:'#e6e6e6'
  },
  searchMainContainer:{
    height:50,
    paddingHorizontal:16,
    marginBottom:10,
    marginTop:5,
  },
  searchContainer:{
    backgroundColor:'#ebebeb',
    flex:1,
    flexDirection:'row',
    borderColor:'#bfbfbf',
    borderWidth:0.5,
    borderRadius:4,
    // justifyContent:'center',
    alignItems:'center',
    marginTop:8,
    marginBottom:2,
  },
  searchInput:{
    color: Color.black,
    height: 40,
    paddingLeft: 8,
    flex: 1,
    textAlign: "left",
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 16 : 14,
      },
      android: {
        fontSize: Styles.width > 360 ? 16 : 14,
      },
    }),
  },
  searchIcon:{
    width:15,
    height:15,
    tintColor:'#737373',
    marginLeft:10,
  },
  clearSearchContainer:{
    padding:6,
    // backgroundColor:'pink',
  },
  clearSearchIcon:{
    width:15,
    height:15,
    tintColor:'#737373',
  },

  headerContainer:{
    backgroundColor:'white',
    flexDirection:'row',
    paddingHorizontal:16,
  },
  headerTitle:{
    color:Color.black,
    textTransform: 'uppercase',
    fontWeight:'500',
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 18 : 14,
      },
      android: {
        fontSize : width > 360 ? 18 : 14,
      },
    }),
  },
  headerSubTextContainer:{
    flexDirection:'row',
  },
  headerSubText:{
    color:Color.primary,
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 18 : 14,
      },
      android: {
        fontSize : width > 360 ? 18 : 14,
      },
    }),
  },
  headerDividerText:{
    color:Color.black,
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 16 : 14,
      },
      android: {
        fontSize : width > 360 ? 16 : 14,
      },
    }),
  },
  divider:{
    width:20,
    height:3,
    backgroundColor:Color.primary,
    marginTop:10,
    marginBottom:10,
    marginHorizontal:16,
  },
  listContainer:{
    marginTop : 10,
  },

  mainTextView:{
    // flex:1,
    borderTopWidth:1,
    borderColor:'#e6e6e6',
    paddingTop:20,
    paddingBottom:8
  },
  headerWidgetContainer:{
    flex:1,
    flexDirection:'row'
  },
  headerWidgetTextContainer:{
    flex:0.9,
    // backgroundColor:'pink'
  },
  headerWidgetText:{
    color:Color.primary,
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 18 : 14,
      },
      android: {
        fontSize : width > 360 ? 18 : 14,
      },
    }),
  },
  iconContainer:{
    flex:0.1,
  },
  arrowIcon:{
    width:20,
    height:20,
    tintColor:Color.primary
  },
});
