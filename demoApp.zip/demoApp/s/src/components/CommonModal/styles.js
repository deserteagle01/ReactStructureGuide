/** @format */

import { StyleSheet, Dimensions } from "react-native";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  modalBoxWrap: {
    // width: width-50,
    // backgroundColor:'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    position:'absolute',
    backgroundColor:'rgba(0,0,0,0.2)',
  },
});
