/** @format */

import React, { PureComponent } from "react";
import {
  View,
  BackHandler
} from "react-native";
// import Modal from "react-native-modalbox";
import styles from "./styles";
import AnimatedModal from "react-native-root-modal";
import * as Animatable from 'react-native-animatable';

export default class CommonModal extends PureComponent {

  handleViewRef = ref => this.view = ref;
  constructor(props){
    super(props);
    this.state={
      isOpen : false,
      modalVisible : false,
      animationType: "fadeIn"
    }
    BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
  }
  handleBackButton = () => {
    if(this.state.isOpen){
      this.setState({isOpen : false, modalVisible: false});
      // this._modalPhoto.close()
      return true;
    }
  }

	componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.handleBackButton);
	}

  open = () => {
    this.setState({isOpen : true, modalVisible: true, animationType: "fadeIn"},() => {
      // this._modalPhoto.open();
    })
  }

  close = () => {
    // this._modalPhoto.close();
    if(this.view){
      this.view.fadeOut(300).then(endState => {
        if(endState.finished){
          this.setState({isOpen : false, modalVisible: false});
        }
      });
    }
  }

  render() {
    return (
      <AnimatedModal ref={(com) => (this._modalPhoto = com)}
        // animationDuration={2000}
        style={styles.modalBoxWrap}
        // position={"center"}
        backdropPressToClose={false}
        // swipeToClose={false}
        {...this.props}
        visible={this.state.modalVisible}
        >
        <Animatable.View animation={this.state.animationType} duration={300} ref={this.handleViewRef}>
        {this.props.children}
        </Animatable.View>
      </AnimatedModal>
    );
  }

}
