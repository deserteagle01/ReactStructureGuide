import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'transparent',
  },
  trackStyle: {
    height: 4,
  }
});

export default styles;
