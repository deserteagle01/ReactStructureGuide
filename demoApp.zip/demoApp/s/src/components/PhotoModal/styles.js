/** @format */

import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Device } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  modalBoxWrap: {
    position: "absolute",
    width,
    height,
    flex:1,
    zIndex: 9999,
    backgroundColor:'#000'
  },
  iconZoom: {
    position: "absolute",
    right: 0,
    top: 10,
    backgroundColor: "rgba(255,255,255,.9)",
    paddingTop: 4,
    paddingRight: 4,
    paddingBottom: 4,
    paddingLeft: 4,
    zIndex: 9999,
  },
  textClose: {
    color: "#666",
    fontWeight: "600",
    fontSize: 10,
    margin: 4,
    zIndex: 9999,
  },
  image: {
    width,
    height: height - 40,
    zIndex: 9999,
  },
  dotActive: {
    backgroundColor: "rgba(183, 196, 203, 1)",
    width: 10,
    height: 10,
    borderRadius: 20,
  },
  dot: {
    width: 6,
    height: 6,
    backgroundColor: "rgba(183, 196, 203, 1)",
  },

  closeIconContainer:{
    width: 35,
    height : 35,
    borderRadius:50,
    alignItems:'center',
    justifyContent:'center',
    position: "absolute",
    right: 10,
    top: 10,
  },
  closeIcon:{
    width: 20,
    height : 20,
    tintColor:"#fff"
  }

});
