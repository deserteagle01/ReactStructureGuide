  /** @format */

  import React, { PureComponent } from "react";
  import {
    Image,
    TouchableOpacity,
    View, BackHandler, Dimensions
  } from "react-native";
  import Swiper from "react-native-swiper";
  import { Images } from "@common";
  import Modal from "react-native-modalbox";
  import styles from "./styles";
  import ImageViewer from 'react-native-image-zoom-viewer';
  import { ImageCache} from "@components";

  const { width, height } = Dimensions.get("window");

  class PhotoModal extends PureComponent {

    constructor(props){
      super(props);
      this.state = {
        index : 0,
        isOpen : false,
      };
      BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
    }
    handleBackButton = () => {
      if(this.state.isOpen){
        this.setState({isOpen : false});
        this._modalPhoto.close()
        return true;
      }
    }
    componentWillUnmount() {
      BackHandler.removeEventListener("hardwareBackPress", this.handleBackButton);
    }

    open = (index = 0) => {
      this.setState({index: index, isOpen : true},()=>{
        this._modalPhoto.open();
      });
    }

    close = () => {
      this._modalPhoto.close();
      this.setState({isOpen : false});
    }

    render() {
      const {
        imageList,
      } = this.props;

      return (
        <Modal
          ref={(com) => (this._modalPhoto = com)}
          style={styles.modalBoxWrap}
          >
          <Swiper
            height={'90%'}
            activeDotStyle={styles.dotActive}
            removeClippedSubviews={false}
            dotStyle={styles.dot}
            showsPagination={false}
            paginationStyle={{ zIndex: 9999, bottom: -15 }}
            >
            <ImageViewer index={this.state.index} imageUrls={imageList.map((image, index) => ({ url: image.src, width: 1000, height: 1000 }))} renderImage={(props)=> {
                return <ImageCache uri={props.source.uri} style={{width:width, height:"90%",resizeMode:'contain'}}/>
            }} renderIndicator={() => <View />} />
          </Swiper>
          <TouchableOpacity style={styles.closeIconContainer} onPress={this.close}>
              <Image source={Images.icons.close_withoutBack} style={styles.closeIcon} resizeMode={'center'}/>
          </TouchableOpacity>
        </Modal>

      );
    }

  }

  export default PhotoModal
