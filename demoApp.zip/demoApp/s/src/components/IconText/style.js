/** @format */

import { StyleSheet,Platform } from "react-native";
import { Color, Styles } from "@common";

export default StyleSheet.create({
  text: {
    color:Color.white,
    fontWeight:'500',
    marginTop:4,
    textAlign:'center',
    ...Platform.select({
      ios: {
        fontSize : Styles.width > 320 ? 12 : 10,
      },
      android: {
        fontSize : Styles.width > 360 ? 12 : 11,
      },
    }),
  },
  mainWrapper: {
    flexDirection:'column',
    alignItems:'center',
    //justifyContent:'center',
    ...Platform.select({
      ios: {
        padding: Styles.width > 320 ? 10 : 5,
      },
      android: {
        padding: Styles.width > 360 ? 10 : 5,
      },
    }),
  }
});
