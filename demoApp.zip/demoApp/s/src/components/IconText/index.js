/** @format */

import React from "react";
import { TouchableOpacity, Image, Text } from "react-native";

import { withTheme, Styles } from "@common";
import styles from "./style";

class IconText extends React.PureComponent {
  static defaultProps = {
    categories: [],
  };

  render() {
    const { icon, text, iconSize, tintColor, onPress } = this.props;
    return (
      <TouchableOpacity style={styles.mainWrapper} onPress={onPress}>
        <Image source={icon} style={{width:Styles.width > 320 ? iconSize : iconSize - 5,height:Styles.width > 320 ? iconSize : iconSize - 5, tintColor:tintColor}} resizeMode={'contain'}/>
        <Text numberOfLines={2} style={styles.text}>{text}</Text>
      </TouchableOpacity>
    );
  }
}

export default withTheme(IconText);
