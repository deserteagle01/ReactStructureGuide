/** @format */

import React, { PureComponent } from "react";
import {
  Text,
  TouchableOpacity,
  View,
  Image,
  Switch,
  FlatList,
  Platform
} from "react-native";
import { connect } from "react-redux";
import { StonestockDialog } from "@components";
import { Images, Languages, Color} from "@common";
import { log, toast } from "@app/Omni";
import Modal from "react-native-modalbox";
import styles from "./styles";
import { CheckBox } from 'react-native-elements';
import { firebase } from '@react-native-firebase/analytics';
class NotifyMeDialog extends PureComponent {

  constructor(props){
    super(props);
    this.state={
      is_notifyMe:this.props.stoneDetail.is_notify,
      resultList : {},
      isSubscribtionOver : false,
      from : "",
      id:'',
    }
    this.saveClicked = false;
  }

  componentDidMount() {
		if (this.props.onRef) {
			this.props.onRef(this);
		}
    this.props.type = "";
	}

	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

  componentWillReceiveProps(nextProps) {
    // log(' ======================= componentWillReceiveProps notify================')
    // log(nextProps)
    if(nextProps.type == 'SAVE_NOTIFYME_PREFERENCE_FAILURE' && nextProps.error != null){
      if(nextProps.code == 300){
        this.setState({isSubscribtionOver : true});
      }else{
        toast(nextProps.error);
      }
    }
    if(nextProps.type == 'FETCH_NOTIFYME_PREFERENCE_FAILURE' && nextProps.error != null){
      if(nextProps.code == 300){
        this.setState({isSubscribtionOver : true})
      }
    }

    if(this.props !== nextProps){
      if(nextProps.type == 'FETCH_NOTIFYME_PREFERENCE_PENDING'){
        this.setState({is_notifyMe:nextProps.stoneDetail.is_notify})
      }

      if(nextProps.type == 'SAVE_NOTIFYME_PREFERENCE_SUCCESS' && this.saveClicked){
          let msg;
          if(nextProps.stoneDetail.is_notify){
            msg = Languages.notifyMeSaveSuccessMsg1 + this.props.stoneDetail.display_name + Languages.notifyMeSaveSuccessMsg2;
          }else{
            msg = Languages.notifyMeCancelSuccessMsg;
          }
          if(this.props.onNotifyMeClose != undefined){
            this.props.onNotifyMeClose(msg);
          }
          this.saveClicked = false;
      }
    }
  }

  open = (resultList, id, from) => {
    let notifyMeData = {};
    for(let item of Object.keys(resultList)){
        let data = [];
        for(let itemInnner of resultList[item]){
          Object.assign(itemInnner,{'key':item});
          data.push({...itemInnner});
        }
        notifyMeData[item] = data;
    }
    if(from == "product_id"){
      this.setState({is_notifyMe : true});
    }
    this.setState({resultList:notifyMeData, from: from, id: id},() => {
        this._NotifyMeModal.open();
    });
  }

  close = () => {
    this._NotifyMeModal.close();
    this.setState({is_notifyMe:this.props.stoneDetail.is_notify})
    this.props.onNotifyModalClose();
  }

  onClosed = () => {
    this.props.onNotifyModalClose();
  }

  _handleNotifyMeRequest(){
    let value = !this.state.is_notifyMe;

    if(!value){
      if(this.props.stoneDetail.is_notify){
        this._stoneStockModal.open();

      }else{
        this.setState(() => ({ is_notifyMe: false }));
        setTimeout(() => {
          this._NotifyMeModal.close();
          this.setState({is_notifyMe:this.props.stoneDetail.is_notify})
        },200);
      }
    }else{
      this.setState(() => ({ is_notifyMe: value }));
    }
  };
  _onCloseNotify = () => {
    const { saveNotifyMePreference , stoneDetail} = this.props;
    this.setState(() => ({ is_notifyMe: false }));
    if(!this.state.isSubscribtionOver && this.props.stoneDetail.is_notify){
      let postData = {
        "notify_enable":false,
      };
      postData[this.state.from] = this.state.id;

      saveNotifyMePreference(postData, this.state.from);
      firebase.analytics().logEvent("NotifyMe", {"ITEM_LIST_ID": this.state.id, "VALUE": "false"});
    }
    setTimeout(() => {
      this._NotifyMeModal.close();
      this.setState({is_notifyMe:this.props.stoneDetail.is_notify})
    },200);
  }

  onCheckAll(item){
    let resultList = this.state.resultList;
    let key = item;
    for(let i=0; i < resultList[key].length ; i++){
      resultList[key][i].is_checked = true;
    }
    this.setState({...this.state,  resultList: {...resultList} });
  }
  onCheckNone(item){
    let resultList = this.state.resultList;
    let key = item;
    for(let i=0; i < resultList[key].length ; i++){
      resultList[key][i].is_checked = false;
    }
    this.setState({...this.state,  resultList: {...resultList} });
  }

  onChangePreferanceValue = (item) => {
    let resultList = this.state.resultList;
    let key = item.key;
    for(let i=0; i < resultList[key].length ; i++){
      if(resultList[key][i].id == item.id && resultList[key][i].name && item.name){
        resultList[key][i].is_checked = !resultList[key][i].is_checked;
        break;
      }
    }
    this.setState({...this.state,  resultList: {...resultList} });
  }

  onSaveData = () => {
    const { saveNotifyMePreference , stoneDetail} = this.props;
    let resultList = this.state.resultList;
    let postData = {
      "notify_enable":true,
      "data":{},
    };
    postData[this.state.from] = this.state.id;

    for(let key of Object.keys(resultList)){
      let selectedData = [];
      for(let i=0; i < resultList[key].length ; i++){
        if(resultList[key][i].is_checked){
          selectedData.push(resultList[key][i].id)
        }
      }
      postData.data[key] = selectedData;
    }
    this._NotifyMeModal.close();
    this.saveClicked = true;
    saveNotifyMePreference(postData, this.state.from);
    firebase.analytics().logEvent("NotifyMe", {"ITEM_LIST_ID": this.state.id, "notify_enable": true});
  }

  _renderSubItem = ({ index, item }) => {
    return (
      <TouchableOpacity style={styles.listItemContainer} onPress={() => this.onChangePreferanceValue(item)} disabled={this.state.isSubscribtionOver}>
        <View style={styles.checkboxContainer}>
          <CheckBox
            containerStyle={styles.checkBoxStyle}
            disabled={this.state.isSubscribtionOver}
            checked={item.is_checked}
            onPress={() => this.onChangePreferanceValue(item)}
            checkedIcon={<Image style={styles.checkBoxIcon} source={Images.icons.checkbox_selected_Notify} resizeMode={'contain'}/>}
            uncheckedIcon={<Image style={styles.checkBoxIcon} source={Images.icons.checkbox_Notify} resizeMode={'contain'}/>}
          />
        </View>
        <View style={styles.listItemTextContainer}>
            <Text style={styles.listItemText}>{item.name}</Text>
        </View>
      </TouchableOpacity>
    );
  }
  _renderItem = ({ index, item }) => {
    const { resultList } = this.state;
    let listVal = resultList[item];
    if(listVal.length == 0){
      return;
    }
		return (
      <View>
        <View style={styles.headerContainer}>
  			   <Text style={styles.headerTitle}>{item}</Text>
           <Text style={styles.headerDividerText}>{' ('}</Text>
           <TouchableOpacity onPress={() => this.onCheckAll(item)} disabled={this.state.isSubscribtionOver}>
              <Text style={styles.headerSubText}>{Languages.CheckAll}</Text>
           </TouchableOpacity>
           <Text style={styles.headerDividerText}>{' / '}</Text>
           <TouchableOpacity style={styles.imageLeftContainer} onPress={() => this.onCheckNone(item)} disabled={this.state.isSubscribtionOver}>
              <Text style={styles.headerSubText}>{Languages.None}</Text>
           </TouchableOpacity>
           <Text style={styles.headerDividerText}>{')'}</Text>
        </View>
        <View style={styles.divider}/>
        <FlatList
          scrollEnabled={true}
          style={styles.listContainer}
          extraData={this.state}
          data={listVal}
          keyExtractor={(item, index) => index.toString()}
          renderItem={this._renderSubItem}
        />
      </View>
		);
	}

  render() {
    const { stoneDetail } = this.props;
    const { from } = this.state;
    let modalStyale, flatListStyle, bottomBtnStyle;
    if(from == "stone_detail_id"){
      modalStyale = this.state.is_notifyMe ? styles.notifyMeOpenModalWarpper : styles.notifyMeModalWarpper;
      flatListStyle = [styles.flatlistContainer,{opacity: this.state.isSubscribtionOver ? 0.5 : 1}];
      bottomBtnStyle = styles.bottomBtnContainer;
    }else{
      modalStyale = styles.notifyMeLibraryModalWarpper;
      flatListStyle = styles.flatlistLibraryContainer;
      bottomBtnStyle = styles.bottomBtnLibraryContainer;
    }

    return (
      <Modal
        ref={(com) => (this._NotifyMeModal = com)}
        style={modalStyale}
        position={"top"}
        swipeToClose={false}
        backdropColor={'transperant'}
        onClosed={this.onClosed}
        backButtonClose={true}
        >
        {from == "stone_detail_id" &&
            <View style={styles.notifyMeHeaderContainer}>
                <View style={styles.notifyMeBelllIconContainer}>
                    <Image source={Images.icons.bell_filled} style={styles.notifyMeBelllIcon} resizeMode={'contain'}/>
                </View>
                <View style={styles.notifyMeTextContainer}>
                    <Text style={styles.notifyMeText}>{Languages.notifyMeText1 + stoneDetail.display_name + Languages.notifyMeText2}</Text>
                </View>
                <View style={styles.notifyMeSwitchContainer}>
                    <View style={styles.switchOuterContainer}>
                        <Switch
                            // onChange={(data) => this._handleNotifyMeRequest(data) }
                            style={{zIndex:99}}
                            value={this.state.is_notifyMe}
                            tintColor={Color.blackDivide}
                            trackColor={{true: 'rgb(80,208,113)'}}
                            thumbColor={Platform.OS == 'android' ? Color.white : 'transperant'}
                        />
                        <TouchableOpacity style={styles.onNotifyMeSwitchUpperAbsoluteView} onPress={() => this._handleNotifyMeRequest()} />
                    </View>
                </View>
            </View>
        }
        {this.state.is_notifyMe &&
          <View style={styles.notifyMeContentView}>
            <FlatList
              style={flatListStyle}
              showsVerticalScrollIndicator={false}
              scrollEnabled={true}
              data={Object.keys(this.state.resultList)}
              extraData={this.state}
              keyExtractor={(item, index) => index.toString()}
              renderItem={this._renderItem}
            />
            {Object.keys(this.state.resultList).length > 0 &&
              <View style={bottomBtnStyle}>
                <TouchableOpacity style={this.state.isSubscribtionOver ? styles.saveNotifyDisableBtnContainer: styles.saveNotifyBtnContainer} onPress={this.onSaveData} disabled={this.state.isSubscribtionOver}>
                   <Text style={styles.saveNotifyBtnText}>{Languages.Save}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.cancelNotifyBtnContainer} onPress={this.close}>
                   <Text style={styles.cancelNotifyBtnText}>{Languages.Cancel}</Text>
                </TouchableOpacity>
              </View>
            }
          </View>
        }

        <StonestockDialog ref={(com) => (this._stoneStockModal = com)}
          titleText={Languages.notifyCancelTitle}
          primaryText={Languages.notifyCancelMsg}
          primaryBtnText={Languages.Yes}
          secondaryBtnText={Languages.Cancel}
          modalStyle={styles.modalStyle}
          primaryButtonCallback={() => this._onCloseNotify()}
          scondaryButtonCallback={() => this._stoneStockModal.close()}
        />
      </Modal>
    );
  }

}
const mapStateToProps = (state) => {
  // log('--------- mapStateToProps stockdetail notifyme--------')
  // log(state)
  return {
    isConnected: state.netInfo.isConnected,
    isFetching:state.stockList.isFetching,
    stoneDetail:state.stockList.product,
    error:state.stockList.error,
    type:state.stockList.type,
    // result:state.stockList.result,
    code:state.stockList.code,
  };
};

function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  const { actions } = require("@redux/StockListRedux");
  const { isConnected } = stateProps;
  return {
    ...ownProps,
    ...stateProps,
    saveNotifyMePreference: (data, from) => {
      if(isConnected){
        actions.saveNotifyMePreference(dispatch, data, from)
      }else{
        toast(Languages.InternetError)
      }
    },
  };
}

export default connect(
  mapStateToProps,
  null,
  mergeProps
)(NotifyMeDialog);
