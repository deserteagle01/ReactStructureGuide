/** @format */

import { StyleSheet, Dimensions, Platform } from "react-native";
import { Color, Device, Styles } from "@common";
const { height, width } = Dimensions.get("window");
let bottomBtnHeight = width > 360 ? 50 : 40;

export default StyleSheet.create({
  notifyMeLibraryModalWarpper:{
    backgroundColor:'transparent',
    width:'95%',
    height:'95%',
    marginTop:5,
    // paddingTop:10,
  },
  notifyMeModalWarpper:{
    backgroundColor:'transparent',
    width:'95%',
    // height:60,
    marginTop:10,
  },
  notifyMeOpenModalWarpper:{
    backgroundColor:Color.black,
    width:'95%',
    // height:'95%',
    marginTop:10,
  },
  notifyMeHeaderContainer:{
    flexDirection:'row',
    backgroundColor:Color.white,
    width:'100%',
    height:60,
    padding:4,
  },
  notifyMeBelllIconContainer:{
    flex:0.1,
    justifyContent:'center',
    alignItems:'center',
    padding:4,
    // backgroundColor:'blue',
  },
  notifyMeBelllIcon:{
    width:30,
    height:30,
    tintColor:Color.primary
  },
  notifyMeTextContainer:{
    flex:0.72,
    justifyContent:'center',
    alignItems:'center',
    padding:4,
    // backgroundColor:'red',
  },
  notifyMeText:{
    color:Color.black,
    fontSize: width > 360 ? 16 : 13,
  },

  notifyMeSwitchContainer:{
    flex:0.18,
    padding:4,
    // padding:10,
  },
  switchOuterContainer:{
    width:'100%',
    height:'100%',
    justifyContent:'center',
    alignItems:'center',
  },
  onNotifyMeSwitchUpperAbsoluteView:{
    // backgroundColor:'rgba(0,0,0,0.5)',
    zIndex:9999,
    position:'absolute',
    top:0,
    right:0,
    left:0,
    bottom:0,
  },
  notifyMeSwitch:{

  },
  notifyMeContentView:{
    backgroundColor:Color.white,
    marginTop:10,
    marginBottom:20,
    height:'95%',
    paddingHorizontal:50,
  },
  headerContainer:{
    backgroundColor:'white',
    flexDirection:'row',
    // paddingLeft:10,
    paddingTop:10,

  },
  headerTitle:{
    color:Color.black,
    textTransform: 'uppercase',
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 16 : 14,
      },
      android: {
        fontSize : width > 360 ? 16 : 14,
      },
    }),
  },
  headerSubText:{
    color:Color.primary,
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 16 : 14,
      },
      android: {
        fontSize : width > 360 ? 16 : 14,
      },
    }),
  },
  headerDividerText:{
    color:Color.black,
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 16 : 14,
      },
      android: {
        fontSize : width > 360 ? 16 : 14,
      },
    }),
  },
  divider:{
    width:20,
    height:3,
    backgroundColor:Color.primary,
    marginTop:15,
  },
  listContainer:{
    marginTop : 10,
  },
  listItemContainer:{
    flexDirection:'row',
    paddingTop:5,
    paddingBottom:5,
    // backgroundColor:'pink',
  },
  listItemTextContainer:{
    flex:0.9,
    justifyContent:'center',
    ...Platform.select({
      ios: {
        marginLeft : width > 320 ? 0 : 10,
      },
      android: {
        marginLeft : width > 360 ? 0 : 10,
      },
    }),
    // alignItems:'center',
    // backgroundColor:'orange',
  },
  listItemText:{
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 15 : 14,
      },
      android: {
        fontSize : width > 360 ? 15 : 14,
      },
    }),
  },
  checkboxContainer:{
    flex:0.1,
    // backgroundColor:'blue',
    // height:30,
  },
  checkBoxStyle:{
    // width:15,
    // height:15,
    marginLeft: 0,
    padding: 0,
    marginRight: 0,
  },
  checkBoxIcon:{
    width:20,
    height:20
  },
  flatlistLibraryContainer:{
    flex:1,
  },
  bottomBtnLibraryContainer:{
    marginVertical:10,
    flexDirection:'row',
    justifyContent:'center',
  },
  flatlistContainer:{
    ...Platform.select({
      ios: {
        flex: Device.isIphoneX ? 0.85 : (width > 320 ? 0.82 : 0.75 ),
      },
      android: {
        flex: width > 360 ? 0.8 : 0.75,
      },
    }),
    // backgroundColor:'orange',
  },
  bottomBtnContainer:{
    ...Platform.select({
      ios: {
        flex: Device.isIphoneX ? 0.15 : (width > 320 ? 0.18 : 0.25 ),
        marginBottom:50,
      },
      android: {
        flex: width > 360 ? 0.2 :0.25,
        marginBottom: width > 360 ? 60 : 50,
      },
    }),
    // backgroundColor:'pink',
    justifyContent:'center',
    // alignItems:'center',
    marginTop:10,
    flexDirection:'row',
  },
  saveNotifyDisableBtnContainer:{
    justifyContent:'center',
    alignItems:'center',
    height:bottomBtnHeight,
    width:90,
    backgroundColor:Color.disablePrimary,
    marginRight:10,
  },
  saveNotifyBtnContainer:{
    justifyContent:'center',
    alignItems:'center',
    height:bottomBtnHeight,
    width:90,
    backgroundColor:Color.primary,
    marginRight:10,
  },
  cancelNotifyBtnContainer:{
    justifyContent:'center',
    alignItems:'center',
    height:bottomBtnHeight,
    width:90,
    backgroundColor:Color.white,
    marginLeft:10,
    borderColor:'rgb(231,231,231)',
    borderWidth:1,
  },
  saveNotifyBtnText:{
    color:Color.white,
    fontSize:18,
    textTransform: 'uppercase',
    textAlign:'center',
    alignSelf:'center',
  },
  cancelNotifyBtnText:{
    color:Color.primary,
    fontSize:18,
    textTransform: 'uppercase',
    textAlign:'center',
    alignSelf:'center',
  },
  headerShimmerContainer:{
    backgroundColor:'white',
    flexDirection:'row',
    paddingLeft:10,
    paddingTop:10,
    height:35,
  },
  listItemShimmerContainer : {
      marginTop : 10,
      height:35,
  },
  //------ confirm to close notify modal style -----
  modalStyle:{
    width:'90%',
    // height: 205
  },
});
