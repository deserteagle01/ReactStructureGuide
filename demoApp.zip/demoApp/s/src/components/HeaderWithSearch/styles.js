import { StyleSheet, Platform } from "react-native";
import { Color, Styles } from "@common";

export default StyleSheet.create({
  headerContainer:{
    backgroundColor:Color.homeHeader
  },
  leftIconHeaderContainer:{
    // backgroundColor:'orange',
    flex:0.2,
    alignItems:'center',
    flexDirection:'row',
  },
  toolbarIcon:{
    resizeMode: "contain",
    marginLeft: 18,
    opacity: 0.8,
    tintColor:Color.white,
    ...Platform.select({
      ios: {
        width: Styles.width > 320 ? 20 : 18,
        height: Styles.width > 320 ? 20 : 18,
      },
      android: {
        width: Styles.width > 360 ? 20 : 18,
        height: Styles.width > 360 ? 20 : 18,
      },
    }),
  },
  centerHeaderContainer:{
    // backgroundColor:'blue',
    flex:0.9,
    justifyContent:'center',
    alignItems:'center',
  },
  logoIcon:{
    // width:220,
    height:40,
    ...Platform.select({
      ios: {
        width: Styles.width > 320 ? 220 : 160,
      },
      android: {
        width: Styles.width > 360 ? 220 : 190,
      },
    }),
    marginBottom:8,
  },
  rightIconHeaderContainer:{
    // backgroundColor:'red',
    flex:0.2,
    justifyContent:'center',
    alignItems:'flex-end',
    opacity: 0.8,
  },
  toolbarRightIcon:{
    resizeMode: "contain",
    marginRight: 18,
    opacity: 0.8,
    tintColor:Color.white,
    ...Platform.select({
      ios: {
        width: Styles.width > 320 ? 20 : 18,
        height: Styles.width > 320 ? 20 : 18,
      },
      android: {
        width: Styles.width > 360 ? 20 : 18,
        height: Styles.width > 360 ? 20 : 18,
      },
    }),
  },

  headerSearchContainer:{
    backgroundColor:Color.homeHeader,
    marginBottom:8,
  },
  searchContainer:{
    backgroundColor:'#ebebeb',
    flex:1,
    flexDirection:'row',
    borderColor:'#bfbfbf',
    borderWidth:0.5,
    borderRadius:4,
    // justifyContent:'center',
    alignItems:'center',
    marginHorizontal:15,
    marginTop:4,
    marginBottom:2,
  },
  searchInput:{
    color: Color.black,
    height: 40,
    paddingLeft: 8,
    flex: 1,
    textAlign: "left",
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 16 : 14,
      },
      android: {
        fontSize: Styles.width > 360 ? 16 : 14,
      },
    }),
  },
  searchIcon:{
    width:15,
    height:15,
    tintColor:'#737373',
    marginLeft:10,
  },
  clearSearchContainer:{
    padding:6,
    // backgroundColor:'pink',
  },
  clearSearchIcon:{
    width:15,
    height:15,
    tintColor:'#737373',
  },
  filterContainer:{
    flex:0.1,
    justifyContent:'center',
    alignItems:'center',
    marginBottom:6,
  },
});
