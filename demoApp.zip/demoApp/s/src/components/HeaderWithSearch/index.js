import React, { PureComponent } from "react";
import { View, TouchableOpacity, Image, TextInput, Keyboard, StatusBar, Platform } from "react-native";
import styles from "./styles";
import { Styles, Languages, Images, Config, Color, withTheme } from "@common";
import { toggleDrawer, log, toast } from "@app/Omni";
import * as Animatable from 'react-native-animatable';
import { connect } from "react-redux";

class HeaderWithSearch extends PureComponent {
  constructor(props){
    super(props);
    this.state = {
      showClearSearch : false,
      searchText : this.props.searchText,
      showBackIcon : false,
      searchPlaceholder : Languages.Search,
      filterColor:Color.white,
    };
    this.slideRight = () => this.view.animate({
      0: {
        translateX: -30,
      },
      0.5: {
        translateX: 0.3,
      },
      1: {
        translateX: 0.5,
      },
      2: {
        translateX: 100,
      }
    })
    this.slideLeft = () => this.view.animate({
       0: {
         translateX: 30,
       },
       0.5: {
         translateX: -0.3,
       },
       1: {
         translateX: -0.5,
       },
       2: {
         translateX: -1,
       }
    })
  }
  handleViewRef = ref => this.view = ref;

  componentDidMount() {
    if (this.props.onRef) {
      this.props.onRef(this);
    }
  }
  componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}
  componentWillReceiveProps(nextProps) {
    if(this.props != nextProps){
      this.setState({searchText : nextProps.searchText, filterColor:Color.white})
      let filterObj = nextProps.filterData;
      if(filterObj){
        for (var key of Object.keys(filterObj)) {
          if(filterObj[key].length > 0){
            this.setState({filterColor:Color.primary})
            break;
          }
        }
      }
      if(nextProps.type == "CLEAR_SEARCH_FILTER_DATA"){
        this.onCloseSearch();
      }
    }
  }

  onSearchClick = () => {
    if(!this.state.showBackIcon){
      this.setState({showBackIcon : true, searchPlaceholder : Languages.SearchPlaceHolder});
      this.slideRight();
    }
    this.props.onSearchClick();
  }
  onCloseSearch = () => {
    this.setState({showBackIcon : false, searchPlaceholder : Languages.Search, searchText: "", showClearSearch : false},() => {this.props.clearRedux()});
    this.slideLeft();
    Keyboard.dismiss();
    this.props.onCloseSearch();
  }

  onChangeSearchText = (text) => {
    this.setState({searchText : text});
    if(text.trim().length > 0){
      this.setState({showClearSearch : true})
    }else{
      this.setState({showClearSearch : false})
    }
    this.props.onChangeSearchText(text);
  }

  onClearSearch = () => {
    this.setState({searchText : ""});
    this.props.onClearSearch();
  }

  onSubmitSearch = () => {
    if(this.state.searchText.length > 0){
      this.props.onSubmitSearch(this.state.searchText);
    }else{
      toast(Languages.SearchBlankErrorMsg)
    }
    Keyboard.dismiss();
  }

  render() {
    const { navigation, filterData } = this.props;
    let filterObj = filterData;
    if(filterObj){
      for (var key of Object.keys(filterObj)) {
        if(filterObj[key].length > 0){
          this.setState({filterColor:Color.primary})
          break;
        }
      }
    }
    return (
      <View>
        {Platform.OS == 'ios' &&
          <StatusBar translucent barStyle="light-content" />
        }
        <View style={[Styles.Common.headerWrapper,styles.headerContainer]}>
            {/* left icon  //onPress={toggleDrawer}*/}
            <View style={styles.leftIconHeaderContainer}>
                {this.state.showBackIcon &&
                  <TouchableOpacity onPress={this.onCloseSearch}>
                    <Image source={Images.icons.back}
                      style={styles.toolbarIcon}/>
                  </TouchableOpacity>
                }
                <TouchableOpacity onPress={toggleDrawer}>
                  <Animatable.Image source={Images.icons.menu} ref={this.handleViewRef} duration={200} style={styles.toolbarIcon}/>
                </TouchableOpacity>
            </View>

            {/* center icon */}
            <View style={styles.centerHeaderContainer}>
                <Image source={Config.LogoWithText} style={styles.logoIcon} resizeMode="stretch"/>
            </View>

            {/* right icon */}
            <View style={styles.rightIconHeaderContainer} >
                <TouchableOpacity onPress={() => {navigation.push("FiltersScreen")}}>
                  <Image
                    source={Images.icons.filter}
                    style={[styles.toolbarRightIcon,{tintColor:this.state.filterColor}]}
                  />
                </TouchableOpacity>
            </View>
        </View>
        <View style={[Styles.Common.headerWrapper,styles.headerSearchContainer]}>
            {/* search icon*/}
            <View style={styles.searchContainer} >
                <Image
                  source={Images.icons.search}
                  style={styles.searchIcon}
                />
                <TextInput
                  onTouchStart={this.onSearchClick}
                  style={styles.searchInput}
                  autoCapitalize="none"
                  multiline={false}
                  underlineColorAndroid="transparent"
                  placeholder={this.state.searchPlaceholder}
                  onChangeText={this.onChangeSearchText}
                  onSubmitEditing={this.onSubmitSearch}
                  returnKeyType="search"
                  value={this.state.searchText}
                />
                {this.state.showClearSearch &&
                  <TouchableOpacity style={styles.clearSearchContainer} onPress={this.onClearSearch}>
                    <Image
                      source={Images.icons.close}
                      style={styles.clearSearchIcon}
                    />
                  </TouchableOpacity>
                }
            </View>
            {/* right icon
            <View style={styles.filterContainer}>
                <TouchableOpacity onPress={onFilterPress} >
                  <Image
                    source={Images.icons.filter}
                    style={styles.toolbarRightIcon}
                  />
                </TouchableOpacity>
            </View>*/}
        </View>
      </View>

    );
  }
}

const mapStateToProps = (state) => {
  return {
    filterData: state.filterTagList.selectedFilter,
    type:state.filterTagList.type,
  };
};
function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  const { actions } = require("@redux/FilterTagRedux");
  return {
    ...ownProps,
    ...stateProps,
    clearRedux: () => {
      actions.clearRedux(dispatch);
    },
  };
}

export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    mergeProps
  )(HeaderWithSearch)
);
