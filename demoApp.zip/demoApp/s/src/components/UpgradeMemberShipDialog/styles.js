/** @format */

import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Device } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  modalBoxWrap: {
    width,
    height,
    backgroundColor:'rgba(0,0,0,0.8)'
  },
  mainContainer:{
    flex:1,
    alignItems:'center',
    justifyContent:"center",
    paddingHorizontal:16,
  },
  titleContainer:{
    // backgroundColor:'pink'
  },
  titleText:{
    ...Platform.select({
      ios: {
        fontSize:width > 320 ? 28 : 20,
      },
      android: {
        fontSize:width > 360 ? 28 : 20,
      },
    }),
    color:Color.white,
    fontWeight:'600',
    textAlign:'center',
  },
  messageContainer:{
    backgroundColor:Color.white,
    padding:12,
    marginTop:20,
  },
  messageText:{
    ...Platform.select({
      ios: {
        fontSize:width > 320 ? 17 : 14,
      },
      android: {
        fontSize:width > 360 ? 17 : 14,
      },
    }),
    color:Color.black,
  },
  btnContainer:{
    height:50,
    backgroundColor:Color.primary,
    alignItems:'center',
    justifyContent:'center',
    marginTop:15,
  },
  btnText:{
    textTransform:'uppercase',
    color:Color.white,
    fontWeight:'500',
    ...Platform.select({
      ios: {
        fontSize:width > 320 ? 16 : 14,
      },
      android: {
        fontSize:width > 360 ? 16 : 14,
      },
    }),
  },
  bottomContainer:{
    marginTop:20,
    alignItems:'center',
    justifyContent:'center',
  },
  bottomText:{
    color:Color.primary,
    ...Platform.select({
      ios: {
        fontSize:width > 320 ? 17 : 14,
      },
      android: {
        fontSize:width > 360 ? 17 : 14,
      },
    }),
  },
});
