  /** @format */

import React, { Component } from "react";
import {
  Text,
  TouchableOpacity,
  View
} from "react-native";
import { connect } from "react-redux";
import { CommonModal } from "@components";
import { Languages, Color, withTheme } from "@common";
import Modal from "react-native-modalbox";
import styles from "./styles";
import { toast,log } from "@app/Omni";

class UpgradeMemberShipDialog extends Component {

    constructor(props){
      super(props);
    }

    componentDidMount() {
      if (this.props.onRef) {
        this.props.onRef(this);
      }
    }
    componentWillUnmount() {
  		if (this.props.onRef) {
  			this.props.onRef(null);
  		}
  	}

    open = () => {
      this._commonModal.open();
    }
    close = () => {
      this._commonModal.close();
    }

    onNotNow = () => {
      this._commonModal.close();
      this.props.clearDetailReduxError();
    }

    onUpgrade = () => {
      this.props.navigation.push("PlanListScreen");
      this._commonModal.close();
    }

    render() {
      const { stone_detail_id } = this.props;
      return (
        <CommonModal ref={(com) => (this._commonModal = com)}>
          <View style={styles.modalBoxWrap}>
              <View style={styles.mainContainer}>
                  {/* title part */}
                  <View style={styles.titleContainer}>
                      <Text style={styles.titleText}>{Languages.upgradeMemberTitle}</Text>
                  </View>

                  {/* center message part */}
                  <View style={styles.messageContainer}>
                      <Text style={styles.messageText}>{Languages.upgradeMemberMessage}</Text>

                      <TouchableOpacity style={styles.btnContainer} onPress={this.onUpgrade}>
                          <Text style={styles.btnText}>{Languages.upgradeMemberBtn}</Text>
                      </TouchableOpacity>
                  </View>

                  {/* bottom not now part */}
                  <TouchableOpacity style={styles.bottomContainer} onPress={this.onNotNow}>
                      <Text style={styles.bottomText}>{Languages.upgradeMemberNotNow}</Text>
                  </TouchableOpacity>

              </View>
          </View>
        </CommonModal>
      );
    }

}

const mapStateToProps = (state) => {
  return {
    isConnected: state.netInfo.isConnected,
  };
};

function mergeProps(stateProps, dispatchProps, ownProps) {
    const { dispatch } = dispatchProps;
    const StockListRedux = require("@redux/StockListRedux");
    const { isConnected } = stateProps;
    return {
      ...ownProps,
      ...stateProps,
      clearDetailReduxError: () => {
        if(isConnected){
          StockListRedux.actions.clearDetailReduxError(dispatch)
        }else{
          toast(Languages.InternetError)
        }
      },
    };
}

export default withTheme(
    connect(
      mapStateToProps,
      undefined,
      mergeProps
    )(UpgradeMemberShipDialog)
);
