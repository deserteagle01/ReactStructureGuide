/** @format */

import { StyleSheet, Platform } from "react-native";
import { Styles, Color } from "@common";

export default StyleSheet.create({
  container_product: {
      paddingHorizontal:16,
      paddingVertical:14,
      borderBottomColor: '#e9e9e9',
      borderBottomWidth: 0.5,
  },
  mainTextWarpper:{
    flexDirection: 'row',
    flex:1,
    alignItems:'center'
  },
  textEditIconContainer:{
    flex:0.9,
    flexDirection: 'row',
  },
  titleTextContainer:{

  },
  titleTextShimmer:{
    flex:1,
  },
  titleText:{
    fontWeight: "700",
    color: Color.listPrimaryText,
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 19 : 18,
      },
      android: {
        fontSize: Styles.width > 360 ? 19 : 18,
      },
    }),
    textAlign: "left",
  },
  editIconContainer:{
    flex:0.1,
    // justifyContent:'center',
    alignItems:'center',
  },
  editIcon: {
    width:18,
    height:18,
    tintColor:Color.primary,
    marginLeft:16,
  },

  deleteIconContainer:{
    flex:0.1,
    justifyContent:'center',
    alignItems:'center',
    marginHorizontal:2
  },
  deleteIcon: {
    width:25,
    height:25,
    tintColor:Color.primary,
  },
  selectedFilterListContainer:{
    marginTop:8
  },


  filterListItemContainer: {
    flexDirection: "row",
    marginTop:2,
  },
  filterListTitleText:{
    width:80,
    color: Color.white,
    fontWeight:'500',
    textAlign: "left",
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 17 : 14,
      },
      android: {
        fontSize: Styles.width > 360 ? 17 : 14,
      },
    }),
  },
  filterListDataText:{
      color: Color.listSecondaryText,
      textAlign: "left",
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 16 : 15,
        },
        android: {
          fontSize: Styles.width > 360 ? 16 : 15,
        },
      }),
      marginRight:80,
  },

});
