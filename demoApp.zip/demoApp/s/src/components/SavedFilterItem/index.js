import React, { PureComponent } from "react";
import { View, TouchableOpacity, Text, Image, FlatList } from "react-native";
import { Images } from "@common";
import { Shimmer } from "@components";
import styles from "./styles";

export default class SavedFilterItem extends PureComponent {
  _renderItem = ({ index, item }) => {
    return (
      <View style={styles.filterListItemContainer}>
          <Text style={styles.filterListTitleText}>{item.display_name + ": "}</Text>
            <Text style={styles.filterListDataText}>
              {item.data.map(u => u.name).join(', ')}
            </Text>
      </View>
    );
  }

  render() {
    const { product, onProductPress, onEditIconPress, onDeleteIconPress, isFetching } = this.props;
    return (
      <TouchableOpacity style={styles.container_product} activeOpacity={0.9} onPress={onProductPress}>
          <View style={styles.mainTextWarpper}>

            <View style={styles.textEditIconContainer}>
                <View style={styles.titleTextContainer}>
                    <Shimmer style={styles.titleTextShimmer} visible={!isFetching} >
                      <Text style={styles.titleText}>{product.filter_name}</Text>
                    </Shimmer>
                </View>
                <TouchableOpacity activeOpacity={0.9} onPress={onEditIconPress} style={styles.editIconContainer}>
                    <Shimmer style={styles.editIcon} visible={!isFetching} >
                        <Image source={Images.icons.edit} style={styles.editIcon} resizeMode={"contain"}/>
                    </Shimmer>
                </TouchableOpacity>
            </View>

            <TouchableOpacity activeOpacity={0.9} onPress={onDeleteIconPress} style={styles.deleteIconContainer}>
                <Shimmer style={styles.deleteIcon} visible={!isFetching} >
                    <Image source={Images.icons.trash} style={styles.deleteIcon} resizeMode={"contain"}/>
                </Shimmer>
            </TouchableOpacity>

          </View>

          <View style={styles.selectedFilterListContainer}>
            <FlatList
              showsVerticalScrollIndicator={false}
              scrollEnabled={true}
              data={product.selected_filters}
              extraData={this.state}
              keyExtractor={(item, index) => index.toString()}
              renderItem={this._renderItem}
            />
          </View>
      </TouchableOpacity>
    );
  }
}
