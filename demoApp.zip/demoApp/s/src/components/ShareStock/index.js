/** @format */

import React, { PureComponent } from "react";
import { Text, TouchableOpacity, View, TextInput, Keyboard, Image,ScrollView,SafeAreaView,ActivityIndicator } from "react-native";
import { Color, Languages,Images } from "@common";
import styles from "./styles";
import { log, toast } from "@app/Omni";
import style from "../Chips/style";
import Modal from 'react-native-modal';
import { ContactSelection } from "..";
import { connect } from "react-redux";
class ShareStock extends PureComponent {
  
  constructor(props){
    super(props);
    this.state = {
      emailIdString : '',
      notes : '',
      isKeyboardShown: false,
      visible: false,
      selectedContactList: []
    };
  }

  componentWillMount () {
    this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this._keyboardDidShow.bind(this));
    this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this._keyboardDidHide.bind(this));
  }

  componentWillUnmount () {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  _keyboardDidShow () {
    this.setState({isKeyboardShown: true});
  }

  _keyboardDidHide () {
    this.setState({isKeyboardShown: false});
  }

  open = () => {
    this.setState({emailIdString: '', notes: '',visible: true, selectedContactList: []});
  }

  cancel = () => {
    this.setState({visible: false});
  }

  share = () => {
    if(this.state.selectedContactList.length>0){
        if(this.state.notes.length > 0){
          this.props.shareStock(this.state.selectedContactList, this.state.notes);
        }else{
          alert(Languages.txtNotesWarning);
        }
  }else{
      alert(Languages.txtShareWarning);
    }
  }

  closeAddEditModal = () => {
    this._contactselection.closeAddEditModal(this.state.selectedContactList);
  }

  refreshSelectedContact = (contactList) => {
    this._contactselection.refreshSelectedContact(this.state.selectedContactList, contactList)
  }

  validateEmailList(emailString){
    Keyboard.dismiss();
    let emailList = emailString.replace(/\s/g, "").split(",");
    let validEmailList = [];
    let invalidEmail = [];
    let regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    for (var i = 0; i < emailList.length; i++) {
        if( emailList[i] === "" || !regex.test(emailList[i])){
          emailList[i] !== "" && invalidEmail.push(emailList[i]);
        } else {
          validEmailList.push(emailList[i]);
        }
    }
    if(invalidEmail.length == 0) {
      return validEmailList;
    } else {
      invalidEmail = invalidEmail.join(', ');
      toast(Languages.notValidEmail + invalidEmail);
      return false;
    }
  }

  deleteTag(data) {
    this.setState({selectedContactList: this.state.selectedContactList.filter(function(contact) { 
      return contact.id !== data.id 
    })});
  }

  renderTags() {
    return this.state.selectedContactList.map((data, index) => {
      return(
          <TouchableOpacity style={styles.tabt} onPress={() => this.deleteTag(data)}>
              <Text style={styles.txttag}>{data.first_name+" "+data.surname}</Text>
              <Image source={Images.icons.closeNew} style={styles.canceltag}/>
          </TouchableOpacity>
      );
    });
  }
  

  render() {
    return (
      <Modal
        hasBackdrop={true}
        isVisible={this.state.visible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={{margin: 0}}
        onBackButtonPress={this.cancel}
        onBackdropPress={this.cancel}>
        
        <View style={{backgroundColor:"white",marginHorizontal:20}}>
          <View style={styles.headerContainer}>
              <Text style={styles.shareTitle}>{Languages.sendDetails}</Text>
          </View>
          <TouchableOpacity style={styles.emailInput} onPress={() => this._contactselection.open(this.state.selectedContactList) }>
              <Text style={styles.txtSelectContact}>{Languages.txtSelectContact}</Text>
          </TouchableOpacity>
          <ScrollView>
            {this.state.selectedContactList.length>0 &&
              <View style={{marginVertical:10,width:"90%",alignSelf:'center', flexDirection:'row',flexWrap: 'wrap'}}>
                  {this.renderTags()}
              </View>
            }
          </ScrollView> 
          <TextInput
            placeholderTextColor={Color.detailPrimaryText}
            placeholder={Languages.notes}
            style={styles.notesInput}
            blurOnSubmit={true}
            autoCapitalize="none"
            multiline={true}
            value={this.state.notes}
            onChangeText={text => this.setState({notes:text})}
          />
          
          <View style={styles.buttonContainer}>
            <TouchableOpacity style={styles.buttonWrapper} onPress={this.cancel}>
              <Text style={styles.cancelBtnText}>{Languages.CANCEL}</Text>
            </TouchableOpacity>
            <View style={styles.verticalDivider}/>
            <TouchableOpacity style={styles.buttonWrapper2} onPress={this.share}>
              <Text style={styles.shareBtnText}>{Languages.SHARE}</Text>
            </TouchableOpacity>
          </View>
          
        </View>
          <ContactSelection
            ref={(com) => (this._contactselection = com)}
            contactList={this.props.contact_list}
            companyList={this.props.company_list}
            selectionWarning={Languages.contactSelectionWarning}
            contactSelected={(items) =>{
              this.setState({selectedContactList: items});
              this._contactselection.cancel();
            }}
            addEditContactClick={(params) => this.props.addEditContact(params)} />
            {this.props.isFetching ?  
              <View style={{position:'absolute', alignSelf:"center",flex:1}}>
                <ActivityIndicator size="small" color="gray" /> 
              </View>
          : null}
      </Modal>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    isFetching:state.stockList.isFetching,
  };
};

//export default ShareStock
export default connect(
  mapStateToProps,
  undefined,
  undefined,
  { forwardRef: true }
)(ShareStock);
