/** @format */

import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Styles, Device, Constants } from "@common";
import { color } from "react-native-reanimated";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  shareModal:{
    width:width - 50,
    backgroundColor:'#f7f7f7',
    //height: "80%",
    maxHeight:"70%",
  },
  shareModal2:(heightper) => ({
    backgroundColor:'white',
    //height: heightper,
    //maxHeight:"70%",
    height:"100%",
    overflow:'hidden',
  }),
  tabt:{
    flexDirection:"row",
    borderColor:Color.primary,
    borderWidth:1,
    alignItems:'center',
    paddingVertical:5,
    paddingHorizontal:5,
    borderRadius: 8,
    marginHorizontal:5,
    marginVertical:5
  },
  txttag:{
    color:Color.primary,
    fontWeight:'400',
    fontSize:14,
    marginLeft: 4
  },
  canceltag:{
    height: 10, 
    width:10, 
    marginLeft: 7, 
    tintColor:Color.primary
  },
  shareModalKeyboard:{
    width:width - 50,
    maxHeight:"70%",
    //height: "80%",
    backgroundColor:'#f7f7f7',
    ...Platform.select({
      android: {
        position:"absolute",
        bottom:"80%",
      },
    }),
  },
  headerContainer:{
    height:55,
    justifyContent:'center',
    alignItems:'center',
    borderRightColor:'blue',
    backgroundColor:Color.primary,
  },
  shareTitle:{
    color:'black',
    fontWeight:'500',
    fontSize:18,
  },
  emailInput:{
    alignItems:"center",
    marginTop:20,
    fontSize: 16,
    width:width - 90,
    // height: 50,
    paddingVertical:10,
    borderColor:'#bbbbbb',
    alignSelf:'center',
    borderWidth:1,
    backgroundColor:Color.white,
    //color:'#525252',
    //color:'#157dfb',
    padding:4,
    marginBottom: 10,
    textAlign:"center",
    textAlignVertical:"top",


    height:45,
    backgroundColor:Color.primary,
    justifyContent: 'center',
    alignItems:'center',
  },
  txtSelectContact: {
    color:'#157dfb',
    color:Color.white,
        textAlign:'center',
        textTransform: 'uppercase',
        fontWeight:'bold',
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 15,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 15,
          },
        }),
  },
  notesInput:{
    fontSize: 16,
    width:width - 90,
    height: 90,
    borderColor:'#bbbbbb',
    alignSelf:'center',
    textAlign:"left",
    textAlignVertical:"top",
    borderWidth:1,
    backgroundColor:Color.white,
    color:'#525252',
    padding:4,
    marginBottom: 10,
  },
  horizontalDivider:{
    width:width - 50,
    height:1,
    backgroundColor:'#e7e8e9',
  },
  verticalDivider:{
    width:1,
    backgroundColor:'#e7e8e9'
  },
  buttonContainer:{
    flexDirection:'row',
    //justifyContent:'space-between',
    alignSelf:'center',
    width:"90%",
    marginVertical:20
  },
  buttonWrapper:{
    //flex:0.49,

    // width:'49%',
    // borderWidth: 1,
    // borderColor: "#e7e8e9",
    // borderRadius: 5,
    // alignItems:'center',
    // justifyContent:'center',
    // borderColor:Color.detailButtonBorder,

    width:'49%',
    backgroundColor:Color.white,
    paddingVertical:10,
        justifyContent: 'center',
        alignItems:'center',
        borderColor:'rgb(231,231,231)',
        borderWidth:1,
  },
  buttonWrapper2:{
    paddingVertical:10,
    alignItems:'center',
    justifyContent:"center",
    width:'49%',
    borderRadius: 5,
    backgroundColor:Color.primary,
    marginLeft:5
  },
  cancelBtnText:{
    color:Color.primary,
    fontSize:16
  },
  shareBtnText:{
    color:'white',
    fontSize:16,
    fontWeight:'700',
  },
});
