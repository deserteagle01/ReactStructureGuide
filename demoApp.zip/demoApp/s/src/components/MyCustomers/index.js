import React, {PureComponent} from 'react';
import {Text, TouchableOpacity, View, TextInput, Keyboard, SafeAreaView, Image, FlatList} from 'react-native';
import {Color, Languages, Images} from '@common';
//import Modal from 'react-native-modalbox';
import Modal from 'react-native-modal';
import styles from './styles';
import {log, toast} from '@app/Omni';
import { AddEditContact, Spinner } from "../../components";
import { connect } from "react-redux";

class MyCustomers extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      displayContactList: this.props.contactList,
      searchText: "",
      showClearSearch: false
    };
  }

  componentWillMount() {}

  componentWillUnmount() {}

  componentDidMount() {

  }

  showError(error){
    this._addeditcontact.showError(error);
  }

  componentWillReceiveProps(nextProps) {
    if(this.props != nextProps){
      if(this.props.contactList != nextProps.contactList){
          this.setState({displayContactList: nextProps.contactList});
      }
    }
  }

  updateContactList(contactList) {
      this.setState({displayContactList: contactList});
  }

  closeAddEditModal = () => {
    this._addeditcontact.cancel();
  }

  ediContactPress(selectItem, index) {
    this._addeditcontact.open(selectItem,this.props.companyList);
  }

  onChangeSearchText = (text) => {
    this.setState({searchText : text, showClearSearch: text.trim().length > 0});
  }

  onClearSearch = () => {
    this.setState({searchText : "", showClearSearch : false});
  }

  _renderItem = ({ item ,index}) => {
    let tempFirst = item.first_name ? item.first_name:"";
    let tempLast = item.surname ? item.surname:"";
    let tempName = tempFirst+" "+tempLast;
    if(tempName.toString().toUpperCase().includes(this.state.searchText.toUpperCase()) || this.state.searchText.length == 0){
      return (
        <View>
        <View style={styles.contactContainer}>
            <View style={styles.textView}>
                <Text style={styles.ct_name}>{tempName+" "}<Text style={styles.cp_name}>{"("+item.company_name+")"}</Text></Text>
                <Text style={styles.txtemail}>{"<"+item.email+">"}</Text>
            </View>
            <View style={styles.buttonsView}>
                <TouchableOpacity onPress={() => this.ediContactPress(item, index)}>
                    <Image source={Images.icons.edit} style={styles.listicon} />
                </TouchableOpacity>
            </View>
      </View>
      <View style={styles.seprator1}>
          <View style={styles.sepratorContainer}></View>
      </View>
    </View>
    );
    }
    else{
      return(
        null
      );
    }
  }

  renderSearchBar(){
    return(
      <View style={styles.searchInputContainer}>
        <Image source={Images.icons.search} style={styles.clearSearchIcon} />
        <TextInput
          style={styles.searchInputOpen}
          autoCapitalize="none"
          multiline={false}
          underlineColorAndroid="transparent"
          placeholder={Languages.Search}
          placeholderTextColor={"#d1d1d1"}
          onChangeText={this.onChangeSearchText}
          returnKeyType="search"
          value={this.state.searchText} />
        {this.state.showClearSearch &&
          <TouchableOpacity style={styles.clearSearchContainer} onPress={this.onClearSearch}>
            <Image
              source={Images.icons.close}
              style={styles.clearSearchIcon} />
          </TouchableOpacity>
        }
      </View>
    )
  }

  render() {
    return (
        <View style={styles.viewContainer}>
            {this.renderSearchBar()}
            <FlatList
              style={styles.contactlist}
              showsVerticalScrollIndicator={false}
              data={this.state.displayContactList}
              renderItem={(item, index) => this._renderItem(item, index)}
              keyExtractor={(item, index) => index.toString()}
              extraData={this.state.searchText} /> 
            <View style={styles.bottomContainer}>
              <TouchableOpacity style={styles.btadd} onPress={() => this._addeditcontact.open(undefined,this.props.companyList)}>
                <Text style={styles.txtadd}>{Languages.txtAddContact}</Text>
              </TouchableOpacity>
            </View>
        
        <AddEditContact
            addEditContactClick={(params) => this.props.addEditContactClick(params)}
            ref={(com) => (this._addeditcontact = com)} />
        {/* {isFetching ? <Spinner mode="overlay" /> : null} */}
      </View>
    );
  }
}

export default connect(
  undefined,
  undefined,
  undefined,
  { forwardRef: true }
)(MyCustomers);