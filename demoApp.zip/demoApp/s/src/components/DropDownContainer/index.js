
import React, {PureComponent} from 'react';
import {Text, TouchableOpacity, View, TextInput, Image, TouchableWithoutFeedback, Platform} from 'react-native';
import {Color, Languages, Images} from '@common';
import Modal from 'react-native-modal';
import styles from './styles';
import { connect } from "react-redux";
import {log, toast} from '@app/Omni';
import { Spinner, SearchableList } from "../../components";
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';

const commonStyle = {
  width: 0,
  height: 0
};
let device = Platform.OS;

const android = {
  elevation: 200,
  color: "white",
  height:20,
  width:20,
};
const pickerStyle1 = {
  chevron: commonStyle,
  inputIOS: commonStyle,
  inputAndroid: android,
};

class DropDownContainer extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      
    };
  }

  componentWillMount() {}

  componentWillUnmount() {}
    
  render() {
    return (
      <View style={styles.flexContainer}>
          <TouchableWithoutFeedback
            onPress={() => 
            this.props.list.length > 0 &&
            this._refPicker.togglePicker(true) }>
            <View style={styles.dropDownContainer}>
              <TextInput
                editable={false}
                pointerEvents="none"
                style={styles.searchInput2}
                autoCapitalize="none"
                multiline={false}
                underlineColorAndroid="transparent"
                placeholder={this.props.placeholder}
                placeholderTextColor={Color.inputBoxPlaceholder}
                value={this.props.value} />
              {device == 'android' ? (
                <View style={styles.btDropdowna}>
                  {this.renderPicker()}
                </View>
              ) : (
                <View style={styles.btDropdown}>
                  <TouchableOpacity
                    onPress={() =>
                      this.props.list.length > 0 &&
                      this._refPicker.togglePicker(true) }>
                    <Image
                      source={Images.icons.DropDown}
                      style={{height: 20, width: 20, marginRight: 0, tintColor:'white'}} />
                  </TouchableOpacity>
                  {this.renderPicker()}
                </View>
              )}
            </View>
          </TouchableWithoutFeedback>
          {this.props.error && (
            <Text style={styles.errorStyle}>{this.props.error}</Text>
          )}
        </View>
    );
  }
  
  renderPicker(){
    if(this.props.list.length>0){
      return(
        <RNPickerSelect
          Icon={() => { return device == "android" ? <Image style={{height: 20, width:20, marginRight: 0}} source={Images.icons.DropDown} /> : null }}
          ref={el => {this._refPicker = el }}
          style={pickerStyle1}
          placeholder={{label: Languages.txtPickerPlaceholder, value: null}}
          onValueChange={(text) => {
            if(text && text != this.props.value){
              let tempSource = [...this.props.list];
              let filteredAttribs = tempSource.filter((e) => e.value === text);
              this.props.updateValue(filteredAttribs[0].label, filteredAttribs[0].value);
            }
          }}
          useNativeAndroidPickerStyle={false}
          items={this.props.list} />
      );
    }else{
      return(
        null
    )}}
}
export default DropDownContainer;