import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Styles, Device, Constants } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
    flexContainer:{
        width:"87%",
        alignSelf:'center',
        //backgroundColor:'white',
        //borderRadius: 8,
      },
      txttitle: {
        alignSelf: 'center',
        color:'white',
        //fontWeight:'500',
        fontSize:18,
        fontWeight:'bold',
      },
      dropDownContainer:{
        flexDirection:'row',
        alignSelf:'center', 
        width: '100%',
        marginVertical:5,
      },
      headerContainer:{
        height:55,
        backgroundColor:Color.primary,
        justifyContent: 'center',
        alignItems:'center',
      },
      errorStyle: {
        color: "red",
        marginLeft: 22,
        marginVertical:2
      },
      secondButtonText:{
        // flex:0.4,
        // width:'50%',
        color:Color.primary,
        textAlign:'center',
        textTransform: 'uppercase',
        fontWeight:'bold',
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 15,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 15,
          },
        }),
      },
      buttonContainer:{
        flexDirection: 'row',
        width: "85%",
        overflow:'hidden',
        alignSelf:'center',
        marginTop: 30,
        marginBottom:25,
        justifyContent:'space-between'
      },
      firstButtonText:{
        color:Color.white,
        textAlign:'center',
        textTransform: 'uppercase',
        fontWeight:'bold',
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 15,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 15,
          },
        }),
      },firstButtonContainer:{
        width:'48%',
        height:55,
        backgroundColor:Color.primary,
        justifyContent: 'center',
        alignItems:'center',
        //marginLeft: 10
      },
      secondButtonContainer:{
        width:'48%',
        height:55,
        backgroundColor:Color.white,
        justifyContent: 'center',
        alignItems:'center',
        borderColor:'rgb(231,231,231)',
        borderWidth:1,
        //marginRight:10,
      },
      btDropdown:{
        position:"absolute",
        right:0,
        justifyContent:'center',
        alignItems:'center',
        height:"99%", 
        width:'15%',
      },
      searchInput2:{
        borderBottomColor:'white',
        borderBottomWidth:1,
        alignSelf: 'center',
        marginTop:15,
        width: "100%",
        color: Color.white,
        height: 40,
        //borderWidth:1,
        textAlign: "left",
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 14,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 14,
          },
        }),
      },
      btDropdown:{
        position:"absolute",
        right:0,
        top:5,
        justifyContent:'center',
        alignItems:'center',
        height:"99%", 
        width:'15%',
      },
      btDropdowna:{
        position:"absolute",
        justifyContent:'center',
        alignItems:'center',
        height:"100%", 
        width:'100%',
        //backgroundColor:'pink'
      },
      searchInput: {
        borderBottomColor:'black',
        borderBottomWidth:1,
        alignSelf: 'center',
        marginTop:15,
        width: "85%",
        color: Color.black,
        height: 40,
        //borderWidth:1,
        textAlign: "left",
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 14,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 14,
          },
        }),
      },
});
