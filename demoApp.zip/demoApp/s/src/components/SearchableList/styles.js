import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Styles, Device, Constants } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
    flexContainer:{
        width:"90%",
        alignSelf:'center',
        backgroundColor:'white',
        borderRadius: 8,
      },
      txttitle: {
        alignSelf: 'center',
        color:'white',
        //fontWeight:'500',
        fontSize:18,
        fontWeight:'bold',
      },
      headerContainer:{
        height:55,
        backgroundColor:Color.primary,
        justifyContent: 'center',
        alignItems:'center',
      },
      clearSearchIcon:{
        width:17,
        height:17,
        tintColor:'black',
        marginLeft: 7
      },
      contactlist:{
        flex:1,
        marginVertical:10,
        marginBottom : 50,
      },
      txtlabel:{
        color:'#d1d1d1',
        color:Color.white,
        fontWeight:'500',
        fontSize:17,
      },
      seprator1:{height:34, justifyContent:'center',width:'100%', marginLeft: 10},
      sepratorContainer:{height:1, backgroundColor:Color.detailButtonBorder,width:'100%'},
      contactContainer:{
        marginHorizontal: 10, 
        //alignItems:'center', 
        // flexDirection:'row', 
        // justifyContent:'space-between', 
        // overflow: "hidden"
      },
      clearSearchContainer:{
        padding:6,
        // backgroundColor:'pink',
      },
      searchInputOpen:{
        color: "black",
        height: 45,
        paddingLeft: 8,
        flex: 1,
        textAlign: "left",
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 14,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 14,
          },
        }),
      },
      searchInputContainer:{
        height: 45,
        flexDirection:'row',
        borderColor:'white',
        backgroundColor: 'white',
        borderRadius:8,
        alignItems:'center',
        marginVertical:10,
        marginHorizontal: 8,
        marginTop: 15,
        borderWidth: 1
      },
      checkIcon: {
        height: 25,
        width: 25
      },
      headerContainer:{
        width: "100%", 
        flexDirection: "row",
        justifyContent: 'space-between',
        backgroundColor:"white",
        alignItems:Platform.OS == "android" ? 'center': "flex-start",
        height:Platform.OS == "android" ? 60:40
      },
      txttitle:{
        color:'black',
        fontWeight:'500',
        fontSize:18,
      },
      backIcon: {
        height: 18,
        width: 18
      },
      errorStyle: {
        color: "red",
        marginLeft: 22,
        marginVertical:2
      },
      secondButtonText:{
        // flex:0.4,
        // width:'50%',
        color:Color.primary,
        textAlign:'center',
        textTransform: 'uppercase',
        fontWeight:'bold',
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 15,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 15,
          },
        }),
      },
      buttonContainer:{
        flexDirection: 'row',
        width: "85%",
        overflow:'hidden',
        alignSelf:'center',
        marginTop: 30,
        marginBottom:25,
        justifyContent:'space-between'
      },
      firstButtonText:{
        color:Color.white,
        textAlign:'center',
        textTransform: 'uppercase',
        fontWeight:'bold',
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 15,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 15,
          },
        }),
      },firstButtonContainer:{
        width:'48%',
        height:55,
        backgroundColor:Color.primary,
        justifyContent: 'center',
        alignItems:'center',
        //marginLeft: 10
      },
      secondButtonContainer:{
        width:'48%',
        height:55,
        backgroundColor:Color.white,
        justifyContent: 'center',
        alignItems:'center',
        borderColor:'rgb(231,231,231)',
        borderWidth:1,
        //marginRight:10,
      },
      btDropdown:{
        position:"absolute",
        right:0,
        justifyContent:'center',
        alignItems:'center',
        height:"99%", 
        width:'15%',
      },
      searchInput2:{
        borderBottomColor:'black',
        borderBottomWidth:1,
        alignSelf: 'center',
        marginTop:15,
        width: "100%",
        color: Color.black,
        height: 40,
        //borderWidth:1,
        textAlign: "left",
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 14,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 14,
          },
        }),
      },
      flexContainer:{
        flex:0, 
        backgroundColor:'white',
      },
      customSafearea: {
        flex:1, 
        backgroundColor:'black',
      },
      viewContainer: {
        flex:1, 
        backgroundColor:"#000",
      },
      txtadd:{
        color:Color.primary,
        marginHorizontal:15, 
        marginVertical: 15
      },
      btadd:{
        borderWidth: 1,
        borderColor: "#e7e8e9",
        borderRadius: 5,
        alignItems:'center',
        justifyContent:'center',
        borderColor:Color.detailButtonBorder,
        width:'60%',
        alignSelf:'center'
        },
      searchInput: {
        borderBottomColor:'black',
        borderBottomWidth:1,
        alignSelf: 'center',
        marginTop:15,
        width: "85%",
        color: Color.black,
        height: 40,
        //borderWidth:1,
        textAlign: "left",
        ...Platform.select({
          ios: {
            fontSize: Styles.width > 320 ? 16 : 14,
          },
          android: {
            fontSize: Styles.width > 360 ? 16 : 14,
          },
        }),
      },
});
