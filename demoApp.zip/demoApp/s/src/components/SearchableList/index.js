
import React, {PureComponent} from 'react';
import {Text, TouchableOpacity, View, TextInput, Keyboard, SafeAreaView, Image, FlatList, ActivityIndicator, Platform} from 'react-native';
import {Color, Languages, Images} from '@common';
import Modal from 'react-native-modal';
import styles from './styles';
import { connect } from "react-redux";
import {log, toast} from '@app/Omni';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';

class SearchableList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      display_list: [],
      actual_list: [],
      visible: false,
      searchText: "",
      showClearSearch: false
    };
  }

  open = (contact,company_list) => {
      let tempDict = {};
      tempDict.visible = true;
      tempDict.display_list = [];
      tempDict.actual_list = this.props.companyList;
      tempDict.searchText = "";
      tempDict.showClearSearch = false;
      this.setState(tempDict);
   };

  cancel = () => {
    this.setState({visible: false});
  };

  onChangeSearchText = (text) => {
    let tempAll = [...this.state.actual_list];
    let filterArray = tempAll.filter((e) => e.label.toString().toUpperCase().includes(text.toUpperCase()));
    this.setState({searchText : text, showClearSearch: text.trim().length > 0, display_list: text.trim().length > 0 ? filterArray: []});
  }

  onClearSearch = () => {
    this.setState({searchText : "", showClearSearch : false, display_list: []});
  }

  renderHeader(){
    return(
      <View style={styles.headerContainer}>
        <TouchableOpacity  style={{marginLeft: 20}} onPress={this.cancel}>
          <Image
            source={Images.icons.closeNew}
            style={styles.backIcon} />
        </TouchableOpacity>
        <Text style={styles.txttitle}>{Languages.txtCompanyTitle}</Text>
        <TouchableOpacity style={{marginRight: 20}} disabled={true}>
            
        </TouchableOpacity>
      </View>
    )
  }

  renderSearchBar(){
    return(
      <View style={styles.searchInputContainer}>
        <Image source={Images.icons.search} style={styles.clearSearchIcon} />
        <TextInput
          style={styles.searchInputOpen}
          autoCapitalize="none"
          multiline={false}
          underlineColorAndroid="transparent"
          placeholder={Languages.SearchCompany}
          placeholderTextColor={"#d1d1d1"}
          onChangeText={this.onChangeSearchText}
          returnKeyType="search"
          value={this.state.searchText} />
        {this.state.showClearSearch &&
          <TouchableOpacity style={styles.clearSearchContainer} onPress={this.onClearSearch}>
            <Image
              source={Images.icons.close}
              style={styles.clearSearchIcon} />
          </TouchableOpacity>
        }
      </View>
    )
  }

  render() {
    return (
      <Modal
        hasBackdrop={true}
        autoCorrect={false}
        isVisible={this.state.visible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={{margin: 0}}
        onBackButtonPress={this.cancel}
        onBackdropPress={this.cancel}>

        <SafeAreaView style={styles.flexContainer} />
        <SafeAreaView style={styles.customSafearea}>
            <View style={styles.viewContainer}>
            {this.renderHeader()}
            {this.renderSearchBar()}
            {this.state.display_list.length > 0 && 
              <FlatList
              style={styles.contactlist}
              showsVerticalScrollIndicator={false}
              data={this.state.display_list}
              renderItem={(item, index) => this._renderItem(item, index)}
              keyExtractor={(item, index) => index.toString()}
              extraData={this.state.display_list} />
            }
            {this.state.display_list.length == 0 && this.state.searchText.length > 0 &&
                <View style={{flex:1, alignItems:'center', justifyContent:'center'}}>
                  <TouchableOpacity style={styles.btadd} onPress={() => this.props.createCompany(this.state.searchText)}>
                    <Text style={styles.txtadd}>{Languages.txtCreateCompany}</Text>
                  </TouchableOpacity>  
                </View>
              }
            </View>
        </SafeAreaView>
    </Modal>
    );
  }

  _renderItem = ({ item ,index}) => {
      return(
        <TouchableOpacity style={styles.contactContainer} onPress={() => this.props.companySelected(item)}>
            <Text style={styles.txtlabel}>{item.label}</Text>
            <View style={styles.seprator1}>
                <View style={styles.sepratorContainer}></View>
            </View>
        </TouchableOpacity>
      );
  }
}

export default SearchableList;