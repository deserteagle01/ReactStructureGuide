import React, { useState, useEffect,useReducer, useImperativeHandle } from 'react';
import {Text, TouchableOpacity, View, Image, ActivityIndicator} from 'react-native';
import {Color, Languages, Images} from '@common';
import Modal from 'react-native-modal';
import styles from './styles';
import {log, toast} from '@app/Omni';
// import { stat } from 'react-native-fs';
import { ImageUpload } from "@components";

export default function StatusModal(props) {
    const [state, setState] = useReducer((state, newState) => ({...state, ...newState}),{statusArray: {}, isVisible: false, selectedStatus: "", imageUpload: false})

    useEffect(() => {
        let selectedList = props.selectedList;
        let tempList = selectedList.filter((e) => e.image_uploaded === false);
        setState({statusArray: props.statusArray, isVisible: props.isSelectionModalVisible, selectedStatus: "", imageUpload: tempList.length > 0 ? true: false});
    }, [props.statusArray, props.isSelectionModalVisible, props.selectedList]);

    cancel = () => {
        setState({isVisible: false});
        props.setModalFlag(false);
    }

    changeButton = () => {
        setState({imageUpload: false});
    }

    save = () => {
        if(state.imageUpload){
            this._imageUpload.open();
        }else{
            if(state.selectedStatus.length > 0){
                props.statusSelected(state.selectedStatus, state.statusArray[state.selectedStatus]);
            }else{
                alert(Languages.txtstatusSelectionWarning);
            }
        }
    }

    selectOption = (key, value) => {
        setState({statusArray: state.statusArray, selectedStatus: key});
    }

    function renderSelection() {
        return Object.keys(state.statusArray).map((key, index) => {
            return(
                <TouchableOpacity style={styles.tabt} onPress={() => selectOption(key, state.statusArray[key])}>
                    <Image source={ state.selectedStatus == key  ? Images.icons.check_box : Images.icons.checkbox_Notify} style={styles.selectedimg}/>
                    <Text style={styles.txttag}>{state.statusArray[key]}</Text>
                </TouchableOpacity>
                );
        });
    }
    
    return (
        <Modal
            hasBackdrop={true}
            autoCorrect={false}
            isVisible={state.isVisible}
            hideModalContentWhileAnimating={true}
            useNativeDriver={true}
            style={{margin: 0}}
            onBackButtonPress={this.cancel}
            onBackdropPress={this.cancel}>

        <View style={styles.flexContainer}>
            <View style={styles.headerContainer}>
              <Text style={styles.txttitle}>{ Languages.txtTitleSTatusPopup }</Text>
            </View>
            <View style={{marginVertical: 10}}>
            {renderSelection()}
            </View>
            <View style={styles.buttonContainer}>
                <TouchableOpacity style={styles.secondButtonContainer} onPress={this.cancel}>
                    <Text style={styles.secondButtonText} numberOfLines={1}>{Languages.CANCEL}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.firstButtonContainer} onPress={this.save}>
                    <Text style={styles.firstButtonText} numberOfLines={1}>{ state.imageUpload ? Languages.txtImageUplaodbt : Languages.save}</Text>
                </TouchableOpacity>
            </View>
        </View>
        {props.isLoading ?  
          <View style={{position:'absolute', alignSelf:"center",flex:1}}>
            <ActivityIndicator size="small" color="gray" /> 
          </View>
          : null}
        <ImageUpload 
            selectedList={props.selectedList}
            changeButton={this.changeButton}
            startUpload={props.startUpload}
            display_name={props.display_name}
            ref={(com) => (this._imageUpload = com)} />
    </Modal>
    );
}

