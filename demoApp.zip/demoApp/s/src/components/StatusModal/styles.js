import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Styles, Device, Constants } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  container:{
    flex: 1
  },
  headerContainer:{
    height:55,
    backgroundColor:Color.primary,
    justifyContent: 'center',
    alignItems:'center',
  },
  flexContainer:{
    width:"90%",
    alignSelf:'center',
    backgroundColor:'white',
    borderRadius: 8,
    overflow:'hidden'
  },
  selectedimg:{
    height:25,
    width: 25,
    tintColor: "#ed8723"
  },
  tabt:{
    width:'100%',
    marginLeft: 20,
    alignItems:'center',
    flexDirection:'row',
    marginVertical:8
    
  },
  txttag:{
    color:Color.TextLight,
    fontWeight:'400',
    fontSize:14,
    marginLeft: 10
  },
  txttitle: {
    alignSelf: 'center',
    color:'white',
    //fontWeight:'500',
    fontSize:18,
    fontWeight:'bold',
  },
  buttonContainer:{
    flexDirection: 'row',
    width: "85%",
    overflow:'hidden',
    alignSelf:'center',
    marginTop: 20,
    marginBottom:25,
    justifyContent:'space-between'
  },
  firstButtonText:{
    color:Color.white,
    textAlign:'center',
    textTransform: 'uppercase',
    //fontWeight:'bold',
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 16 : 15,
      },
      android: {
        fontSize: Styles.width > 360 ? 16 : 15,
      },
    }),
  },firstButtonContainer:{
    width:'48%',
    height:50,
    backgroundColor:Color.primary,
    justifyContent: 'center',
    alignItems:'center',
    //marginLeft: 10
  },
  secondButtonContainer:{
    width:'48%',
    height:50,
    backgroundColor:Color.white,
    justifyContent: 'center',
    alignItems:'center',
    borderColor:'rgb(231,231,231)',
    borderWidth:1,
    //marginRight:10,
  },
  });
