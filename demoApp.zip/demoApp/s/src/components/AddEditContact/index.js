
import React, {PureComponent} from 'react';
import {Text, TouchableOpacity, View, TextInput, Keyboard, SafeAreaView, Image, FlatList, ActivityIndicator, Platform} from 'react-native';
import {Color, Languages, Images} from '@common';
import Modal from 'react-native-modal';
import styles from './styles';
import { connect } from "react-redux";
import {log, toast} from '@app/Omni';
import { indexOf } from 'lodash';
import style from '../Chips/style';
import { Spinner, SearchableList } from "../../components";
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
//let Emailregex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
let Emailregex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
const commonStyle = {
  width: 0,
  height: 0
};
let device = Platform.OS;

const android = {
  elevation: 200,
  color: "white",
  height:20,
  width:20,
};
const pickerStyle1 = {
  chevron: commonStyle,
  inputIOS: commonStyle,
  inputAndroid: android,
};

class AddEditContact extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      contact: undefined,
      first_name: "",
      first_nameError: undefined,
      last_name: "",
      last_nameError: undefined,
      contact_id: "",
      email: "",
      emailError: undefined,
      company: "",
      company_id: "",
      companyError: undefined,
      company_list: [],
    };
  }

  componentWillMount() {}

  componentWillUnmount() {}

  open = (contact,company_list) => {
      let tempDict = {};
      tempDict.first_name = contact ? contact.first_name ? contact.first_name : "" : "";
      tempDict.last_name = contact ? contact.surname ? contact.surname : "" : "";
      tempDict.contact_id = contact ? contact.id : "";
      tempDict.email = contact ? contact.email: "";
      tempDict.company_list = company_list;
      tempDict.company = contact ? contact.company_name: "";
      tempDict.company_id = contact ? contact.company_id: "";
      tempDict.contact = contact
      tempDict.visible = true;
      tempDict.first_nameError = undefined;
      tempDict.last_nameError = undefined;
      tempDict.emailError = undefined;
      tempDict.companyError = undefined;
      this.setState(tempDict);
  };

  cancel = () => {
    this.setState({visible: false, contact: undefined });
  };

  showError(error){
    alert(error);
  }
  checkValidation = () => {
    const {first_name, last_name, email, company} = this.state;
    let requiredValid = this.checkRequiredFieldValidation(first_name, last_name,email, company);
    if((requiredValid.first_nameError == undefined && requiredValid.last_nameError == undefined) && (requiredValid.emailError == undefined && requiredValid.companyError == undefined)){
        if(Emailregex.test(email)){
          this.setState(requiredValid);
          return true;
        }
        else{
          requiredValid.emailError = Languages.notValidEmail;
          this.setState(requiredValid);
          return false;
        }
    }
    else{
      this.setState(requiredValid);
      return false;
    }
  }
  
  checkRequiredFieldValidation(first_name, last_name, email, company){
    let tempState = {
      first_nameError: undefined,
      last_nameError: undefined,
      emailError: undefined,
      companyError: undefined
    };
    if(first_name.trim().length <= 0){
      tempState.first_nameError = Languages.ErrFirstNameReq;    
    }
    if(last_name.trim().length <= 0){
      tempState.last_nameError = Languages.ErrLastNameReq;    
    }
    if(email.trim().length <= 0){
      tempState.emailError = Languages.ErrEmailReq;    
    }
    if(company.trim().length <= 0){
      tempState.companyError = Languages.ErrCompReq;
    }
    return tempState;
  }

  isFieldDirty = () => {
    if(this.state.contact){
      //Edit contact case
      let passedSurname = this.state.contact.surname ? this.state.contact.surname.trim() : "";
      let passedFirstname = this.state.contact.first_name ? this.state.contact.first_name.trim() : ""; 
      if((this.state.first_name.trim() == passedFirstname && this.state.last_name.trim() == passedSurname) && (this.state.email.trim() == this.state.contact.email.trim() && this.state.company.trim() == this.state.contact.company_name.trim())){
          return false;
      }else{
         return true
      }
    }
    else{
      //Add contact case
      return true;
    }
  }

  save = () => {
    if(this.checkValidation()){
      if(this.isFieldDirty()){
          let params = {};
          params.first_name = this.state.first_name;
          params.surname = this.state.last_name;
          params.email = this.state.email;
          params.company_name = this.state.company;
          if(this.state.contact) { 
            params.id = this.state.contact_id;
          }
          let tempSource = [...this.state.company_list];
          let filteredAttribs = tempSource.filter((e) => e.label.trim() === this.state.company.trim());
          if(filteredAttribs.length > 0){
            params.company_id = filteredAttribs[0].value;
          }
          this.props.addEditContactClick(params);
      }
      else{
        this.cancel();
      }
    }
  }

  render() {
    return (
      <Modal
        hasBackdrop={true}
        autoCorrect={false}
        isVisible={this.state.visible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={{margin: 0}}
        onBackButtonPress={this.cancel}
        onBackdropPress={this.cancel}>

        <View style={styles.flexContainer}>
            <View style={styles.headerContainer}>
              <Text style={styles.txttitle}>{this.state.contact ? Languages.txtEditContact : Languages.txtAddContact }</Text>
            </View>
            <TextInput
                style={styles.searchInput}
                placeholderTextColor={Color.inputBoxPlaceholder}
                autoCapitalize="none"
                multiline={false}
                underlineColorAndroid="transparent"
                placeholder={Languages.txtContactNamePlaceholder}
                onChangeText={(text) => this.setState({first_name: text})}
                value={this.state.first_name} />

                {this.state.first_nameError &&
                    <Text style={styles.errorStyle}>{this.state.first_nameError}</Text>
                }

            <TextInput
                style={styles.searchInput}
                placeholderTextColor={Color.inputBoxPlaceholder}
                autoCapitalize="none"
                multiline={false}
                underlineColorAndroid="transparent"
                placeholder={Languages.txtLastNamePlaceholder}
                onChangeText={(text) => this.setState({last_name: text})}
                value={this.state.last_name} />

                {this.state.last_nameError &&
                    <Text style={styles.errorStyle}>{this.state.last_nameError}</Text>
                }
          

            <TextInput
                style={styles.searchInput}
                autoCapitalize="none"
                multiline={false}
                underlineColorAndroid="transparent"
                placeholder={Languages.UserOrEmail}
                placeholderTextColor={Color.inputBoxPlaceholder}
                onChangeText={(text) => this.setState({email: text})}
                value={this.state.email} />

                {this.state.emailError &&
                    <Text style={styles.errorStyle}>{this.state.emailError}</Text>
                }

            <TouchableOpacity style={{flexDirection:'row',alignSelf:'center', width: '87%'}} onPress={() => this._searchablelist.open()}>
              <TextInput
                  pointerEvents="none"
                  style={styles.searchInput2}
                  editable={false}
                  autoCapitalize="none"
                  multiline={false}
                  underlineColorAndroid="transparent"
                  placeholder={Languages.txtCompanyName}
                  placeholderTextColor={Color.inputBoxPlaceholder}
                  onChangeText={(text) => this.setState({company: text, company_id: ""})}
                  value={this.state.company} />
                  {/* {
                    device == "android" ?
                  <View style={styles.btDropdown}>
                      {this.renderCompanyPicker()}
                  </View>
                    :
                    <View style={styles.btDropdown}>
                    <TouchableOpacity onPress={() => 
                      {
                        if(this.state.company_list.length > 0){
                          this.refName.togglePicker(true)
                        }} }>
                        <Image source={Images.icons.DropDown} style={{height: 20, width:20, marginRight: 0}}/>
                      </TouchableOpacity>
                        {this.renderCompanyPicker()}
                      </View>
                  } */}
            </TouchableOpacity>
            {this.state.companyError &&
                    <Text style={styles.errorStyle}>{this.state.companyError}</Text>
                }
            <View style={styles.buttonContainer}>
                <TouchableOpacity style={styles.secondButtonContainer} onPress={this.cancel}>
                    <Text style={styles.secondButtonText} numberOfLines={1}>{Languages.CANCEL}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.firstButtonContainer} onPress={this.save}>
                    <Text style={styles.firstButtonText} numberOfLines={1}>{Languages.save}</Text>
                </TouchableOpacity>
            </View>
        </View>
        <SearchableList 
          companyList={this.state.company_list}
          createCompany={(text) => {
            this.setState({company: text, company_id: ""});
            this._searchablelist.cancel();
          }}
          companySelected={(item) => {
            this.setState({company: item.label, company_id: item.value});
            this._searchablelist.cancel();
          }}
          ref={(com) => (this._searchablelist = com)} />
        {this.props.isContactFetching ?  
          <View style={{position:'absolute', alignSelf:"center",flex:1}}>
            <ActivityIndicator size="small" color="gray" /> 
          </View>
          : null}
    </Modal>
    );
  }
  
  renderCompanyPicker(){
    if(this.state.company_list.length>0){
      return(
        <RNPickerSelect
          Icon={() => { return device == "android" ? <Image style={{height: 20, width:20, marginRight: 0}} source={Images.icons.DropDown} /> : null }}
          ref={el => {this.refName = el }}
          style={pickerStyle1}
          placeholder={{label: Languages.txtPickerPlaceholder, value: null}}
          onValueChange={(text) => {
            if(text && text != this.state.company){
              let tempSource = [...this.state.company_list];
              let filteredAttribs = tempSource.filter((e) => e.value === text);
              this.setState({company: filteredAttribs[0].label, company_id: filteredAttribs[0].value});
            }
          }}
          useNativeAndroidPickerStyle={false}
          items={this.state.company_list} />
      );
    }else{
      return(
        null
    )}}
}

const mapStateToProps = (state) => {
  return {
    isContactFetching: (state.Contacts.type == "ADD_EDIT_CONTACT_PENDING" || state.Contacts.type == "FETCH_CONTACT_PENDING") ? true : false
  };
};

export default connect(
    mapStateToProps,
    undefined,
    undefined,
    { forwardRef: true }
  )(AddEditContact);