/** @format */

import { StyleSheet, Dimensions, Platform } from "react-native";
import { Color, Styles } from "@common";
const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  mainViewContainer:{
    width,
    height,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBoxWrap: {
    // height: '55%',
    width: '80%',
    backgroundColor:'#fff',
  },
  headerContainer:{
    height:55,
    backgroundColor:Color.primary,
    justifyContent: 'center',
    alignItems:'center',
    padding:10,
    flexDirection:'row',
    paddingLeft:0
  },
  headerText:{
    flex:0.9,
    color:'white',
    fontWeight:'bold',
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 18 : 17,
      },
      android: {
        fontSize: Styles.width > 360 ? 18 : 18,
      },
    }),
  },
  headerCloseContainer:{
    flex:0.1,
    justifyContent:'center',
    alignItems:'center',
    position:'absolute',
    right:0,
    padding:16,
  },
  headerCloseIcon:{
    height: 20,
    width: 20,
    tintColor:Color.white,
    alignSelf:'flex-end',
    padding:8
  },
  imageContainer:{
    height:55,
    justifyContent: 'center',
    alignItems:'center',
  },
  mainImageIcon:{
    height: 50,
    width: 50,
    tintColor:'#36af26',
  },
  primaryTextContainer:{
    // height:100,
    marginHorizontal:35,
    // paddingVertical:8,
    // backgroundColor:'pink'
  },
  primaryText:{
    color:Color.black,
    paddingVertical:8,
    // backgroundColor:'orange',
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 16 : 15,
      },
      android: {
        fontSize: Styles.width > 360 ? 16 : 15,
      },
    }),
  },

  dividerContainer:{
    height:5,
    width:60,
    backgroundColor:Color.primary,
    alignSelf:'center',
  },
  secondaryTextContainer:{
    height:100,
    justifyContent: 'center',
    alignItems:'center',
    padding:8,
    // backgroundColor:'pink'
  },
  secondaryText:{
    color:Color.black,
    fontSize:18,
  },
  buttonContainer:{
    flexDirection:'row',
    height:80,
    justifyContent: 'center',
    alignItems:'center',
    padding:8,
    // backgroundColor:'pink',
    borderColor:'rgb(231,231,231)',
    // borderTopWidth:1,
    marginLeft:8,
    marginRight:8,
    bottom:0,
  },
  firstButtonContainer:{
    width:'50%',
    height:55,
    backgroundColor:Color.primary,
    justifyContent: 'center',
    alignItems:'center',
    marginRight:5,
  },
  firstButtonText:{
    // flex:0.4,
    // width:'50%',
    color:Color.white,
    textAlign:'center',
    textTransform: 'uppercase',
    fontWeight:'bold',
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 16 : 15,
      },
      android: {
        fontSize: Styles.width > 360 ? 16 : 15,
      },
    }),
  },
  secondButtonContainer:{
    width:'50%',
    height:55,
    backgroundColor:Color.white,
    justifyContent: 'center',
    alignItems:'center',
    marginLeft:5,
    borderColor:'rgb(231,231,231)',
    borderWidth:1,
  },
  secondButtonText:{
    // flex:0.4,
    // width:'50%',
    color:Color.primary,
    textAlign:'center',
    textTransform: 'uppercase',
    fontWeight:'bold',
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 16 : 15,
      },
      android: {
        fontSize: Styles.width > 360 ? 16 : 15,
      },
    }),
  },


});
