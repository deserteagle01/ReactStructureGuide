/** @format */

import React, { PureComponent } from "react";
import {
  Text,
  TouchableOpacity,
  View,
  Image
} from "react-native";
import { Images} from "@common";
import { CommonModal } from "@components";
import defaultStyles from "./styles";

class StonestockDialog extends PureComponent {

  constructor(props){
    super(props);
  }

  componentDidMount() {
		if (this.props.onRef) {
			this.props.onRef(this);
		}
	}

	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

  open = () => {
    this._commonModal.open();
  }

  close = () => {
    this._commonModal.close()
  }

  static defaultProps = {
      showCloseButtonAtHeader : true,
      showButton : true,
      showDivider: false,
      showMainLogoImage: false,
  };


  render() {
    const {
      titleText,
      primaryText,
      secondaryText,
      showDivider,
      showMainLogoImage,
      imageIcon,
      showButton,
      showCloseButtonAtHeader,
      closeButtonIconAtHeader,
      primaryBtnText,
      secondaryBtnText,
      modalStyle,
      headerContainerStyle,
      headerTextStyle,
      headerCloseContainerStyle,
      headerCloseIconStyle,
      imageContainerStyle,
      mainImageIconStyle,
      primaryTextContainerStyle,
      primaryTextStyle,
      dividerContainerStyle,
      secondaryTextContainerStyle,
      secondaryTextStyle,
      buttonContainerStyle,
      firstButtonContainerStyle,
      firstButtonTextStyle,
      secondButtonContainerStyle,
      secondButtonTextStyle,
      primaryButtonCallback,
      scondaryButtonCallback,
      boldText,
      boldTextBefore,
      boldTextAfter,
      boldTextStyle,
    } = this.props;
    return (
      <CommonModal ref={(com) => (this._commonModal = com)}>
          <View style={defaultStyles.mainViewContainer}>
          <View style={[defaultStyles.modalBoxWrap,modalStyle]} >
            {/* header part*/}
            {titleText && titleText != "" &&
              <View style={[defaultStyles.headerContainer,headerContainerStyle]}>
                <Text style={[defaultStyles.headerText,headerTextStyle]} numberOfLines={1}>{titleText}</Text>
              </View>
            }
            {showCloseButtonAtHeader &&
              <TouchableOpacity style={[defaultStyles.headerCloseContainer,headerCloseContainerStyle]} onPress={this.close}>
                <Image source={(closeButtonIconAtHeader != undefined && closeButtonIconAtHeader != "") ? closeButtonIconAtHeader : Images.icons.close_withoutBack} style={[defaultStyles.headerCloseIcon,headerCloseIconStyle]} />
              </TouchableOpacity>
            }

            {/* image part*/}
            {showMainLogoImage &&
              <View style={[defaultStyles.imageContainer,imageContainerStyle]}>
                  <Image source={(imageIcon != undefined && imageIcon != "") ? imageIcon : Images.icons.check_box} style={[defaultStyles.mainImageIcon,mainImageIconStyle]} />
              </View>
            }

            {/* primary text part*/}
            {primaryText && primaryText != "" &&
              <View style={[defaultStyles.primaryTextContainer,primaryTextContainerStyle]}>
                <Text style={[defaultStyles.primaryText,primaryTextStyle]}>{primaryText}</Text>
              </View>
            }

            {this.props.children}

            {/* divider part*/}
            {showDivider &&
              <View style={[defaultStyles.dividerContainer,dividerContainerStyle]} />
            }

            {/* secondary text part*/}
            {secondaryText && secondaryText != "" &&
              <View style={[defaultStyles.secondaryTextContainer,secondaryTextContainerStyle]}>
                <Text style={[defaultStyles.secondaryText,secondaryTextStyle]}>{secondaryText}</Text>
              </View>
            }

            {/* bottom button part*/}
            {showButton &&
              <View style={[defaultStyles.buttonContainer,buttonContainerStyle]}>
                  {primaryBtnText && primaryBtnText != "" &&
                    <TouchableOpacity style={[defaultStyles.firstButtonContainer,firstButtonContainerStyle]} onPress={primaryButtonCallback}>
                        <Text style={[defaultStyles.firstButtonText,firstButtonTextStyle]} numberOfLines={1}>{primaryBtnText}</Text>
                    </TouchableOpacity>
                  }
                  {secondaryBtnText && secondaryBtnText != "" &&
                    <TouchableOpacity style={[defaultStyles.secondButtonContainer,secondButtonContainerStyle]} onPress={scondaryButtonCallback}>
                        <Text style={[defaultStyles.secondButtonText,secondButtonTextStyle]} numberOfLines={1}>{secondaryBtnText}</Text>
                    </TouchableOpacity>
                  }
              </View>
            }

          </View>
          </View>
      </CommonModal>
    );
  }

}

export default StonestockDialog
