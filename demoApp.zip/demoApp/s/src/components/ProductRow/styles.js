/** @format */

import { StyleSheet, Platform } from "react-native";
import { Styles, Color, Constants } from "@common";

let imageHeight = Constants.productImageHeight;
let descHeight = Constants.productDescHeight;

export default StyleSheet.create({
  container_product: {
      backgroundColor: 'rgb(25,25,25)',
      paddingBottom: 10,
      marginHorizontal: Styles.width / 30,
      marginTop: 4,
      marginBottom:10,
    },
    imageContainer:{
      width:Styles.width-2*( Styles.width / 30),
      height:imageHeight,
      marginBottom: 8,
      alignItems:"center",
      justifyContent:"center",
    },
    image: {
      marginBottom: 8,
      width: Styles.width - 30,
      height:imageHeight,
    },
    subtext_wrapper: {
      ...Styles.Common.Row,
      top: 0,
      marginTop: 0,
      flexDirection:"row",
    },
    textContainer:{
      paddingHorizontal: 15,
      paddingVertical:5,
      flexDirection:"column",
      flex:1,
      alignItems:"flex-start",
      justifyContent:"center",
    },
    textView:{
      // flexDirection:"column",
      flex:1,
      alignItems:"flex-start",
      justifyContent:"center",
    },
    mainTextWarpper:{
      //flex: 1,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    mainTextIconWrapper:{
      flex:0.1,
      alignItems:'flex-end',
      justifyContent:"center",
    },
    mainTextIcon:{
      width:15,
      height:15,
      tintColor:Color.primary
    },
    listViewPrimaryText:{
      fontWeight: "500",
      color: Color.listPrimaryText,
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 18 : 14,
        },
        android: {
          fontSize: Styles.width > 360 ? 18 : 15,
        },
      }),
      textAlign: "left",
      flexWrap: 'wrap',
    },
    listViewSecondaryText:{
      color: Color.listSecondaryText,
      textAlign: "left",
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 14 : 11,
        },
        android: {
          fontSize: Styles.width > 360 ? 14 : 12,
        },
      }),
      marginTop: 1
    },
    listViewSecondaryText2:{
      color: Color.listSecondaryText,
      textAlign: "left",
      ...Platform.select({
        ios: {
          fontSize: Styles.width > 320 ? 14 : 11,
        },
        android: {
          fontSize: Styles.width > 360 ? 14 : 12,
        },
      }),
      marginTop: 3
    },
    listViewTextDivider:{
      color: Color.listSecondaryText,
      fontSize: Styles.FontSize.tiny,
    },
    dividerText:{
      color: Color.white,
      fontSize:16,
      fontWeight:'500',
    },
    viewFirstRow: {
      flexDirection:'row',
      flexWrap: 'wrap',
      //alignItems:'center'
    },
    subTextContainer:{
      flexDirection: "row",
      marginTop: 4,
    },
    listViewSecondaryShimmerText:{
      // flex:1,
      width: Styles.width - 60,
    },
    listViewNameTextShimmer:{
      width: Styles.width /3,
    },
    overlayBtnContainer:{
      position:'absolute',
      right:0,
      bottom:0,
      top:0,
    },
    overlayBtnInnerTopContainer:{
      padding:8,
      flex:0.5,
    },
    overlayBtnInnerBottomContainer:{
      padding:8,
      flex:0.5,
      justifyContent:"flex-end"
    },
    saveIconWrapper:{
      backgroundColor:"transparent"
    },
    hideIconWrapper:{
      backgroundColor:"transparent",
    },
    overlayIcon:{
      width:30,
      height:30,
      tintColor:Color.primary,
    },
    //------ hide stock modal style -----
    modalStyle:{
      width:'90%',
      // ...Platform.select({
      //   ios: {
      //     height : Styles.width > 320 ? 205 : 210,
      //   },
      //   android: {
      //     height : Styles.width > 360 ? 205 : 220,
      //   },
      // }),
    },
});
