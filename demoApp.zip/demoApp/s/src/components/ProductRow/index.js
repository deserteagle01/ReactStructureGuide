import React, { PureComponent } from "react";
import { View, TouchableOpacity, Image, Text, ImageBackground, InteractionManager } from "react-native";
import { Styles, withTheme, Images, Languages } from "@common";
import { getProductImage, log, toast } from "@app/Omni";
import { ImageCache, Shimmer, SaveHideStoneModal } from "@components";
import styles from "./styles";
import { connect } from "react-redux";
import Carousel from 'react-native-snap-carousel';
import { firebase } from '@react-native-firebase/analytics';

class ProductRow extends PureComponent {

  constructor(props){
    super(props);
  }

  onSaveClick = (item) => {
    this._saveHideStoneModal.saveClick(item, this.props.from);
  }
  onHideClick = (item) => {
    this._saveHideStoneModal.open(item, this.props.from);
  }

  _renderItem({item,index},onPress){
    const image_width = Styles.width * 0.9 - 2;
    return (
      <TouchableOpacity style={{flex:1}} activeOpacity={0.9} onPress={onPress}>
          <ImageCache
              uri={getProductImage(item,image_width)}
              style={{flex:1}}
          />
      </TouchableOpacity>
    )
  }
  render() {
    const { product, onPress, isFetching, tags, from } = this.props;
    var images=[];
    for(var i=0;i<product.images.length;i++){
      images.push(product.images[i].src)
    }
    
    let materialDetail = product.material_detail, qualityDetail = product.quality_detail, totalLiveBundle = product.total_stocks_bundle, stock_id = product.stone_detail_id, stock_number = product.stock_number,
      quantitySqm = product.quantity_stocks_sqm, sizeDetail = product.size_detail, finishingDetail = product.finishing_detail, showOverlayBtn = true, block_no = product.block_no;

    if(tags && (["recently_submitted", "owner_stock"].indexOf(tags) !== -1) && product && product.stone_ids && product.stone_ids.length > 1){
        materialDetail = product.material_string;
        qualityDetail = product.quality_string;
        totalLiveBundle = product.total_live_number_of_bundle;
        quantitySqm = product.total_quantity_sqm;
        sizeDetail = product.size_string.includes(',') ? null : product.size_string;
        finishingDetail = product.finishing_string.includes(',') ? null : product.finishing_string;
        block_no = product.block_string;
        showOverlayBtn = false;
    }
    let isVisibleBottomText = from == "searchList" &&  !showOverlayBtn ? false : true;
    return (
      <View>
        <View style={styles.container_product}>
            <Shimmer style={styles.image} visible={!isFetching}>
                <View style={styles.imageContainer}>
                  <Carousel
                      sliderWidth={Styles.width-2*( Styles.width / 30)}
                      itemWidth={Styles.width-2*(Styles.width / 30) }
                      data={images}
                      renderItem={({item,index}) => this._renderItem({item,index},onPress)}
                      removeClippedSubviews={false}
                  />
                  {/*overlay icon*/}
                  {showOverlayBtn &&
                    <View style={styles.overlayBtnContainer}>
                      <ImageBackground source={Images.icons.icon_overlay} style={{ width: '100%', height: '100%', backgroundColor:"transparent"}} resizeMode={'stretch'}>
                      {tags != "owner_stock" && !product.is_self_owned &&
                        <View style={styles.overlayBtnInnerTopContainer}>
                            <TouchableOpacity style={styles.saveIconWrapper} onPress={() => this.onSaveClick(product)}>
                              <Image source={product.is_add_to_watchlist ? Images.icons.heartFilled : Images.icons.heart} style={styles.overlayIcon} resizeMode={'contain'} />
                            </TouchableOpacity>
                        </View>
                      }
                      {tags != "owner_stock" && !product.is_self_owned &&
                        <View style={styles.overlayBtnInnerBottomContainer}>
                            <TouchableOpacity style={styles.hideIconWrapper} onPress={() => this.onHideClick(product)}>
                              <Image source={product.is_hidden ? Images.icons.eye : Images.icons.hide} style={styles.overlayIcon} resizeMode={'contain'} />
                            </TouchableOpacity>
                        </View>
                      }
                      </ImageBackground>
                    </View>
                  }
                </View>
            </Shimmer>
            <TouchableOpacity
              activeOpacity={0.5}
              onPress={onPress}
              style={styles.textContainer}>
              <View style={styles.textView}>
                <View style={styles.mainTextWarpper}>
                  <View style={{flex:0.9}}>
                    <Shimmer style={styles.listViewNameTextShimmer} visible={!isFetching} >
                    <View style={styles.viewFirstRow}>
                      <Text
                        style={styles.listViewPrimaryText}
                        numberOfLines={1}>
                        {product.display_name}
                      </Text>
                      <Text style={styles.dividerText}>{'  /  '}</Text>
                      <Text style={styles.listViewSecondaryText2}>{materialDetail}</Text>
                      </View>
                    </Shimmer>
                  </View>
                  <View style={styles.mainTextIconWrapper}>
                    <Image source={Images.icons.rightArrow} style={styles.mainTextIcon}/>
                  </View>
                </View>

                {(finishingDetail || sizeDetail) ?
                  <Shimmer style={styles.listViewSecondaryShimmerText} visible={!isFetching} >
                    <Text
                    style={styles.listViewSecondaryText}
                    numberOfLines={1}>
                      {finishingDetail}
                      {(finishingDetail && sizeDetail) &&
                        <Text style={styles.dividerText}>{'  /  '}</Text>
                      }
                      {sizeDetail}
                    </Text>
                  </Shimmer>
                  : null
                }

                <Shimmer style={styles.listViewSecondaryShimmerText} visible={!isFetching} >
                  <Text
                    style={styles.listViewSecondaryText}
                    numberOfLines={1}>
                    {totalLiveBundle + ' ' + Languages.BUNDLES}
                    <Text style={styles.dividerText}>{'  /  '}</Text>
                    {quantitySqm + ' ' + Languages.SQM}
                  </Text>
                </Shimmer>

                <Shimmer style={styles.listViewSecondaryText} visible={!isFetching} >
                  {showOverlayBtn ?
                    <Text
                    style={styles.listViewSecondaryText}
                    numberOfLines={1}>
                      {Languages.txtBlockNumber+":"} {block_no}
                      <Text style={styles.dividerText}>{'  /  '}</Text>
                      {Languages.StockId+":"} {stock_number}
                    </Text> :
                    <Text
                    style={styles.listViewSecondaryText}
                    numberOfLines={1}>
                      {Languages.multipleBlocks}
                    </Text>
                  }
                </Shimmer>

              </View>
            </TouchableOpacity>
        </View>
        <SaveHideStoneModal onRef={(com) => (this._saveHideStoneModal = com)} tags={tags} navigation={this.props.navigation} />
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    isFetching: state.stockList.isFetchingList || state.browse.isFetchingShowAll,
  };
};

export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    undefined
  )(ProductRow)
);
