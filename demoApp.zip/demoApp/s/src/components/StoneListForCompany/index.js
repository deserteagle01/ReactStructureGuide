import React, { PureComponent } from "react";
import PropTypes from "prop-types";
import { View, FlatList, Image, Text, ScrollView} from "react-native";
import { connect } from "react-redux";
import { withTheme, Languages, Images } from "@common";
import { ProductRow } from "@components";
import { toast,log } from "@app/Omni";
import styles from "./styles";
import { firebase } from '@react-native-firebase/analytics';

class StoneListForCompany extends PureComponent {
  static propTypes = {
    onViewProductScreen: PropTypes.func,
    navigation: PropTypes.object,
  };

  constructor(props){
    super(props);
    this.state = {
      isRefreshFetch : false,
      company_id : this.props.company_id,
    }
    this.pageNumber = 1;
  }

  componentDidMount() {
    const { fetchStockList } = this.props;

    this.pageNumber = 1;
    let stoneFilter = {
      "company_id":this.state.company_id,
    }
    fetchStockList(this.pageNumber, stoneFilter);
    firebase.analytics().setCurrentScreen("StoneListForCompany Screen");
  }

  componentWillReceiveProps(nextProps) {
    // log("----------------------- componentWillReceiveProps stone listlist -----------")
    // log(nextProps)
    if(nextProps.error != null && nextProps.type == 'FETCH_STOCKLIST_FAILURE'){
      toast(nextProps.error)
    }
  }

  renderRow = (product) => {
    return (
      <ProductRow
        navigation={this.props.navigation}
        product={product.item}
        onPress={() => this.onRowClickHandle(product.item)}
      />
    );
  }

  onRowClickHandle = (product) => {
    this.props.navigation.push("DetailScreen", {"product" : product});
  }

  onEndReachedCompany = () => {
    const { stillFetch, fetchStockList, isConnected } = this.props;
    if (isConnected && stillFetch) {
      this.pageNumber = this.pageNumber + 1;
      let stoneFilter = {
        "company_id":this.state.company_id,
      }
      fetchStockList(this.pageNumber, stoneFilter);
    }
  }

  onRefreshHandle = () => {
    const { fetchStockList, isConnected } = this.props;
    this.pageNumber = 1;
    if(isConnected){
      let stoneFilter = {
        "company_id":this.state.company_id,
      }
      fetchStockList(this.pageNumber, stoneFilter);
    }else{
      toast(Languages.InternetError)
    }
  }

  render() {
    const { stockList } = this.props;

    return (
      <View>
      {stockList.length > 0 ?
        <FlatList
          keyExtractor={(item, index) => `${item.stone_detail_id}`}
          data={stockList}
          renderItem={this.renderRow}
          onEndReached={this.onEndReachedCompany}
          refreshing={this.state.isRefreshFetch}
          onRefresh={this.onRefreshHandle}
          initialListSize={4}
        />
        :
        <View style={styles.notFoundContainer}>
            <View style={styles.imageContainer}>
                <Image style={styles.imageIcon} source={Images.icons.attention}/>
            </View>
            <View style={styles.textContainer}>
                <Text style={styles.text}>{Languages.recordsNotFound}</Text>
            </View>
        </View>
      }
      </View>

    );
  }
}

const mapStateToProps = (state) => {
  // log('--------- mapStateToProps stone StoneListForCompany-------------')
  // log(state)
  return {
    isConnected: state.netInfo.isConnected,
    stockList: state.stockListForCompany.list,
    isFetching:state.stockListForCompany.isFetching,
    stillFetch:state.stockListForCompany.stillFetch,
    error:state.stockListForCompany.error,
    type:state.stockListForCompany.type,
  };
};

function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  const StockListForCompanyRedux = require("@redux/StockListForCompanyRedux");
  const { isConnected } = stateProps;
  return {
    ...ownProps,
    ...stateProps,
    fetchStockList: (pageNumber, stoneFilter) => {
      if(isConnected){
        StockListForCompanyRedux.actions.fetchStockList(dispatch, pageNumber, stoneFilter)
      }else{
        toast(Languages.InternetError)
      }
    },
  };
}

export default withTheme(
  connect(
    mapStateToProps,
    undefined,
    mergeProps
  )(StoneListForCompany)
);
