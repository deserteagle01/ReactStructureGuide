import React, { StyleSheet, Dimensions } from "react-native";
import { Color, Constants, Styles } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  mainContainer:{
    flex:1
  },
  notFoundContainer:{
    // flex:1,
    height:'90%',
    flexDirection:'row',
    justifyContent:'center',
    alignItems:'center',
  },
  imageContainer:{

  },
  imageIcon:{
    width:25,
    height:25,
  },
  textContainer:{
    marginLeft:8,
  },
  text:{
    color:Color.white,
    fontSize:18,
    fontWeight:'500',
  },
});
