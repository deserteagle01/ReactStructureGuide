/** @format */

import { StyleSheet, Dimensions, Platform } from "react-native";
import { Color, Device, Styles } from "@common";
const { height, width } = Dimensions.get("window");

export default StyleSheet.create({
  listItemLastItemContainer:{
    flexDirection:'row',
    paddingTop:10,
    paddingBottom:10,
    backgroundColor:Color.white,
    paddingHorizontal:16
  },
  listItemContainer:{
    flexDirection:'row',
    paddingTop:10,
    paddingBottom:10,
    backgroundColor:Color.white,
    borderBottomWidth:1,
    borderColor:'#cfcfcf',
    paddingHorizontal:16,
  },
  listItemTextContainer:{
    flex:0.9,
    justifyContent:'center',
    // backgroundColor:'pink',
  },
  listItemText:{
    ...Platform.select({
      ios: {
        fontSize : width > 320 ? 17 : 14,
      },
      android: {
        fontSize : width > 360 ? 17 : 14,
      },
    }),
  },
  checkboxContainer:{
    flex:0.1,
    justifyContent:'center',
    alignItems:'flex-end',
    // backgroundColor:'orange'
  },
  checkBoxStyle:{
    marginLeft: 0,
    padding: 0,
    marginRight: 0,
  },
  checkBoxIcon:{
    ...Platform.select({
      ios: {
        width: width > 320 ? 30 : 20,
        height: width > 320 ? 30 : 20,
      },
      android: {
        width: width > 360 ? 30 : 20,
        height: width > 360 ? 30 : 20,
      },
    }),
  },
});
