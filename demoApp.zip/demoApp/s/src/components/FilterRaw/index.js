/** @format */

import React, { PureComponent } from "react";
import {
  Text,
  TouchableOpacity,
  View,
  Image,
} from "react-native";
import { Images} from "@common";
import styles from "./styles";
import { CheckBox } from 'react-native-elements';

export default class FilterRaw extends PureComponent {

  constructor(props){
    super(props);
    this.state = {
      is_selected:this.props.is_selected,
      isLastItem:this.props.isLastItem,
      item : this.props.item,
    }
  }

  componentWillReceiveProps(nextProps) {
    if(this.props != nextProps ){
      this.setState({item : nextProps.item, is_selected:nextProps.is_selected});
    }
  }
  onChangePreferanceValue = (item) => {
    item.is_selected = !item.is_selected;
    this.setState({item:item,is_selected:item.is_selected});
    this.props.onChangePreferanceValue(item);
  }

  render() {
    const { item, isLastItem } = this.state;
    return (
      <TouchableOpacity style={isLastItem ? styles.listItemLastItemContainer : styles.listItemContainer} activeOpacity={1} onPress={() => this.onChangePreferanceValue(item)}>
        <View style={styles.listItemTextContainer}>
            <Text style={styles.listItemText}>{item.name}</Text>
        </View>
        <View style={styles.checkboxContainer}>
          <CheckBox
              containerStyle={styles.checkBoxStyle}
              checked={this.state.is_selected}
              onPress={() => this.onChangePreferanceValue(item)}
              checkedIcon={<Image style={styles.checkBoxIcon} source={Images.icons.checkbox_selected_filter} resizeMode={'contain'}/>}
              uncheckedIcon={<Image style={styles.checkBoxIcon} source={Images.icons.checkbox_filter} resizeMode={'contain'}/>}
            />
        </View>
      </TouchableOpacity>
    );
  }

}
