import React from 'react';
import { View, Text, TouchableOpacity, InteractionManager, Platform, Dimensions } from 'react-native';
import t from 'tcomb-form-native';
import Autocomplete from 'react-native-autocomplete-input';
import { log } from "@app/Omni";
const { height, width } = Dimensions.get("window");
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

const Component = t.form.Component;

class tcombAutoComplete extends Component {
  constructor(props) {
    super(props);
    this.state = {
      elements: [],
      propForQuery: '',
      query: '',
      autocompleteStyle : styles.autocompleteContainer,
      isSeleted : false,
    };
    this.localsOnChange = null;
    this.getTemplate = this.getTemplate.bind(this);

    InteractionManager.runAfterInteractions(() => {
      const locals = super.getLocals();
      const { config: { elements, propForQuery } } = locals;
      const query = this.props.value;
      this.setState({ elements, propForQuery, query });
      locals.onChange(query);
    });
  }

  getLocals() {
    return super.getLocals();
  }

  onSelectItem(item, locals){
    this.setState({ query: item.name, isSeleted: true });
    locals.onChange(item.id);
  }

  getTemplate() {
    return function(locals) {
      const { query, isSeleted } = this.state;
      let elements = this.findElement(query);
      const comp = (a, b) => a.toLowerCase().trim() === b.toLowerCase().trim();
      if(isSeleted){
        elements = [];
      }
      // log('locals')
      // log(locals)
      autocompleteStyle = styles.autocompleteContainer;
      if (locals.hasError) {
        autocompleteStyle = styles.autocompleteContainerError;
      }

      return (
        // <KeyboardAwareScrollView innerRef={ref => this.scrollView = ref} style={styles.container}
        //   enableOnAndroid={true}
        //   enableAutomaticScroll={true}
        //   >
          <Autocomplete
            // onFocus={() => {this.scrollView.props.scrollToEnd({animated: true})}}
            autoCorrect={false}
            style={autocompleteStyle}
            inputContainerStyle={{borderWidth:0}}
            // containerStyle={autocompleteStyle}
            listStyle={{maxHeight: height < 650 ? 200 : 350, borderWidth:0}}
            data={
              elements.length === 1 && comp(query, elements[0].name)
                ? []
                : elements
            }
            defaultValue={query}
            onChangeText={text => {
              this.setState({ query: text, isSeleted:false });
              locals.onChange(text);
            }}
            placeholderTextColor={locals.config.placeholderTextColor}
            placeholder={locals.config.placeholder}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.autocompleteListTextContainer} activeOpacity={0.9} onPress={() => this.onSelectItem(item, locals)} >
                <Text style={styles.autocompleteListText}>{item.name}</Text>
              </TouchableOpacity>
            )}
          />
        // </KeyboardAwareScrollView>
      );
    }.bind(this);
  }

  findElement(query) {
    if (query === '' || !query) {
      return [];
    }

    const { elements } = this.state;
    const regex = new RegExp(`${query.trim()}`, 'i');
    return elements.filter(element => element.name.search(regex) >= 0);
  }
}

const styles = {
  container: {
    flex: 1,
  },
  autocompleteContainer: {
    backgroundColor:'transparent',
    color:'#fff',
    height: Platform.OS == "android" ? 55 : 50,
    paddingHorizontal:8,
    borderColor:'#e6e6e6',
    borderWidth:1,
    fontSize:17,
    borderRadius:5,
    marginTop: Platform.OS == "android" ? 10 : 0,
  },
  autocompleteContainerError: {
    backgroundColor:'transparent',
    color:'#fff',
    height: Platform.OS == "android" ? 55 : 50,
    paddingHorizontal:8,
    borderColor:'#a94442',
    borderWidth:1,
    fontSize:17,
    borderRadius:5,
    marginTop: Platform.OS == "android" ? 10 : 0,
  },
  autocompleteListTextContainer:{
    paddingVertical:12,
    backgroundColor:'#282828',
    borderBottomWidth:1,
    borderColor:"#757575",
  },
  autocompleteListText:{
    fontSize:15,
    paddingLeft:10,
    color:'#fff',
  },
};

tcombAutoComplete.transformer = {
  format: value => {
    return value;
  },
  parse: value => {
    return value;
  },
};

export default tcombAutoComplete;
