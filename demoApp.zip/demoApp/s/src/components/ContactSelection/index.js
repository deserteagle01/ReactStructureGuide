import React, {PureComponent} from 'react';
import {Text, TouchableOpacity, View, TextInput, Keyboard, SafeAreaView, Image, FlatList} from 'react-native';
import {Color, Languages, Images} from '@common';
//import Modal from 'react-native-modalbox';
import Modal from 'react-native-modal';
import styles from './styles';
import {log, toast} from '@app/Omni';
import { AddEditContact } from "../../components";
import { connect } from "react-redux";
class ContactSelection extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      displayContactList: [],
      searchText: "",
      showClearSearch: false
    };
    this.selectedRow = null;
  }

  componentWillMount() {}

  componentWillUnmount() {}

  open = (selectedContact) => {
    this.setState({visible: true,searchText: "",showClearSearch: false}, this.refreshSelectedContact(selectedContact, this.props.contactList));
  };

  refreshSelectedContact = (selectedContact, allContactList) => {
    let tempContactList = [...allContactList];
    let tempselectedContact = [...selectedContact];
    for(let i = 0; i < tempContactList.length; i++) {
      let tempFindContact = tempselectedContact.filter((e) => e.id === tempContactList[i].id);

      if(tempFindContact.length > 0) {
        tempContactList[i] =  {...tempContactList[i], ...{isSelected: true}}
      }
    }
    this.setState({displayContactList: tempContactList});
  }

  closeAddEditModal = () => {
    this._addeditcontact.cancel();
  }

  cancel = () => {
    this.setState({visible: false});
  };

  ediContactPress(selectItem, index) {
    this._addeditcontact.open(selectItem,this.props.companyList);
  }

  checkbuttonPress(selectItem, index) {
    if(this.props.isSingleSelect){
        if(this.selectedRow != null){
          let tempContactList = [...this.state.displayContactList];
          tempContactList[this.selectedRow] = { ...tempContactList[this.selectedRow], isSelected: false};
          tempContactList[index] = { ...tempContactList[index], isSelected: true};
          this.setState({displayContactList: tempContactList});
        }else{
          this.rowSelected(selectItem, index);
        }
        this.selectedRow = index;
    }else{
      this.rowSelected(selectItem, index);
    }
  }

  rowSelected(selectItem, index){
    let tempContactList = [...this.state.displayContactList];
    tempContactList[index] = { ...tempContactList[index], isSelected: !selectItem.isSelected};
    this.setState({displayContactList: tempContactList});
  }

  onChangeSearchText = (text) => {
    this.setState({searchText : text, showClearSearch: text.trim().length > 0});
  }

  onClearSearch = () => {
    this.setState({searchText : "", showClearSearch : false});
  }

  selectContact = () => {
    let tempSource = [...this.state.displayContactList];
    let filteredAttribs = tempSource.filter((e) => e.isSelected === true);
    if(filteredAttribs.length > 0){
        let isEmailExist = true;
        for(let i = 0; i < filteredAttribs.length; i++) {
            if(!filteredAttribs[i].email || !filteredAttribs[i].email.trim()){
              isEmailExist = false;
            }
        }
        if(isEmailExist){
          this.props.contactSelected(filteredAttribs);
        }else{
          alert(Languages.contactEmailWarning);
        }
    }else{
      alert(this.props.selectionWarning)
    }
  }

  renderHeader(){
    return(
      <View style={styles.headerContainer}>
        <TouchableOpacity  style={{marginLeft: 20}} onPress={this.cancel}>
          <Image
            source={Images.icons.closeNew}
            style={styles.backIcon} />
        </TouchableOpacity>
        <Text style={styles.txttitle}>{Languages.txtContactSelection}</Text>
        <TouchableOpacity style={{marginRight: 20}} onPress={this.selectContact}>
          <Image
            source={Images.icons.check_mark}
            style={styles.checkIcon} />
        </TouchableOpacity>
      </View>
    )
  }
  
  _renderItem = ({ item ,index}) => {
    let tempFirst = item.first_name ? item.first_name:"";
    let tempLast = item.surname ? item.surname:"";
    let tempName = tempFirst+" "+tempLast;
    if(tempName.toString().toUpperCase().includes(this.state.searchText.toUpperCase()) || this.state.searchText.length == 0){
      return (
        <View>
        <TouchableOpacity style={styles.contactContainer} onPress={() => this.checkbuttonPress(item, index)}>
            <View style={styles.textView}>
                <Text style={styles.ct_name}>{tempName+" "}<Text style={styles.cp_name}>{"("+item.company_name+")"}</Text></Text>
                <Text style={styles.txtemail}>{"<"+item.email+">"}</Text>
            </View>
            <View style={styles.buttonsView}>
                <TouchableOpacity onPress={() => this.ediContactPress(item, index)}>
                    <Image source={Images.icons.edit} style={styles.listicon} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => this.checkbuttonPress(item, index)}>
                    <Image source={item.isSelected  ? Images.icons.check_box : Images.icons.checkbox_Notify} style={styles.listicon} />
                </TouchableOpacity>
            </View>
      </TouchableOpacity>
      <View style={styles.seprator1}>
          <View style={styles.sepratorContainer}></View>
      </View>
    </View>
    );
    }
    else{
      return(
        null
      );
    }
  }

  renderSearchBar(){
    return(
      <View style={styles.searchInputContainer}>
        <Image source={Images.icons.search} style={styles.clearSearchIcon} />
        <TextInput
          style={styles.searchInputOpen}
          autoCapitalize="none"
          multiline={false}
          underlineColorAndroid="transparent"
          placeholder={Languages.Search}
          placeholderTextColor={"#d1d1d1"}
          onChangeText={this.onChangeSearchText}
          returnKeyType="search"
          value={this.state.searchText} />
        {this.state.showClearSearch &&
          <TouchableOpacity style={styles.clearSearchContainer} onPress={this.onClearSearch}>
            <Image
              source={Images.icons.close}
              style={styles.clearSearchIcon} />
          </TouchableOpacity>
        }
      </View>
    )
  }

  render() {
    return (
      <Modal
        hasBackdrop={true}
        isVisible={this.state.visible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={{margin: 0}}
        onBackButtonPress={this.cancel}
        onBackdropPress={this.cancel}>

        {/* <View style={{flex:1, backgroundColor:'white'}}> */}
        <SafeAreaView style={styles.flexContainer} />
        <SafeAreaView style={styles.customSafearea}>
        <View style={styles.viewContainer}>
            {this.renderHeader()}
            {this.renderSearchBar()}
            <FlatList
              style={styles.contactlist}
              showsVerticalScrollIndicator={false}
              data={this.state.displayContactList}
              renderItem={(item, index) => this._renderItem(item, index)}
              keyExtractor={(item, index) => index.toString()}
              extraData={this.state.searchText} /> 
            <View style={styles.bottomContainer}>
              <TouchableOpacity style={styles.btadd} onPress={() => this._addeditcontact.open(undefined,this.props.companyList)}>
                <Text style={styles.txtadd}>{Languages.txtAddContact}</Text>
              </TouchableOpacity>
            </View>
        </View>
        <AddEditContact
            addEditContactClick={(params) => this.props.addEditContactClick(params)}
            ref={(com) => (this._addeditcontact = com)} />
        </SafeAreaView>
        {/* </View> */}
      </Modal>
    );
  }
}

export default connect(
  undefined,
  undefined,
  undefined,
  { forwardRef: true }
)(ContactSelection);