import { StyleSheet, Platform, Dimensions } from "react-native";
import { Color, Styles, Device, Constants } from "@common";

const { width, height } = Dimensions.get("window");

export default StyleSheet.create({
  shareModal:{
    width:width - 50,
    borderRadius:10,
    backgroundColor:'lightgray',
  },
  shareModalKeyboard:{
    width:width - 50,
    height:250,
    borderRadius:10,
    backgroundColor:'#f7f7f7',
    ...Platform.select({
      android: {
        position:"absolute",
        bottom:"80%",
      },
    }),
  },
  contactContainer:{
    marginHorizontal: 10, 
    alignItems:'center', 
    flexDirection:'row', 
    justifyContent:'space-between', 
    overflow: "hidden"
  },
  ct_name:{
    color:'#d1d1d1',
    color:Color.white,
    fontWeight:'500',
    fontSize:17,
  },
  cp_name:{
    marginLeft: 5,
    color:Color.listSecondaryText,
    fontWeight:'300',
    fontSize:14,
  },
  txtemail: {
    color:Color.listSecondaryText,
    fontWeight:'300',
    fontSize:14,
    marginTop: 5
  },
  contactlist:{
    flex:1,
    marginVertical:10,
    marginBottom : 50,
  },
  flexContainer:{
    flex:0, 
    backgroundColor:'white',
  },
  customSafearea: {
    flex:1, 
    backgroundColor:'black',
  },
  viewContainer: {
    flex:1, 
    backgroundColor:"#000",
  },
  txtadd:{
    color:Color.primary,
    marginHorizontal:15, 
    marginVertical: 15
  },
  btadd:{
    borderWidth: 1,
    borderColor: "#e7e8e9",
    borderRadius: 5,
    alignItems:'center',
    justifyContent:'center',
    borderColor:Color.detailButtonBorder,
    },
  bottomContainer:{
    position:'absolute',
     bottom:0, 
     alignItems:'center', 
     justifyContent:'center', 
     alignSelf:'center'
  },
  txttitle:{
    color:'black',
    fontWeight:'500',
    fontSize:18,
  },
  headerContainer:{
    width: "100%", 
    flexDirection: "row",
    justifyContent: 'space-between',
    backgroundColor:"white",
    alignItems:Platform.OS == "android" ? 'center': "flex-start",
    height:Platform.OS == "android" ? 60:40
  },
  modalBoxWrap: {
    width:width - 50,
    backgroundColor:'#f7f7f7',
    //backgroundColor:'#fff',
  },
  backIcon: {
    height: 18,
    width: 18
  },
  checkIcon: {
    height: 25,
    width: 25
  },
  shareTitle:{
    color:'black',
    fontWeight:'500',
    fontSize:18,
  },
  emailInput:{
    alignItems:"center",
    fontSize: 16,
    width:width - 90,
    // height: 50,
    borderColor:'#bbbbbb',
    alignSelf:'center',
    borderWidth:1,
    backgroundColor:Color.white,
    //color:'#525252',
    //color:'#157dfb',
    padding:4,
    marginBottom: 10,
    textAlign:"center",
    textAlignVertical:"top",
  },
  txtSelectContact: {
    color:'#157dfb',
  },
  notesInput:{
    fontSize: 16,
    width:width - 90,
    height: 90,
    borderColor:'#bbbbbb',
    alignSelf:'center',
    textAlign:"left",
    textAlignVertical:"top",
    borderWidth:1,
    backgroundColor:Color.white,
    color:'#525252',
    padding:4,
    marginBottom: 10,
  },
  horizontalDivider:{
    width:width - 50,
    height:1,
    backgroundColor:'#e7e8e9',
  },
  verticalDivider:{
    width:1,
    backgroundColor:'#e7e8e9'
  },
  buttonsView:{
    flexDirection:'row',
    alignItems: 'center',
    flex:0.2,
    justifyContent:'space-between'
  },
  SearchIconOpen:{
    width:15,
    height:15,
    tintColor:'#d1d1d1',
  },
  clearSearchContainer:{
    padding:6,
    // backgroundColor:'pink',
  },
  clearSearchIcon:{
    width:17,
    height:17,
    tintColor:'black',
    marginLeft: 7
  },
  searchInputOpen:{
    color: "black",
    height: 45,
    paddingLeft: 8,
    flex: 1,
    textAlign: "left",
    ...Platform.select({
      ios: {
        fontSize: Styles.width > 320 ? 16 : 14,
      },
      android: {
        fontSize: Styles.width > 360 ? 16 : 14,
      },
    }),
  },
  seprator1:{height:34, justifyContent:'center',width:'100%', marginLeft: 10},
  sepratorContainer:{height:1, backgroundColor:Color.detailButtonBorder,width:'100%'},
  searchInputContainer:{
    height: 45,
    flexDirection:'row',
    borderColor:'white',
    backgroundColor: 'white',
    borderRadius:8,
    alignItems:'center',
    marginVertical:10,
    marginHorizontal: 8,
    marginTop: 15,
    borderWidth: 1
  },
  textView: {
    flex: 0.8, overflow: 'hidden',
    marginLeft: 5
  },
  listicon:{height: 20, width: 20, tintColor: "#ed8723"},
  buttonContainer:{
    flex:1,
    flexDirection:'row',
    justifyContent:'flex-end',
  },
  buttonWrapper:{
    flex:0.49,
    alignItems:'center',
    justifyContent:"center",
  },
  cancelBtnText:{
    color:'#157dfb',
    fontSize:16
  },
  shareBtnText:{
    color:'#157dfb',
    fontSize:16,
    fontWeight:'700',
  },
});
