package com.stonestocks.app;
import com.amazonaws.mobile.client.AWSMobileClient;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.facebook.react.ReactActivity;
import com.facebook.react.modules.i18nmanager.I18nUtil;

import org.devio.rn.splashscreen.SplashScreen;
import com.mesibo.api.Mesibo;
import com.amazonaws.services.s3.AmazonS3Client;

public class MainActivity extends ReactActivity {

    /**
     * Returns the name of the main component registered from JavaScript.
     * This is used to schedule rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "StoneStocks";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SplashScreen.show(this);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        I18nUtil sharedI18nUtilInstance = I18nUtil.getInstance();
        Context context = getApplicationContext();
        sharedI18nUtilInstance.allowRTL(context, true);
    }
}
