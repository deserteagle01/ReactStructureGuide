package com.stonestocks.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Records {
    private String groupId;
    private String imageUrl;

    public Records(String aInt, String string) {
        this.imageUrl = string;
        this.groupId = aInt;
    }
    public String getGroupId() {return groupId; }
    public void setGroupId(String groupId) {this.groupId = groupId;}
    public String getImageUrl() {return imageUrl;}
    public void setImageurl(String imageUrl) { this.imageUrl = imageUrl;}

    @Override
    public String toString() {
        return "Records{" +
                "groupId=" + groupId +
                ", imageUrl='" + imageUrl + '\'' +
                '}';
    }
}
