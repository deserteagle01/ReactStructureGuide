package com.stonestocks.app;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;

import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.mobile.client.AWSMobileClient;

import com.mesibo.messaging.MesiboActivity;
import com.mesibo.uihelper.MesiboUiHelper;
import com.mesibo.uihelper.MesiboUiHelperConfig;
import com.stonestocks.app.MainActivity;
import com.stonestocks.app.R;

import androidx.core.app.NotificationCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import com.stonestocks.app.R;
import com.mesibo.api.Mesibo;
import com.mesibo.calls.MesiboAudioCallFragment;
import com.mesibo.calls.MesiboCall;
import com.mesibo.calls.MesiboVideoCallFragment;
import com.mesibo.messaging.MesiboUI;
import com.stonestocks.app.fcm.MesiboRegistrationIntentService;
import com.stonestocks.app.fcm.MyFirebaseMessagingService;

//import com.biznovare.mesibo.MesiboFileTransferHelper;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import com.google.gson.Gson;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Toast;
import android.util.Log;

public class MesiboListener implements Mesibo.ConnectionListener, Mesibo.UIHelperListner,Mesibo.MessageListener, Mesibo.CrashListener, Mesibo.FileTransferListener, Mesibo.FileTransferHandler, MesiboRegistrationIntentService.GCMListener {
    private static Gson mGson = new Gson();
    private static Mesibo.HttpQueue mQueue = new Mesibo.HttpQueue(4, 0);
    public static  AmazonS3Client s3Client;
    public static  Context context;
    public  static  String aws_secretKey;
    public  static  String aws_accessKey;
    public  static  String aws_bucketName;

    public static class UploadResponse {
        public String op;
        public String file;
        public String result;

        UploadResponse() {
            result = null;
            op = null;
            file = null;
        }
    }

    private static final String TAG = "MesiboListner";
    private static MesiboListener _instance = null;

    public static MesiboListener getInstance(String secretKey, String accessKey, String bucketName) {
        aws_accessKey = accessKey;
        aws_secretKey = secretKey;
        aws_bucketName = bucketName;
        if(null==_instance)
            synchronized(MesiboListener.class) {
                if(null == _instance) {
                    _instance = new MesiboListener();
                }
            }


        BasicAWSCredentials credentials = new BasicAWSCredentials(aws_accessKey, aws_secretKey);
        s3Client = new AmazonS3Client(credentials);
        s3Client.setRegion(Region.getRegion(Regions.AP_SOUTH_1));


        return _instance;
    }

    public static  void  initilizeListnerContext(Context con){
        context = con;
    }


    /*  CONNECTION LISTENERS START */
    @Override
    public void Mesibo_onConnectionStatus(int i) {
        if(Mesibo.STATUS_OFFLINE == i){
            Log.d(TAG,"STATUS_OFFLINE" + i);
        } else if(Mesibo.STATUS_CONNECTING == i){
            Log.d(TAG,"STATUS_CONNECTING" + i);
        } else if(Mesibo.STATUS_CONNECTFAILURE == i){
            Log.d(TAG,"STATUS_CONNECTFAILURE" + i);
        } else if(Mesibo.STATUS_ACTIVITY == i){
            Log.d(TAG,"STATUS_ACTIVITY" + i);
        } else if(Mesibo.STATUS_AUTHFAIL == i){
            Log.d(TAG,"STATUS_AUTHFAIL" + i);
        } else if(Mesibo.STATUS_MANDUPDATE == i){
            Log.d(TAG,"STATUS_MANDUPDATE" + i);
        } else if(Mesibo.STATUS_NONETWORK == i){
            Log.d(TAG,"STATUS_NONETWORK" + i);
        } else if(Mesibo.STATUS_ONLINE == i){
            Log.d(TAG,"STATUS_ONLINE" + i);
        } else if(Mesibo.STATUS_SHUTDOWN == i){
            Log.d(TAG,"STATUS_SHUTDOWN" + i);
        } else if(Mesibo.STATUS_SIGNOUT == i){
            Log.d(TAG,"STATUS_SIGNOUT" + i);
        } else if(Mesibo.STATUS_STOPPED == i){
            Log.d(TAG,"STATUS_STOPPED" + i);
        } else if(Mesibo.STATUS_UNKNOWN == i){
            Log.d(TAG,"STATUS_UNKNOWN" + i);
        } else {
            Log.d(TAG,"STATUS OTHER" + i);
        }
    }
    /*  CONNECTION LISTENERS END */

    /*  MESSAGING LISTENERS START */
    @Override
    public boolean Mesibo_onMessage(Mesibo.MessageParams messageParams, byte[] bytes) {
        Log.d(TAG,"Mesibo_onMessage" + messageParams.toString());
        this.printMessageParam(messageParams);
        System.out.println("^^^^^^^^^^");
        System.out.println(messageParams);

        String strMessage = new String(bytes);
        System.out.println(strMessage);
        String channelId = "StoneStock";

        AppWebApi.notify(channelId, 0, "StoneStocks", strMessage);

        return true;
    }

    @Override
    public void Mesibo_onShowProfile(Context var1, Mesibo.UserProfile var2) {
        String groupid=String.valueOf(var2.groupid);
        MesiboModule.sendDatatoreact(var2.name, groupid, var1);
    }

    @Override
    public void Mesibo_onForeground(Context var1, int var2, boolean var3){

    }

    @Override
    public void Mesibo_onDeleteProfile(Context c, Mesibo.UserProfile u, Handler handler) {

    }

    @Override
    public int Mesibo_onGetMenuResourceId(Context context, int type, Mesibo.MessageParams params, Menu menu) {


        return 0;
    }

    @Override
    public boolean Mesibo_onMenuItemSelected(Context context, int type, Mesibo.MessageParams params, int item) {

        return false;
    }

    @Override
    public void Mesibo_onSetGroup(Context context, long groupid, String name, int type, String status, String photoPath, String[] members, Handler handler) {

    }

    @Override
    public void Mesibo_onGetGroup(Context context, long groupid, Handler handler) {

    }

    @Override
    public ArrayList<Mesibo.UserProfile> Mesibo_onGetGroupMembers(Context context, long groupid) {
        return null;
    }

    @Override
    public void Mesibo_onMessageStatus(Mesibo.MessageParams messageParams) {
        //Log.d(TAG,"Mesibo_onMessageStatus" + messageParams.toString());
        //this.printMessageParam(messageParams);
    }

    @Override
    public void Mesibo_onActivity(Mesibo.MessageParams messageParams, int i) {
        //Log.d(TAG,"Mesibo_onActivity" + messageParams.toString() + ", Activity:" + i);
        //this.printMessageParam(messageParams);
    }

    @Override
    public void Mesibo_onLocation(Mesibo.MessageParams messageParams, Mesibo.Location location) {
        Log.d(TAG,"Mesibo_onLocation" + messageParams.toString());
        this.printMessageParam(messageParams);
    }

    @Override
    public void Mesibo_onFile(Mesibo.MessageParams messageParams, Mesibo.FileInfo fileInfo) {
        Log.d(TAG,"Mesibo_onFile" + messageParams.toString());
        this.printMessageParam(messageParams);
    }

    /*  MESSAGING LISTENERS END */


    @Override
    public void Mesibo_onCrash(String s) {
        Log.d(TAG,"Mesibo_onCrash" + s);
    }



    private void printMessageParam(Mesibo.MessageParams messageParams){
        Log.d(TAG,"MID:" + messageParams.mid );
        Log.d(TAG,"groupid:" + messageParams.groupid );
        Log.d(TAG,"peer:" + messageParams.peer );
        Log.d(TAG,"duration:" + messageParams.duration );
        Log.d(TAG,"flag:" + messageParams.flag );
        Log.d(TAG,"origin:" + messageParams.origin );
        Log.d(TAG,"ts:" + messageParams.ts );
        Log.d(TAG,"type:" + messageParams.type );
        Log.d(TAG,"userFlags:" + messageParams.userFlags );
        Log.d(TAG,"getExpiry:" + messageParams.getExpiry() );
        Log.d(TAG,"getStatus:" + messageParams.getStatus() );
        Log.d(TAG,"getType:" + messageParams.getType() );
        Log.d(TAG,"isCall:" + messageParams.isCall() );
        Log.d(TAG,"isDbMessage:" + messageParams.isDbMessage() );
        Log.d(TAG,"isDbSummaryMessage:" + messageParams.isDbSummaryMessage() );
        Log.d(TAG,"isDeleted:" + messageParams.isDeleted() );
        Log.d(TAG,"isForwarded:" + messageParams.isForwarded() );
        Log.d(TAG,"isVideoCall:" + messageParams.isVideoCall() );
        Log.d(TAG,"isVoiceCall:" + messageParams.isVoiceCall() );
        Log.d(TAG,"isIncoming:" + messageParams.isIncoming() );

        Mesibo.UserProfile profile = messageParams.profile;
        Mesibo.UserProfile group_profile = messageParams.groupProfile;
        this.printProfile(profile);
        this.printProfile(group_profile);
    }

    private void printProfile(Mesibo.UserProfile profile){
        if(profile != null){
            Log.d(TAG,"address:" + profile.address);
            Log.d(TAG,"groupid:" + profile.groupid);
            Log.d(TAG,"status:" + profile.status);
            Log.d(TAG,"picturePath:" + profile.picturePath);
            Log.d(TAG,"groupMembers:" + profile.groupMembers);
            Log.d(TAG,"draft:" + profile.draft);
            Log.d(TAG,"name:" + profile.name);
            Log.d(TAG,"flag:" + profile.flag);
            Log.d(TAG,"lastActiveTime:" + profile.lastActiveTime);
            Log.d(TAG,"lookedup:" + profile.lookedup);
            Log.d(TAG,"unread:" + profile.unread);
        }
    }

    @Override
    public boolean Mesibo_onFileTransferProgress(Mesibo.FileInfo fileInfo) {
        Log.d(TAG, "Mesibo_onFileTransferProgress: " + fileInfo.title);
        return true;
    }

    /** This function is called when mesibo need to transfer (upload or download) a file.
     * All you have to do is to
     * 1) upload or download file as requested in file.mode
     * 2) In case of upload, if upload is successful, set the URL of the uploaded file which will
     * be sent to receiver
     */
    @Override
    public boolean Mesibo_onStartFileTransfer(Mesibo.FileInfo file) {
        if(Mesibo.FileInfo.MODE_DOWNLOAD == file.mode)
            return this.downloadFile(file.getParams(), file);

        return this.uploadFile(file.getParams(), file);
//        return  true;
    }

    /** This function is called when mesibo need to abort a file transfer.
     */
    @Override
    public boolean Mesibo_onStopFileTransfer(Mesibo.FileInfo file) {
//        Mesibo.Http http = (Mesibo.Http) file.getFileTransferContext();
//        if(null != http)
//            http.cancel();
//
//        return true;
        return  true;
    }

    @Override
    public void Mesibo_onGCMToken(String token) {
        System.out.println(token);
        AppWebApi.setGCMToken(token);
    }

    @Override
    public void Mesibo_onGCMMessage(/*Bundle data,*/ boolean inService) {
        AppWebApi.onGCMMessage(inService);
    }

    public boolean uploadFile(Mesibo.MessageParams params, final Mesibo.FileInfo file) {


        /* [OPTIONAL] check the required network connectivity for automatic or manual file download */
        if(Mesibo.getNetworkConnectivity() != Mesibo.CONNECTIVITY_WIFI && !file.userInteraction)
            return false;

        try {
            final long mid = file.mid;
            String key = String.valueOf(mid);//No
            String[] pathArr = file.getPath().split(File.separator);
            String fileName = pathArr[pathArr.length-1];
            file.setUrl(key+"::"+fileName);
            //TransferUtility transferUtility = new TransferUtility(s3Client, context);
            TransferUtility transferUtility =
                    TransferUtility.builder()
                            .context(context)
                            .awsConfiguration(AWSMobileClient.getInstance().getConfiguration())
                            .s3Client(s3Client)
                            .build();

            File filetoUpload = new File(file.getPath());
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+filetoUpload);


            TransferObserver transferObserver = transferUtility.upload(aws_bucketName,key, new File(file.getPath()));

            transferObserver.setTransferListener(new TransferListener() {
                @Override
                public void onStateChanged(int id, TransferState state) {
                    if (state.equals(TransferState.COMPLETED)) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"Completed");
                        Mesibo.updateFileTransferProgress(file, 100, 1);
                    } else if (state.equals(TransferState.FAILED)) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"Failed to upload");
                    }
                }

                @Override
                public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"onProgressChanged");
                }

                @Override
                public void onError(int id, Exception ex) {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+ ex.getLocalizedMessage());
                }
            });

        } catch (Exception e) {
            String stackTrace = Log.getStackTraceString(e); 
            Log.e(TAG, "Error occurred while uploading the image: " + stackTrace);
            Toast.makeText(context, "Can't upload a file.", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    public boolean downloadFile(final Mesibo.MessageParams params, final Mesibo.FileInfo file) {


        /* [OPTIONAL] check the required network connectivity for automatic or manual file download */
        if(Mesibo.getNetworkConnectivity() != Mesibo.CONNECTIVITY_WIFI && !file.userInteraction)
            return false;


        //TransferUtility transferUtility = new TransferUtility(s3Client, context);
        TransferUtility transferUtility =
                TransferUtility.builder()
                        .context(context)
                        .awsConfiguration(AWSMobileClient.getInstance().getConfiguration())
                        .s3Client(s3Client)
                        .build();

        try {
            String[] urlArr = file.getUrl().split("::");
            String key = urlArr[0];
            String fileName = urlArr[1];
            String filePath = file.getPath().replace(file.getUrl(), fileName);
            Log.d(TAG, "~~~~~~~~~~~~~~~~~~New File Path~~~~~~~~~~~~~~~~" + filePath);
            file.setPath(filePath);
            TransferObserver downloadObserver = transferUtility.download(aws_bucketName,key, new File(filePath));

            downloadObserver.setTransferListener(new TransferListener() {

                int status = file.getStatus();

                @Override
                public void onStateChanged(int id, TransferState state) {
                    if (TransferState.COMPLETED == state) {
                        // Handle a completed upload.
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"download complete");
                        Mesibo.updateFileTransferProgress(file, 100, status);
                    }
                }

                @Override
                public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                    float percentDonef = ((float)bytesCurrent/(float)bytesTotal) * 100;
                    int percentDone = (int)percentDonef;
                    Mesibo.updateFileTransferProgress(file, percentDone, status);
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"complete %"+ percentDone);
                }

                @Override
                public void onError(int id, Exception ex) {
                    // Handle errors
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"complete %"+ ex.getLocalizedMessage());
                }

            });

        } catch (Exception e) {
            String stackTrace = Log.getStackTraceString(e); 
            Log.e(TAG, "Error occurred while downloading the image: " + stackTrace);
            Toast.makeText(context, "Can't download a file.", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

}

