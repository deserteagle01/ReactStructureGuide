package com.stonestocks.app;

import android.Manifest;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.app.Application;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Type;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Timer;
import android.content.SharedPreferences;
import android.view.ViewGroup;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
//import androidx.fragment.app.FragmentManager;
//import androidx.fragment.app.FragmentTransaction;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.uimanager.IllegalViewOperationException;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mesibo.api.Mesibo;
import com.mesibo.calls.MesiboCall;
import com.mesibo.mediapicker.MediaPicker;
import com.mesibo.messaging.MesiboMessagingFragment;
import com.mesibo.messaging.MesiboUI;
import com.stonestocks.app.fcm.MesiboRegistrationIntentService;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONArray;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.TimerTask;
import java.util.stream.Collectors;

import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;

import javax.annotation.Nullable;
import static org.webrtc.ContextUtils.getApplicationContext;

public class MesiboModule extends ReactContextBaseJavaModule implements ActivityCompat.OnRequestPermissionsResultCallback {


    public static ReactContext mReactContext;
    public static final String TAG = "MesiboModule";
    private static Context mContext = null;
    private static MesiboCall mCall = null;
    private static Activity actObj = null;
    public  static String isFrom = null;
    //private static AppConfig mConfig = null;
    public  static String deviceToken = "";
    private Mesibo.ReadDbSession mReadSession = null;




    public MesiboModule(ReactApplicationContext reactContext) {
        super(reactContext); //required by React Native
        mReactContext = reactContext;
    }

    @Override
    //getName is required to define the name of the module represented in JavaScript
    public String getName() {
        return "MesiboManager";
    }


    private boolean checkIfAlreadyhavePermission(Activity act) {
        int readStorage = ContextCompat.checkSelfPermission(act, Manifest.permission.READ_EXTERNAL_STORAGE);
        int writeStorage = ContextCompat.checkSelfPermission(act, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (readStorage == PackageManager.PERMISSION_GRANTED && writeStorage == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }


    private void requestForSpecificPermission(Activity act) {
        ActivityCompat.requestPermissions(act, new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }

    public static void sendDatatoreact(String groupname,String groupId ,Context contt) {
        Intent goToMainActivity = new Intent(contt, MainActivity.class);
        goToMainActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Will clear out your activity history stack till now
        contt.startActivity(goToMainActivity);
        WritableMap params = Arguments.createMap();
        params.putString("groupName", groupname);
        params.putString("groupId", groupId);

        if(isFrom != "groupUI"){
            sendEvent(mReactContext, "datafromNative", params);
        }
    }

    public static void  sendEvent(ReactContext reactContext, String eventName, @Nullable WritableMap params) {
        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(eventName, params);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 101: {
                System.out.println("~~~~~"+grantResults);
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        System.out.println("Greetings from React-native, PErmission granted @@@@@@@@@@");
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }

            break;
        }
    }


    @ReactMethod
    public  void logout() {
        Mesibo.setKey("apntoken", "");
        Mesibo.stop(false);
        Mesibo.reset();
    }


    @ReactMethod
    public  void login(String token, String secretKey, String accessKey, String bucketName, Callback errorCallback){
        String isInitialize = this.initializeMesibo(token, secretKey, accessKey, bucketName);
        if(isInitialize.equals("permission")){
            errorCallback.invoke("PermissionAsked");
        }else if(isInitialize.equals("true")){
            errorCallback.invoke(false);
        }else{
            errorCallback.invoke("Invalid AuthenticationToken");
        }
    }

    public String initializeMesibo(String token, String secretKey, String accessKey, String bucketName) {
        actObj = this.getCurrentActivity();
        mContext = actObj.getApplicationContext();
        SharedPreferences sp = mContext.getSharedPreferences("your_prefs", Context.MODE_PRIVATE);
        deviceToken = sp.getString("devicetoken", "");

        if(token != null) {
            if (!checkIfAlreadyhavePermission(actObj)) {
                requestForSpecificPermission(actObj);
                return "permission";
            }
            else {

               actObj.runOnUiThread(new Runnable() {
                   @Override
                   public void run() {
                        Mesibo api = Mesibo.getInstance();
                        api.init(mContext);
                        Mesibo.setPath(mContext.getFilesDir().getAbsolutePath());
                        Mesibo.setSecureConnection(true);
                        String path = Mesibo.getBasePath();
                        MediaPicker.setPath(path);
                        AppWebApi.sendGCMToken(deviceToken, token);
                        AppWebApi.intializeContext(mContext, actObj);
                        MesiboListener.initilizeListnerContext(mContext);
                        api.addListener(MesiboListener.getInstance(secretKey, accessKey, bucketName));
                        api.setAccessToken(token);
                        Mesibo.setDatabase("mesibo.db", 0);

                        api.start();
                    }});

                return "true";
            }
        }else{
            return "false";
        }
    }


    @ReactMethod
    public  void launchMesiboUI(String token, ReadableArray groups, Callback errorCallback){
        isFrom = "defaultUI";
        this.setGroupProfile(groups);
        actObj = getCurrentActivity();

        MesiboUI.Config opt = MesiboUI.getConfig();
        opt.enableBackButton = true; // Enable Back button on Channels page
        opt.messageListTitle = "StoneStocks";
        opt.mEnableNotificationBadge = true;
        opt.enableVoiceCall = false;
        opt.enableVideoCall = false;
        opt.enableSearch = true;
        opt.mToolbarColor = 0xffffff;
        opt.useLetterTitleImage = false;

        MesiboUI.launch(actObj, Intent.FLAG_ACTIVITY_NEW_TASK, false, false);
        errorCallback.invoke(false);
    }

    @ReactMethod
    public void readStoredChatList(ReadableArray grpArray, final Promise promise){
        Log.i(TAG, "Reading local chat list for filtering ongoing chat list.");
        WritableMap result = Arguments.createMap();
        temp: try {
            for (int l = 0; l < grpArray.size(); l++) {
                final ReadableMap currentObj = grpArray.getMap(l);
                if (currentObj != null) {
                    String grpid = currentObj.getString("mesibo_group_id");
                    if (grpid != null) {
                        long groupid = Long.parseLong(grpid);
                        Log.i(TAG, "Processing group with id: " + groupid);
                        try {
                            Mesibo.ReadDbSession mReadSession = new Mesibo.ReadDbSession(null, groupid, null, null);
                            if(mReadSession != null){
                                int availableMsgCount = mReadSession.read(2000);
                                Log.i(TAG, "Read message count: " + availableMsgCount);
                                if (availableMsgCount > 0) {
                                    result.putBoolean(groupid + "", (true));
                                }
                            }
                        }
                        catch(Exception e) {
                            String stackTrace = Log.getStackTraceString(e);
                            Log.e(TAG, "Error occurred while reading local chats: " + stackTrace);
                        }
                    }
                }
            }
            promise.resolve(result);
        }
        catch(Exception e) {
            String stackTrace = Log.getStackTraceString(e);
            Log.e(TAG, "Error occurred while reading local chats: " + stackTrace);
            promise.reject("READ_LOCAL_CHAT_LIST", e);
        }
    }

    @ReactMethod
    public void checkPermission(Callback errorCallback) {
        if (!checkIfAlreadyhavePermission(this.getCurrentActivity())) {
            requestForSpecificPermission(this.getCurrentActivity());
        }

        errorCallback.invoke(false);
    }

    @ReactMethod
    public  void sendMessage(String token, ReadableArray groups ,Callback errorCallback){
                final ReadableMap currentObj = groups.getMap(0);
                String grpid = currentObj.getString("mesibo_group_id");
                String grpname = currentObj.getString("name");
                String msg = currentObj.getString("message");

                long groupid = Long.parseLong(grpid);

                Mesibo.UserProfile profileCreate = Mesibo.createUserProfile(null, groupid, grpname);

                Mesibo.MessageParams p = new Mesibo.MessageParams();
                p.groupProfile = profileCreate;
                p.peer = "";
                p.groupid = groupid;
                p.flag = Mesibo.FLAG_READRECEIPT | Mesibo.FLAG_DELIVERYRECEIPT;

                long mid = Mesibo.random();
                int rv = Mesibo.sendMessage(p, mid, msg);

                if(Mesibo.RESULT_OK == rv) {
                    errorCallback.invoke(false);
                } else {
                    errorCallback.invoke("failed to send message");
                }
    }
        

    @ReactMethod
    public  void launchGroupDetail(String token, ReadableArray groups,String group_id ,String group_name ,Callback errorCallback){
            isFrom = "groupUI";
            this.setGroupProfile(groups);
            actObj = getCurrentActivity();
            MesiboUI.Config opt = MesiboUI.getConfig();
            opt.enableBackButton = true; // Enable Back button on Channels page
            opt.messageListTitle = "StoneStocks";
            opt.mEnableNotificationBadge = true;
            opt.enableVoiceCall = false;
            opt.enableVideoCall = false;
            opt.enableSearch = true;
            opt.mToolbarColor = 0xffffff;
            opt.useLetterTitleImage = false;

            long groupid = Long.parseLong(group_id);
            MesiboUI.launchMessageView(actObj, group_name, groupid);
            errorCallback.invoke(false);
    }

    
    public void setGroupProfile(ReadableArray grpArray) {
        actObj.runOnUiThread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void run() {

                SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(actObj.getApplicationContext());
                Gson gson = new Gson();
                String json = sharedPrefs.getString("groupimagearray", "");

                File direct = new File(mContext.getExternalFilesDir(null) + "/StoneStocks/ChatImage");
                if (!direct.exists()) {
                    File wallpaperDirectory = new File(mContext.getFilesDir(), "/StoneStocks/ChatImage/");
                    wallpaperDirectory.mkdirs();
                }
                
                List<Records> existRecord = new ArrayList<>();
                List<Records> recordObj = new ArrayList<>();

                if(json != null && json != ""){
                    Type type = new TypeToken<List<Records>>() {}.getType();
                    existRecord = gson.fromJson(json, type);
                }
                
                Mesibo.reset();
                for(int l=0; l< grpArray.size(); l++){
                    final ReadableMap currentObj = grpArray.getMap(l);
                    String grpid = currentObj.getString("mesibo_group_id");
                    String grpname = currentObj.getString("name");
                    String groupName = currentObj.getMap("stock_detail_id").getString("name");
                    String imageUrl = currentObj.getMap("stock_detail_id").getString("group_img_url");
                    String filename = grpname+".jpeg";
                    long groupid = Long.parseLong(grpid);

                    File file = new File(mContext.getExternalFilesDir("/StoneStocks/ChatImage/"), filename);

                    Mesibo.UserProfile profileCreate = Mesibo.createUserProfile(null, groupid, grpname);
                    Mesibo.UserProfile profileSet = Mesibo.setUserProfile(profileCreate, true);
                    Mesibo.getUserProfile(null, groupid);

                    if(json != null && json != ""){
                        List<Records> filteredImageList = existRecord.stream().filter(record -> record.getImageUrl().contains(imageUrl)).collect(Collectors.toList());
                        List<Records> filteredIdList = existRecord.stream().filter(record -> record.getGroupId().contains(grpid)).collect(Collectors.toList());
                        if(filteredImageList.size() <= 0){
                            if(filteredIdList.size() > 0){
                                existRecord.remove(filteredIdList.get(0));
                            }

                            saveImageToDirectory(imageUrl, file, profileCreate);
                            existRecord.add(new Records(grpid, imageUrl));

                        }else{
                            profileCreate.picturePath = file.getAbsolutePath();
                        }
                    }else{
                        saveImageToDirectory(imageUrl, file, profileCreate);
                        recordObj.add(new Records(grpid, imageUrl));
                    }
                }

                if(json != null && json != ""){
                    saveImageData(sharedPrefs, existRecord);
                }else{
                    saveImageData(sharedPrefs, recordObj);
                }
            }});

    }

    public void saveImageData(SharedPreferences sharedPrefs, List<Records> imageArr) {
        SharedPreferences.Editor editor = sharedPrefs.edit();
        Gson gsonNew = new Gson();
        String jsonnew = gsonNew.toJson(imageArr);
        editor.putString("groupimagearray", jsonnew);
        editor.commit();
    }

    public void  saveImageToDirectory(String imageUrl, File file, Mesibo.UserProfile profile) {
        new Thread(new Runnable(){
            @Override
            public void run() {
                Bitmap  bitimg = getBitmapFromURL(imageUrl);
                try {
                    FileOutputStream out = new FileOutputStream(file);
                    bitimg.compress(Bitmap.CompressFormat.JPEG, 100, out);
                    out.flush();
                    out.close();
                    profile.picturePath = file.getAbsolutePath();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }


    public static Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            return BitmapFactory.decodeStream(input);
            //return myBitmap;

        } catch (IOException e) {
            // Log exception
            return null;
        }
    }
}
