package com.stonestocks.app;


import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.mesibo.api.Mesibo;
import com.google.gson.Gson;
import com.mesibo.calls.MesiboCall;
import com.stonestocks.app.AppConfiguration;

import static android.app.DownloadManager.Request.VISIBILITY_VISIBLE;

/**
 * Web API to communicate with your own backend server(s).
 * Note - in this example, we are not authenticating. In real app, you should authenticate user first
 * using email or phone OTP.
 *
 * When user is successfully authenticated, your server should create a mesibo auth token using
 * mesibo server side api and send it back here.
 *
 * Refer to PHP server api for code sample.
 */

public class AppWebApi {
    public static final String TAG="SampleAppWebApi";
    private static SharedPreferences mSharedPref = null;
    private static NotifyUser mNotifyUser = null;
    public static final String mSharedPrefKey = "com.mesibo.samplecodeapp";
    private static Gson mGson = new Gson();
    private static String mToken = null;
    public final static String KEY_GCMTOKEN = "gcmtoken";
    private static String mApiUrl = "https://app.mesibo.com/api.php";
    public  static  Context cContext = null;
    public  static  Activity currentActivity = null;

    public static abstract class ResponseHandler implements Mesibo.HttpListener {
        private Mesibo.Http http = null;
        private Bundle mRequest = null;
        private boolean mBlocking = false;
        private boolean mOnUiThread = false;
        public static boolean result = true;
        public Context mContext = null;

        @Override
        public boolean Mesibo_onHttpProgress(Mesibo.Http http, int state, int percent) {
            if(percent < 0) {
                HandleAPIResponse(null);
                return true;
            }

            if(100 == percent && Mesibo.Http.STATE_DOWNLOAD == state) {
                String strResponse = http.getDataString();
                Response response = null;

                if (null != strResponse) {
                    try {
                        response = mGson.fromJson(strResponse, Response.class);
                    } catch (Exception e) {
                        result = false;
                    }
                }

                if(null == response)
                    result = false;

                //final Context context = (null == this.mContext)?AppWebApi.mContext:this.mContext;

                if(!mOnUiThread) {
                    //parseResponse(response, mRequest, context, false);
                    HandleAPIResponse(response);
                }
                else {
                    final Response r = response;

                    Handler uiHandler = new Handler(getContext().getMainLooper());
                    Runnable myRunnable = new Runnable() {
                        @Override
                        public void run() {

                            HandleAPIResponse(r);
                        }
                    };
                    uiHandler.post(myRunnable);
                }
            }
            return true;
        }



        public void setBlocking(boolean blocking) {
            mBlocking = blocking;
        }

        public void setOnUiThread(boolean onUiThread) {
            mOnUiThread = onUiThread;
        }

        public boolean sendRequest(Bundle postBunlde, String filePath, String formFieldName) {

            postBunlde.putString("dt", String.valueOf(Mesibo.getDeviceType()));
            int nwtype = Mesibo.getNetworkConnectivity();
            if(nwtype == 0xFF) {

            }

            mRequest = postBunlde;
            http = new Mesibo.Http();
            http.url = mApiUrl;
            http.postBundle = postBunlde;
            http.uploadFile = filePath;
            http.uploadFileField = formFieldName;
            http.notifyOnCompleteOnly = true;
            http.concatData = true;
            http.listener = this;
            if(mBlocking)
                return http.executeAndWait();
            return http.execute();
        }

        public void setContext(Context context) {
            this.mContext = context;
        }

        public Context getContext() {
            return this.mContext;
        }

        public abstract void HandleAPIResponse(Response response);
    }


    public interface DemoWebApiResponseHandler {
        void onApiResponse(boolean result);
    }

    public static class Contacts {
        public String name = "";
        public String phone = "";
        public long   gid = 0;
    }

    public static class Response {
        public String result;
        public String op;
        public String error;
        public String token;
        public Contacts[] contacts;

        Response() {
            result = null;
            op = null;
            error = null;
            token = null;
            contacts = null;
        }
    }


    private static String mGCMToken = null;
    private static boolean mGCMTokenSent = false;
    public static void setGCMToken(String token) {
        mGCMToken = token;
        //sendGCMToken();
    }

    public static void intializeContext(Context forwardContext, Activity currentAct){
        //cContext = forwardContext;
        cContext = currentAct.getApplicationContext();
        currentActivity = currentAct;
    }

    public static void sendGCMToken(String pushtoken, String authtoken) {
        Bundle b = createPostBundle("setnotify", authtoken);
        if(null == b) return;

        b.putString("notifytoken", pushtoken);
        b.putString("fcmid", "326313569692");

        ResponseHandler http = new ResponseHandler() {
            @Override
            public void HandleAPIResponse(Response response) {
                if(null != response && response.result.equalsIgnoreCase("OK") ) {
                    Mesibo.setKey(KEY_GCMTOKEN, pushtoken);
                } else
                    mGCMTokenSent = false;
            }
        };

        http.sendRequest(b, null, null);
    }

    private static Bundle createPostBundle(String op, String authToken) {

        Bundle b = new Bundle();
        b.putString("op", op);
        b.putString("token", authToken);
        return b;
    }

    public static void notify(String channelid, int id, String title, String message) {
        System.out.println(cContext);

        currentActivity.runOnUiThread (new Thread(new Runnable() {
            public void run() {
        Intent intent = new Intent(cContext, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(cContext, 0 /* Request code */, intent,
                PendingIntent.FLAG_ONE_SHOT);


        //String channelId = getString(com.stone.stocks.R.string.default_notification_channel_id);
        String channelId = "StoneStocks";
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(cContext, channelId)
                        .setSmallIcon(R.mipmap.notification)
                        .setColor(Color.parseColor("#606060"))
                        .setContentTitle(title)
                        .setContentText(message)
                        .setAutoCancel(true)
                        .setSound(defaultSoundUri)
                        .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) cContext.getSystemService(Context.NOTIFICATION_SERVICE);

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId,
                    "StoneStocks",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }


                notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
            }}));



    }

    public static void notify(Mesibo.MessageParams params, String message) {
        NotifyUser naada = new NotifyUser(MainApplication.getAppContext());
        String name = "StoneStocks";
        //naada.sendNotificationInList(name, message);
    }


    public static void onGCMMessage(boolean inService) {

    }

    public static synchronized  void init() {
        if(null != mSharedPref) return;
    }

    public static boolean isLoggedin() {
        return !TextUtils.isEmpty(mToken);
    }

    public static String getToken() {
        return mToken;
    }

    public static void addContact(String name, String phone) {
        if(TextUtils.isEmpty(phone)) return;

        Mesibo.UserProfile profile = new Mesibo.UserProfile();
        profile.name = name;
        profile.address = phone;
        if(TextUtils.isEmpty(name))
            profile.name = phone;

        Mesibo.setUserProfile(profile, false);
    }

    public static boolean setStringValue(String key, String value) {
        try {
            synchronized (mSharedPref) {
                SharedPreferences.Editor poEditor = mSharedPref.edit();
                poEditor.putString(key, value);
                poEditor.commit();
                //backup();
                return true;
            }
        } catch (Exception e) {
            Log.d(TAG, "Unable to set long value in RMS:" + e.getMessage());
            return false;
        }
    }

    public static String getStringValue(String key, String defaultVal) {
        try {
            synchronized (mSharedPref) {
                if (mSharedPref.contains(key))
                    return mSharedPref.getString(key, defaultVal);
                return defaultVal;
            }
        } catch (Exception e) {
            Log.d(TAG, "Unable to fet long value in RMS:" + e.getMessage());
            return defaultVal;
        }
    }




}
