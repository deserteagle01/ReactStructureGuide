package com.stonestocks.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import com.mesibo.api.Mesibo;
import com.mesibo.messaging.MesiboMessagingFragment;
import com.mesibo.messaging.MesiboUI;

public class GroupLaunchActivity extends AppCompatActivity implements MesiboMessagingFragment.FragmentListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_launch);

        double grp_Id = getIntent().getDoubleExtra("groupID", 0);

        MesiboMessagingFragment mFrag = new MesiboMessagingFragment();
        Bundle bl = new Bundle();
        //bl.putString(MesiboUI.PEER, "");
        bl.putLong(MesiboUI.GROUP_ID, 97393);
        mFrag.setArguments(bl);


        try {
          int result =  getSupportFragmentManager().beginTransaction().replace(R.id.group_fragment, mFrag).commit();
            System.out.println("Result ~~~~~~~~~~~~" + result);
        } catch (Exception e) {
            // This will catch any exception, because they are all descended from Exception
            System.out.println("Error ~~~~~~~~~~~~" + e.getMessage());
        }



        //((FragmentActivity)act).getSupportFragmentManager().beginTransaction().add(mFrag, null).commit();
        //add(mFrag, null).commit();

        // act.getFragmentManager().beginTransaction().add(R.id.fragment_container, mFrag);

        //getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, mFrag).commit();

        //((FragmentActivity)act).getSupportFragmentManager().beginTransaction().add(R.id.fragment_container , mFrag).commit();


        //act.getFragmentManager().beginTransaction().replace(R.id.fragment_container, customFrag).commit();

//        Intent intent = new Intent(GroupLaunchActivity.this, MainActivity.class);
//        startActivity(intent);
        //finish();
    }


    @Override
    public void Mesibo_onUpdateUserPicture(Mesibo.UserProfile userProfile, Bitmap bitmap, String s) {

    }

    @Override
    public void Mesibo_onUpdateUserOnlineStatus(Mesibo.UserProfile userProfile, String s) {

    }

    @Override
    public void Mesibo_onShowInContextUserInterface() {

    }

    @Override
    public void Mesibo_onHideInContextUserInterface() {

    }

    @Override
    public void Mesibo_onContextUserInterfaceCount(int i) {

    }

    @Override
    public void Mesibo_onError(int i, String s, String s1) {

    }
}
