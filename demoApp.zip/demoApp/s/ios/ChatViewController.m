//
//  ChatViewController.m
//  mstore
//
//  Created by admin on 7/16/20.
//  Copyright © 2020 Facebook. All rights reserved.
//

#import "ChatViewController.h"
#import <mesibo/mesibo.h>
#import <MesiboUI/MesiboUI.h>
#import "AppDelegate.h"
@interface ChatViewController ()

@end

@implementation ChatViewController
@synthesize containerView;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  NSString *isGrpupDetail = [[NSUserDefaults standardUserDefaults] objectForKey:@"isgroupdetail"];
  
  UIViewController *mesiboController = [MesiboUI getMesiboUIViewController];
  //[mesiboController setDefinesPresentationContext:false];
  //[mesiboController setHidesBottomBarWhenPushed:YES];
  //mesiboController.mPanBtn.hidden = YES;
  //mPaneBtn
  [self addChildViewController:mesiboController];
  mesiboController.view.frame = CGRectMake(0, 0, containerView.frame.size.width, containerView.frame.size.height);
  [self.containerView addSubview:mesiboController.view];
  [mesiboController didMoveToParentViewController:self];
  if([isGrpupDetail  isEqual: @"1"]){
    NSString *grp = [[NSUserDefaults standardUserDefaults] objectForKey:@"groupID"];
    NSString *name = [[NSUserDefaults standardUserDefaults] objectForKey:@"name"];
    
    NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
    f.numberStyle = NSNumberFormatterDecimalStyle;
    NSNumber *myNumber = [f numberFromString:grp];
    uint32_t grp_Id = [myNumber unsignedIntValue];
    
    MesiboUserProfile *groupProfile = [MesiboInstance createProfile:NULL groupid: grp_Id name:name];
    MesiboUserProfile *settingProfile =  [MesiboInstance setProfile:groupProfile refresh:true];
    MesiboUserProfile *gettingProfile = [MesiboInstance getProfile:NULL groupid: grp_Id];
    
    [MesiboUI launchMessageViewController:self profile:groupProfile];
  }
}

-(IBAction)backPRess:(id)sender {
  AppDelegate *appDelegate=( AppDelegate* )[UIApplication sharedApplication].delegate;
  
  [appDelegate goToReactNative];
}

@end
