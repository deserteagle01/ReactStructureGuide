
// CalendarManager.h
#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

@interface MesiboManager : RCTEventEmitter <RCTBridgeModule>

@property (nonatomic, retain) NSString *isFrom;

- (void)sendDataToReact:(uint32_t)groupId groupname:(NSString *)groupname;
@end
