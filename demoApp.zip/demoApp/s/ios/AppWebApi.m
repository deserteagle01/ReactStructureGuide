
//  Copyright © 2016 Mesibo. All rights reserved.

#import "AppWebApi.h"
#import "Mesibo/Mesibo.h"

#import "MesiboListener.h"

//#import "ContactUtils/ContactUtils.h"
#import <ContactsUI/ContactsUI.h>

#import "AppConfiguration.h"

#define KEY_TOKEN @"token"
#define UPLOADURL_KEY  @"upload"
#define DOWNLOADURL_KEY  @"download"
#define INVITE_KEY  @"inivte"
#define CC_KEY  @"cc"

/**
 * Web API to communicate with your own backend server(s).
 * Note - in this example, we are not authenticating. In real app, you should authenticate user first
 * using email or phone OTP.
 *
 * When user is successfully authenticated, your server should create a mesibo auth token using
 * mesibo server side api and send it back here.
 *
 * Refer to PHP server api for code sample.
 */


@interface AppWebApi ( /* class extension */ )
{
    NSUserDefaults *mUserDefaults;
    NSString *mToken, *mPhone, *mInvite, *mCc;
    uint64_t mContactTimestamp;
    SampleAPI_LogoutBlock mLogoutBlock;
    BOOL mSyncPending;
    BOOL mResetSyncedContacts;
    BOOL mAutoDownload;
    NSString *mDeviceType;
    NSString *mApnToken;
    NSString *mApiUrl;
    NSString *mUploadUrl;
    NSString *mDownloadUrl;
    int mApnTokenType;
    NSString *mGoogleKey;
    BOOL mApnTokenSent;
    BOOL mSyncStarted;
    BOOL mInitPhonebook;
    void (^mAPNCompletionHandler)(UIBackgroundFetchResult);
}
#define SYNCEDCONTACTS_KEY @"syncedcontacts"
@end

@implementation AppWebApi

+(AppWebApi *)getInstance {
    static AppWebApi *myInstance = nil;
    if(nil == myInstance) {
        @synchronized(self) {
            if (nil == myInstance) {
                myInstance = [[self alloc] init];
                [myInstance initialize];
            }
        }
    }
    return myInstance;
}

-(void)initialize {
  mApnToken = nil;
  mApnTokenType = 0;
  mApnTokenSent = NO;
  mGoogleKey = nil;
  mInvite = nil;
  
  mApiUrl = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"MessengerApiUrl"];
  
  if (!mApiUrl || ![self isValidUrl:mApiUrl]) {
      NSLog(@"************* INVALID URL - set a valid URL in MessengerApiUrl field in Info.plist ************* ");
  }
  
 
  mUserDefaults = [NSUserDefaults standardUserDefaults];
  mContactTimestamp = 0;
  mToken = [mUserDefaults objectForKey:@"token"];
  

  mPhone = nil;
  mCc = nil;
  mSyncPending = YES;
  mResetSyncedContacts = NO;
  mSyncStarted = NO;
  mInitPhonebook = NO;
  
  mDeviceType = [NSString stringWithFormat:@"%d", [MesiboInstance getDeviceType]];
  
  if([mToken length] > 0) {
      mContactTimestamp = [[mUserDefaults objectForKey:@"ts"] longLongValue];
      //[self startMesibo:NO];
  }
}

/**
 * Start mesibo only after you have a user access token
 */

-(BOOL) isValidUrl:(NSString *)url {
    return ([url hasPrefix:@"http://"] || [url hasPrefix:@"https://"]);
}



-(void) setPushToken:(NSString *)token {
    mApnToken = token;
    mApnTokenType = 1;
    [self sendAPNToken];
}

-(void) sendAPNToken {
  //[MesiboInstance setPushToken:mApnToken];
  //[MesiboInstance setPushToken:mApnToken];
}

+(void) setPushNotificationToken:(NSString *)token {
  //[MesiboInstance setPushToken:token];
}


-(BOOL)getMediaAutoDownload {
    return mAutoDownload;
}

-(NSString *) getUploadUrl {
  mUploadUrl = @"https://mesibo.com/demofiles/";
    return mUploadUrl;
}

-(NSString *) getDownloadUrl {
    mDownloadUrl = @"https://mesibo.com/demofiles/";
    return mDownloadUrl;
}


-(NSString *)getSavedValue:(NSString *)value key:(NSString *)key {
    if(value) {
        [MesiboInstance setKey:value value:key];
        return value;
    }
    
    return [MesiboInstance readKey:key];
}

#define AUTODOWNLOAD_KEY    @"autodownload"
-(void) initAutoDownload {
    NSString *autodownload = [MesiboInstance readKey:AUTODOWNLOAD_KEY];
    mAutoDownload = (!autodownload || [autodownload isEqualToString:@"1"]);
}


-(NSString *) getToken {
    if([AppWebApi isEmpty:mToken])
        return nil;
    
    return mToken;
}

-(NSString *) getApiUrl {
    return SAMPLEAPP_API_URL;
}


-(void)save {
    [mUserDefaults setObject:mToken forKey:@"token"];
    [mUserDefaults synchronize];
}

-(void) checkSyncFailure:(NSDictionary *)request {
    NSString *op = (NSString *)[request objectForKey:@"op"];
    if([AppWebApi equals:op old:@"getcontacts"]) {
        mSyncPending = YES;
    }
}

-(BOOL) parseResponse:(NSString *)response request:(NSDictionary*)request handler:(SampleAPI_onResponse) handler {
    NSMutableDictionary *returnedDict = nil;
    NSString *op = nil;
    int result = SAMPLEAPP_RESULT_FAIL;
    
    NSError *jsonerror = nil;
    
    //MUST not happen
    if(nil == response)
        return YES;
    
    //LOGD(@"Data %@", [NSString stringWithUTF8String:(const char *)[data bytes]]);
    NSData *data = [response dataUsingEncoding:NSUTF8StringEncoding];
    id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&jsonerror];
    
    if (jsonerror != nil) {
        if(nil != handler)
            handler(result, nil);
        return YES;
    }
    
    if ([jsonObject isKindOfClass:[NSArray class]]) {
        //LOGD(@"its an array!");
        //NSArray *jsonArray = (NSArray *)jsonObject;
        
    }
    else {
        //LOGD(@"its probably a dictionary");
        returnedDict = (NSMutableDictionary *)jsonObject;
    }
    
    if(nil == returnedDict) {
        if(nil != handler)
            handler(result, nil);
        
        [self checkSyncFailure:request];
        
        return YES;
        
    }
    
    //NSString *result = (NSString *)[returnedDict objectForKeyOrNil:@"result"];
    //NSString *subresult = (NSString *)[returnedDict objectForKeyOrNil:@"subresult"];
    op = (NSString *)[returnedDict objectForKey:@"op"];
    NSString *res = (NSString *)[returnedDict objectForKey:@"result"];
    if([res isEqualToString:@"OK"]) {
        result = SAMPLEAPP_RESULT_OK;
    } else {
        NSString *error = (NSString *)[returnedDict objectForKey:@"error"];
        if([error isEqualToString:@"AUTHFAIL"]) {
            result = SAMPLEAPP_RESULT_AUTHFAIL;
            
            return NO;
        }
    }
    
    int64_t serverts = (uint64_t) [[returnedDict objectForKey:@"ts"] longLongValue];
    
    if(SAMPLEAPP_RESULT_OK != result) {
        if(nil != handler)
            handler(result, returnedDict);
        return NO;
    }
    
    NSString *temp = (NSString *)[returnedDict objectForKey:@"invite"];
    if(temp && [temp length] >0) {
        mInvite = [self getSavedValue:temp key:INVITE_KEY];
    }
    
    NSDictionary *urls = (NSDictionary *)[returnedDict objectForKey:@"urls"];
    if(urls) {
        mUploadUrl = [self getSavedValue:(NSString *)[urls objectForKey:@"upload"] key:UPLOADURL_KEY];
        mDownloadUrl = @"https://mesibo.com/demofiles/";
    }
  
  //#define SAMPLEAPP_API_URL   @"https://mesibo.com/demoapi/api.php"
  //#define SAMPLEAPP_DOWNLOAD_URL   @"https://mesibo.com/demofiles/"
    
    if([op isEqualToString:@"login"]) {
        mToken = (NSString *)[returnedDict objectForKey:@"token"];
        mPhone = (NSString *)[returnedDict objectForKey:@"phone"];
        mCc = (NSString *)[returnedDict objectForKey:@"cc"];
        

        if(![AppWebApi isEmpty:mToken]) {
            mContactTimestamp = 0;
            [self save];
            
            mResetSyncedContacts = YES;
            mSyncPending = YES;
            [MesiboInstance reset];
            
            
            //NO DB OP SHOULD BE HERE UNLESS DB is initialized
            //[self startMesibo:MESIBO_DBTABLE_PROFILES];
            
            [self createContact:returnedDict serverts:serverts selfProfile:YES refresh:NO visibility:VISIBILITY_VISIBLE];
            
        }
        
    } else if([op isEqualToString:@"getcontacts"]) {
        NSArray *contacts = (NSArray *)[returnedDict objectForKey:@"contacts"];
        
        int visibility = VISIBILITY_VISIBLE;
        NSString *h = [request objectForKey:@"hidden"];
        if(h && [h isEqualToString:@"1"]) {
            visibility = VISIBILITY_HIDE;
        }
        
        for(int i=0; i<contacts.count; i++) {
            NSDictionary *userDictionary = [contacts objectAtIndex:i];
            
            [self createContact:userDictionary serverts:serverts selfProfile:NO refresh:YES visibility:visibility];
        }
        
        if(contacts.count > 0) {
            [self save];
        }
        mResetSyncedContacts = NO;
        
            
        
    } else if([op isEqualToString:@"getgroup"] || [op isEqualToString:@"setgroup"]) {
        [self createContact:returnedDict serverts:serverts selfProfile:NO refresh:NO visibility:VISIBILITY_VISIBLE];
    } else if([op isEqualToString:@"editmembers"] || [op isEqualToString:@"setadmin"]) {
        uint32_t groupid = [[returnedDict objectForKey:@"gid"] unsignedIntValue];
        if(groupid > 0) {
            MesiboUserProfile *u = [MesiboInstance getGroupProfile:groupid];
            if(u) {
                u.groupMembers = [returnedDict objectForKey:@"members"];
                u.status = [self groupStatusFromMembers:u.groupMembers];
                [MesiboInstance setProfile:u refresh:NO];
            }
        }
    } else if([op isEqualToString:@"delgroup"]) {
        uint32_t groupid = [[returnedDict objectForKey:@"gid"] unsignedIntValue];
        [self updateDeletedGroup:groupid];
    } else if([op isEqualToString:@"upload"]) {
        int profile = [[returnedDict objectForKey:@"profile"] intValue];
        if(profile) {
            [self createContact:returnedDict serverts:serverts selfProfile:YES refresh:NO visibility:VISIBILITY_VISIBLE];
        }
        
    }
    
    if(handler)
        handler(result, returnedDict);
    
    return YES;
    
}


-(void) updateDeletedGroup:(uint32_t)groupid {
    if(!groupid) return;
    
    MesiboUserProfile *u = [MesiboInstance getGroupProfile:groupid];
    if(!u) return;
    u.flag |= MESIBO_USERFLAG_DELETED;
    u.status = @"Not a group member";
    [MesiboInstance setProfile:u refresh:NO];
}

-(NSString *) groupStatusFromMembers:(NSString*) members {
    if([AppWebApi isEmpty:members])
        return nil;
    
    NSArray *s = [members componentsSeparatedByString: @":"];
    if(!s || s.count < 2)
        return nil;
    
    NSArray *users = [s[1] componentsSeparatedByString: @","];
    if(!users)
        return nil;
    
    NSString *status = @"";
    
    for(int i=0; i < users.count; i++) {
        if(![AppWebApi isEmpty:status]) {
            status = [status stringByAppendingString:@", "];
        }
        
        NSString *p = [self getPhone];
        if(p && [p isEqualToString:users[i]]) {
            status = [status stringByAppendingString:@"You"];
        } else {
            MesiboUserProfile *u = [MesiboInstance getUserProfile:users[i]];
            if(u)
                [MesiboInstance lookupProfile:u source:2];
            
            if(u && u.name)
                status = [status stringByAppendingString:u.name];
            else
                status = [status stringByAppendingString:users[i]];
        }
        
        if([status length] > 32)
            break;
    }
    
    return status;
}

-(NSString *) getPhone {
    if(mPhone)
        return mPhone;
    
    MesiboUserProfile *u = [MesiboInstance getSelfProfile];
    if(!u) {
        //MUST not hapen
        return nil;
    }
    
    mPhone = u.address;
    return mPhone;
}

-(void) createContact:(NSDictionary *)response serverts:(int64_t)serverts selfProfile:(BOOL)selfProfile refresh:(BOOL)refresh visibility:(int)visibility {
    NSString *name = [response objectForKey:@"name"];
    NSString *phone = [response objectForKey:@"phone"];
    NSString *status = [response objectForKey:@"status"];
    NSString *photo = [response objectForKey:@"photo"];
    NSString *members = [response objectForKey:@"members"];
    
    
    if(![photo isKindOfClass:[NSString class]])
        photo = @"";
    
    uint32_t groupid = 0;
    if(!selfProfile) {
        groupid = [[response objectForKey:@"gid"] unsignedIntValue];
        if(groupid)
            phone = @"";
    }
    
    if([AppWebApi isEmpty:phone] && 0 == groupid) {
        return;
    }
    
    int64_t timestamp = (uint64_t) [[response objectForKey:@"ts"] longLongValue];
    if(!selfProfile && timestamp > mContactTimestamp)
        mContactTimestamp = timestamp;
    
    NSString *tn = [response objectForKey:@"tn"];
    
    [self createContact:name phone:phone groupid:groupid status:status members:members photo:photo tnbase64:tn ts:timestamp when:(serverts-timestamp) selfProfile:selfProfile refresh:refresh visibility:visibility];
}


-(void) createContact:(NSString *)name phone:(NSString *)phone groupid:(uint32_t)groupid status:(NSString *)status members:(NSString *)members photo:(NSString *)photo tnbase64:(NSString *)tnbase64 ts:(uint64_t)ts when:(int64_t)when selfProfile:(BOOL)selfProfile refresh:(BOOL)refresh visibility:(int)visibility {
    
    MesiboUserProfile *u = [[MesiboUserProfile alloc] init];
    u.address = phone;
    u.groupid = groupid;
    if(selfProfile) {
        u.groupid = 0;
        groupid = 0;
    }
    
    if(!selfProfile && 0 == u.groupid) {
        u.name = @"";
    }
    
    if([AppWebApi isEmpty:u.name]) {
        u.name = name;
    }
    
    if([AppWebApi isEmpty:u.name]) {
        u.name = phone;
        if([AppWebApi isEmpty:u.name]) {
            u.name = [NSString stringWithFormat:@"Group-%d", groupid];
        }
    }
    
    if(0 == u.groupid && ![AppWebApi isEmpty:phone] && [phone isEqualToString:@"0"]) {
        //debug
        u.name = @"Hello - debug";
        return;
    }
    
    u.status = status;
    if(u.groupid) {
        u.groupMembers = members;
        NSString *phone = [self getPhone];
        if(!phone) {
            return;
        }
        if(![members containsString:phone]) {
            [self updateDeletedGroup:groupid];
            return;
        }
        u.status = [self groupStatusFromMembers:members];
    }
    
    if(!u.status) {
        u.status = @"";
    }
    
    u.picturePath = photo;
    u.timestamp = ts;
    if(!selfProfile &&  ts > 0 && u.timestamp > mContactTimestamp)
        mContactTimestamp = u.timestamp;
    
    if(when >= 0) {
        u.lastActiveTime = [MesiboInstance getTimestamp] - (when*100);
    }
    
    if([tnbase64 length] > 3) {
        NSData *tnData = [[NSData alloc] initWithBase64EncodedString:tnbase64 options:0];
        if(tnData && [tnData length] > 100) {
            NSString *imagePath = [MesiboInstance getFilePath:MESIBO_FILETYPE_PROFILETHUMBNAIL];
            if([MesiboInstance createFile:imagePath fileName:u.picturePath data:tnData overwrite:YES]) {
            }
        }
    }
    
    if(VISIBILITY_HIDE == visibility) {
        u.flag |= MESIBO_USERFLAG_HIDDEN;
    } else if(VISIBILITY_UNCHANGED == visibility) {
        MesiboUserProfile *tp = [MesiboInstance getProfile:u.address groupid:u.groupid];
        if(tp && (tp.flag&MESIBO_USERFLAG_HIDDEN)) {
            u.flag |= MESIBO_USERFLAG_HIDDEN;
        }
    }
    
    if(selfProfile) {
        mPhone = u.address;
        [MesiboInstance setSelfProfile:u];
    }
    else
        [MesiboInstance setProfile:u refresh:refresh];
    
}


-(BOOL) getGroup:(uint32_t) groupid handler:(SampleAPI_onResponse) handler {
    if(nil == mToken || 0 == groupid)
        return NO;
    
    NSMutableDictionary *post = [[NSMutableDictionary alloc] init];
    [post setValue:@"getgroup" forKey:@"op"];
    [post setValue:mToken forKey:@"token"];
    [post setValue:[@(groupid) stringValue] forKey:@"gid"];
    
    [self invokeApi:post filePath:nil handler:handler];
    return YES;
}

-(void) invokeApi:(NSDictionary *)post filePath:(NSString *)filePath handler:(SampleAPI_onResponse) handler {
    
    
    Mesibo_onHTTPProgress progressHandler = ^BOOL(MesiboHttp *http, int state, int progress) {
        
        if(100 == progress && state == MESIBO_HTTPSTATE_DOWNLOAD) {
            [self parseResponse:[http getDataString] request:post handler:handler];
        }
        
        if(progress < 0) {
            NSLog(@"invokeAPI failed");
            // 100 % progress will be handled by parseResponse
            if(nil != handler) {
                handler(SAMPLEAPP_RESULT_FAIL, nil);
            }
        }
        
        
        return YES;
        
    };
    
    MesiboHttp *http = [MesiboHttp new];
    http.url = SAMPLEAPP_API_URL;
    http.postBundle = post;
    http.uploadFile = filePath;
    http.uploadFileField = @"photo";
    http.listener = progressHandler;
    
    if(![http execute]) {
        
    }
}

+(BOOL) equals:(NSString *)s old:(NSString *)old {
    int sempty = (int) [s length];
    int dempty = (int) [old length];
    if(sempty != dempty) return NO;
    if(!sempty) return YES;
    
    return ([s caseInsensitiveCompare:old] == NSOrderedSame);
}

+(BOOL) isEmpty:(NSString *)string {
    if(/*[NSNull null] == string ||*/ nil == string || 0 == [string length])
        return YES;
    return NO;
}


-(void) createContacts:(NSDictionary *)response {
    NSArray *contacts = [response objectForKey:@"contacts"];

    if(!contacts) return;

    for(int i=0; i < contacts.count; i++) {
        NSDictionary *c = [contacts objectAtIndex:i];

        NSString *name = [c objectForKey:@"name"];
        NSString *phone = [c objectForKey:@"phone"];

        [self addContact:name phone:phone];
    }
}

-(void) addContact:(NSString *)name phone:(NSString *)phone {
    if([AppWebApi isEmpty:phone]) {
        return;
    }

    MesiboUserProfile *u = [[MesiboUserProfile alloc] init];

    if([AppWebApi isEmpty:name]) {
        name = phone;
    }

    u.name = name;
    u.address = phone;

    [MesiboInstance setProfile:u refresh:NO];
    
}

-(void) onContactsChanged {
    mSyncPending = YES;
    [self startSync];
}

-(void) startSync {
    
    
    @synchronized (self) {
        if(!mSyncPending)
            return;
        
        mSyncPending = NO;
    }
    
    if(mResetSyncedContacts) {
        [MesiboInstance setKey:SYNCEDCONTACTS_KEY value:@""];
    }
    
    id thiz = self;
    [self getContacts:nil hidden:NO handler:^(int result, NSDictionary *response) {
            //update entire table after all groups added since UI doesn't add group messages unless profile present
            NSArray *contacts = (NSArray *)[response objectForKey:@"contacts"];
        
            if([contacts count] > 0) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [MesiboInstance setProfile:nil refresh:YES];
                });
            }
        
            [thiz startContactSync];
    }];
}

-(void) startContactSync {
    
    if(nil == self)
        return;
    
    @synchronized (self) {
    if(mSyncStarted)
        return;
    
    mSyncStarted = YES;
    }
    
    //TBD, we need to fix contact utils to run in this thread
    // We must run in UI thread else contact change is not triggered
    [MesiboInstance runInThread:YES handler: ^{
        __block NSMutableArray *mContacts = [NSMutableArray new];
        __block NSMutableArray *mDeletedContacts = [NSMutableArray new];
    }];
}


-(void) logout {
    
    [MesiboInstance stop];
    NSMutableDictionary *post = [[NSMutableDictionary alloc] init];
    [post setValue:@"logout" forKey:@"op"];
    
    //even if token value is wrong, logout will happen due to AUTHFAIL
    [post setValue:mToken forKey:@"token"];
    
    [self invokeApi:post filePath:nil handler:nil];
    
    mToken = @"";
    [self save];
    [MesiboInstance reset];
    
}

-(void) login:(NSString *)name phone:(NSString *)phone handler:(SampleAPI_onResponse) handler {
    NSMutableDictionary *post = [[NSMutableDictionary alloc] init];
    [post setValue:@"login" forKey:@"op"];
    if(name)
        [post setValue:name forKey:@"name"];
    [post setValue:phone forKey:@"phone"];
    
    [post setValue:SAMPLEAPP_NAMESPACE forKey:@"ns"];
    
    NSString *packageName = [[NSBundle mainBundle] bundleIdentifier];
    [post setValue:packageName forKey:@"aid"];
    [self invokeApi:post filePath:nil handler:handler];
  
}

-(void) resetDB {
    //[MesiboInstance resetDatabase:MESIBO_DBTABLE_ALL];
}



-(void) addContacts:(NSArray *)profiles hidden:(BOOL)hidden {
    NSMutableArray *addresses = [NSMutableArray new];
    
    for(int i=0; i < profiles.count; i++) {
        MesiboUserProfile *profile = (MesiboUserProfile *)[profiles objectAtIndex:i];
        if(profile.address && (profile.flag&MESIBO_USERFLAG_TEMPORARY) && !(profile.flag&MESIBO_USERFLAG_PROFILEREQUESTED)) {
            profile.flag |= MESIBO_USERFLAG_PROFILEREQUESTED;
            [addresses addObject:profile.address];
        }
    }
    
    if([addresses count] == 0)
        return;
    
    [self getContacts:addresses hidden:hidden handler:^(int result, NSDictionary *response) {
        
    }];
}

-(BOOL) getContacts:(NSArray *)contacts hidden:(BOOL)hidden handler:(SampleAPI_onResponse) handler {
    NSMutableDictionary *post = [[NSMutableDictionary alloc] init];
    [post setValue:@"getcontacts" forKey:@"op"];
    [post setValue:mToken forKey:@"token"];
    
    if(hidden && (!contacts || [contacts count] == 0))
        return NO;
    
    [post setValue:(hidden?@"1":@"0") forKey:@"hidden"];
    
    if(!hidden && mResetSyncedContacts) {
        [post setValue:@"1" forKey:@"reset"];
        mContactTimestamp = 0;
    }
    
    [post setValue:[NSNumber numberWithUnsignedLongLong:mContactTimestamp] forKey:@"ts"];
    if(contacts && contacts.count > 0) {
        NSString *string = [contacts componentsJoinedByString:@","];
        [post setValue:string forKey:@"phones"];
    }
    if(handler)
        [self invokeApi:post filePath:nil handler:handler];
    else {
        NSString *response = [self fetch:post filePath:nil];
        if(!response) {
            //TBD, if response nil due to network error, we must retry later
            return NO;
        }
        
        BOOL rv = [self parseResponse:response request:post handler:handler];
        if(contacts && rv) {
            [self saveSyncedContacts:contacts];
        }
        
        return rv;
    }
    return YES;
}

-(void) autoAddContact:(MesiboParams *)params {
    if(MESIBO_MSGSTATUS_OUTBOX == params.status)
        return;
    
    if(0 == (params.profile.flag&MESIBO_USERFLAG_TEMPORARY) || (params.profile.flag&MESIBO_USERFLAG_PROFILEREQUESTED) )
        return;
    
    MesiboUserProfile *profile = params.profile;
    NSMutableArray *profiles = [NSMutableArray new];
    [profiles addObject:profile];
    [self addContacts:profiles hidden:YES];
}


-(void) saveSyncedContacts:(NSArray *) contacts {
    //
  //NSString *str = [ContactUtilsInstance synced:contacts type:CONTACTUTILS_SYNCTYPE_SYNC];
    //[MesiboInstance setKey:SYNCEDCONTACTS_KEY value:str];
}

-(NSString *) fetch:(NSDictionary *)post filePath:(NSString *) filePath {
    MesiboHttp *http = [MesiboHttp new];
    http.url = [self getApiUrl];
    http.postBundle = post;
    http.uploadFile = filePath;
    http.uploadFileField = @"photo";
    
    if([http executeAndWait]) {
        return [http getDataString];
    }
    
    return nil;
}

-(BOOL) setGroup:(MesiboUserProfile *)profile members:(NSArray *)members handler:(SampleAPI_onResponse)handler {
    if(nil == mToken)
        return NO;
    
    NSMutableDictionary *post = [[NSMutableDictionary alloc] init];
    [post setValue:@"setgroup" forKey:@"op"];
    [post setValue:mToken forKey:@"token"];
    
    if(profile.groupid)
        [post setValue:[@(profile.groupid) stringValue] forKey:@"gid"];
    
    if(profile.name)
        [post setValue:profile.name forKey:@"name"];
    if(profile.status)
        [post setValue:profile.status forKey:@"status"];
    
    if(members && members.count > 0) {
        NSString *string = [members componentsJoinedByString:@","];
        [post setValue:string forKey:@"m"];
    }
    
    [self invokeApi:post filePath:profile.picturePath handler:handler];
    
    return YES;
}

@end
