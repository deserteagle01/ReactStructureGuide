
//  Copyright © 2017 Mesibo. All rights reserved.

#import <Foundation/Foundation.h>
#import "Mesibo/Mesibo.h"
//#import "MesiboCall/MesiboCall.h"

#define MesiboListenersInstance [MesiboListener getInstance]


@interface MesiboListener : NSObject <MesiboDelegate>

+(MesiboListener *)getInstance :(NSString *)secretKey accessKey:(NSString *)accessKey bucketName:(NSString *)bucketName;

@end
