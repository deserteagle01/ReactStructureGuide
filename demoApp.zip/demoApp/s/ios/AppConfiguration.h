
#import <Foundation/Foundation.h>


#define SAMPLEAPP_API_URL   @"https://mesibo.com/demoapi/api.php"
#define SAMPLEAPP_DOWNLOAD_URL   @"https://mesibo.com/demofiles/"

// IMPORTANT: define a random namespace string in case you are using public api
// so that it only shows contacts created in your test environment
#define SAMPLEAPP_NAMESPACE @"aXmsal0q7nNNy"


#define SAMPLEAPP_TOOLBARCOLOR 0xFF00998b

#define GOOGLE_MAP_KEY  @"SET YOUR OWN GOOGLE MAP KEY"
