#import <UIKit/UIKit.h>
#import <mesibo/mesibo.h>
#import <mediapicker/ImagePicker.h>
#import <MesiboUI/MesiboUI.h>
#import "MesiboListener.h"
#import <React/RCTBridgeModule.h>
#import <mesiboui/MesiboUI.h>
//#import <mesibouihelper/mesibouihelper.h>
#import "AppDelegate.h"
#import <React/RCTBundleURLProvider.h>
#import <React/RCTRootView.h>
#import <React/RCTI18nUtil.h>
#import "AppWebApi.h"
#import <React/RCTEventEmitter.h>
#import "MesiboManager.h"


#define SampleAPIInstance [AppWebApi getInstance]

@implementation MesiboManager
@synthesize isFrom;
//MesiboUiHelperConfig *mAppLaunchData;

RCT_EXPORT_MODULE(MesiboManager);

+ (id)allocWithZone:(NSZone *)zone {
    static MesiboManager *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [super allocWithZone:zone];
    });
    return sharedInstance;
}

RCT_EXPORT_METHOD(logout) {
  [MesiboInstance setKey:@"apntoken" value:@""];
  [MesiboInstance stop];
  [MesiboInstance reset];
}

- (NSArray<NSString *> *)supportedEvents
{
  return @[@"datafromNative"];
}

- (void)sendDataToReact:(uint32_t)groupId groupname:(NSString *)groupname {
  NSString *gid = [NSString stringWithFormat:@"%u",groupId];
    MesiboManager *notification = [MesiboManager allocWithZone:nil];
    [notification sendNotificationToReactNative:@{@"groupName": groupname, @"groupId": gid}];

}

- (void)sendNotificationToReactNative:(NSDictionary *)groupData {
  if(![isFrom  isEqual: @"groupUI"]){
    [self sendEventWithName:@"datafromNative" body:groupData];
  }
}

RCT_EXPORT_METHOD(login:(NSString *)token :(NSString *)secretKey :(NSString *)accessKey :(NSString *)bucketName :(RCTResponseSenderBlock )callback) {
  if (token != nil) {
      [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"accessToken"];
      [[NSUserDefaults standardUserDefaults] synchronize];
    
      NSString *deviceToken = [[NSUserDefaults standardUserDefaults] stringForKey:@"deviceToken"];
      NSString *appdir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
      
      //[MesiboInstance setPushToken:deviceToken];
      [AppWebApi setPushNotificationToken:deviceToken];
      [MesiboInstance setPath:appdir];
      [MesiboInstance addListener:[MesiboListener getInstance:secretKey accessKey:accessKey bucketName:bucketName]];
      [MesiboInstance setAccessToken:token];
      [MesiboInstance setSecureConnection:YES];
      [MesiboInstance setDatabase:@"mesibo.db" resetTables:0];
      [MesiboInstance start];
    
    
    callback(@[ [NSNull null] ]);
  }
  else{
    callback(@[ @"Invalid AuthenticationToken" ]);
  }
}

RCT_EXPORT_METHOD(launchMesiboUI:(NSString *)token groups:(NSArray *)groups :(RCTResponseSenderBlock )callback) {
    isFrom = @"defaultUI";
    [self setGroupProfile: groups];
    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"isgroupdetail"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSMutableDictionary *result = [self launchMesiboUI:FALSE groupID:0];
    if([result[@"result"]  isEqual: @"1"]){
        callback(@[ [NSNull null] ]);
    }else{
        callback(@[ result[@"message"] ]);
    }
}

RCT_EXPORT_METHOD(sendMessage:(NSString *)token groups:(NSArray *)groups :(RCTResponseSenderBlock )callback) {
    NSDictionary  *currenObj = [groups objectAtIndex:0];
    NSString *msg = [currenObj objectForKey:@"message"];
    NSString *name = [currenObj objectForKey:@"name"];
    NSNumber *tempId = [currenObj valueForKey:@"mesibo_group_id"];
    uint32_t grp_Id = [tempId unsignedIntValue];
    NSMutableDictionary *result = [self sendMessageToGroup:grp_Id groupname:name msg:msg];
    if([result[@"result"]  isEqual: @"1"]){
        callback(@[ [NSNull null] ]);
    }else{
        callback(@[ result[@"message"] ]);
    }
}

RCT_EXPORT_METHOD(launchGroupDetail:(NSString *)token groups:(NSArray *)groups groupId:(NSString *)groupId groupname:(NSString *)groupname :(RCTResponseSenderBlock )callback) {
  isFrom = @"groupUI";
  [self setGroupProfile: groups];
  [[NSUserDefaults standardUserDefaults] setObject: groupId  forKey:@"groupID"];
  [[NSUserDefaults standardUserDefaults] setObject:groupname forKey:@"name"];
  [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"isgroupdetail"];
  [[NSUserDefaults standardUserDefaults] synchronize];
  
  NSMutableDictionary *result = [self launchMesiboUI:TRUE groupID:0];
  if([result[@"result"]  isEqual: @"1"]){
      callback(@[ [NSNull null] ]);
  }else{
      callback(@[ result[@"message"] ]);
  }
}

RCT_EXPORT_METHOD(readStoredChatList:(NSArray *)grpArray resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject) {
  NSLog(@"Reading local chat list for filtering ongoing chat list.");
  NSMutableDictionary *returnDict = [NSMutableDictionary dictionary];
  @try {
    for (int i = 0; i < grpArray.count; i++){
      NSDictionary  *currentObj = [grpArray objectAtIndex:i];
      if (currentObj != nil) {
        NSNumber *grpid = [currentObj valueForKey:@"mesibo_group_id"];
        if (grpid != nil) {
          uint32_t grp_Id = [grpid unsignedIntValue];
          NSLog(@"Processing group with ID: %d", grp_Id);
          MesiboReadSession *mReadSession = [MesiboReadSession new];
          [mReadSession initSession:nil groupid:grp_Id query:nil delegate:nil];
          int availableMsgCount = [mReadSession read:2000];
          NSLog(@"Read message count: %d", availableMsgCount);
          if (availableMsgCount > 0) {
            [returnDict setObject:[NSNumber numberWithBool:YES] forKey:[NSString stringWithFormat:@"%i", grp_Id]];
          }
        }
      }
    }
    resolve(returnDict);
  }
  @catch (NSException *exception) {
    NSLog(@"Error occurred while reading local chats: %@", exception);
    NSError *error = nil;
    reject(@"READ_LOCAL_CHAT_LIST", @"Error occurred while reading local chats.", error);
  }
}
  
-(NSMutableDictionary *)launchMesiboUI:(BOOL)detail groupID:(uint32_t)groupID {
  NSMutableDictionary *returnDict = [[NSMutableDictionary alloc] init];

    @try {
      dispatch_async(dispatch_get_main_queue(), ^{
        MesiboUiOptions *ui = [MesiboInstance getUiOptions];
        ui.enableBackButton = true;
        ui.enableSearch = false;
        ui.messageListTitle = @"StoneStocks";
        ui.enableVideoCall = false;
        ui.enableVoiceCall = false;
        ui.mEnableNotificationBadge = true;
        ui.useLetterTitleImage = false;
        ui.emptyUserListMessage = @"You do not have any messages";
        ui.mToolbarColor = 0x000000;
        ui.mMaxImageFileSize = 0;
        ui.mMaxVideoFileSize = 0;
        
          AppDelegate *appDelegate=( AppDelegate* )[UIApplication sharedApplication].delegate;
          [appDelegate goNativeStoryboard];
      });
      
      [returnDict setObject:@"1" forKey:@"result"];
      [returnDict setObject:@"success" forKey:@"message"];
      
      return returnDict;
    }
    @catch (NSException *exception) {
      [returnDict setObject:@"0" forKey:@"result"];
      [returnDict setObject:exception.reason forKey:@"message"];
      
      return returnDict;
    }
}


-(void) setGroupProfile:(NSArray *)groups {
  dispatch_async(dispatch_get_main_queue(), ^{
  NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  NSString *documentsPath = [paths objectAtIndex:0]; //Get the docs directory
  NSFileManager *fileManager = [NSFileManager defaultManager];
  NSMutableArray *arrImageUrl = [[[NSUserDefaults standardUserDefaults] objectForKey:@"ImageGroupurl"] mutableCopy];
  NSMutableArray *arrEmpty = [[NSMutableArray alloc]init];
    
    [MesiboInstance reset];
    for (int i = 0; i < groups.count; i++){
    NSDictionary  *currenObj = [groups objectAtIndex:i];
    NSString *name = [currenObj objectForKey:@"name"];
    NSString *groupname = [[currenObj objectForKey:@"stock_detail_id"] valueForKey:@"name"];
    NSNumber *temp_number = [currenObj valueForKey:@"mesibo_group_id"];
    NSString *imgURl = [[currenObj valueForKey:@"stock_detail_id"] valueForKey:@"group_img_url"];
    uint32_t grp_Id = [temp_number unsignedIntValue];
    NSURL * url = [NSURL URLWithString:imgURl];
    
    NSString *imgName = [NSString stringWithFormat:@"%@.png",name];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:imgName];
    
    NSMutableDictionary *dictGroupTemp = [[NSMutableDictionary alloc]init];
    [dictGroupTemp setObject:temp_number forKey:@"gid"];
    [dictGroupTemp setObject:imgURl forKey:@"ImageUrl"];
    
    if(arrImageUrl && arrImageUrl.count > 0) {
        NSArray *filterUrl = [arrImageUrl filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(ImageUrl == %@)", imgURl]];
        NSArray *filterId = [arrImageUrl filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(gid == %@)", temp_number]];
        if(filterUrl.count <= 0) {
            if(filterId.count > 0) {
                NSMutableArray *removeArray = [filterId mutableCopy];
                [arrImageUrl removeObject: [removeArray objectAtIndex:0]];
            }
            
            NSData *pngData = [NSData dataWithContentsOfURL:url];
            [pngData writeToFile:filePath atomically:YES];
            [arrImageUrl addObject:dictGroupTemp];
        }
    }
    else{
        //[self saveImage:url filepath:filePath];
        NSData *pngData = [NSData dataWithContentsOfURL:url];
        [pngData writeToFile:filePath atomically:YES];
        [arrEmpty addObject:dictGroupTemp];
    }
    
    MesiboUserProfile *groupProfile = [[MesiboUserProfile alloc]init];
    [groupProfile setGroupid:grp_Id];
    [groupProfile setName:name];
    [groupProfile setPicturePath: filePath];
    

    MesiboUserProfile *settingProfile =  [MesiboInstance setProfile:groupProfile refresh:true];
    MesiboUserProfile *gettingProfile = [MesiboInstance getProfile:NULL groupid: grp_Id];
    NSLog(@"%@ %@", settingProfile, gettingProfile);
  }
  
  if(arrImageUrl && arrImageUrl.count > 0){
    [[NSUserDefaults standardUserDefaults] setObject:arrImageUrl forKey:@"ImageGroupurl"];
  }
  else{
    [[NSUserDefaults standardUserDefaults] setObject:arrEmpty forKey:@"ImageGroupurl"];
  }
  
  [[NSUserDefaults standardUserDefaults] synchronize];
  
  });
}

-(void) saveImage:(NSURL *)url filepath:(NSString *)filepath {
  NSData *pngData = [NSData dataWithContentsOfURL:url];
  [pngData writeToFile:filepath atomically:YES];
}



-(NSMutableDictionary *)sendMessageToGroup:(uint32_t)groupId  groupname:(NSString *)groupname  msg:(NSString *)msg {
  NSMutableDictionary *returnDict = [[NSMutableDictionary alloc] init];
  //creating group profile
  MesiboUserProfile *groupProfile = [MesiboInstance createProfile:NULL groupid:groupId name:groupname];
  
  MesiboParams *param = [MesiboParams new];
  [param setGroupProfile:groupProfile];
  [param setPeer:@""];
  [param setGroupid:groupId];
  [param setFlag:MESIBO_FLAG_READRECEIPT|MESIBO_FLAG_DELIVERYRECEIPT];
  [param setExpiry:3600*24*7];
  uint32_t mid = [MesiboInstance random];
  
  @try {
    int msgsend = [MesiboInstance sendMessage:param msgid:mid string:msg];
    NSLog(@"-------------message send  = %u",msgsend);
    [returnDict setObject:@"1" forKey:@"result"];
    [returnDict setObject:@"success" forKey:@"message"];
    
    return returnDict;
  }
  @catch (NSException *exception) {
    [returnDict setObject:@"0" forKey:@"result"];
    [returnDict setObject:exception.reason forKey:@"message"];
    
    return returnDict;
  }
}

@end
