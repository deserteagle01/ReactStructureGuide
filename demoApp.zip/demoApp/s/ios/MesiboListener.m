
//  Copyright © 2017 Mesibo. All rights reserved.

#import "MesiboListener.h"
#import "AppWebApi.h"
#import <Photos/Photos.h>
#import <Mesibo/Mesibo.h>
#import <AWSS3/AWSS3.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AWSCore/AWSCore.h>
#import "AppDelegate.h"
#import "MesiboManager.h"
#define SampleAPIInstance [AppWebApi getInstance]
NSString *accessToken;
NSString *aws_secretKey;
NSString *aws_accessKey;
NSString *aws_bucketName;
@implementation MesiboListener

+(MesiboListener *)getInstance :(NSString *)secretKey accessKey:(NSString *)accessKey bucketName:(NSString *)bucketName {
    static MesiboListener *myInstance = nil;
    aws_accessKey = accessKey;
    aws_secretKey = secretKey;
    aws_bucketName = bucketName;
    if(nil == myInstance) {
        @synchronized(self) {
            if (nil == myInstance) {
                myInstance = [[self alloc] init];
                [myInstance initialize];
            }
        }
    }
    return myInstance;
}

-(void) initialize {
    accessToken = [[NSUserDefaults standardUserDefaults] stringForKey:@"accessToken"];
  
    [MesiboInstance addListener:self];
    //[MesiboCallInstance setListener:self];
  
    AWSStaticCredentialsProvider *s3Provider = [[AWSStaticCredentialsProvider alloc] initWithAccessKey:aws_accessKey secretKey:aws_secretKey];
  
    //AWSRegionUSEast2
    
    AWSServiceConfiguration *s3Configuration = [[AWSServiceConfiguration alloc] initWithRegion: AWSRegionAPSouth1 credentialsProvider:s3Provider];
    [AWSServiceManager defaultServiceManager].defaultServiceConfiguration = s3Configuration;
}

-(void) Mesibo_OnMessage:(MesiboParams *)params data:(NSData *)data {
  NSString* myString;
  myString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
  NSLog(@"----------- on message received ----------q------- = %@",myString);
  //TODO:
  [SampleAPIInstance autoAddContact:params];
    if([MesiboInstance isReading:params])
        return;
    
    if([data length] == 0) {
        return;
    }
    


    UILocalNotification *notification = [[UILocalNotification alloc] init];
    notification.fireDate = [NSDate dateWithTimeIntervalSinceNow:0];
    notification.alertBody = myString;
    notification.timeZone = [NSTimeZone defaultTimeZone];
    notification.soundName = UILocalNotificationDefaultSoundName;
    

    [[UIApplication sharedApplication] scheduleLocalNotification:notification];
}

-(void) Mesibo_onFile:(MesiboParams *)params file:(MesiboFileInfo *)file {
//    if(nil != file){
//        NSLog(@"File Info: %@", file.type);
//        NSLog(@"File Info source: %@", file.source);
//        NSLog(@"File Info size: %@", file.size);
//        NSLog(@"File Info maxDimension: %@", file.maxDimension);
//        NSLog(@"File Info maxSize: %@", file.maxSize);
//        NSLog(@"File Info mimeType: %@", file.mimeType);
//        NSLog(@"File Info launchUrl: %@", file.launchUrl);
//        NSLog(@"File Info userInteraction: %@", file.userInteraction);
//        NSLog(@"File Info secure: %@", file.secure);
//        NSLog(@"File Info title: %@", file.title);
//        NSLog(@"File Info message: %@", file.message);
//        NSLog(@"File Info mid: %@", file.mid);
//        NSLog(@"File Info lat: %@", file.lat);
//        NSLog(@"File Info lon: %@", file.lon);
//        NSLog(@"File Info asset: %@", file.asset);
//        NSLog(@"File Info localIdentifier: %@", file.localIdentifier);
//        NSLog(@"File Info fileTransferContext: %@", file.fileTransferContext);
//    }
    
}

-(void) Mesibo_onLocation:(MesiboParams *)params location:(MesiboLocation *)location {
    
}

// so that we get contact while user has started typing
-(void) Mesibo_onActivity:(MesiboParams *)params activity:(int)activity {
  [SampleAPIInstance autoAddContact:params];
  NSLog(@"-------------acitivity ======%@  %d",params, activity);
}




-(void) Mesibo_OnConnectionStatus:(int)status {
    NSLog(@"-------- Connection status: %d", status);
// #define MESIBO_STATUS_UNKNOWN            0
//  #define MESIBO_STATUS_ONLINE            1
//  #define MESIBO_STATUS_OFFLINE           2
//  #define MESIBO_STATUS_SIGNOUT           3
//  #define MESIBO_STATUS_AUTHFAIL          4
//  #define MESIBO_STATUS_STOPPED           5
//  #define MESIBO_STATUS_CONNECTING        6
//  #define MESIBO_STATUS_CONNECTFAILURE    7
//  #define MESIBO_STATUS_NONETWORK         8
//  #define MESIBO_STATUS_MANDUPDATE        10
//  #define MESIBO_STATUS_SHUTDOWN          20
//  #define MESIBO_STATUS_ACTIVITY          -1
}

-(BOOL) Mesibo_onUpdateUserProfiles:(MesiboUserProfile *)profile {
    
  NSLog(@"--------------------Mesibo_onUpdateUserProfiles group%@",profile);
    //return NO;
  return YES;
}

- (void)Mesibo_onShowProfile:(id)parent profile:(MesiboUserProfile *)profile {
    AppDelegate *appDelegate=( AppDelegate* )[UIApplication sharedApplication].delegate;
    [appDelegate goToReactNative];
  
    MesiboManager *reactobj = [[MesiboManager alloc]init];
    [reactobj sendDataToReact:profile.groupid groupname:profile.name];
}


-(void) Mesibo_onSetGroup:(id)parent profile:(MesiboUserProfile *)profile type:(int)type members:(NSArray *)members handler:(Mesibo_onSetGroupHandler)handler {
  NSLog(@"---------Mesibo_onSetGroup----------setup group%@",members);
  [SampleAPIInstance setGroup:profile members:members handler:^(int result, NSDictionary *response) {
         u_int32_t groupid = [[response objectForKey:@"gid"] unsignedIntValue];
         handler(groupid);
     }];
  
}

-(void) Mesibo_onGetGroup:(id)parent groupid:(uint32_t)groupid handler:(Mesibo_onSetGroupHandler)handler {
      NSLog(@"on get group handler --------Mesibo_onGetGroup----------=%u",groupid);
     [SampleAPIInstance getGroup:groupid handler:^(int result, NSDictionary *response) {
        NSLog(@"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
     }];
}


-(NSArray *) Mesibo_onGetGroupMembers:(id)parent groupid:(uint32_t)groupid {
    //return nil;
    MesiboUserProfile *profile = [MesiboInstance getProfile:nil groupid:groupid];
    if(!profile) return nil;
    
    return [self getGroupMembers:profile.groupMembers];
}
   
   -(NSArray *) getGroupMembers:(NSString*) members {
       if([AppWebApi isEmpty:members])
           return nil;
       
       NSArray *s = [members componentsSeparatedByString: @":"];
       if(!s || s.count < 2)
           return nil;
       
       NSArray *users = [s[1] componentsSeparatedByString: @","];
       if(!users)
           return nil;
       
       
       NSMutableArray *m = [NSMutableArray new];
       
       for(int i=0; i < users.count; i++) {
           MesiboUserProfile *u = [MesiboInstance getUserProfile:users[i]];
           if(!u)
               u = [MesiboInstance createProfile:users[i] groupid:0 name:nil];
           
           [m addObject:u];
       }
       
       return m;
   }


/** Message filtering
 * This function is called every time a message received. This function should return true if
 * message to be acceped or false to drop it
 *
 * In this example, we are using it to get contact and real-time notifications from the server (refer
 * php example). PHP sanmple code sends a special message with type '1' when new contact signs up
 * or need to send any push notification. All such messages are processed and filtered here.
 */

-(BOOL) Mesibo_OnMessageFilter:(MesiboParams *)params direction:(int)direction data:(NSData *)data {
    // using it for notifications
    if(1 != params.type)
        return YES;
    
    if(![data length])
        return NO;
    
    NSError *jsonerror = nil;
    NSMutableDictionary *returnedDict = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&jsonerror];
    
    if (jsonerror != nil) {
        return NO;
    }
    
    if (![jsonObject isKindOfClass:[NSArray class]]) {
        //LOGD(@"its probably a dictionary");
        returnedDict = (NSMutableDictionary *)jsonObject;
    }
    
    if(!returnedDict)
        return NO;
    
    //    NSString *name = (NSString *)[returnedDict objectForKeyOrNil:@"name"];
    //    NSString *phone = (NSString *)[returnedDict objectForKeyOrNil:@"phone"];
    //
    //    [SampleAPIInstance addContact:name phone:phone];

    return NO;
}


-(void) Mesibo_onForeground:(id)parent screenId:(int)screenId foreground:(BOOL)foreground {
    //userlist is in foreground
    if(foreground && 0 == screenId) {
        //notify count clear
    }
}

- (BOOL)Mesibo_onMenuItemSelected:(id)parent type:(int)type profile:(MesiboUserProfile *)profile item:(int)item {
    // userlist menu are active
    if(type == 0) { // USERLIST
        if(item == 1) {   //item == 0 is reserved
            
        }
        
    } else { // MESSAGEBOX
//        if(item == 0) {
//            NSLog(@"Menu btn from messagebox pressed");
//            [MesiboCallInstance call:parent callid:0 address:profile.address video:NO incoming:NO];
//        }else if (item ==1) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [MesiboCallInstance call:parent callid:0 address:profile.address video:YES incoming:NO];
//
//            });
//        }
    }
    
    return true;
}

-(NSArray *) Mesibo_onGetMenu:(id)parent type:(int) type profile:(MesiboUserProfile *)profile {
    
    NSArray*btns = nil;
    
    if(type == 0) {
        UIButton *button =  [UIButton buttonWithType:UIButtonTypeCustom];
//        [button setTitle:@"New" forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"ic_message_white"] forState:UIControlStateNormal];
        [button setFrame:CGRectMake(0, 0, 44, 44)];
        [button setTag:0];
        
        UIButton *button1 =  [UIButton buttonWithType:UIButtonTypeCustom];
//        [button1 setTitle:@"More" forState:UIControlStateNormal];
        [button1 setImage:[UIImage imageNamed:@"ic_more_vert_white"] forState:UIControlStateNormal];
        [button1 setFrame:CGRectMake(0, 0, 44, 44)];
        [button1 setTag:1];
        
#if 0
        UIButton *button2 =  [UIButton buttonWithType:UIButtonTypeCustom];
//        [button2 setTitle:@"Favorite" forState:UIControlStateNormal];
        [button2 setImage:[UIImage imageNamed:@"ic_favorite_border_white"] forState:UIControlStateNormal];
        [button2 setFrame:CGRectMake(0, 0, 44, 44)];
        [button2 setTag:2];
#endif
        
        btns = @[button, button1];
    } else {
        if(profile && !profile.groupid) {
            UIButton *button =  [UIButton buttonWithType:UIButtonTypeCustom];
//            [button setTitle:@"Call" forState:UIControlStateNormal];
            [button setImage:[UIImage imageNamed:@"ic_call_white"] forState:UIControlStateNormal];
            [button setFrame:CGRectMake(0, 0, 44, 44)];
            [button setTag:0];
            
            UIButton *vbutton =  [UIButton buttonWithType:UIButtonTypeCustom];
//            [vbutton setTitle:@"Video" forState:UIControlStateNormal];
            [vbutton setImage:[UIImage imageNamed:@"ic_videocam_white"] forState:UIControlStateNormal];
            [vbutton setFrame:CGRectMake(0, 0, 44, 44)];
            [vbutton setTag:1];
            
            btns = @[vbutton, button];
        }
        
    }
    
    return btns;
    
}


//-(BOOL) MesiboCall_onNotifyIncoming:(int)type profile:(MesiboUserProfile *)profile video:(BOOL)video {
//    return YES;
//}


//-(void) MesiboCall_onShowViewController:(id)parent vc:(id)vc {
////    [UiUtils launchVC:parent vc:vc];
//}

//-(void) MesiboCall_onDismissViewController:(id)vc {
//    
//}



// ~~~~~~~~~~~~~~~ file transfer

-(BOOL) Mesibo_onStartUpload:(MesiboFileInfo *)file {
  int type = [MesiboInstance getNetworkConnectivity];
  if(MESIBO_CONNECTIVITY_WIFI != type && !file.userInteraction)
      return NO;
  
  if(nil != file && NULL != file) { 
    @try {
      NSLog(@"Mesibo_onStartUpload called for %@", file.title);
      NSString *filePath = [file getPath];
      NSLog(@" File Path: %@", filePath);
      NSString *fileName = filePath.lastPathComponent;
      NSString *fileExtension = [filePath pathExtension];
      NSString *UTI = (__bridge_transfer NSString *)UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, (__bridge CFStringRef)fileExtension, NULL);
      NSString *contentType = (__bridge_transfer NSString *)UTTypeCopyPreferredTagWithClass((__bridge CFStringRef)UTI, kUTTagClassMIMEType);

      // Here set current message 32bit id as key to download
      [file setUrl:[NSString stringWithFormat: @"%@::%@", @(file.mid), fileName]];
      AWSS3TransferManagerUploadRequest *request = [[AWSS3TransferManagerUploadRequest alloc]init];
      [request setBody:[NSURL fileURLWithPath:[file getPath]]];
      [request setKey:[@(file.mid) stringValue]];
      [request setBucket:aws_bucketName];
      [request setContentType: contentType];
      [request setACL: AWSS3ObjectCannedACLPublicRead];
      request.uploadProgress = ^(int64_t bytesSent, int64_t totalBytesSent, int64_t totalBytesExpectedToSend) {
          NSLog(@"Sent: %lld", bytesSent);
          NSLog(@"totalBytesSent: %lld", totalBytesSent);
          NSLog(@"totalBytesExpectedToSend: %lld", totalBytesExpectedToSend);
      };
      
      AWSS3TransferManager *transferManger = AWSS3TransferManager.defaultS3TransferManager;

      AWSTask *task =  [[transferManger upload :request] continueWithBlock:^id _Nullable(AWSTask * _Nonnull task) {
              if (task.error != nil) {
                  if( task.error.code != AWSS3TransferManagerErrorCancelled
                     && task.error.code != AWSS3TransferManagerErrorPaused) {
                      NSLog(@"(%i) %@", (int)task.error.code, [task.error localizedDescription]);
                      NSLog(@"Message: %@", task.error.userInfo[@"Message"]);
                      NSLog(@"Key to Upload: %@", [@(file.mid) stringValue]);
                  }

                  [MesiboInstance updateFileTransferProgress:file progress:-1 status:1];

              } else {
                  NSLog(@"S3 Upload completed for %@", [file getPath]);
                  NSLog(@"Key to Upload: %@", [@(file.mid) stringValue]);
                  [MesiboInstance updateFileTransferProgress:file progress:100 status:1];

              }
          return task;
      }];
      if (task.error != nil) {
          NSLog(@"(%i) %@", (int)task.error.code, [task.error localizedDescription]);
          return NO;
      }
      else {
          return YES;
      }
    }
    @catch (NSException *exception) {
        NSLog(@"Error while uploading file: %@", exception.reason);
        UIAlertView *alert = [[UIAlertView alloc]
            initWithTitle:@"Can't upload file."
            message:nil
            delegate:self
            cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
    }     
  } else{
      NSLog(@"No file to upload");
      return NO;
  }
}

-(BOOL) Mesibo_onStartDownload:(MesiboFileInfo *)file {
  
  if(nil != file){
      NSLog(@"Mesibo_onStartDownload called for %@", file.title);
  } else{
      NSLog(@"Mesibo_onStartDownload called ");
  }
  
  int type = [MesiboInstance getNetworkConnectivity];
  
  if(MESIBO_CONNECTIVITY_WIFI != type && !file.userInteraction)
      return NO;
  
  
  if(nil != file && NULL != file){
    @try{
      NSLog(@"Mesibo_onStartDownload called for %@", file.title);
      NSString *filePath = [file getPath];
      NSArray *urlArr = [[file getUrl] componentsSeparatedByString:@"::"];
      NSString *key = [urlArr objectAtIndex:0];
      NSString *fileName = [urlArr objectAtIndex:1];
      NSString *newFilePath = [filePath stringByReplacingOccurrencesOfString:[file getUrl] withString:fileName];
      [file setPath:newFilePath];

      NSLog(@" New File Path: %@", newFilePath);


      AWSS3TransferManagerDownloadRequest *request = [[AWSS3TransferManagerDownloadRequest alloc]init];
      [request setKey:key];
      [request setBucket:aws_bucketName];
      [request setDownloadingFileURL:[NSURL fileURLWithPath:[file getPath]]];
      

      request.downloadProgress = ^(int64_t bytesSent, int64_t totalBytesSent, int64_t totalBytesExpectedToSend) {
          NSLog(@"Sent: %lld", bytesSent);
          NSLog(@"totalBytesSent: %lld", totalBytesSent);
          NSLog(@"totalBytesExpectedToSend: %lld", totalBytesExpectedToSend);
      };
     
    //TransferObserver downloadObserver = transferUtility.download("stonestocks",file.getUrl(), new File(file.getPath()));

      AWSS3TransferManager *transferManger = AWSS3TransferManager.defaultS3TransferManager;
      AWSTask *task =  [[transferManger download :request] continueWithBlock:^id _Nullable(AWSTask * _Nonnull task) {
          if (task.error != nil) {
              if( task.error.code != AWSS3TransferManagerErrorCancelled
                 && task.error.code != AWSS3TransferManagerErrorPaused) {
                  NSLog(@"Download Failed: (%i) %@", (int)task.error.code, [task.error localizedDescription]);
                  NSLog(@"Message: %@", task.error.userInfo[@"Message"]);
                  NSLog(@"Key to Download: %@", [@(file.mid) stringValue]);
              }
              [MesiboInstance updateFileTransferProgress:file progress:-1 status:1];
          } else {
              NSLog(@"S3 Download completed for %@", [file getPath]);
              [MesiboInstance updateFileTransferProgress:file progress:100 status:1];
          }
          return task;
      }];

      if (task.error != nil) {
          return NO;

      } else {
          return YES;
      }
    }
    @catch (NSException *exception) {
        NSLog(@"Error while downloading file: %@", exception.reason);
        UIAlertView *alert = [[UIAlertView alloc]
            initWithTitle:@"Can't download file."
            message:nil
            delegate:self
            cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
    }
  } else{
      NSLog(@"No file to download");
      return NO;
  }
}

-(BOOL) Mesibo_onStartFileTransfer:(MesiboFileInfo *)file {
    
    if(MESIBO_FILEMODE_DOWNLOAD == file.mode) {
        return [self Mesibo_onStartDownload:file];
    }
    
    return [self Mesibo_onStartUpload:file];
    
}

-(BOOL) Mesibo_onStopFileTransfer:(MesiboFileInfo *)file {
//    MesiboHttp *http = [file getFileTransferContext];
//    if(http) {
//        [http cancel];
//    }
    return YES;
}

- (BOOL)Mesibo_onFileTransferProgress:(MesiboFileInfo *)file{
    NSLog(@"File Transfer Progress");
    return YES;
}

@end


