//
//  ChatViewController.h
//  mstore
//
//  Created by admin on 7/16/20.
//  Copyright © 2020 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ChatViewController : UIViewController

@property (nonatomic, weak) IBOutlet UIView *containerView;

@end




