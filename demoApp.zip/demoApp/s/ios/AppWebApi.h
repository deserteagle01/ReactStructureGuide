
//  Copyright © 2018 Mesibo. All rights reserved.


#import <Foundation/Foundation.h>
#import "Mesibo/Mesibo.h"
//#import "MesiboCall/MesiboCall.h"


@interface SampleAppWebApiResponse : NSObject
@property (nonatomic) NSString *result;
@property (nonatomic) NSString *op;
@property (nonatomic) NSString *error;
@property (nonatomic) NSString *token;

@property (nonatomic) NSString *name;
@property (nonatomic) NSString *status;
@property (nonatomic) NSString *photo;
@property (nonatomic) NSString *invite;
@property (nonatomic) uint32_t gid;
@property (nonatomic) int type;
@end

#define SAMPLEAPP_RESULT_OK         0
#define SAMPLEAPP_RESULT_FAIL       1
#define SAMPLEAPP_RESULT_AUTHFAIL   2

#define VISIBILITY_HIDE         0
#define VISIBILITY_VISIBLE      1
#define VISIBILITY_UNCHANGED    2


typedef void (^SampleAPI_onResponse)(int result, NSDictionary *response);

#define SampleAPIInstance [AppWebApi getInstance]

@interface AppWebApi : NSObject

+(AppWebApi *) getInstance;
typedef void (^SampleAPI_LogoutBlock)(id parent);
-(void) initialize;


-(NSString *) getUploadUrl;
-(NSString *) getDownloadUrl;
-(BOOL) getMediaAutoDownload;
-(NSString *) getToken;
-(NSString *) getApiUrl;
-(BOOL) getGroup:(uint32_t) groupid handler:(SampleAPI_onResponse) handler ;
-(void) startMesibo:(BOOL) resetProfiles;
-(BOOL) setGroup:(MesiboUserProfile *)profile members:(NSArray *)members handler:(SampleAPI_onResponse) handler ;
-(void) resetDB;
-(void) logout;
-(void) login:(NSString *)name phone:(NSString *)phone handler:(SampleAPI_onResponse) handler;
//-(void) login:(NSString *)akAuthCode handler:(SampleAPI_onResponse) handler;

-(void) addContact:(NSString *)name phone:(NSString *)phone;
-(void) autoAddContact:(MesiboParams *)params;

+(BOOL) isEmpty:(NSString *)string; //utility
+(BOOL) equals:(NSString *)s old:(NSString *)old;
-(void) setPushToken:(NSString *)token;
+(void) setPushNotificationToken:(NSString *)token;

@end
