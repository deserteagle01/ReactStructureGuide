/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, { Component } from "react";
import { I18nManager } from "react-native";
import { Provider } from "react-redux";
import { persistStore } from "redux-persist";
import { PersistGate } from "redux-persist/es/integration/react";
import { Languages, Config } from "@common";
import { getNotification } from "@app/Omni";
import store from "@store/configureStore";
import Router from "./src/Router";
import {log} from "@app/Omni";
export default class ReduxWrapper extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
    
  }

  async componentDidMount() {
    const notification = await getNotification();
    
    console.disableYellowBox = true;
    // console.ignoredYellowBox = ['Warning: View.propTypes', 'Warning: BackAndroid'];

    const language = store.getState().language;
    // set default Language for App
    Languages.setLanguage(language.lang);
    I18nManager.forceRTL(language.lang === "ar");
  }

  async componentWillUnmount() {
    const notification = await getNotification();
  }

  render() {
    const persistor = persistStore(store);

    return (
      <Provider store={store}>
        <PersistGate persistor={persistor}>
          <Router />
        </PersistGate>
      </Provider>
    );
  }
}
