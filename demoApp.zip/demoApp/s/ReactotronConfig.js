/** @format */

import Reactotron from "reactotron-react-native";
import { reactotronRedux as reduxPlugin } from "reactotron-redux";

console.disableYellowBox = true;

Reactotron.configure({ name: "StoneStocks" });

Reactotron.useReactNative({
  asyncStorage: { ignore: ["secret"] },
});

Reactotron.use(reduxPlugin());

if (__DEV__) {
  Reactotron.connect({
    enabled: true,
    host: '192.168.0.107',  // server ip
    port: 9090
  });
  Reactotron.clear();
}

console.tron = Reactotron;
