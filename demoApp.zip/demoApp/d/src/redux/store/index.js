import { applyMiddleware, compose, createStore } from "redux";
import thunk from "redux-thunk";
import reducers from "../Reducer";
import { logger } from "redux-logger";
import { composeWithDevTools } from "redux-devtools-extension";

const middleware = __DEV__ ? [thunk] : [thunk];

const configureStore = () => {
	return createStore(reducers, undefined, composeWithDevTools(applyMiddleware(...middleware)));
};

export default configureStore();
