import { Alert , I18nManager} from 'react-native';
import { ACTION_TYPE_MASTERLIST } from '../Actions/ActionType.js';
import { translate, setI18nConfig } from "@languages";

const initialState = {
	areas: [],
	blocks: [],
	delivery_shifts: [],
	isLoading: false,
	error: null,
	phone: '',
	email: '',
	planStartDate: [],
	privacyPolicyData: {},
	android:{},
	ios:{},
	onesignal_app_id: "",
	help_ar:"",
	help_en:"",
	wallet_help_text:"",
	wallet_help_text_ar:"",
}

const language = [
	{ label: "English", value: 'en' },
	{ label: "عربى", value: 'ar' },
]

const gender = [
	{ label: I18nManager.isRTL ? "أنثى" : "Female", value: 'female' },
	{ label: I18nManager.isRTL ? "الذكر" : "Male", value: 'male' },
]

const daysList=[
	{key:1,value: 'Sunday',day:"SUN", isChecked: false, isDisable: false},
	{key:2,value: 'Monday',day:"MON", isChecked: false, isDisable: false},
	{key:3,value: 'Tuesday',day:"TUE", isChecked: false, isDisable: false},
	{key:4,value: 'Wednesday',day:"WED", isChecked: false, isDisable: false},
	{key:5,value: 'Thursday',day:"THU", isChecked: false, isDisable: false},
	{key:6,value: 'Friday',day:"FRI", isChecked: false, isDisable: false},
	{key:7,value: 'Saturday',day:"SAT", isChecked: false, isDisable: false},
]
const numberAddressesAdd=[
	'LetSecond',
	'LetThird',
	'LetFourth',
	'LetFifth',
	'LetSixth',
	'LetSeventh',
]
const numberAddressesEdit=[
	'LetEditSecond',
	'LetEditThird',
	'LetEditFour',
	'LetEditFifth',
	'LetEditSixth',
	'LetEditSeventh',
]

const fetchMasterListReducer = (state = initialState, action) => {
	const { type } = action;
	switch (type) {

		case ACTION_TYPE_MASTERLIST.MASTER_DATA_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_MASTERLIST.FETCH_MASTER_DATA:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data
			};

		case ACTION_TYPE_MASTERLIST.MASTER_DATA_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case ACTION_TYPE_MASTERLIST.COMPANY_DETAILS_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_MASTERLIST.FETCH_COMPANY_DETAILS:
			return {
				...state,
				...action.data,
				isLoading: false,
				error: null
			};

		case ACTION_TYPE_MASTERLIST.COMPANY_DETAILS_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

			case ACTION_TYPE_MASTERLIST.PLANSTART_DATE_DATA_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_MASTERLIST.FETCH_PLANSTART_DATE:
			return {
				...state,
				isLoading: false,
				error: null,
				planStartDate:action.data
			};

		case ACTION_TYPE_MASTERLIST.PLANSTART_DATE_DATA_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};
		
		case ACTION_TYPE_MASTERLIST.DISLIKE_DATA_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_MASTERLIST.FETCH_DISLIKE_DATA:
			return {
				...state,
				...action.data,
				isLoading: false,
				error: null
			};

		case ACTION_TYPE_MASTERLIST.DISLIKE_DATA_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};
			
		case ACTION_TYPE_MASTERLIST.PRIVACYPOLICY_DATA_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_MASTERLIST.FETCH_PRIVACYPOLICY_DATA:
			return {
				...state,
				privacyPolicyData: action.data,
				isLoading: false,
				error: null
			};

		case ACTION_TYPE_MASTERLIST.PRIVACYPOLICY_DATA_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};
		
		case ACTION_TYPE_MASTERLIST.LANGUAGE_LIST:
			return {
				...state,
				language,
				isLoading: false,
				error: null
		};

		case ACTION_TYPE_MASTERLIST.GENDER_LIST:
			return {
				...state,
				gender,
				isLoading: false,
				error: null
		};

		
		case ACTION_TYPE_MASTERLIST.DAY_LIST:
			return {
				...state,
				daysList,
				numberAddressesAdd,
				numberAddressesEdit,
				isLoading: false,
				error: null
		};


		default: {
			return state;
		}
	}
}

export default fetchMasterListReducer;
