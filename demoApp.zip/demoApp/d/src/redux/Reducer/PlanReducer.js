import { Alert } from 'react-native';
import { PLAN_TYPE } from '../Actions/ActionType.js';

const initialState = {

	isLoading: false,
	error: null,
	type: null,
	
	//For plan list
	plans: [],
	promo_codes: [],
	lastUpdatedPlanList: 0,

	//For plan details
	period_type: '',
	product_tmpl_id: null,
	plan_name: "",
	all_product_ids: [],
	product_id: null,
	all_periods: [],
	all_protein_carg: null,
	normal_configuration_lines: [],

	//For update Plans
	delivery_days: [],
	price_subtotal: 0,
	extra_amount: 0,
	unit_price: 0,
	plan_price: 0,
	amount_promotion: 0,
	amount_total: 0,
	warning_list: [],
	qty:0,
	promo_code: "",


	//for appointment which are not common
    name: "",
    dietitian_address: {},
    payment_method: "",
    dietitian_name_ar: "",
    dietitian_name: "",
    start_datetime: "",
    end_datetime: "",
    is_customize: false,
    all_periods_ar: [],
    promotion_id: false,
    id: null,
    subscription_qty: 0,
    appointment_id: null,
    is_book_appointment: false,
    already_confirmed_amount: 0,
    order_line_id: false,
    order_line_state: "",
    state: "",

	//for changePlan submit
	changePlanDataDic: {},
	savePlanDataDic: {}

}

const PlanReducer = (state = initialState, action) => {
	const { type } = action;

	switch (type) {

		case PLAN_TYPE.PLAN_LOADING:
			return {
				...initialState,
				isLoading: true,
				error: null,
				type: PLAN_TYPE.PLAN_LOADING
			};

		case PLAN_TYPE.PLAN_SUCCESS:
			return {
				...state,
				error: null,
				...action.data,
				isLoading: false,
				lastUpdatedPlanList: Date.parse(new Date()),
				type: PLAN_TYPE.PLAN_SUCCESS
			};

		case PLAN_TYPE.PLAN_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message,
				type: PLAN_TYPE.PLAN_ERROR
			};

		case PLAN_TYPE.PLAN_DETAIL_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case PLAN_TYPE.PLAN_DETAIL_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data
			};

		case PLAN_TYPE.PLAN_DETAIL_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};


		case PLAN_TYPE.EDIT_PLAN_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case PLAN_TYPE.EDIT_PLAN_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				savePlanDataDic: action.data
			};

		case PLAN_TYPE.EDIT_PLAN_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case PLAN_TYPE.BOOK_DIETITION_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};
	
		case PLAN_TYPE.BOOK_DIETITION_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data
			};
	
		case PLAN_TYPE.BOOK_DIETITITON_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case PLAN_TYPE.CLEAR_PLAN_DETAILS:
			return {
				...state,
				normal_configuration_lines: [],
			}

		case PLAN_TYPE.CANCEL_DIETITION_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case PLAN_TYPE.CANCEL_DIETITION_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data
			};

		case PLAN_TYPE.CANCEL_DIETITITON_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};


		case PLAN_TYPE.GET_CHANGE_PLAN_LOADING:
			return {
				...initialState,
				isLoading: true,
				error: null
			};

		case PLAN_TYPE.GET_CHANGE_PLAN_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data.data
			};

		case PLAN_TYPE.GET_CHANGE_PLAN_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};


		case PLAN_TYPE.GET_RENEW_PLAN_LOADING:
			return {
				...initialState,
				isLoading: true,
				error: null
			};

		case PLAN_TYPE.GET_RENEW_PLAN_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data.data
			};

		case PLAN_TYPE.GET_RENEW_PLAN_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};


		case PLAN_TYPE.SUBMIT_CHANGE_PLAN_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};
	
		case PLAN_TYPE.SUBMIT_CHANGE_PLAN_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				changePlanDataDic: action.data
			};
	
		case PLAN_TYPE.SUBMIT_CHANGE_PLAN_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		default: {
			return state;
		}
	}
}

export default PlanReducer;


