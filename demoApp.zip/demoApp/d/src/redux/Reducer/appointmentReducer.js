import { Alert } from 'react-native';
import { ACTION_TYPE_APPOINTMENT } from '../Actions/ActionType.js';
import Moment from 'moment';

const initialState = {
	isLoadingFor: false,
	isLoadingForAvailable: false,
	isLoadingForDietitionCalendar: false,

	error: null,
	errorDietitionCalendar: null,
	type: null,
	
    //For get appointment
    weight: 0.0,
    fat: 0.0,
    height: 0.0,
    last_appointment_date: false,
    height_difference: 0.0,
    fat_difference: 0.0,
    muscle_difference: 0.0,
    customer_body_details: [],
    weight_difference: 0.0,
    muscle: 0.0,
    gender: null,
	birth_date: null,
	isLoading_Appointment: false,
	lastUpdatedAppointment: 0,
	dataSets: [],
	xAxisDate: [],
	
	//For Dietition List
	lastUpdatedDietitionList: 0,
	lastUpdatedAvailableList: 0,
	lastUpdatedDietitionCalendar: 0,
	dietitionList: [],
	availableList: [],
	calendarList: {},
	selectedDate: null,
	slotList: [],
	selectedTimeSlot: null

	//Booking dietition
}

function sortAppointmentData(json) {
	var allData = json;
	
	var dictNew = {};
	var arrayWrongDateData = [];
	for (var key in allData) {
		var tempDayDict = {};
		let slots = allData[key].slots;
		tempDayDict.status = allData[key].status

		var arrayTemp = [];
		slots.forEach(function(item) {
			var stillUtc = Moment.utc(item.start_datetime).toDate();
			var local = Moment(stillUtc).local().format('YYYY-MM-DD');

			if(key == local) {
				arrayTemp.push(item);
			}else{
				arrayWrongDateData.push(item);
			}
        });
        if(arrayTemp.length == 0 && allData[key].status == "available"){
			tempDayDict.status = "not_available";
		}
        tempDayDict.slots = arrayTemp;
		dictNew[key] = tempDayDict;
	}
    arrayWrongDateData.forEach(function(item) {
		var stillUtc = Moment.utc(item.start_datetime).toDate();
		var local = Moment(stillUtc).local().format('YYYY-MM-DD');
		var remaining_Dict = {};
		var tempDict = {};
		if(dictNew.hasOwnProperty(local)){
			tempDict = dictNew[local];
		}else{
			tempDict = {
				status: "not_available",
				slots: []
			}
		}
        let tempSlot = tempDict.slots;
		var newSlot = [item, ...tempSlot];
        remaining_Dict.status = tempDict.status;
		if(tempDict.status == "not_available"){
			remaining_Dict.status = "available"
		}
        remaining_Dict.slots = newSlot;
		dictNew[local] = remaining_Dict;
	});
    return dictNew
}

function configureGraphData(customer_body_details) {
	  let tempArray = customer_body_details
	  var weightArr = [];
	  var muscleMassArr = [];
	  var fatArr = [];
	  var tempDateArr = [];
	  tempArray.forEach(element => {
	    var dates = Moment(element.start_date).format('MMM'); 
	    var year = Moment(element.start_date).format('YY'); 
	    var xLabel = dates+'\n'+year;
	    
	    weightArr.push(element.weight);
	    muscleMassArr.push(element.muscle);
	    fatArr.push(element.fat);
	    tempDateArr.push(xLabel);
	  });
	  var tempDataset = [{
	      data: weightArr,
	      color: (opacity = 1) => `rgb(130, 111, 245)`,
	    },{
	      data: muscleMassArr,
	      color: (opacity = 1) => `rgb(254, 206, 48)`,
	    },{
	      data: fatArr,
	      color: (opacity = 1) => `rgb(254, 109, 72)`,
	    }]
	
		return {dataSets: tempDataset,  xAxisDate:  tempDateArr }
	}
const appointmentReducer = (state = initialState, action) => {
	const { type } = action;

	switch (type) {

		case ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_LOADING:
			return {
				...state,
				error: null,
				isLoading_Appointment: true,
				type: ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_LOADING
			};
			
		case ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_SUCCESS:
			let getdata = configureGraphData(action.data.data.customer_body_details);
			return {
				...state,
				error: null,
				...action.data.data,
				lastUpdatedAppointment: Date.parse(new Date()),
				dataSets: getdata.dataSets,
				xAxisDate: getdata.xAxisDate,
				isLoading_Appointment: false,
				type: ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_SUCCESS
			};

		case ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_ERROR:
			return {
				...state,
				error: action.message,
				isLoading_Appointment: false,
				type: ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_ERROR
			};

		case ACTION_TYPE_APPOINTMENT.GET_DIETITION_LOADING:
			return {
				...state,
				isLoadingFor: true,
				error: null,
				type: ACTION_TYPE_APPOINTMENT.GET_DIETITION_LOADING,
			};

		case ACTION_TYPE_APPOINTMENT.GET_DIETITION_SUCCESS:
			return {
				...state,
				isLoadingFor: false,
				error: null,
				lastUpdatedDietitionList: Date.parse(new Date()),
				type: ACTION_TYPE_APPOINTMENT.GET_DIETITION_SUCCESS,
				dietitionList: action.data.data
			};

		case ACTION_TYPE_APPOINTMENT.GET_DIETITION_ERROR:
			return {
				...state,
				isLoadingFor: false,
				error: action.message,
				type: ACTION_TYPE_APPOINTMENT.GET_DIETITION_ERROR,
			};

			
		case ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_LOADING:
			return {
				...state,
				isLoadingForAvailable: true,
				error: null,
				type: ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_LOADING
			};

		case ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_SUCCESS:
			return {
				...state,
				isLoadingForAvailable: false,
				error: null,
				lastUpdatedAvailableList: Date.parse(new Date()),
				type: ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_SUCCESS,
				availableList: action.data.data
			};

		case ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_ERROR:
			return {
				...state,
				isLoadingForAvailable: false,
				type: ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_ERROR,
				error: action.message
			};

			
		case ACTION_TYPE_APPOINTMENT.CALENDAR_SELECTED_CLEAR:
			return {
				...state,
				selectedDate: null,
				slotList: [],
			}

		case ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_LOADING:
			return {
				...state,
				errorDietitionCalendar: null,
				selectedDate: null,
				slotList: [],
				isLoadingForDietitionCalendar: true,
				type: ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_LOADING
			};

		case ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_SUCCESS:
				let data = action.data.data;
				let newDataDic = {};
				for (var key in data) {
					let dictNew = {};
					let dietitonData = data[key];
					let tempSortedData = sortAppointmentData(dietitonData);
					if(action.forceFetch){
						dictNew[key] = tempSortedData;
						tempSortedData["lastUpdated"] = Date.parse(new Date());
						newDataDic = Object.assign({}, newDataDic, dictNew);
					}else{
						tempSortedData["lastUpdated"] = Date.parse(new Date());
						let tempDic = {...state.calendarList[key], ...tempSortedData};
						newDataDic[key] = tempDic;
					}
				}
				let mergeDataDict = {...state.calendarList, ...newDataDic};
				
			return {
				...state,
				errorDietitionCalendar: null,
				calendarList: mergeDataDict,
				isLoadingForDietitionCalendar: false,
				lastUpdatedDietitionCalendar: Date.parse(new Date()),
				type: ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_SUCCESS
			};

		case ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_ERROR:
			return {
				...state,
				isLoadingForDietitionCalendar: false,
				errorDietitionCalendar: action.message,
				type: ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_ERROR
			};

		case ACTION_TYPE_APPOINTMENT.UPDATE_SELECTED_DATE:
			return {
				...state,
				...action.data
			}

		default: {
			return state;
		}
	}
}

export default appointmentReducer;