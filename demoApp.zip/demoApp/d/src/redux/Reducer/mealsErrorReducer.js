import { Alert } from 'react-native';
import { ACTION_TYPE_MEALS, ACTION_TYPE_MEALS_ERROR } from '../Actions/ActionType.js';

const initialState = {
    error: null,
    action_type: null
}

const mealsErrorReducer = (state = initialState, action) => {
	switch (action.type) {
		case ACTION_TYPE_MEALS_ERROR.UPDATE_USER_MEAL_PLAN_ERROR_NEW:
			return {
				...state,
                error: action.message,
                action_type: action.type,
            };
            
            case ACTION_TYPE_MEALS_ERROR.CLEAR_EROR: 
			return {
				...state,
                error: null,
                action_type: action.type,
			}
            
        default:
			return state;
	}
}

export default mealsErrorReducer;
