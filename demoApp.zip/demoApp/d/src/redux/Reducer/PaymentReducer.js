import { Alert } from 'react-native';
import { ACTION_TYPE_PAYMENT } from '../Actions/ActionType.js';

const initialState = {
	isLoading: false,
	error: null,
	//For intiate payment
	payment_url: "",
	isPayment: null
}

const PaymentReducer = (state = initialState, action) => {
	const { type } = action;

	switch (type) {

		case ACTION_TYPE_PAYMENT.PAYMENT_INITIATE_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_PAYMENT.PAYMENT_INITIATE_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data
			};

		case ACTION_TYPE_PAYMENT.PAYMENT_INITIATE_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case ACTION_TYPE_PAYMENT.PAYMENT_STATUS_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_PAYMENT.PAYMENT_STATUS_SUCCESS:
			return {
				...state,
				isPayment: true,
				isLoading: false,
				error: null
			};

		case ACTION_TYPE_PAYMENT.PAYMENT_STATUS_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case ACTION_TYPE_PAYMENT.CLEAR_PAYMENT_DETAILS:
			return {
				...initialState,
				...action.data
			}

		case ACTION_TYPE_PAYMENT.UPDATE_PAYMENT_STATUS:
			return {
				...state,
				...action.params
			}

		default: {
			return state;
		}
	}
}

export default PaymentReducer;


