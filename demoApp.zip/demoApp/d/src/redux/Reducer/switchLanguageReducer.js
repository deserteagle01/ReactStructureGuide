import { Alert } from 'react-native';
import { ACTION_TYPE_SWITCH } from '../Actions/ActionType.js';
import { Constants } from "@common";

const initialState = {
  lang: Constants.Language,
  rtl: Constants.isRTL,
}

const switchLanguageReducer = (state = initialState, action) => {
  
  switch (action.type) {
    case ACTION_TYPE_SWITCH.SWITCH_LANGUAGE:
      return {
        ...state,
        ...action.params
      };

    default:
      return state;
  }
};

export default switchLanguageReducer;
