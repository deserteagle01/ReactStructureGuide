import { Alert } from 'react-native';
import { ACTION_TYPE_MEALS } from '../Actions/ActionType.js';

const initialState = {
	userProduct: {},
	isLoading: false,
	isMenuLoading: false,
	error: null,
	filter_list: [],
	all_tags: [],
	userSelectedMeals: {},
	action_type: null,
	nextMealDate: null,
	lastUpdatedMenuList: 0,
	isLoadingForUserProduct: false,
	lastUpdatedUserProduct: 0,
	monthUpdated: {}
}

const mealsReducer = (state = initialState, action) => {
	switch (action.type) {
		case ACTION_TYPE_MEALS.FETCH_USER_PRODUCT_PLAN_LOADING:
			return {
				...state,
				isLoadingForUserProduct: true,
				error: null,
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.FETCH_USER_PRODUCT_PLAN_SUCCESS:
				let currentTimeStamp = Date.parse(new Date());
				let monthUpdates = {};
				for(let i = 0; i < action.dateArray.length; i++){
					monthUpdates[action.dateArray[i]] = currentTimeStamp;
				}
			return {
				...state,
				isLoadingForUserProduct: false,
				error: null,
				userProduct: {...state.userProduct, ...action.data.data },
				calendarStartDate: Object.keys(action.data.data).length > 0 ? action.currentDate : null,
				action_type: action.type,
				nextMealDate: null,
				lastUpdatedUserProduct: currentTimeStamp,
				monthUpdated: {...state.monthUpdated, ...monthUpdates}
			};

		case ACTION_TYPE_MEALS.FETCH_USER_PRODUCT_PLAN_ERROR:
			return {
				...state,
				isLoadingForUserProduct: false,
				error: action.message,
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.FETCH_MENU_LOADING:
			return {
				...state,
				isMenuLoading: true,
				error: null,
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.FETCH_MENU_SUCCESS:
			return {
				...state,
				isMenuLoading: false,
				error: null,
				filter_list: action.data.filter_list || [],
				all_tags: action.data.all_tags || [],
				lastUpdatedMenuList: Date.parse(new Date()),
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.FETCH_MENU_ERROR:
			return {
				...state,
				isMenuLoading: false,
				error: action.message,
				action_type: action.type,
				nextMealDate: null
		};

		case ACTION_TYPE_MEALS.UPDATE_USER_MEAL_PLAN_LOADING:
			return {
				...state,
				isLoading: true,
				error: null,
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.UPDATE_USER_MEAL_PLAN_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				userProduct: {...state.userProduct, ...action.data },
				action_type: action.type,
				nextMealDate: action.nextSelectedDate || null
			};

		case ACTION_TYPE_MEALS.UPDATE_USER_MEAL_PLAN_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message,
				action_type: action.type,
				nextMealDate: null
		};

		case ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_LOADING:
			return {
				...state,
				isLoading: true,
				error: null,
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				userProduct: {...state.userProduct, ...action.data },
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message,
				action_type: action.type,
				nextMealDate: null
		};

		case ACTION_TYPE_MEALS.SUBMIT_PRODUCT_RATING_LOADING:
			return {
				...state,
				isLoading: true,
				error: null,
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.SUBMIT_PRODUCT_RATING_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				userProduct: {...state.userProduct, ...action.data },
				action_type: action.type,
				nextMealDate: null
			};

		case ACTION_TYPE_MEALS.SUBMIT_PRODUCT_RATING_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message,
				action_type: action.type,
				nextMealDate: null
		};


		case ACTION_TYPE_MEALS.CLEAR_MEAL_DETAILS:
			return {
				...initialState,
				...action.data
			}

		
		
		default:
			return state;
	}
}

export default mealsReducer;
