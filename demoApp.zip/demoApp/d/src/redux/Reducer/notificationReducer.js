import { NOTIFICATION_TYPE } from '../Actions/ActionType.js';

const initialState = {
	isLoading: false,
	isMenuLoading: false,
	error: null,
	notifications: []
}

const notificationReducer = (state = initialState, action) => {
	switch (action.type) {
		case NOTIFICATION_TYPE.NOTIFICATION_GET_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case NOTIFICATION_TYPE.NOTIFICATION_GET_SUCCESS:
			return {
                ...state,
                ...action.data,
                isLoading: false,
                error: null,
			};

		case NOTIFICATION_TYPE.NOTIFICATION_GET_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case NOTIFICATION_TYPE.NOTIFICATION_READ_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case NOTIFICATION_TYPE.NOTIFICATION_READ_SUCCESS:
			return {
                ...state,
                ...action.data,
				isLoading: false,
				error: null,
			};

		case NOTIFICATION_TYPE.NOTIFICATION_READ_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
		};

		case NOTIFICATION_TYPE.NOTIFICATION_CLEAR_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case NOTIFICATION_TYPE.NOTIFICATION_CLEAR_SUCCESS:
			return {
                ...state,
                ...action.data,
				isLoading: false,
				error: null,
			};

		case NOTIFICATION_TYPE.NOTIFICATION_CLEAR_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
		};

		default:
			return state;
	}
}

export default notificationReducer;

