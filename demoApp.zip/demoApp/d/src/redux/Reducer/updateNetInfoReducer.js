import { Alert } from 'react-native';
import { ACTION_TYPE_CONNECTION } from '../Actions/ActionType.js';

const initialState = {
  isConnected: true
}

const updateNetInfoReducer = (state = initialState, action) => {
  switch (action.type) {
    case ACTION_TYPE_CONNECTION.UPDATE_CONNECTION_STATUS:
      return Object.assign({}, state, {
        isConnected: action.isConnected
      });
    default:
      return state;
  }
}

export default updateNetInfoReducer;



