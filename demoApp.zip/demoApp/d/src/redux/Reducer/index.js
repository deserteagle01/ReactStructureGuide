// Wherever you build your reducers
import { combineReducers, createStore, applyMiddleware, compose } from 'redux';
import AsyncStorage from "@react-native-community/async-storage";
import { persistReducer } from "redux-persist";
import updateNetInfoReducer from './updateNetInfoReducer.js';
import updateUserReducer from './updateUserReducer.js';
import switchLanguageReducer from './switchLanguageReducer.js';
import fetchMasterListReducer from './fetchMasterListReducer';
import PlanReducer from './PlanReducer';
import mealsReducer from './mealsReducer';
import PaymentReducer from './PaymentReducer';
import notificationReducer from './notificationReducer';
import appointmentReducer from './appointmentReducer';
import walletListReducer from './walletListReducer';
import mealsErrorReducer from './mealsErrorReducer';


const config = {
	key: "root",
	debug: true,
	storage: AsyncStorage,
};

const AppReducers = combineReducers({
	updateNetInfoReducer,
	updateUserReducer,
	switchLanguageReducer,
	fetchMasterListReducer,
	PlanReducer,
	mealsReducer,
	PaymentReducer,
	notificationReducer,
	appointmentReducer,
	walletListReducer,
	mealsErrorReducer
});

const rootReducer = (state, action) => {
	return AppReducers(state, action);
}

const pReducer = persistReducer(config, rootReducer);

export default pReducer;