import { Alert , I18nManager} from 'react-native';
import { ACTION_TYPE_WALLET } from '../Actions/ActionType.js';
import { translate, setI18nConfig } from "@languages";

const initialState = {
	isLoading: false,
	error: null,
	walletList: [],
	totalAmount:0,
}

const walletListReducer = (state = initialState, action) => {
	const { type } = action;
	switch (type) {

		case ACTION_TYPE_WALLET.WALLETLIST_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_WALLET.WALLETLIST_SUCCESS:
			return {
				isLoading: false,
				error: null,
				walletList:action.data.data,
				totalAmount:action.data.total_amount
			};

		case ACTION_TYPE_WALLET.WALLETLIST_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		default: {
			return state;
		}
	}
}

export default walletListReducer;
