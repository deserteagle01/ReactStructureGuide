import { Alert } from 'react-native';
import { ACTION_TYPE_USER, ACTION_TYPE_EDITPROFILE, ACTION_HOME } from '../Actions/ActionType.js';

const initialState = {
	user_id: "",
	session_user_id: "",
	partner_id: "",
	comment: "",
	first_name: "",
	last_name: "",
	name:"",
	mobile: "",
	gender: "",
	area_id: "",
	area_name: "",
	block_id: "",
	block_name: "",
	street: "",
	street2: "",
	avenue: "",
	shift_id: "",
	email: "",
	birth_date: "",
	expected_plan_start_date: "",
	dislike_category_ids: [],
	opt_out_notifications: false,
	lang: "",
	area: [],
	blocks: [],
	active_package: {},
	ref: "",
	introComplete: false,
	isLogin: false,
	isLoading: false,
	error: null,
	successRegister: false,
	sucessProfile: false,
	sucessChangePwd: false,
	is_exist: false,
	password: '',
	auto_password: '',
	changeAddress: {},
	weight: 0,
	height: 0,
	secondary_firstname: "",
	secondary_lastname: "",
	// homeScreen
	notification_count:0,
	plan_end_date:"",
	total_days_plan:"",
	allow_change_plan:"",
	allow_renew:"",
	current_planid:"",
	days_remaining:"",
	image_url:"",
	isLoadingUploadImage:false,
	addresses:[],
	secondaryAddress:false,
	isFromHome: false,
	currentDate: "",
	com_lang: "ar",
	plan_name:"",
	plan_name_ar:"",
	// wallet
	yourWalletAmount:"12.00",
	first_appointment_date: "",
	referral_code: "",
	share_message: "",
	lastUpdatedHomeData: 0
}

const updateUserReducer = (state = initialState, action) => {
	switch (action.type) {
		case ACTION_TYPE_USER.UPDATE_USER_DETAILS:
			return {
				...state,
				...action.params
			};

		case ACTION_TYPE_USER.USER_EXIST_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_USER.USER_EXIST_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data
			};

		case ACTION_TYPE_USER.USER_EXIST_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case ACTION_TYPE_USER.USER_LOGIN_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_USER.USER_LOGIN_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data.user,
				isLogin: true
			};

		case ACTION_TYPE_USER.USER_LOGIN_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case ACTION_TYPE_USER.USER_REGISTER_LOADING:
			return {
				...state,
				isLoading: true,
				error: null,
				successRegister: false
			};

		case ACTION_TYPE_USER.USER_REGISTER_ERROR:
			return {
				...state,
				isLoading:false,
				error:action.message,
				successRegister: false
			};

		case ACTION_TYPE_USER.USER_REGISTER_SUCCESS:
			return {
				...state,
				...action.data,
				isLoading:false,
				successRegister: true,
				isLogin: true
			};

		case ACTION_TYPE_USER.USER_UPDATE_LOADING:
			return {
				...state,
				isLoadingEditProfile: true,
				sucessProfile: false,
				error: null
			};

		case ACTION_TYPE_USER.USER_UPDATE_SUCCESS:
			return {
				...state,
				isLoadingEditProfile: false,
				sucessProfile: true,
				error: null,
				...action.data,
			};

		case ACTION_TYPE_USER.USER_UPDATE_ERROR:
			return {
				...state,
				isLoadingEditProfile: false,
				sucessProfile: false,
				error: action.message
			};

		case ACTION_TYPE_EDITPROFILE.USER_CHANGEPWD_LOADING:
			return {
				...state,
				isLoadingChangePwd: true,
				sucessChangePwd: false,
				errorChangePwd: null
			};

		case ACTION_TYPE_EDITPROFILE.USER_CHANGEPWD_SUCCESS:
			return {
				...state,
				isLoadingChangePwd: false,
				sucessChangePwd: true,
				errorChangePwd: false,
			};

		case ACTION_TYPE_EDITPROFILE.USER_CHANGEPWD_ERROR:
			return {
				...state,
				isLoadingChangePwd: false,
				sucessChangePwd: false,
				errorChangePwd: action.message
			};

		case ACTION_TYPE_EDITPROFILE.USER_DISLIKE_CATEGORY_LOADING:
			return {
				...state,
				isLoadingDislikeCategory: true,
				sucessDislikeCategory: false,
				errorDislikeCategory: null
			};

		case ACTION_TYPE_EDITPROFILE.USER_DISLIKE_CATEGORY_SUCCESS:
			return {
				...state,
				isLoadingDislikeCategory: false,
				sucessDislikeCategory: true,
				errorDislikeCategory: false,
				...action.data.user
			};

		case ACTION_TYPE_EDITPROFILE.USER_DISLIKE_CATEGORY_ERROR:
			return {
				...state,
				isLoadingDislikeCategory: false,
				sucessDislikeCategory: false,
				errorDislikeCategory: action.message
			};

		case ACTION_TYPE_EDITPROFILE.UPDATE_USER_ADDRESS:
			let fullObject = Object.assign({}, state.changeAddress, action.data);
			return {
				...state,
				changeAddress: {...fullObject},
				isLoading: false,
				error: null
			};
		case ACTION_TYPE_EDITPROFILE.UPDATE_ADDRESS_ONBACKPRESSED:
				return {
					...state,
					changeAddress:action.data,
					error: null
				};
		case ACTION_TYPE_EDITPROFILE.USER_UPDATE_ADDRESS_LOADING:
			return {
				...state,
				isLoading:true,
				error:null,
				successAddress: false
			};
		case ACTION_TYPE_USER.USER_SEND_OTP_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_USER.USER_SEND_OTP_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null
			};

		case ACTION_TYPE_USER.USER_SEND_OTP_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};


		case ACTION_TYPE_USER.SEND_OTP_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_USER.SEND_OTP_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null
			};

		case ACTION_TYPE_USER.SEND_OTP_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		case ACTION_TYPE_EDITPROFILE.USER_UPDATE_ADDRESS_ERROR:
			return {
				...state,
				isLoading:false,
				error: action.message,
				successAddress: false
			};

		case ACTION_TYPE_EDITPROFILE.USER_UPDATE_ADDRESS_SUCCESS:
			return {
				...state,
				isLoading:false,
				successAddress: true,
				addresses: action.data.addresses,
			};
			// delete/disable address
			case ACTION_TYPE_EDITPROFILE.USER_DELETE_ADDRESS_SUCCESS:
				return {
					...state,
					isLoading:false,
					addresses: action.data.addresses,
				}
			case ACTION_TYPE_EDITPROFILE.USER_DELETE_ADDRESS_ERROR:
				return {
					...state,
					isLoading:false,
					error: action.message,
					};

		case ACTION_TYPE_USER.USER_VERIFY_OTP_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_USER.USER_VERIFY_OTP_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data.user
			};

		case ACTION_TYPE_USER.USER_VERIFY_OTP_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

			
		case ACTION_TYPE_USER.VERIFY_OTP_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_USER.VERIFY_OTP_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				...action.data.user
			};

		case ACTION_TYPE_USER.VERIFY_OTP_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		// homescreen
		case ACTION_HOME.HOME_DATA_LOADING:
			return {
				...state,
				isLoading: true,
			}
		case ACTION_HOME.HOME_DATA_SUCCESS:
			return {
				...state,
				isLoading: false,
				error: null,
				lastUpdatedHomeData: Date.parse(new Date()),
				...action.data,
				
			};

		case ACTION_HOME.HOME_DATA_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};
		// profile pic upload
		case ACTION_HOME.UPLOADIMAGE_LOADING:
			return {
				...state,
				isLoadingUploadImage: true,
				error: null
			};

		case ACTION_HOME.UPLOADIMAGE_SUCCESS:
			return {
				...state,
				isLoadingUploadImage: false,
				error: null,
				...action.data,
			};

		case ACTION_HOME.UPLOADIMAGE_ERROR:
			return {
				...state,
				isLoadingUploadImage: false,
				error: action.message
			};

		case ACTION_TYPE_USER.CLEAR_USER_REDUCER:
			return {
				...initialState,
				...action.data,
			};

		case ACTION_TYPE_USER.USER_LOGOUT_LOADING:
			return {
				...state,
				isLoading: true,
				error: null
			};

		case ACTION_TYPE_USER.USER_LOGOUT_ERROR:
			return {
				...state,
				isLoading: false,
				error: action.message
			};

		default:
			return state;
	}
}

export default updateUserReducer;
