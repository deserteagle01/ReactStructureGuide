import { ACTION_TYPE_MASTERLIST } from './ActionType';
import { connect } from 'react-redux';
import DietStationAPI from "../../webservice/DietStationApi";

export function PreloadedDataAction() {
	return (dispatch, state) => {
		//dispatch({ type: ACTION_TYPE_MASTERLIST.MASTER_DATA_LOADING });
		return DietStationAPI.preLoadedMasterData().then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_MASTERLIST.MASTER_DATA_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_MASTERLIST.FETCH_MASTER_DATA, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_MASTERLIST.MASTER_DATA_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_MASTERLIST.MASTER_DATA_ERROR, message: error.error });
		});
	}
}

export function getCompanyDetails() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MASTERLIST.COMPANY_DETAILS_LOADING });
		return DietStationAPI.getCompanyDetails().then(json => {
			// console.log("AuthLoading==>",json);
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_MASTERLIST.COMPANY_DETAILS_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_MASTERLIST.FETCH_COMPANY_DETAILS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_MASTERLIST.COMPANY_DETAILS_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_MASTERLIST.COMPANY_DETAILS_ERROR, message: error.error });
		});
	}
}

export function getPlanStartDate() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MASTERLIST.PLANSTART_DATE_DATA_LOADING });
		return DietStationAPI.getPlanStartDate().then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_MASTERLIST.PLANSTART_DATE_DATA_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_MASTERLIST.FETCH_PLANSTART_DATE, data: json.dates });
			} else {
				dispatch({ type: ACTION_TYPE_MASTERLIST.PLANSTART_DATE_DATA_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_MASTERLIST.PLANSTART_DATE_DATA_ERROR, message: error.error });
		});
	}
}

export function fetchDislikeDataList() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MASTERLIST.DISLIKE_DATA_LOADING });
		return DietStationAPI.dislikeMasterData().then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_MASTERLIST.DISLIKE_DATA_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_MASTERLIST.FETCH_DISLIKE_DATA, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_MASTERLIST.DISLIKE_DATA_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_MASTERLIST.DISLIKE_DATA_ERROR, message: error.error });
		});
	}
}


export function fetchLanguageList() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MASTERLIST.LANGUAGE_LIST});
	}
}

export function fetchPrivacyPolicy() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MASTERLIST.PRIVACYPOLICY_DATA_LOADING });
		return DietStationAPI.getPrivacyPolicyData().then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_MASTERLIST.PRIVACYPOLICY_DATA_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_MASTERLIST.FETCH_PRIVACYPOLICY_DATA, data: json });//json.privacy_policy				
			} else {
				dispatch({ type: ACTION_TYPE_MASTERLIST.PRIVACYPOLICY_DATA_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_MASTERLIST.PRIVACYPOLICY_DATA_ERROR, message: error.error });
		});
	}
}

export function fetchGenderList() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MASTERLIST.GENDER_LIST});
	}
}
export function fetchDayList() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MASTERLIST.DAY_LIST});
	}
}
