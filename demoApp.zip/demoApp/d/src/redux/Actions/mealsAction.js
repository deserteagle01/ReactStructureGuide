import { ACTION_TYPE_MEALS, ACTION_TYPE_MEALS_ERROR } from './ActionType';
import { connect } from 'react-redux';
import DietStationAPI from "../../webservice/DietStationApi";
import { Constants } from "@common";
import moment from 'moment';
import { expiry, callAPI, callCalendarAPI } from "../../common/Utility";

export function bindActionCreators(dispatch, state) {
	return {
		fetchMenuList : (forcefetch) => {
			return fetchMenuList(forcefetch)(dispatch, state)       
		},
		fetchUserProductList : (forcefetch, param, strCurrentMonth) => {
			return fetchUserProductList(forcefetch, param, strCurrentMonth)(dispatch, state)
		},
	}
}

function getShortDate(strDate){
	var dateObj = new Date(strDate);
	var momentObj = moment(dateObj);
	return momentObj.format('MM-YYYY'); 
}

export function fetchUserProductList(forceFetch, param, strCurrentMonth) {
	return (dispatch, state) => {
		let currentTimeStamp = Date.parse(new Date());
		let startDate = param.start_date;
		let endDate = param.end_date;

		let short_start = getShortDate(startDate);
		let short_end = getShortDate(endDate);
		let short_current = getShortDate(strCurrentMonth);
		let dateArr = [short_start, short_current, short_end];

		let startTime = state.mealsDetail.monthUpdated.hasOwnProperty(short_start) ? state.mealsDetail.monthUpdated.short_start : 0;
		let currentTime = state.mealsDetail.monthUpdated.hasOwnProperty(short_current) ? state.mealsDetail.monthUpdated.short_current : 0;
		let endTime = state.mealsDetail.monthUpdated.hasOwnProperty(short_end) ? state.mealsDetail.monthUpdated.short_end : 0;
		
		callAPI(state, dispatch, DietStationAPI.fetchProductData, (state) =>  {
			if(state) {
				return {
					isLoading: state.mealsDetail.isLoadingForUserProduct,
					expiry: expiry.Meal.fetchUserProductList,
					lastUpdated: [startTime, currentTime, endTime],
					needDataCheck: true,
					error: state.mealsDetail.error,
					data: state.mealsDetail.userProduct,
					keys: [startDate, strCurrentMonth, endDate]
					
				};
			}
		}
		,ACTION_TYPE_MEALS.FETCH_USER_PRODUCT_PLAN_LOADING, ACTION_TYPE_MEALS.FETCH_USER_PRODUCT_PLAN_SUCCESS, ACTION_TYPE_MEALS.FETCH_USER_PRODUCT_PLAN_ERROR, forceFetch, param, {currentDate: strCurrentMonth, dateArray: dateArr });
	}
}

export function fetchMenuList(forceFetch) {
		let params = { 'last_update_timestamp': moment(new Date()).lang("en-gb").format(Constants.dateFormate) };
		return (dispatch, state) => {
		callAPI(state, dispatch, DietStationAPI.fetchMenuData, (state) =>  {
			if(state) {
				return {
					isLoading: state.mealsDetail.isMenuLoading,
					expiry: expiry.Meal.fetchMenuList,
					lastUpdated: [state.mealsDetail.lastUpdatedMenuList],
					error: state.mealsDetail.error
				};
			}
		}
		,ACTION_TYPE_MEALS.FETCH_MENU_LOADING, ACTION_TYPE_MEALS.FETCH_MENU_SUCCESS, ACTION_TYPE_MEALS.FETCH_MENU_ERROR, forceFetch, params, {});
	}
}

export function updateUserMealPlan(params,nextSelectedDate = null){
	return (dispatch, state) => {
		return DietStationAPI.updateUserMealPlan(params).then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_MEALS.UPDATE_USER_MEAL_PLAN_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_MEALS.UPDATE_USER_MEAL_PLAN_SUCCESS, data: json.data, nextSelectedDate: nextSelectedDate });
			} else {
				//dispatch({ type: ACTION_TYPE_MEALS.UPDATE_USER_MEAL_PLAN_ERROR, message: json.error });
				dispatch({ type: ACTION_TYPE_MEALS_ERROR.UPDATE_USER_MEAL_PLAN_ERROR_NEW, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_MEALS.UPDATE_USER_MEAL_PLAN_ERROR, message: error.error });
		});
	}
}

export function userMealPauseUnpause(params){
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_LOADING });
		return DietStationAPI.userMealPauseUnpause(params).then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_SUCCESS, data: json.data });
			} else {
				dispatch({ type: ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_ERROR, message: error.error });
		});
	}
}

export function submitRating(params){
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_MEALS.SUBMIT_PRODUCT_RATING_LOADING });
		return DietStationAPI.submitRating(params).then(json => {
			console.log("SUBMIT RATING ==", json);
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_MEALS.SUBMIT_PRODUCT_RATING_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_MEALS.SUBMIT_PRODUCT_RATING_SUCCESS, data: json.data });
			} else {
				dispatch({ type: ACTION_TYPE_MEALS.SUBMIT_PRODUCT_RATING_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_MEALS.SUBMIT_PRODUCT_RATING_ERROR, message: error.error });
		});
	}
}


