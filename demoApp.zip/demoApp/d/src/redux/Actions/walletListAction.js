import { ACTION_TYPE_WALLET } from './ActionType';
import { connect } from 'react-redux';
import DietStationAPI from "../../webservice/DietStationApi";

export function fetchWalletList() {
	return async (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_WALLET.WALLETLIST_LOADING });
		return await DietStationAPI.walletList().then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_WALLET.WALLETLIST_ERROR, message: "Can't get data from server" });
			}
			else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_WALLET.WALLETLIST_SUCCESS, data: json});
			}
			else {
				dispatch({ type: ACTION_TYPE_WALLET.WALLETLIST_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_WALLET.WALLETLIST_ERROR, message: error.error });
		  });
	}
}
