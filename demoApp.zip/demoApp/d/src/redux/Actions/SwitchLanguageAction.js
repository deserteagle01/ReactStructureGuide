import { ACTION_TYPE_SWITCH } from './ActionType';
import { connect } from 'react-redux';


export function switchLanguageAction(params) {
  return (dispatch, state) => {
    dispatch({ type: ACTION_TYPE_SWITCH.SWITCH_LANGUAGE, params });
  }
}









