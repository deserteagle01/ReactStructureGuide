import { ACTION_TYPE_USER, ACTION_TYPE_EDITPROFILE,ACTION_HOME, ACTION_TYPE_MEALS, ACTION_TYPE_PAYMENT, PLAN_TYPE } from './ActionType';
import { connect } from 'react-redux';
import DietStationAPI from "../../webservice/DietStationApi";
import { expiry, callAPI } from "../../common/Utility";
//import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'

export function updateUserDetails(params) {
	return (dispatch) => {
		dispatch({ type: ACTION_TYPE_USER.UPDATE_USER_DETAILS, params });
	}
}

export function logoutAction(params, sourceParams) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_USER.USER_LOGOUT_LOADING });
		return DietStationAPI.logout(sourceParams).then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.USER_LOGOUT_ERROR, message: "Can't get data from server" });
				dispatchActions(dispatch, params);
			} else if (json.status == 'success') {
				dispatchActions(dispatch, params);
			} else {
				dispatch({ type: ACTION_TYPE_USER.USER_LOGOUT_ERROR, message: json.error });
				dispatchActions(dispatch, params);
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_USER.USER_LOGOUT_ERROR, message: error.error });
			dispatchActions(dispatch, params);
		});
	}
}

export function clearDataAction(params) {
	return (dispatch, state) => {
		return dispatchActions(dispatch, params);
	}
}

export function dispatchActions(dispatch, params) {
	dispatch({ type: ACTION_TYPE_USER.CLEAR_USER_REDUCER, data: params });
	dispatch({ type: ACTION_TYPE_MEALS.CLEAR_MEAL_DETAILS, data: {} });
	dispatch({ type: ACTION_TYPE_PAYMENT.CLEAR_PAYMENT_DETAILS, data: {} });
}


export function registerUser(params) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_LOADING });
		return DietStationAPI.registerUser(params).then(json => {
			console.log("register API response==" + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_SUCCESS, data: json.user });
			} else {
				dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_ERROR, message: error.error });
		});
	}
}

export function registerUpdateUser(params) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_LOADING });
		return DietStationAPI.registerUpdateUser(params).then(json => {
			console.log("register update API response==" + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_SUCCESS, data: json.user });
			} else {
				dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_USER.USER_REGISTER_ERROR, message: error.error });
		});
	}
}

export function UserExistAction(Phonenumber) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_USER.USER_EXIST_LOADING });
		return DietStationAPI.checkUserExist(Phonenumber).then(json => {
			console.log("checkUserExist==" + JSON.stringify(json))
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.USER_EXIST_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_USER.USER_EXIST_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_USER.USER_EXIST_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_USER.USER_EXIST_ERROR, message: error.error });
		});
	}
}

export function UserLoginAction(phonenumber, password) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_USER.USER_LOGIN_LOADING });
		return DietStationAPI.userAuthLogin(phonenumber, password).then(json => {
			//console.log('Login response=====' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.USER_LOGIN_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_USER.USER_LOGIN_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_USER.USER_LOGIN_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_USER.USER_LOGIN_ERROR, message: error.error });
		});
	}
}

export function EditUserAction(firstname, lastname, gender, birthdate, email, language,ar_firstname,ar_lastname,commuLang) {
	return (dispatch) => {
		dispatch({ type: ACTION_TYPE_USER.USER_UPDATE_LOADING });
		return DietStationAPI.UserEditAPI(firstname, lastname, gender, birthdate, email, language,ar_firstname,ar_lastname,commuLang).then(json => {
			console.log('User edit response=====' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.USER_UPDATE_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_USER.USER_UPDATE_SUCCESS, data: json.user });
			} else {
				dispatch({ type: ACTION_TYPE_USER.USER_UPDATE_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_USER.USER_UPDATE_ERROR, message: error.error });
		});
  }
}

export function ChangePwdAction(current_password, new_password) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_CHANGEPWD_LOADING });
		return DietStationAPI.ChangePwd(current_password, new_password).then(json => {
			console.log('ChangePwdAction response=====' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_CHANGEPWD_ERROR, message: "Can't get data from server" });
			} else if ((json.status).toLowerCase() == 'success') {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_CHANGEPWD_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_CHANGEPWD_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_CHANGEPWD_ERROR, message: error.error });
		});
  }
}

export function DislikeCategoryAction(dislike_category_ids) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DISLIKE_CATEGORY_LOADING });
		return DietStationAPI.dislikeCategory(dislike_category_ids).then(json => {
			console.log('dislikeCategory response=====' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DISLIKE_CATEGORY_ERROR, message: "Can't get data from server" });
			} else if ((json.status).toLowerCase() == 'success') {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DISLIKE_CATEGORY_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DISLIKE_CATEGORY_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DISLIKE_CATEGORY_ERROR, message: error.error });
		});
  	}
}

export function updateUserAddress(params) {
	return (dispatch) => {
		dispatch({ type: ACTION_TYPE_EDITPROFILE.UPDATE_USER_ADDRESS, data: params });
	}
}

export function submitAddEditAddress(params) {
	return (dispatch) => {
		dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_UPDATE_ADDRESS_LOADING });
		return DietStationAPI.addEditAddress(params).then(json => {
			// console.log("params==", params)
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_UPDATE_ADDRESS_ERROR, message: "Can't get data from server" });
			} else if ((json.status).toLowerCase() == 'success') {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_UPDATE_ADDRESS_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_UPDATE_ADDRESS_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_UPDATE_ADDRESS_ERROR, message: error.error });
		});
  	}
}
export function submitDisableDeleted(params) {
	return (dispatch) => {
		return DietStationAPI.deletDisableAddress(params).then(json => {
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DELETE_ADDRESS_ERROR, message: "Can't get data from server" });
			} else if ((json.status).toLowerCase() == 'success') {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DELETE_ADDRESS_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DELETE_ADDRESS_ERROR, message: json.error });
			}
		}).catch((error) => {
			dispatch({ type: ACTION_TYPE_EDITPROFILE.USER_DELETE_ADDRESS_ERROR, message: error.error });
		});
  	}
}

export function ChoosePasswordAction(otp, password, mobile) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_USER.USER_VERIFY_OTP_LOADING });
		return DietStationAPI.choosePassword(otp, password, mobile).then(json => {
			console.log('verify otp response=====' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.USER_VERIFY_OTP_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_USER.USER_VERIFY_OTP_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_USER.USER_VERIFY_OTP_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_USER.USER_VERIFY_OTP_ERROR, message: error.error });
		});
  }
}


export function sendOTPAction(action, mobile) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_USER.SEND_OTP_LOADING });
		return DietStationAPI.sendOTP(action, mobile).then(json => {
			console.log('send otp response =====' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.SEND_OTP_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_USER.SEND_OTP_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_USER.SEND_OTP_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_USER.SEND_OTP_ERROR, message: error.error });
		});
  }
}

export function verifyOTPAction(otp, mobile) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_USER.VERIFY_OTP_LOADING });
		return DietStationAPI.verifyOTP(otp, mobile).then(json => {
			console.log('send otp response =====' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_USER.VERIFY_OTP_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_USER.VERIFY_OTP_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_USER.VERIFY_OTP_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_USER.VERIFY_OTP_ERROR, message: error.error });
		});
  }
}


export function bindActionCreators(dispatch, state) {
	return {
		getHomeDataAction : (forcefetch) => {
			return getHomeDataAction(forcefetch)(dispatch, state)       
		},
	}
}


export function getHomeDataAction(forceFetch) {
	return (dispatch, state) => {
	callAPI(state, dispatch, DietStationAPI.getHomeData, (state) =>  {
		if(state) {
			return {
				isLoading: state.homeData.isLoading,
				expiry: expiry.Home.getHomeDataAction,
				lastUpdated: [state.homeData.lastUpdatedHomeData],
				error: state.homeData.error
			};
		}
	}
	,ACTION_HOME.HOME_DATA_LOADING, ACTION_HOME.HOME_DATA_SUCCESS, ACTION_HOME.HOME_DATA_ERROR, forceFetch, {}, {});
}
}
export function uploadImageUrl(imageBase64) {
	return (dispatch) => {
		dispatch({ type: ACTION_HOME.UPLOADIMAGE_LOADING });
	  return DietStationAPI.uploadImageUrl(imageBase64).then(json => {
		if (json === undefined) {
		  dispatch({ type: ACTION_HOME.UPLOADIMAGE_ERROR, message: "Can't get data from server" });
		} else if (json.status == 'success') {
		  dispatch({ type: ACTION_HOME.UPLOADIMAGE_SUCCESS, data: json });
		} else {
		  dispatch({ type: ACTION_HOME.UPLOADIMAGE_ERROR, message: json.error });
		}
	  }).catch((error) => {
		dispatch({ type: ACTION_HOME.UPLOADIMAGE_ERROR, message: error.error });
	  });
  	}
}
