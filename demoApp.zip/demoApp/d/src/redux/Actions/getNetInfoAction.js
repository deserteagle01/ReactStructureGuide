import { ACTION_TYPE_CONNECTION, } from './ActionType';
import { connect } from 'react-redux';

export function getNetInfoAction(isConnected) {
  return (dispatch, state) => {
    dispatch({ type: ACTION_TYPE_CONNECTION.UPDATE_CONNECTION_STATUS, isConnected });
  }
}



