import { NOTIFICATION_TYPE } from './ActionType';
import DietStationAPI from "../../webservice/DietStationApi";

export function getNotificationAction(offset, limit) {
	return (dispatch, state) => {
		dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_GET_LOADING });
		return DietStationAPI.getNotificationList(offset, limit).then(json => {
			console.log('Get notification data' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_GET_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_GET_SUCCESS, data: json });
			} else {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_GET_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_GET_ERROR, message: error.error });
		});
	}
}

export function readNotificationAction(id) {
	return (dispatch, state) => {
		dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_READ_LOADING });
		return DietStationAPI.markReadNotification(id).then(json => {
			console.log('read notification data' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_READ_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_READ_SUCCESS, data: json });
			} else {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_READ_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_READ_ERROR, message: error.error });
		});
	}
}

export function clearNotificationAction(id) {
	return (dispatch, state) => {
		dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_CLEAR_LOADING });
		return DietStationAPI.clearAllNotifications(id).then(json => {
			console.log('clear notification data' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_CLEAR_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_CLEAR_SUCCESS, data: json });
			} else {
				dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_CLEAR_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: NOTIFICATION_TYPE.NOTIFICATION_CLEAR_ERROR, message: error.error });
		});
	}
}
