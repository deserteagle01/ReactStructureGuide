import { ACTION_TYPE_APPOINTMENT } from './ActionType';
import { connect } from 'react-redux';
import DietStationAPI from "../../webservice/DietStationApi";
import { expiry, callAPI, callCalendarAPI } from "../../common/Utility";
import moment from 'moment';
export function getAppointmentDashboard(forceFetch) {
	return (dispatch, state) => {
		callAPI(state, dispatch, DietStationAPI.getAppointmentDashboard, (state) =>  {
			if(state) {
				return {
					isLoading: state.appointmentData.isLoading_Appointment,
					expiry: expiry.Appointment.getAppointmentDashboard,
					lastUpdated: [state.appointmentData.lastUpdatedAppointment],
					error: state.appointmentData.error
				};
			}
	}
	,ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_LOADING, ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_SUCCESS, ACTION_TYPE_APPOINTMENT.GET_APPOINTMENT_ERROR, forceFetch, {}, {});
}
}

export function bindActionCreators(dispatch, state) {
	return {
		getDietitionList : (forcefetch) => {
			return getDietitionList(forcefetch)(dispatch, state)       
		}, 
		getAvailableDietition: (forcefetch) => {
			return getAvailableDietition(forcefetch)(dispatch, state)
		},
		getDietitionCalendar: (forcefetch, param, strCurrentMonth) => {
			return getDietitionCalendar(forcefetch, param, strCurrentMonth)(dispatch, state)
		},
		clearSelectedDate: () => {
			return clearSelectedDate()(dispatch, state)
		},
		updateSelecteDate: (param) => {
			return updateSelecteDate(param)(dispatch, state)
		},
		getAppointmentDashboard: (forcefetch) => {
			return getAppointmentDashboard(forcefetch)(dispatch, state)
		}
	}
}

export function getDietitionList(forceFetch) {
	return (dispatch, state) => {
		callAPI(state, dispatch, DietStationAPI.getDietition, (state) =>  {
			if(state) {
				return {
					isLoading: state.appointmentData.isLoadingFor,
					expiry: expiry.Appointment.getDietitionList,
					lastUpdated: [state.appointmentData.lastUpdatedDietitionList],
					error: state.appointmentData.error
				};
			}
	}
	,ACTION_TYPE_APPOINTMENT.GET_DIETITION_LOADING, ACTION_TYPE_APPOINTMENT.GET_DIETITION_SUCCESS, ACTION_TYPE_APPOINTMENT.GET_DIETITION_ERROR, forceFetch, {}, {});
}
}

export function getAvailableDietition(forceFetch) {
	return (dispatch, state) => {
		callAPI(state, dispatch, DietStationAPI.getFirstAvailable, (state) =>  {
			if(state) {
				return {
					isLoading: state.appointmentData.isLoadingFor,
					expiry: expiry.Appointment.getAvailableDietition,
					lastUpdated: [state.appointmentData.lastUpdatedAvailableList],
					error: state.appointmentData.error
				};
			}
	}
	,ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_LOADING, ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_SUCCESS, ACTION_TYPE_APPOINTMENT.AVAILABLE_DIETITION_ERROR, forceFetch, {}, {});
}
}

export function getDietitionCalendar(forceFetch, param, strCurrentMonth) {
	
	return (dispatch, state) => {
		let lastUpdated = forceFetch ? state.appointmentData.lastUpdatedDietitionCalendar : state.appointmentData.calendarList[param.dietitian_id[0]].lastUpdated
		callAPI(state, dispatch, DietStationAPI.getDietitionDates, (state) =>  {
			
			if(state) {
				return {
					isLoading: state.appointmentData.isLoadingForDietitionCalendar,
					expiry: expiry.Appointment.getDietitionCalendar,
					lastUpdated: [lastUpdated],
					error: state.appointmentData.error,
					needDataCheck: true,
					data: state.appointmentData.calendarList[param.dietitian_id[0]],
					keys: [strCurrentMonth]
				};
			}
	}
	,ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_LOADING, ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_SUCCESS, ACTION_TYPE_APPOINTMENT.CALENDAR_DIETITION_ERROR, forceFetch, param, {forceFetch: forceFetch});
	}
}



export function clearSelectedDate() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_APPOINTMENT.CALENDAR_SELECTED_CLEAR });	
	}
}
export function updateSelecteDate(params) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_APPOINTMENT.UPDATE_SELECTED_DATE, data: params });
	}
}

