import { ACTION_TYPE_PAYMENT } from './ActionType';
import { connect } from 'react-redux';
import DietStationAPI from "../../webservice/DietStationApi";

export function InitiatePayment() {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_INITIATE_LOADING });
		return DietStationAPI.initiatePayment().then(json => {
                console.log('payment initiate response' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_INITIATE_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_INITIATE_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_INITIATE_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_INITIATE_ERROR, message: error.error });
		});
	}
}


export function CheckPaymentStatus(param,statusPayment) {
	return (dispatch, state) => {
		dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_STATUS_LOADING });
		return DietStationAPI.statusPayment(param,statusPayment).then(json => {
                console.log('payment status response' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_STATUS_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_STATUS_SUCCESS, data: json });
			} else {
				dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_STATUS_ERROR, message: "failed" });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: ACTION_TYPE_PAYMENT.PAYMENT_STATUS_ERROR, message: error.error });
		});
	}
}


export function updatePaymentStatus(params) {
	return (dispatch) => {
		dispatch({ type: ACTION_TYPE_PAYMENT.UPDATE_PAYMENT_STATUS, params });
	}
}
