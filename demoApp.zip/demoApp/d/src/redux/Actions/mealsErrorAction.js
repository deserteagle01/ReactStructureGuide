import { ACTION_TYPE_MEALS_ERROR } from './ActionType';
import { connect } from 'react-redux';

export function clearError() {
	return (dispatch, state) => {
		ACTION_TYPE_MEALS_ERROR.CLEAR_EROR
		dispatch({ type: ACTION_TYPE_MEALS_ERROR.CLEAR_EROR });
	}
}