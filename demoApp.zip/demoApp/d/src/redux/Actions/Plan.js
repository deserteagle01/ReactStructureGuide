import { PLAN_TYPE } from './ActionType';
import { connect } from 'react-redux';
import DietStationAPI from "../../webservice/DietStationApi";
import { expiry, callAPI } from "../../common/Utility";
export function bindActionCreators(dispatch, state) {
	return {
		getPlanAction: (forceFetch) => {
			return getPlanAction(forceFetch)(dispatch, state)
		},
	}
}

export function getPlanAction(forceFetch) {
	return (dispatch, state) => {
		callAPI(state, dispatch, DietStationAPI.getPlans, (state) =>  {
			if(state) {
				return {
					isLoading: state.planData.isLoading,
					expiry: expiry.Plan.getPlanAction,
					lastUpdated: [state.planData.lastUpdatedPlanList],
					error: state.planData.error
				};
			}
	}
	,PLAN_TYPE.PLAN_LOADING, PLAN_TYPE.PLAN_SUCCESS, PLAN_TYPE.PLAN_ERROR, forceFetch, {},{});
	}
}

export function getPlanDetailAction(plan_id) {
	return (dispatch, state) => {
		dispatch({ type: PLAN_TYPE.PLAN_DETAIL_LOADING });
		return DietStationAPI.getPlansDetails(plan_id).then(json => {
			console.log('Get Plan details' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: PLAN_TYPE.PLAN_DETAIL_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: PLAN_TYPE.PLAN_DETAIL_SUCCESS, data: json });
			} else {
				dispatch({ type: PLAN_TYPE.PLAN_DETAIL_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: PLAN_TYPE.PLAN_DETAIL_ERROR, message: error.error });
		});
	}
}
export function setPlanDetailAction(json) {
	return (dispatch, state) => {
		console.log('Set Manually Plan details' + JSON.stringify(json));
		return new Promise((resolve, reject)=>{
			dispatch({ type: PLAN_TYPE.PLAN_DETAIL_SUCCESS, data: json });
			resolve();
		});
	}
}

export function updatePlanDetailAction(planData, islogin) {
	return (dispatch, state) => {
		dispatch({ type: PLAN_TYPE.EDIT_PLAN_LOADING });
		return callEditPlandetail(planData, islogin).then(json => {
			if (json === undefined) {
				dispatch({ type: PLAN_TYPE.EDIT_PLAN_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: PLAN_TYPE.EDIT_PLAN_SUCCESS, data: json });
			} else {
				if (json.result == "error") {
					dispatch({ type: PLAN_TYPE.EDIT_PLAN_ERROR, message: json.error_message });
				} else {
					dispatch({ type: PLAN_TYPE.EDIT_PLAN_ERROR, message: json.error });
				}
			}
		})
		.catch((error) => {
			console.log(error);
			dispatch({ type: PLAN_TYPE.EDIT_PLAN_ERROR, message: error.error });
		});
	}
}

export function bookDietitionAppointment(Id) {
	return (dispatch, state) => {
		dispatch({ type: PLAN_TYPE.BOOK_DIETITION_LOADING });
		return DietStationAPI.bookDietition(Id).then(json => {
            console.log('book dietitions response' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: PLAN_TYPE.BOOK_DIETITITON_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: PLAN_TYPE.BOOK_DIETITION_SUCCESS, data: json });
			} else {
				dispatch({ type: PLAN_TYPE.BOOK_DIETITITON_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: PLAN_TYPE.BOOK_DIETITITON_ERROR, message: error.error });
		});
	}
}

export function cancelAppointment(Id) {
	return (dispatch, state) => {
		dispatch({ type: PLAN_TYPE.CANCEL_DIETITION_LOADING });
		return DietStationAPI.cancelDietition(Id).then(json => {
            console.log('cancel dietitions response' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: PLAN_TYPE.CANCEL_DIETITITON_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: PLAN_TYPE.CANCEL_DIETITION_SUCCESS, data: json });
			} else {
				dispatch({ type: PLAN_TYPE.CANCEL_DIETITITON_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: PLAN_TYPE.CANCEL_DIETITITON_ERROR, message: error.error });
		});
	}
}


function callEditPlandetail(planData, islogin) {
	if (islogin) {
		return DietStationAPI.updatePlan(planData);
	}
	else {
		return DietStationAPI.editPlansDetails(planData);
	}
}


export function changePlanSubmit(planData) {
	return (dispatch, state) => {
		dispatch({ type: PLAN_TYPE.SUBMIT_CHANGE_PLAN_LOADING });
		return DietStationAPI.changePlanSubmit(planData).then(json => {
            console.log('---submit change plan data response' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: PLAN_TYPE.SUBMIT_CHANGE_PLAN_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: PLAN_TYPE.SUBMIT_CHANGE_PLAN_SUCCESS, data: json });
			} else {
				dispatch({ type: PLAN_TYPE.SUBMIT_CHANGE_PLAN_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: PLAN_TYPE.SUBMIT_CHANGE_PLAN_ERROR, message: error.error });
		});
	}
}


export function getChangePlanData() {
	return (dispatch, state) => {
		dispatch({ type: PLAN_TYPE.GET_CHANGE_PLAN_LOADING });
		return DietStationAPI.getChangePlan().then(json => {
            console.log('get change plan data response' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: PLAN_TYPE.GET_CHANGE_PLAN_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: PLAN_TYPE.GET_CHANGE_PLAN_SUCCESS, data: json });
			} else {
				dispatch({ type: PLAN_TYPE.GET_CHANGE_PLAN_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: PLAN_TYPE.GET_CHANGE_PLAN_ERROR, message: error.error });
		});
	}
}


export function getRenewPlanData() {
	return (dispatch, state) => {
		dispatch({ type: PLAN_TYPE.GET_RENEW_PLAN_LOADING });
		return DietStationAPI.getRenewPlan().then(json => {
            console.log('get renew plan data response' + JSON.stringify(json));
			if (json === undefined) {
				dispatch({ type: PLAN_TYPE.GET_RENEW_PLAN_ERROR, message: "Can't get data from server" });
			} else if (json.status == 'success') {
				dispatch({ type: PLAN_TYPE.GET_RENEW_PLAN_SUCCESS, data: json });
			} else {
				dispatch({ type: PLAN_TYPE.GET_RENEW_PLAN_ERROR, message: json.error });
			}
		}).catch((error) => {
			console.log(error);
			dispatch({ type: PLAN_TYPE.GET_RENEW_PLAN_ERROR, message: error.error });
		});
	}
}

export function clearPlanDetails() {
	return (dispatch, state) => {
		dispatch({type: PLAN_TYPE.CLEAR_PLAN_DETAILS });
	}
}
