import { I18nManager} from "react-native";
import i18n from "i18n-js";
import * as RNLocalize from "react-native-localize";
import memoize from "lodash.memoize"; // Use for caching/memoize for better performance

import { Constants } from "@common";

// import en from "./locales/en";
// import ar from "./locales/ar";

const translationGetters = {
  // lazy requires (metro bundler does not support symlinks)
  ar: () => require("./locales/ar.json"),
  en: () => require("./locales/en.json")
};

export const translate = memoize(
  (key, config) => i18n.t(key, config),
  (key, config) => (config ? key + JSON.stringify(config) : key)
);

export const setI18nConfig = (default_lang, is_rtl) => {
  
  // fallback if no available language fits
  if(default_lang == undefined){
    const fallback = { languageTag: Constants.Language, isRTL: Constants.isRTL };
  }else{
    const fallback = { languageTag: default_lang, isRTL: is_rtl };
  }

  let locales = RNLocalize.getLocales();
  let { languageTag, isRTL } =
    RNLocalize.findBestAvailableLanguage(Object.keys(translationGetters)) || fallback;

  if (default_lang) {
    languageTag = default_lang;
    isRTL = is_rtl;
  }

    // clear translation cache
    translate.cache.clear();

    // update layout direction
    I18nManager.forceRTL(isRTL);
    // set i18n-js config
    i18n.translations = { [languageTag]: translationGetters[languageTag]() };
    i18n.locale = languageTag;
};
