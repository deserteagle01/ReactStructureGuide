import React, { Component } from "react";
import { View, TouchableOpacity, Text, Image, StyleSheet, Dimensions, I18nManager } from "react-native";
import { connect } from "react-redux";
import { setI18nConfig } from "@languages";
import { Images, Styles, Colors } from "@common";
import LanguageModal from "../LanguageModal";
import { bindActionCreators } from "redux";
import * as switchLanguage from "../../redux/Actions/SwitchLanguageAction";


class LanguageSwitcher extends Component {
  constructor(props) {
    super(props);
    this._openLanguageModal=this._openLanguageModal.bind(this);
    
  }
  _openLanguageModal = () => {
    this.refs.languageModal.toggleModal(true);
  };

  _closeLanguageModal = () => {
    this.refs.languageModal.toggleModal(false);
  };

  _changeLanguage = (lang, isRTL) => {
    setI18nConfig(lang, isRTL);    
    if(this.props.isfor != 'comminication_language') {
        this.props.actions.switchLanguage.switchLanguageAction({lang: lang, rtl: isRTL });
    }
    this.props.updateScreen(lang,isRTL);
  }

  renderText() {
    if(this.props.isfor == 'comminication_language') {
      return(
        <Text style={styles.text}>
              {
                this.props.userData.com_lang == 'ar' ?
                'عربى'
                :
                'English'
              }
            </Text>
      );
    }
    else{
      return(
        <Text style={styles.text}>
              {
                this.props.selectedLangFlag.rtl ?
                'عربى'
                :
                'English'
              }
            </Text>
      );
    }
  }

  render() {
    return (
      <View>
        <LanguageModal ref={"languageModal"} selectedLangFlag={this.props.isfor  == 'comminication_language'  ? this.props.userData.com_lang : this.props.selectedLangFlag.lang} changeLanguage={this._changeLanguage}/>
        <TouchableOpacity
          style={styles.container}
          onPress={() => {
            this._openLanguageModal();
          }}>
          {this.renderText()}
          <Image source={Images.icons.up} style={styles.upImage} />
        </TouchableOpacity>
      </View>

    );
  }
}

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row"

  },
  text: {
    fontFamily:  Styles.FontFamily().ProximaNovaSemiBold,
    fontSize: 15,
    marginRight: 8,
    color: Colors.white
  },
  upImage: {
    width: 16,
    height: 16
  }
});


const mapStateToProps = (state) => ({
  selectedLangFlag: state.switchLanguageReducer,
  userData: state.updateUserReducer,
});


function mapDispatchToProps(dispatch) {
  return {
    actions: {
      switchLanguage: bindActionCreators(switchLanguage, dispatch),
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(LanguageSwitcher);