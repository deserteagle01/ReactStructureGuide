import React, { Component } from "react";
import { View, Text, StyleSheet ,Platform, ImageStore} from "react-native";
import { connect } from "react-redux";
import { Styles, Validations, Colors, Images } from "@common";
import { translate } from "@languages";
import InputAddress from "../InputAddress"
import { GradientButton ,InputAccessory,InputTextString} from "@components";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { communicationNameGetter} from "../../common/Utility";
import InputSelectionPicker from "../InputSelectionPicker"
class ProfileAddress extends Component {
	constructor(props) {
		super(props);
		this.state = {
			singUpArea:"",
			singUpAreaError: null,
			singUpBlock: "",
			singUpBlockError: null,
			singUpStreet:"",
			singUpStreetError: null,
			singUpHouseNo: "",
			singUpHouseNoError: null,
			singUpAvenue:"",
			singUpAvenueError: null,
			singUpFilterBlock: "",
			isPrimary:false,

		};
		this.inputRefs = {};
	}
	componentWillMount(){
		this.props.actions.MasterList.PreloadedDataAction();
	}
	componentWillReceiveProps(nextProps) {
		if(this.props!=nextProps) {
			this.prepareState(nextProps);
		}
	}
	componentDidMount(){
		this.prepareState(this.props)
	}
	prepareState(props) {
		let areaItem = [];
		props.governorate_areas.forEach((governate)=> {
			areaItem.push({
				label: governate.gover_name,
				label_ar: governate.gover_name_ar
			});
			governate.gover_areas.forEach((area)=>{
				areaItem.push(area);
			});
		});
		let filterBlock = [];
		addressVal = props.userInfo.changeAddress;
		if (!addressVal || !addressVal.hasOwnProperty('area_id')) {
			addressVal = this.props.addressVal;
		}
		if(addressVal) {
			// update redux on back pressed
			filterBlock = props.blockItem.filter(item => {
				return item.area_id == addressVal.area_id
			})
			this.setState({
				singUpFilterBlock: filterBlock,
				isPrimary:addressVal.isPrimary,
				singUpArea:addressVal.area_id,
				singUpBlock:addressVal.block_id,
				singUpStreet:addressVal.street,
				singUpHouseNo:addressVal.street2,
				singUpAvenue:addressVal.avenue,
				areaItem:areaItem
			});
		}else{
			this.setState({
				singUpFilterBlock: filterBlock,
				areaItem:areaItem
			});

		}
	}
	selectedAreaHandler = (item) => {
		text = item && item.value;
		if(this.props.blockItem!==[]){
			const filterBlock = this.props.blockItem.filter(item => {
				return item.area_id == text
			})

			this.setState({singUpFilterBlock : filterBlock,
				singUpArea: text,
				singUpBlock:"",
				singUpBlockError:""

			});
		}
	}

	selectedBlockHandler = (item) => {
		text = item && item.value;
		this.setState({ singUpBlock: text})
	}

	streetTextHandler = (text) => {
		this.setState({ singUpStreet: text })
	}

	houseNoTextHandler = (text) => {
		this.setState({ singUpHouseNo: text })
	}

	avenueTextHandler = (text) => {
		this.setState({ singUpAvenue: text })
	}

	validateAddress = () => {
		let option = { fullMessages: false };
		let singUpAreaError = Validations('reqField', this.state.singUpArea, option);
		console.log("Erorr ",singUpAreaError);
		let singUpBlockError = Validations('reqField', this.state.singUpBlock, option);
		let singUpStreetError = Validations('reqField', this.state.singUpStreet, option);
		let singUpHouseNoError = Validations('reqField', this.state.singUpHouseNo, option);
		this.setState({ singUpAreaError: singUpAreaError, singUpBlockError: singUpBlockError, singUpStreetError: singUpStreetError, singUpHouseNoError: singUpHouseNoError })
		if (!singUpAreaError && !singUpBlockError && !singUpStreetError && !singUpHouseNoError) {
			var primaryaddress = this.props.userInfo.addresses[0];
			const reqParams = {
				id: this.props.addressVal !== null ? this.props.addressVal.id : "",
				area_id: this.state.singUpArea,					// Update this field value only
				block_id: this.state.singUpBlock,				// Update this field value only
				street: this.state.singUpStreet,				// Update this field value only
				street2: this.state.singUpHouseNo,				// Update this field value only
				avenue: this.state.singUpAvenue,				// Update this field value only
				isPrimary: this.state.isPrimary,
				daysArray: this.state.isPrimary ? primaryaddress.daysArray : [],
				// I have to pass days array when edit primaryaddress daysArray not editable so, array is [] 
			};
			this.props.actions.UpdateUserAction.updateUserAddress(reqParams);
			this.props.gotoNext();
		}
		return false;
	}

	onUpArrowClicked = (refs) => {
		if(refs == "area"){
            // this.props.navigation.navigate("EditAddressScreen");
        } else if(refs == "block"){
            this.inputRefs["area"].togglePicker(true);
        } else if(refs == "street"){
            this.inputRefs["block"].togglePicker(true);
        } else if(refs == "houseNo"){
            this.inputRefs["street"].focus();
        } else if(refs == "avenue"){
            this.inputRefs["houseNo"].focus();
        }
    }

    onDownArrowClicked = (refs)=>{
		
        if(refs == "area"){
            this.inputRefs["block"].togglePicker(true);
        } else if(refs == "block"){
            this.inputRefs["street"].focus();
        } else if(refs == "street"){
            this.inputRefs["houseNo"].focus();
        } else if(refs == "houseNo"){
            this.inputRefs["avenue"].focus();
        } else if(refs == "avenue"){
            this.validateAddress();
        }
    }

	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView enableOnAndroid={true} keyboardShouldPersistTaps={'always'} showsVerticalScrollIndicator={false}>
					<Text style={styles.label}>{this.props.addAddressModal}</Text>
					<View style={styles.inputNameContainer}>
						{this.state.areaItem &&
							<InputSelectionPicker
								ref = {"area"}
								value = {this.state.singUpArea}
								data = {this.state.areaItem}
								valueExtractor = {(item) => this.props.getCName(item,"label")}
								onSelectItem = {(item) => this.selectedAreaHandler(item)}
								placeholder={translate("SelectArea")}
								placehoderStyle = {{color:Colors.gray}}
								containerStyle={{borderColor:"lightgray"}}
								icon  = {Images.icons.downGray}
								style = {{color:Colors.gray, fontFamily:Styles.FontFamily().ProximaNova}}
								errorMsg={this.state.singUpAreaError?translate(this.state.singUpAreaError):""}
								errorMsgStyle={{color:Colors.red}}
								isGroupView={true}
						/>		
						}
					</View>

					{this.props.blockItem &&
						<InputSelectionPicker 
							ref={"block"}
							value = {this.state.singUpBlock}
							data = {this.state.singUpFilterBlock}
							onSelectItem = {(item) => this.selectedBlockHandler(item)}
							placeholder={translate("Block")}
							placehoderStyle = {{color:Colors.gray}}
							containerStyle={{borderColor:"lightgray", marginTop:16}}
							icon  = {Images.icons.downGray}
							style = {{color:Colors.red, fontFamily:Styles.FontFamily().ProximaNova}}
							errorMsg={this.state.singUpBlockError?translate(this.state.singUpBlockError):""}
							errorMsgStyle={{color:Colors.red}}
						/>
					}
					<View style={styles.lineInputNameContainer}>
						<InputAddress textHandler={this.streetTextHandler} onRef={(el) => {this.inputRefs["street"] = el} } refName={"street"} errorMsg={this.state.singUpStreetError} inputText={this.state.singUpStreet} placeholderText={translate("Street")} inputAccessoryViewID={"street"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}/>
					</View>
					<View style={styles.lineInputNameContainer}>
						<InputAddress textHandler={this.houseNoTextHandler} onRef={(el) => {this.inputRefs["houseNo"] = el} } refName={"houseNo"} errorMsg={this.state.singUpHouseNoError}  inputText={this.state.singUpHouseNo} placeholderText={translate("HouseNo")} inputAccessoryViewID={"houseNo"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}/>
					</View>
					<View style={styles.lineInputNameContainer}>
						<InputAddress textHandler={this.avenueTextHandler} onRef={(el) => {this.inputRefs["avenue"] = el} } refName={"avenue"} errorMsg={this.state.singUpAvenueError} inputText={this.state.singUpAvenue} placeholderText={translate("Avenue")} inputAccessoryViewID={"avenue"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}/>
					</View>
					<View>
						<GradientButton style={styles.addressBtnConti}
							onPressAction={() => { this.validateAddress() }}
							text={translate("Continue")}
						/>
						</View>
				</KeyboardAwareScrollView>
				{Platform.OS == 'ios' &&
					<View>
					 <InputAccessory   inputAccessoryViewID={"street"} hideDoneBar={true} onUpArrowClick={() => this.onUpArrowClicked('street')} onDownArrowClick={() => this.onDownArrowClicked('street')}/>
						<InputAccessory inputAccessoryViewID={"houseNo"} hideDoneBar={true} onUpArrowClick={() => this.onUpArrowClicked('houseNo')} onDownArrowClick={() => this.onDownArrowClicked('houseNo')}/>
						<InputAccessory inputAccessoryViewID={"avenue"} hideDoneBar={true} onUpArrowClick={() => this.onUpArrowClicked('avenue')} onDownArrowClick={() => this.onDownArrowClicked('avenue')}/> 
					</View>
				}
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
		paddingHorizontal: 16
	},
	label: {
		fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.black,
		textAlign: 'left',
		lineHeight: 36,
		letterSpacing: -0.1,
	},
	textInputFocus: {
		borderBottomColor: Colors.white,
	},
	inputNameContainer: {
		marginTop: 24,
	},
	lineInputNameContainer: {

	},
	addressBtnConti: {
		marginTop: 16,
		marginBottom:16,
		width: "100%",
		marginHorizontal:0
	}
});

const mapStateToProps = (state) => {
	return {
		governorate_areas: state.fetchMasterListReducer.governorate_areas,
		blockItem: state.fetchMasterListReducer.blocks,
		userInfo: state.updateUserReducer,
		getCName: communicationNameGetter(state),		
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
			MasterList: bindActionCreators(MasterList, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(ProfileAddress);
