import React from "react";
import { StyleSheet, Text, TouchableOpacity, Image, I18nManager } from "react-native";
import LinearGradient from "react-native-linear-gradient";

import { Styles, Colors, Images } from "@common";

class GradientButton extends React.PureComponent {
  render() {
    const {
      children,
      style,
      text,
      textStyle,
      gradientBegin,
      gradientEnd,
      disabledGradientBegin,
      disabledGradientEnd,
      gradientDirection,
      height,
      width,
      radius,
      impact,
      impactStyle,
      onPressAction,
      disabled,
      isCheckedVisible
    } = this.props;
    const disabledColor = [
      disabledGradientBegin || "#D3D3D3",
      disabledGradientEnd || "#696969"
    ];

    const horizontalGradient = {
      start: { x: 0, y: 0.5 },
      end: { x: 1, y: 0.5 }
    };

    const verticalGradient = {
      start: { x: 0, y: 0 },
      end: { x: 0, y: 1 }
    };

    const diagonalGradient = {
      start: { x: 0, y: 0 },
      end: { x: 1, y: 1 }
    };
    return (
      <TouchableOpacity
        style={[styles.button, { height, width }, style]}
        onPress={
          disabled
            ? null
            : () => {
              if (onPressAction) {
                return onPressAction();
              }
            }
        }
        disabled={disabled}
      >
        <LinearGradient
          style={[styles.gradient, { borderRadius: radius }]}
          colors={disabled ? disabledColor : [gradientBegin, gradientEnd]}
          start={
            gradientDirection === "vertical"
              ? verticalGradient.start
              : gradientDirection === "diagonal"
                ? diagonalGradient.start
                : horizontalGradient.start
          }
          end={
            gradientDirection === "vertical"
              ? verticalGradient.end
              : gradientDirection === "diagonal"
                ? diagonalGradient.end
                : horizontalGradient.end
          }
        >

          {text ?
            <Text style={[styles.text, textStyle]}>{text}</Text>
            :
            children
          }

          {isCheckedVisible &&
            <Image source={I18nManager.isRTL ? Images.icons.rightCheckRedishPink : Images.icons.leftCheckRedishPink} style={styles.checkLogo} />
          }

        </LinearGradient>
      </TouchableOpacity>
    );
  }
}

GradientButton.defaultProps = {
  gradientBegin: "rgb(238,29,36)",
  gradientEnd: "rgb(255,110,0)",
  gradientDirection: "horizontal",
  height: 56,
  radius: 10,
  impact: false,
  impactStyle: "Heavy",
  textStyle: {},
  disabled: false,
  disabledGradientBegin: "#696969",
  disabledGradientEnd: "#D3D3D3",
};

const styles = StyleSheet.create({
  button: {
    marginHorizontal: 16
  },
  gradient: {
    height: "100%",
    width: "100%",
    alignItems: "center",
    justifyContent: "center"
  },
  text: {
    color: Colors.white,
    fontSize: Styles.FontSize.fnt17,
    fontFamily: Styles.FontFamily().ProximaNovaBold
  },
  checkLogo: {
    width: 28,
    height: 28,
    position: "absolute",
    justifyContent: "center",
    right: 14
  }
});

export default GradientButton;
