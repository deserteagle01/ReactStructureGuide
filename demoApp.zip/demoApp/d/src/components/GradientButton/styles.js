import { StyleSheet } from "react-native";
import { Colors } from "@common";

export default (styles = StyleSheet.create({
  btnContainer: {
    marginTop: 16,
    marginHorizontal: 1,
  },
  btn: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center"
  },
  btnText: {
    color: Colors.white,
    fontSize: 20
  }
}));
