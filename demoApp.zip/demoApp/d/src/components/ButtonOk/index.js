import React, { Component } from "react";
import { View, Text, StyleSheet, Platform, I18nManager, Dimensions, Keyboard, Animated, Image, TouchableOpacity } from "react-native";
import { Styles, Validations, Colors } from "@common";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { translate } from "@languages";
import Images from "../../common/Images";
const { height, width } = Dimensions.get("window");
class ButtonOk extends Component {
    constructor(props) {
        super(props);
        this.state = {

        };
    }

    componentDidMount() {

    }

    render() {
        const { buttonStyle, textStyle, iconStyle, image, onClcikOk, lang } = this.props;
        return (
            <TouchableOpacity style={[styles.okbt, buttonStyle]} onPress={this.props.onPress}>
                <Text style={[styles.txtOk(lang), textStyle]}>{translate("Ok")}</Text>
                <Image
                    source={image ? image : Images.icons.tick_grey}
                    style={[styles.tickIcon, iconStyle]}>
                </Image>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    okbt: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.white,
        height: 50,
        width: 110,
        marginTop: 15,
        marginLeft: 10,
        borderRadius: 8,
        flexDirection: 'row'
    },
    txtOk:(lang) => ({
        fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
        fontSize: 18,
        color: Colors.black6f,
        textAlign: 'left',
    }),
    tickIcon: {
        height: 20,
        width: 20,
        marginLeft: 10
    }
});


export default ButtonOk;
