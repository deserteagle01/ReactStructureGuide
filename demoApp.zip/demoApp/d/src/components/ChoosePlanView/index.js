import React, { Component, PureComponent } from "react";
import { connect } from "react-redux";
import { View, ScrollView, StyleSheet, SafeAreaView,Text, StatusBar,ImageBackground, Dimensions, TouchableOpacity, Image, I18nManager, TextInput, FlatList } from "react-native";
import styles from "./styles";
import Modal from "react-native-modal";
import { translate, setI18nConfig } from "@languages";
import { CustomPlanView, Fade,AnimatedMove, GradientButton, OutlineButton, NeedHelp, LanguageSwitcher, Spinner, Toast, WebViewModal, ChoosePlanCard, AppointmentView } from "@components";
const { height, width } = Dimensions.get("window");
import { Images, Styles, Colors, Validations } from "@common";
const screen = Dimensions.get("window");
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as GetPlanAction from "../../redux/Actions/Plan";
import { firebase } from '@react-native-firebase/analytics';

class ChoosePlanView extends PureComponent {
    constructor(props) {
        super(props);
        this.state = { selectedIndex: 0, planData: this.props.planData.plans, stage: this.props.forwardStage ? this.props.forwardStage : 'list-cards', planDetailData: this.props.planDetailFrom == "referralUserExists" ? this.props.userInfo.plan_data: this.props.planData};
        this.props.stageTo("list-cards", this.state.planData);
    }


    componentDidMount() {
        if(this.props.forwardStage != "plan-detail") {
            firebase.analytics().setCurrentScreen("Choose Plan Screen");
            if (this.props.Connected) {
                this.props.actions.GetPlanAction.getPlanAction(false);
            } else {
                this.toast.show(translate("InternetToast"));
            }
        }
        if(this.props.modalReOpenPlanData) {
            this.onPlanClicked(this.props.modalReOpenPlanData);
        }
    }

    componentWillReceiveProps(nextProps){
        if(this.props.planData != nextProps.planData){
            if(nextProps.error != null){
                this.toast.show(nextProps.error)
            }
            if(nextProps.type == "PLAN_SUCCESS"){
                firebase.analytics().logEvent("view_item_list");
                this.setState({ planData: nextProps.planData.plans });
                this.props.stageTo(this.state.stage, nextProps.planData.plans);
            
            }
        }
    }

    renderSwitchView() {
        return (
            <View>
                {
                    this.props.userInfo.isLogin ?
                        <View style={styles.switchView}>
                            <TouchableOpacity style={this.state.selectedIndex == 0 ? styles.selected : styles.unselected} onPress={() => this.setState({ selectedIndex: 0 })}>
                                <Text style={this.state.selectedIndex == 0 ? styles.txtSelected : styles.txtUnelected}>{translate("ChoosePlan")}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={this.state.selectedIndex == 1 ? styles.selected : styles.unselected} onPress={() => this.setState({ selectedIndex: 1 })}>
                                <Text style={this.state.selectedIndex == 1 ? styles.txtSelected : styles.txtUnelected}>{translate("BookApointment")}</Text>
                            </TouchableOpacity>
                            <View style={styles.orView}>
                                <Text style={styles.txtor}>OR</Text>
                            </View>
                        </View>
                        :
                        <View style={styles.switchView2}>
                            <TouchableOpacity style={this.state.selectedIndex == 0 ? styles.selected2 : styles.unselected2} onPress={() => this.setState({ selectedIndex: 0 })}>
                                <Text style={this.state.selectedIndex == 0 ? styles.txtSelected2 : styles.txtUnelected2}>{translate("ChoosePlan")}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={this.state.selectedIndex == 1 ? styles.selected3 : styles.unselected3} onPress={() => this.setState({ stage: "book-appointment", selectedIndex: 1 })}>
                                <Text style={this.state.selectedIndex == 1 ? styles.txtSelected2 : styles.txtUnelected2}>{translate("BookApointment")}</Text>
                            </TouchableOpacity>
                        </View>
                }
            </View>
        )
    }

    async onCancel() {
        if(this.state.stage=="list-cards"){
            this.props.onDone();
        } else {
            if(this.props.forwardStage){
                this.props.onDone();
            }else{
                await this.setState({stage:"list-cards"});
                this.props.stageTo("list-cards", this.state.planData);
                this.props.onPrev();
            }
        }
    }
    render() {
        return (
            <View style={[styles.container]}>
                <View style={[styles.subContainer,]}>
                    <View style={styles.planlistview}>

                    {this.state.stage=="list-cards" || this.state.stage=="plan-detail" ?
                        <View style={styles.header}>
                            <TouchableOpacity onPress={()=>this.onCancel()} style={ this.props.planDetailFrom == "referralUserExists" ? {height:0, width:0,overflow: "hidden"}: {}}>
                                <Image source={this.state.stage=="list-cards"?Images.icons.closeBox:Images.icons.cancel_redBackground} style={styles.cancelLogo} />
                            </TouchableOpacity>

                            <View style={styles.helpView}>
                                <NeedHelp textStyle={styles.txtCall} iConPath={Images.icons.callGrey} />
                            </View>
                        </View>
                        :null
                    }

                        <Fade remove={this.state.stage!="list-cards"} visible={this.state.stage=="list-cards"} duration={300} style={{flex:1}}>
                            
                            {!this.props.userInfo.isLogin ? this.renderSwitchView() :null}

                            {!this.props.userInfo.isLogin?
                                <View style={styles.suggestionView2}>
                                    <WebViewModal ref="refBestPlanModal" sourceUri={this.props.companyDetails.best_plan_url || "http://thedietstation.com"}/>
                                    <TouchableOpacity onPress={() => this.refs.refBestPlanModal.show()} style={{flexDirection:"row"}}>
                                        <Text style={styles.suggestion2}>{translate("BestPlanForYou")}</Text>
                                        <Image source={Images.icons.info_ic} style={styles.infoimg} />
                                    </TouchableOpacity>
                                </View>
                            :null}

                            <FlatList
                                style={styles.flexView}
                                data={this.state.planData}
                                extraData={this.state}
                                keyExtractor={(item, index) => index.toString()}
                                renderItem={this._renderItem}
                                />
                        </Fade>
                        
                        {this.state.stage=="plan-detail"?
                            <CustomPlanView
                                {...this.props}
                                initialPlanDetailData={this.state.planDetailData}
                                closeCustomPlanModal={() => this.hide()} 
                                ContinuePress={(isStartDate, isPayment) =>  this.onContinue(isStartDate, isPayment)}/>
                            :null
                        }    
                        
                        <Fade remove={this.state.stage!="book-appointment"} visible={this.state.stage=="book-appointment"} duration={300} style={{flex:1}}>
                            <AppointmentView 
                                {...this.props}
                                currentStageHeight = {this.state.currentStageHeight}
                                navigation ={this.props.navigation}
                                onPressCancel={(data) => this.showConfirmedInfo(data)}
                                onContinue = {() => this.props.onBookingDone()} />
                        </Fade>

                    </View>
                    <Toast refrence={(refrence) => this.toast = refrence} />
                </View>
                { this.props.paymentReducer.isLoading ? <Spinner mode="overlay" /> : null}
            </View>
        );
    }

    showConfirmedInfo(data) {
        this.setState({stage: "list-cards", selectedIndex: 0 });
        this.props.stageTo("list-cards", this.state.planData);
    }


    async onPlanClicked(planDetailData) {
        // console.log( ">> #S", planDetailData);
        // this.props.navigation.navigate('CustomPlan', {Plan_id: plan_id});
        this.props.onNext("list-cards");
        await this.setState({planDetailData:planDetailData, stage: planDetailData.is_book_appointment ? "book-appointment" : "plan-detail"});
    }
    
    onContinue(isStartdate, isPayment){
        this.props.onNext(this.state.stage, isStartdate, isPayment);
    }

    
    _renderItem = ({ item, index }) => {
        return (
            <ChoosePlanCard item = {item} onPlanClicked={(data) => this.onPlanClicked(data)} key={index} />
        );
    }
    
}

function mergeProps(stateProps, dispatchProps, ownProps) {
        const { dispatch } = dispatchProps;
        return {
            ...ownProps,
            ...stateProps,
            actions: {
                UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
                GetPlanAction: GetPlanAction.bindActionCreators(dispatch , stateProps),
            }
        };
}

const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    userInfo: state.updateUserReducer,
    planData: state.PlanReducer,
    companyDetails: state.fetchMasterListReducer,    
    paymentReducer: state.PaymentReducer,
    error: state.PlanReducer.error,
    type: state.PlanReducer.type
});

export default connect(mapStateToProps, undefined, mergeProps)(ChoosePlanView);


