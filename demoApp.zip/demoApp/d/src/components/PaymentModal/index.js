import React, { Component } from "react";
import { View, ScrollView, StyleSheet, Text, Dimensions, TouchableOpacity, Image, I18nManager, TextInput, SafeAreaView } from "react-native";
import Modal from "react-native-modal";
import { translate, setI18nConfig } from "@languages";
import { GradientButton } from "@components";
import { Images, Styles, Colors, Validations, AppConfig } from "@common";
const screen = Dimensions.get("window");
import { WebView } from 'react-native-webview';
import { firebase } from '@react-native-firebase/analytics';

export default class PaymentModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isModalVisible: false,
            links: ""
        };

        this.togglePaymentModal = this.togglePaymentModal.bind(this);
    }

    togglePaymentModal(visible, links) {
        if (links != undefined) {
            this.setState({ isModalVisible: visible, links: links });
        } else {
            this.setState({ isModalVisible: visible });
        }
    };

    getPaymentId(url) {
        let tempArr  = url.split("?");
        let param = tempArr[1];
        var temp2 = param.split("&");
        var temp3 = temp2[0].split("=");
        var temp4 = temp2[1].split("=");
        
        return ([temp3[1], temp4[1]]);
    }

    _onNavigationStateChange(status) {
        if(status.url.includes(AppConfig.DietStation.successUrl)) {
            firebase.analytics().logEvent("checkout_progress", {checkout_step: "Return Payment Success", checkout_option: "Success"});
            let  returnParam = this.getPaymentId(status.url);
            this.setState({isModalVisible: false});
            this.props.onClose(returnParam[0], returnParam[1],true);
        }
        else if(status.url.includes(AppConfig.DietStation.errorUrl)) {
            firebase.analytics().logEvent("checkout_progress", {checkout_step: "Return Payment Faild", checkout_option: "Faild"});
            let  returnParam = this.getPaymentId(status.url);
            this.setState({isModalVisible: false});
            this.props.onClose(returnParam[0], returnParam[1],false);
        }
    };

    cancelPress() {
        this.props.cancelPress();
        this.setState({ isModalVisible: false });
    }

    render() {
        return (
            <Modal
                hasBackdrop
                isVisible={this.state.isModalVisible}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={0.5}
                useNativeDriver={true}
                style={{ margin: 0 }}
                onBackdropPress={() => {
                    this.togglePaymentModal(false, undefined);
                }}>
                <View style={styles.mainModalContainer}>
                    <View style={styles.promocodeview}>

                        <WebView 
                            source={{ uri: this.state.links }}
                            startInLoadingState
                            sharedCookiesEnabled={true}
                            style={{ flex: 1, marginTop:70 }}
                            onNavigationStateChange={(status) =>
                                this._onNavigationStateChange(status)
                            }
                            scalesPageToFit />

                    <TouchableOpacity style={styles.cancelButton} onPress={() => this.cancelPress()}>
                        <Image source={Images.icons.closeBox} style={styles.infoimg} />
                    </TouchableOpacity>

                    </View>
                </View>
            </Modal>
        );
    }
}

const styles = StyleSheet.create({
    mainModalContainer: {
        height: '100%',
        width: '100%',
        justifyContent: 'center'
    },
    cancelButton: {
        position:'absolute',
        right:15,
        top:35,
    },
    infoimg: {
        height:28,
        width: 28
    },
    promocodeview: {
        backgroundColor: 'white',
        borderRadius: 16,
        flex: 1
    }
});