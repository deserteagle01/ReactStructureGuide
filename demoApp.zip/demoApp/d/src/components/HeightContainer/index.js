import React, { Component } from "react";
import { View, Text, StyleSheet, Image, Dimensions, Platform, Keyboard } from "react-native";
import { connect } from "react-redux";
import { Styles, Colors, Images, Validations } from "@common";
import InputWithIcon from "../InputWithIcon"
import FullButton from "../FullButton"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import { InputAccessory } from "@components";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const { height, width } = Dimensions.get("window");
import ButtonOk from  "../ButtonOk";
import { TouchableOpacity } from "react-native-gesture-handler";

class HeightContainer extends Component {
	constructor(props) {
		super(props);
		this.state = {
			profileHeight: "",
			profileHeightError: null,
		};
		this.inputRefs = {};
	}

	init() {
		setI18nConfig("ar",false);
		this.setState({profileHeight: this.props.signupDetail.height});
	}
	
	textHeightHandler(text){
		this.setState({ profileHeight: text })
	}

	async validate() {
		return new Promise((resolve, reject) => { 
			let height = this.state.profileHeight;
			let option = { fullMessages: false };
			let profileHeightError = Validations('numericonly', height == 0 ? "" : height, option);
			this.setState({  profileHeightError: profileHeightError })
			if (!profileHeightError) {
				const reqParams = {
					height: this.state.profileHeight,				// Update this field value only
				};
				this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
				resolve({result: 1});
			}else{
				resolve({result: 0});
			}
		});
	}

	
	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView extraScrollHeight={Platform.OS === 'ios' ? 40 : 90} enableOnAndroid={true} keyboardShouldPersistTaps={'always'}>
					<View>
						<Text style={[styles.label(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt : null ]}>{translate("TellAboutYourSelf")}</Text>

						<View style={styles.noteContainer}>
							<Text style={[styles.labelsmall(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt : null]}>{translate("HelpUsToShowDiet")}</Text>
						</View>
						
						<View style={styles.heightContainer}>
							<InputWithIcon 
								onRef={(el) => {this.inputRefs["height"] = el} } 
								refName={"height"} 
								returnKeyEvent={(inputAccessoryViewID) => console.log(inputAccessoryViewID)}
							 	inputAccessoryViewID={"height"} 
							 	lang={this.props.signupDetail.com_lang}
								textHandler={(text) => this.textHeightHandler(text)} 
								errorMsg={this.state.profileHeightError} 
								iconPath={translate("CM")} 
								inputText={this.state.profileHeight} 
								placeholderText={translate("YourHeight")} 
								inputType="4" />
						</View>
						
					</View>

					{this.state.profileHeight.length > 0 &&
					<TouchableOpacity onPress={this.props.heightSelection}>
						<ButtonOk  lang={this.props.signupDetail.com_lang} />
					</TouchableOpacity>
					}

				{Platform.OS == 'ios' &&
                        <InputAccessory inputAccessoryViewID={"height"} disableUpArrow={true} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} />
                }
				</KeyboardAwareScrollView>
				
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		lineHeight: 36,
		textAlign: 'left',
		marginTop: height*0.14
	}),
	noteContainer: {
		marginTop: 16,
		marginHorizontal:0
	},
	labelsmall: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		fontSize: 14,
		color: Colors.white,
		lineHeight: 18,
		textAlign: 'left'
	}),
	heightContainer: {
		marginTop: 23,
	},
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(HeightContainer);