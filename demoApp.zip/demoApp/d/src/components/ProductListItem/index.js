import React, { Component, PureComponent } from "react";
import { View, StyleSheet, Text, Image, TouchableOpacity, FlatList, Animated, I18nManager } from "react-native";
import { Colors, Styles, Images } from "@common";
import { translate } from "@languages";
import ReactNativeHapticFeedback from "react-native-haptic-feedback";
import {CachedImage} from "react-native-img-cache";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as mealsAction from "../../redux/Actions/mealsAction";

var width = Styles.width / 2 - 25;
var shadowOpacity = 0.3;
var shadowRadius = 4;
var elevation = 4;
class ProductListItem extends PureComponent {
	constructor(props) {
		super(props);
		this.gram = translate('g');
	}

	componentWillMount() {
		this.animatedValue = new Animated.Value(0);
		this.value = 0;
		this.animatedValue.addListener(({ value }) => {
			this.value = value;
		})
	}

	triggerHapticEffect = (type) => {
		const options = {
		  enableVibrateFallback: true,
		  ignoreAndroidSystemSettings: true
		};
		ReactNativeHapticFeedback.trigger(type, options);
	}

	doAnimation = (toValue, friction, tension) => {
		Animated.spring(this.animatedValue, {
			toValue: toValue,
			friction: friction,
			tension: tension,
			useNativeDriver:true,
		}).start();
	}


	_getTagName = (tag_id) => {
		let tagData = this.props.mealDetail.all_tags.filter((item) => {
			return item.id == tag_id;
		});
		if(tagData && tagData[0]){
			return I18nManager.isRTL ? (tagData[0].name_ar || tagData[0].name) : tagData[0].name;
		}
		return null;
	}

	detailBoxItem = (item, currSelectedStatus) => {
		var myloop = [];
		if(item.tag2_ids != undefined && item.tag2_ids.length > 0){
			for (let i = 0; i < item.tag2_ids.length; i++) {
			  myloop.push(
					<View key={Math.random() * i * 999} style={styles.mealTagItemView} >
						<Text style={styles.mealTagItemText}>{this._getTagName(item.tag2_ids[i])}</Text>
					</View>
			  );
			}
		}
		return (
			<View>
				{/* meal image view */}
				<View style={item.quantity > 0 ? styles.mealImageViewWithBorder : styles.mealImageView}>
					<CachedImage
						defaultSource={Images.placeholder}
					  source={{ uri: item.image.length > 0 ? item.image : null }}
					  style={item.quantity > 0 ? styles.mealImageWithBorder : styles.mealImage}
					/>
					{/* meal type view */}
					{item.tag !== "" &&
						<View style={styles.mealTypeView}>
							<Image style={styles.mealTypeIcon} source={item.tag == 'Veg' ? Images.icons.veg : Images.icons.bodyBuilding} />
						</View>
					}
					{/* meal selected icon view */}
					{item.quantity > 0 &&
						<View style={styles.selectedItemView}>
							{item.quantity == 1 ?
								<Image style={styles.oneItemSelectedQtyView} source={Images.icons.check} />
								:
								<Text style={styles.moreThanOneItemSelectedView}>{item.quantity}</Text>
							}
						</View>
					}
					{/* meal image bottom tag view */}
					<View style={styles.mealTagListView}>
						{myloop}
					</View>
				</View>
				{/* meal item text view */}
				<View style={styles.mealTextView}>
					<View style={styles.mealTitleTextView}>
						<Text style={styles.mealTitleText}>{I18nManager.isRTL? (item.name_ar || item.name) : item.name}</Text>
					</View>
					{(currSelectedStatus == 'rate' && !item.is_rated) ?
						<View style={styles.mealSubBtnView}>
							<TouchableOpacity style={styles.rateButton} onPress={() => this.props.toggleRateModel(item)}>
								<Text style={styles.rateButtonText}>{translate("RateMePlease")}</Text>
							</TouchableOpacity>
						</View>
						:
						<View style={styles.mealSubTextView}>
							<View style={styles.mealSubTextLeftView}>
								<View style={styles.mealSubTextLeftTopView}>
									<Text style={styles.mealSubTextTitle}>{translate('Protein')}</Text>
									<Text style={styles.mealSubTextData}>{' ' + item.protein + this.gram + ' '}</Text>
									<Text style={styles.mealSecondSubTextTitle}>{translate('Cal')}</Text>
									<Text style={styles.mealSubTextData}>{' ' + item.calorie}</Text>
								</View>
								<View style={styles.mealSubTextLeftBottomView}>
									<Text style={styles.mealSubTextTitle}>{translate('Carbs')}</Text>
									<Text style={styles.mealSubTextData}>{' ' + item.carb + this.gram + ' '}</Text>
									<Text style={styles.mealSecondSubTextTitle}>{translate('Fat')}</Text>
									<Text style={[styles.mealSubTextData]}>{' ' + item.fat + this.gram}</Text>
								</View>
							</View>{/**/}
							<View style={styles.mealSubTextRightView}>
								<View style={styles.mealSubTextRightInnerView}>
									<Image source={Images.icons.Rate} style={styles.rateIcon} />
									<View style={styles.rateTextView}>
										<Text style={styles.rateText1}>{(item.rating != undefined ? item.rating.toFixed(1).split('.')[0] : 0)}</Text>
										{item.rating != undefined && <View style={{flexDirection: 'row'}}>
										<Text style={styles.rateText2}>{'.'}</Text><Text style={styles.rateText2}>{item.rating.toFixed(1).split('.')[1]}</Text></View>}
										<Text style={styles.rateText1}>{'/'}</Text>
										<Text style={styles.rateText2}>{'5'}</Text>
									</View>
								</View>
							</View>
						</View>
					}
				</View>
			</View>
		)
	}

	render() {
		const { item, index, currSelectedStatus } = this.props;
		return ( 
			<TouchableOpacity style={[styles.mainContainer, item.quantity > 0 ? styles.mainContainerWithBorder: ""]} onPress={() => { 
				if (this.value < 90) { this.onProductSelect(item) }
				this.triggerHapticEffect("impactLight")
			 }}>
				{/* Front Part rendering */}
				<View style={styles.flipCard}>
					{this.detailBoxItem(item, currSelectedStatus)}
				</View>
			</TouchableOpacity>
		);
	}

	onProductSelect = () => {
		const { item, currSelectedStatus, userSelectedMeals,currDate, categoryId } = this.props;
		let tempSelectedMeal = userSelectedMeals[currDate][categoryId] || {};
		if(currSelectedStatus != 'pause'){
			if(Object.keys(tempSelectedMeal).length == 0){
				return;
			}
			if(tempSelectedMeal.type != 'custom' && currSelectedStatus !== 'prepare' && currSelectedStatus !== 'rate' && currSelectedStatus !== 'delivered'){
				this.onAddProduct(item);
			}
		}else{
			this.showErrorMessage(true, translate('pauseDayWarning'), translate('WARNINGTXT'));
		}
	}

	onAddProduct = () => {
		const { item, userSelectedMeals,currDate, categoryId } = this.props;
		let tempSelectedMeal = userSelectedMeals[currDate][categoryId] || {};
		let meal_data = {...tempSelectedMeal};
		let selectedItemArray = [...meal_data.selected_items];
		const productIndex = selectedItemArray.findIndex(obj => obj.recipe_template_id === item.product_id);
		if (meal_data.quantity <= meal_data.selected_quantity) {
			if(productIndex == -1){
				this.showErrorMessage(true, translate('maxProductSelectedMessage'), translate('maxProductSelectedTitle'));
			}else if(item.quantity > 0){
				meal_data.selected_quantity -= item.quantity;
				selectedItemArray.splice(productIndex, 1);
				item.quantity = 0;
				item.selected = false;
				meal_data = {...meal_data, selected_items : selectedItemArray};
				this.updateMealData(meal_data);
			}
		} else {
			if(productIndex != -1){
				selectedItemArray[productIndex].quantity += 1;
				item.quantity += 1;
				meal_data = {...meal_data, selected_items : selectedItemArray};
				meal_data.selected_quantity += 1;
				if ((meal_data.quantity == meal_data.selected_quantity)) {
					this.props.productMainContentFlatlistScroll && this.props.productMainContentFlatlistScroll(tempSelectedMeal.mealHeaderIndex);
				}
				this.updateMealData(meal_data);

			}else{
				let dislikeAttr = item.dislike_attributes.filter((el) => {
					return this.props.selectedDislike.some((f) => {
						return f === el.id ;
					});
				});
				if(dislikeAttr.length > 0){
					this.props.toggleDiscardChangeModal && this.props.toggleDiscardChangeModal(item,dislikeAttr).then(() => {
						this.addNewSeletedProduct(true);
					}).catch(error => {
						console.log('Error',error);
					});
				}else{
					this.addNewSeletedProduct(false);
				}
			}
		}
	}

	onRemoveProduct = () => {
		const { item,userSelectedMeals,currDate, categoryId } = this.props;
		let tempSelectedMeal = userSelectedMeals[currDate][categoryId] || {};
		if(item.quantity > 0){
			let meal_data = {...tempSelectedMeal};
			let selectedItemArray = [...meal_data.selected_items];

			const productIndex = selectedItemArray.findIndex(obj => obj.recipe_template_id === item.product_id);

			if(selectedItemArray[productIndex].quantity > 1){
				selectedItemArray[productIndex].quantity -= 1;
				item.quantity -= 1;
				meal_data = {...meal_data, selected_items : selectedItemArray}
			}else{
				selectedItemArray.splice(productIndex, 1);
				item.quantity = 0;
				item.selected = false;
				meal_data = {...meal_data, selected_items : selectedItemArray}
			}
			meal_data.selected_quantity -= 1;
			this.updateMealData(meal_data);
		}
	}

	addNewSeletedProduct(has_dislike){
		const { item,userSelectedMeals,currDate, categoryId } = this.props;
		let tempSelectedMeal = userSelectedMeals[currDate][categoryId] || {};
		let meal_data = {...tempSelectedMeal};
		let selectedItemArray = [...meal_data.selected_items];

		item.quantity += 1;
		item.selected = true;
		var productObj = {
			"quantity": item.quantity,
			"is_rated": false,
			"recipe_template_id": item.product_id,
			"has_dislike":has_dislike,
			"calorie":item.calorie,
			"carb":item.carb,
			"fat":item.fat,
			"protein":item.protein,
		}
		selectedItemArray.push(productObj);
		meal_data.selected_quantity += item.quantity;
		meal_data = {...meal_data, selected_items : selectedItemArray}
		this.updateMealData(meal_data);
		if ((meal_data.quantity == meal_data.selected_quantity)) {
			this.props.productMainContentFlatlistScroll && this.props.productMainContentFlatlistScroll(tempSelectedMeal.mealHeaderIndex);
		}
	}

	updateMealData = (mealData) => {
		let userMeals = {...this.props.userSelectedMeals};
		userMeals[this.props.currDate][this.props.categoryId] = {...mealData};
		this.props.updateMealSelectionData({...userMeals});
	}

	showErrorMessage = (visible, message, title) => {
		this.props.toggleMessageModal && this.props.toggleMessageModal(visible, message, title);
	}
}

const styles = StyleSheet.create({
	mainContainer: {
		width: width,
		height: 256,
		margin: 8,
		flexDirection: 'column',
		backgroundColor: Colors.white,
		alignSelf: 'center',
		borderRadius: 8,
		shadowRadius: 5,
		shadowColor: Colors.warmGrey,
		shadowOffset: { height: 0, width: 0 },
		elevation: 4,
		shadowOpacity: 0.5,
		borderColor: Colors.shamrockGreen,
		borderWidth: 0,
	},
	mainContainerWithBorder: {
		width: width + 4,
		height: 260,
		borderWidth: 2,
		margin: 6,
	},
	mealImageView: {
		width: width,
		height: 163,
		backgroundColor: 'transparent',
		borderTopLeftRadius: 8, borderTopRightRadius: 8
	},
	mealImageViewWithBorder: {
		width: width,
		height: 163,
		backgroundColor: 'transparent',
		borderTopLeftRadius: 8, borderTopRightRadius: 8
	},
	mealImage: { width: width, height: 163, borderTopLeftRadius: 7, borderTopRightRadius: 7, resizeMode: 'cover', overflow: 'hidden', },
	mealImageWithBorder: { width: width, height: 163, borderTopLeftRadius: 7, borderTopRightRadius: 7, resizeMode: 'cover', overflow: 'hidden', },
	mealTextView: { height: 93, flexDirection: 'column', borderBottomLeftRadius: 8, borderBottomRightRadius: 8, paddingLeft: 8, paddingRight: 8, },
	mealTitleTextView: { height: 47, paddingTop: 8 },
	mealTitleText: { fontSize: 13, lineHeight: 16, color: Colors.black, fontFamily: Styles.FontFamily().ProximaNovaSemiBold, textAlign: 'left' },
	mealSubTextView: { height: 45, flexDirection: 'row', borderTopWidth: 1, borderTopColor: Colors.warmGrey10, alignItems: 'center' },
	mealSubTextLeftView: { flex: 0.75, flexDirection: 'column', },
	mealSubTextLeftTopView: { flex: 0.25, flexDirection: 'row' },
	mealSubTextTitle: { flex: 0.28, fontSize: 9, color: Colors.black06, fontFamily: Styles.FontFamily().ProximaNova, backgroundColor: 'transparent', textAlign: 'left' },
	mealSubBtnView: { height: 46 },
	rateButton: { backgroundColor: Colors.marigoldTwo, width: "100%", height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
	rateButtonText: { fontSize: 13, lineHeight: 24, color: Colors.black, fontFamily: Styles.FontFamily().ProximaNovaSemiBold },
	mealSecondSubTextTitle: { flex: 0.15, marginLeft: 2, fontSize: 9, color: Colors.black06, fontFamily: Styles.FontFamily().ProximaNova, backgroundColor: 'transparent', textAlign: 'left' },
	mealSubTextData: { flex: 0.2, fontSize: 9, color: Colors.black, fontFamily: Styles.FontFamily().ProximaNovaBold, backgroundColor: 'transparent', textAlign: 'left' },
	mealSubTextLeftBottomView: { flex: 0.25, flexDirection: 'row', marginTop: 1 },
	mealSubTextRightView: { flex: 0.3, alignItems: 'flex-end' },
	mealSubTextRightInnerView: {
		flexDirection: 'row',
	},
	rateIcon: {
		width: 12,
		height: 11.3
	},
	rateTextView: {
		flexDirection: 'row',
		alignSelf: 'center'
	},
	rateText1: {
		fontSize: 12,
		color: Colors.black06,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
	},
	rateText2: {
		fontSize: 8,
		color: Colors.black06,
		fontFamily: Styles.FontFamily().ProximaNova,
		alignSelf: 'flex-end'
	},
	mealTypeView: { width: 31, height: 31, position: 'absolute', backgroundColor: Colors.white98, borderRadius: 8, margin: 8, justifyContent: 'center' },
	mealTypeIcon: { width: 18, height: 18, alignSelf: 'center' },
	mealTagListView: { position: 'absolute', bottom: 6, right: 8, flexDirection:'row' },
	mealTagItemView: { backgroundColor: Colors.pinkishRed, borderRadius: 8, height: 20, margin: 1, paddingLeft: 4, paddingRight: 4, justifyContent: 'center' },
	mealTagItemText: { fontSize: 10, color: Colors.white, fontFamily: Styles.FontFamily().ProximaNova, alignSelf: 'center' },
	selectedItemView: { position: 'absolute', right: 0, margin: 8, width: 24, height: 24, justifyContent: 'center', backgroundColor: Colors.shamrockGreen, borderRadius: 50 },
	oneItemSelectedQtyView: { width: 24, height: 24, alignSelf: 'center', backgroundColor: Colors.white, borderRadius: 50, tintColor: Colors.shamrockGreen },
	moreThanOneItemSelectedView: { color: Colors.white, fontSize: 16, alignSelf: 'center', lineHeight: 20, fontFamily: Styles.FontFamily().ProximaNovaSemiBold },
	flipCard: {
		// alignItems: 'center',
		// justifyContent: 'center',
		backfaceVisibility: 'hidden',
		width: width,
		height: 256,
		flexDirection: 'column',
		backgroundColor: Colors.white,
		alignSelf: 'center',
		borderRadius: 8,
		shadowRadius: shadowRadius,
		shadowColor: Colors.warmGrey,
		shadowOffset: { height: 0, width: 0 },
		elevation: elevation,
		shadowOpacity: shadowOpacity,
		borderColor: Colors.shamrockGreen,
		borderWidth: 0,
	},
	flipCardBack: {
		//position: "absolute",
		top: 0,
		width: width,
		height: 256,
		flexDirection: 'column',
		backgroundColor: Colors.white,
		alignSelf: 'center',
		borderRadius: 8,
		shadowRadius: shadowRadius,
		shadowColor: Colors.warmGrey,
		shadowOffset: { height: 0, width: 0 },
		elevation: elevation,
		shadowOpacity: shadowOpacity,
		borderColor: Colors.shamrockGreen,
		borderWidth: 0,
	},
	rearProductView: {
		width: width,
		height: 256,
	},
	closeBtnContainer: {
		flex: 0.1,
		right: 0,
		padding: 8,
		alignSelf: 'flex-end',
	},
	closeIcon: {
		width: 28,
		height: 28,
	},
	addProductIcon: {
		width: 28,
		height: 28,
	},
	removeProductIcon: {
		width: 28,
		height: 28,
	},
	productQtyTextView: {
		width: 48,
		height: 48,
		backgroundColor: Colors.white,
		alignItems: 'center',
		justifyContent: 'center',
		borderRadius: 50,
		marginLeft: 16,
		marginRight: 16,
		shadowRadius: shadowRadius,
		shadowColor: Colors.warmGrey,
		shadowOffset: { height: 0, width: 0 },
		elevation: elevation,
		shadowOpacity: shadowOpacity,
		borderColor: Colors.shamrockGreen,
		borderWidth: 0,
	},
	productQtyText: {
		fontSize: 28,
		lineHeight: 32,
		color: Colors.battleshipGrey,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		alignSelf: 'center'
	},
	rearProductTextView: {
		flexDirection: 'row',
		flex: 0.8,
		alignSelf: 'center',
		alignItems: 'center',
		justifyContent: 'center',
	},
});

const mapStateToProps = (state,ownProps) => ({
 	mealDetail: state.mealsReducer,
	selectedDislike: state.updateUserReducer.dislike_category_ids.slice(0),
});

function mapDispatchToProps(dispatch) {
    return {
        actions: {
			mealsAction: bindActionCreators(mealsAction, dispatch),
		}
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductListItem);