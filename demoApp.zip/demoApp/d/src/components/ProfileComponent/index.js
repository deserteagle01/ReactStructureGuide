import React, { Component } from "react";
import { View, StyleSheet, Text, Image, TouchableOpacity, Linking } from "react-native";
import { Colors, Styles, Images } from "@common";
import { translate } from "@languages";


export default class ProfileComponent extends Component {
  constructor(props) {
      super(props);
  }

  render() {
    return (
      <View style={[styles.mainContainer,{borderBottomColor:this.props.isLast ? 'white' : Colors.whiteTwo,height:this.props.subText !== '' ? 79 : 64}]}>
          <Image source={this.props.icon} style={[styles.icon,{tintColor:this.props.isLast ? Colors.vermillion : null}]} />
          <View style={[styles.textContainer,{marginTop:this.props.subText === '' ? 21 : 18}]}>
              <Text style={styles.mainText}>{this.props.mainText}</Text>
              <Text style={styles.subText}>{this.props.subText}</Text>
          </View>
      </View>
      );
    }
}

const styles = StyleSheet.create({
  mainContainer:{
    flexDirection:'row',
    height:79,
    borderBottomColor: Colors.whiteTwo,
    borderBottomWidth: 1,},
  icon: {
    width:28,
    height:28,
    marginLeft:16,
    alignSelf:'center'
  },
  textContainer: {
    flexDirection:'column',
    marginLeft:16,},
  mainText: {
    color: Colors.dark,
    fontSize: Styles.FontSize.fnt19,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    textAlign: 'left',
  },
  subText:{
    color: Colors.greyishBrown,
    fontSize: Styles.FontSize.fnt12,
    marginTop:4,
    fontFamily: Styles.FontFamily().ProximaNova,}
});
