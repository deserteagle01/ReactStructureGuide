import React, {Component} from 'react'
import {Animated,Platform} from 'react-native'

export default class MaterialAnimation extends Component {

    constructor(props) {
        super(props);
        this.state = {
            initialMove: new Animated.Value(0),
            endMove: 1,
            duration:700,
        };
    }

    componentDidMount() {
            Animated.timing(this.state.initialMove, {
              toValue: this.state.endMove,
              duration: this.state.duration,
              delay:this.props.index * 500,
              useNativeDriver: true,
            }).start();
           
    }

    render() {
        return (
            <Animated.View key={this.props.index}
                           style={{
                            opacity: this.props.index>=1?this.state.initialMove:null,
                               }}>
                {this.props.children}
            </Animated.View>
        )
    }
}