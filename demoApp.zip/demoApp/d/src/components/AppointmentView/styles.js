import { StyleSheet } from "react-native";

export default (styles = StyleSheet.create({
    givenHeight: {
        marginVertical: 15
    },
    Container: {
        height: '95%',
        width: '100%',
        justifyContent: 'center',
        position:'absolute',
        bottom: 0,
        top: 0,
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        overflow: "hidden",
        margin: 0,
        padding: 0,
    },
}));
