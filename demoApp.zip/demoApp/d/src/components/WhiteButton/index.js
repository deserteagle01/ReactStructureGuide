import React, { Component } from "react";
import { View, StyleSheet, Text, TextInput, Dimensions, Image, ActivityIndicator, TouchableOpacity, I18nManager } from "react-native";
import { Colors, Styles, Images } from "@common";
//import { TouchableOpacity } from "react-native-gesture-handler";
const screen = Dimensions.get("window");

export default function WhiteButton(props) {

    const { style, text, onPress } = props;
    return (
        <TouchableOpacity style={[styles.btStyle, style]}
        onPress={onPress}
        >
        {text == '' ?
                    <Image 
                       source={ I18nManager.isRTL ? Images.icons.RedLeftArrow :  Images.icons.redRightArrow }
                        style={{height:28,width:28}}/>   
                :
                    <Text style={styles.title}>{text}</Text>
            }
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
    btStyle:{
        width:'90%',
        alignItems:'center',
        justifyContent:'center',
        height:56,
        borderRadius:8,
        backgroundColor:Colors.white
    },
    title:{
        color: Colors.pinkishRed,
        fontSize: 17,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
    }
});
