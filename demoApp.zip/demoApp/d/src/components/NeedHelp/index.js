import React, { Component } from "react";
import { connect } from "react-redux";
import { View, StyleSheet, Text, Image, TouchableOpacity, Linking,Platform, I18nManager } from "react-native";
import { Colors, Styles, Images } from "@common";
import { translate } from "@languages";


class NeedHelp extends Component {
  constructor(props) {
      super(props);
  }

  _onPressHelp = () => {
      let number = this.props.fetchData.phone;
      Linking.openURL('tel://' + number).catch(err => {
        console.log(err);
     });
  };

  _onPressNotification = () => {
    this.props.notificationPress();
  }

  render() {
    const { showIcon, textStyle, iConPath,style, lang } = this.props;
    console.log('language ---------', lang);
    return (
        <View style={styles.mainContainer}>
          {showIcon &&
            <View style={[styles.showIconView,style]}>
                <TouchableOpacity style={styles.container} onPress={()=>{this._onPressNotification()}}>
                  <Image
                    source={Images.icons.bell}
                    defaultSource={Images.icons.bell}
                    style={styles.bellImage}
                  />
                </TouchableOpacity>
                {(this.props.notifCount !== "" && this.props.notifCount !== 0 && this.props.notifCount !== undefined) &&
                    <View style={styles.notifContainer}>
                        <Text style={styles.notifText}>{this.props.notifCount}</Text>
                    </View>
                }
            </View>
          }
          <TouchableOpacity style={styles.container} onPress={()=>{this._onPressHelp()}}>
            {!showIcon &&
            <Text style={[styles.helpText(lang), textStyle]}>{lang == 'ar' ? translate("NeedHelp") : translate("NeedHelp")}
            </Text>
            }
            <Image
              source={iConPath != undefined?iConPath:Images.icons.call}
              defaultSource={Images.icons.call}
              style={
                [styles.callImage]}
            />

          </TouchableOpacity>
        </View>
      );
    }
}

const styles = StyleSheet.create({
  mainContainer:{
    flexDirection:"row",
    justifyContent:'center',
  },
  container: {
    flexDirection:"row",
    justifyContent:'center',
    alignItems:"center",
  },
  showIconView:{
    marginTop:3,
  },
  notifContainer:{
    backgroundColor:Colors.shamrockGreen,
    position:'absolute',
    right:8,
    top:8,
    borderRadius:50,
    padding:0,
    height:12,
    width:12,
    justifyContent:'center',
    alignItems:'center'
  },
  notifText:{
    color:Colors.white,
    fontSize:Styles.FontSize.fnt8,
    textAlign:'center',
    alignSelf:'center'
  },
  helpText: (lang) => ({
    color: Colors.white,
    fontSize: 14,
    letterSpacing: -0.16,
    fontFamily: Styles.FontFamily(lang).ProximaNova
  }),
  callImage: {
    width: 28,
    height: 28,
    marginLeft: 6
  },
  bellImage:{
    width: 40,
    height: 40,
  }
});

const mapStateToProps = (state) => ({
  fetchData: state.fetchMasterListReducer
});

export default connect(mapStateToProps)(NeedHelp);


