/** @format */

import React, { PureComponent } from "react";
import { connect } from "react-redux";
import { AppConfig } from "@common";
import {
    View,
    Text,
} from "react-native";
import Moment from 'moment';
import { Images, Colors, Styles,Constants } from "@common";
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as Appointment from "../../redux/Actions/Appointment";
import * as Plan from "../../redux/Actions/Plan";
import * as mealsAction from "../../redux/Actions/mealsAction";
import { firebase } from '@react-native-firebase/analytics';
import { sourceScreen } from "../../common/Utility";
import {CachedImage} from "react-native-img-cache";
class Prefetcher extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            arrImg: []
        };
        this.fromPrefetch = true;
    }

    startPrefetching(options) {
        if (this.props.Connected) { 
            this.actionPrefetching(options);
        }
    }

    componentWillReceiveProps(nextProps){
        if(this.props.appointmentData != nextProps.appointmentData){
            if(nextProps.appointmentData.error != null){
                
            }
            if(nextProps.appointmentData.type == "GET_DIETITION_SUCCESS" && this.fromPrefetch){
                this.fromPrefetch = false;
                this.getDietitionListCalendar(nextProps.appointmentData.dietitionList)
            }
        }
        if(this.props.planData != nextProps.planData){
            if(nextProps.error != null){
                
            }
            if(nextProps.type == "PLAN_SUCCESS"){
                this.setState({arrImg: nextProps.planData.plans});
            }
        }
    }

    getDietitionListCalendar(dietitionList) {
        let rangeDate = this.getStartAndEndDay(0 , 3, Constants.fullDateFormate, 1);
        let arrIds = [];
        for (let dietition of dietitionList) {
            arrIds.push(dietition.dietitian_id);
        }
        let params = { dietitian_id: arrIds, start_date: rangeDate.strFirstday, end_date: rangeDate.strLastday };
        this.props.actions.Appointment.getDietitionCalendar(true, params);
    }

    getStartAndEndDay(intStart, intEnd, dateFormat, firstdayLimit) {
        var date = new Date();
        var firstDay = new Date(date.getFullYear(), date.getMonth() + intStart , firstdayLimit);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + intEnd, 0);
        lastDay.setHours(23);
        lastDay.setMinutes(59);
        lastDay.setSeconds(59);
        let strFirstday = Moment.utc(firstDay).format(dateFormat);   
        let strLastday = Moment.utc(lastDay).format(dateFormat);   
        return {
            "strFirstday": strFirstday,
            "strLastday": strLastday
        }
    }

    getUserProductCalendar(forceFetch) {
        let currentMonthDay = Moment(new Date()).format(Constants.dateFormate);
        let rangeDate = this.getStartAndEndDay(-1 ,2, Constants.dateFormate, 2);
        let params = { start_date: rangeDate.strFirstday, end_date: rangeDate.strLastday, expand: true };
        this.props.actions.Meal.fetchUserProductList(forceFetch, params, currentMonthDay);
    }

    homeScreenPrefetch(options) {
        this.props.actions.Meal.fetchMenuList(options.forceFetch || false);
        this.getUserProductCalendar(options.forceFetch || false);
        this.props.actions.Appointment.getAppointmentDashboard(false);
    }

    appointmentPrefetch() {
        this.props.actions.Appointment.getDietitionList(false);
        this.props.actions.Appointment.getAvailableDietition(false);
    }

    actionPrefetching(options) {
        let source = options.source;
        switch (source) {
		    case sourceScreen.login:
                if(options.action == "choosePlan"){
                    this.props.actions.Appointment.getDietitionList(true);
                }
                if(options.action == "onLoginLoading"){
                    this.props.actions.Plan.getPlanAction(true);
                }
                if(options.action == "fetchFirstAvailable") {
                    this.props.actions.Appointment.getAvailableDietition(true);
                }
                break;

            case sourceScreen.home:
                this.homeScreenPrefetch(options);
                break;

            case sourceScreen.appoitnment: 
                this.appointmentPrefetch();
                
            default:
                console.log("~~~~~ default");
        }
    }

    render() {
        return (
            <View style={{height:0, width:0}}>
                {this.renderAllImg(this.state.arrImg)}
            </View>
        );
    }
    renderAllImg(arrData) {
        return arrData.map((data, index) => {
            return (
                <CachedImage
                    key={index.toString()}
                    source={{uri: data.plan_image_url }} />
            )
        })
    }
}

function mergeProps(stateProps, dispatchProps, ownProps) {
    const { dispatch } = dispatchProps;
    return {
        ...ownProps,
        ...stateProps,
        actions: {
            UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
            Appointment: Appointment.bindActionCreators(dispatch, stateProps),
            Plan: Plan.bindActionCreators(dispatch, stateProps),
            Meal: mealsAction.bindActionCreators(dispatch, stateProps),
        }
    };
}

const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    appointmentData: state.appointmentReducer,
    mealsDetail: state.mealsReducer,
    planData: state.PlanReducer,
    type: state.PlanReducer.type,
    error: state.PlanReducer.error,
});

export default connect(mapStateToProps, undefined, mergeProps, { forwardRef: true })(Prefetcher);