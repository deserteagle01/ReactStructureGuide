import React, { Component } from "react";
import { StyleSheet, TextInput, Image, Text, TouchableHighlight, TouchableOpacity, I18nManager ,TouchableWithoutFeedback} from "react-native";
import { Styles, Colors,Images } from "@common";
import { translate } from "@languages";
import { View } from "react-native-animatable";
import DatePicker from "../DatePicker";
import moment from 'moment';
import { InputAccessory } from "@components";
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';

export default class InputWithIcon extends Component {
	constructor(props) {
		super(props);
		this.toggleSwitch = this.toggleSwitch.bind(this);
		this.state = {
            showPassword: true // boolean to show/hide the password 
		};
		// this.returnRef = this.returnRef.bind(this);
	}
	componentDidMount(){
		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}
	// returnRef=()=>{
	// 	if (this.props.onRef) {
	// 		this.props.onRef(this.refs['refDatePicker']);
	// 	}
	// }
	componentDidUpdate(){

		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}

	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

	toggleSwitch() {
		this.setState({ showPassword: !this.state.showPassword });
	}
	
	handlerFocus = (input) => {
		this.setState({
			[input]: true
		});
	};

	handlerBlur = (input) => {
		this.setState({
			[input]: false
		});
	};

	textHandler = (text) => {		
		this.props.textHandler(text);
	}

	openDatepicker = () => {
        this.refs.refDatePicker.showDateTimePicker();
	}
	InputAccessoryView = () => {
	
			<View style={[defaultStyles.modalViewMiddle]} testID="input_accessory_view">
				<View style={[defaultStyles.chevronContainer]}></View>
				<TouchableWithoutFeedback onPress={() => {console.log("reftouch",this.props.refName)}} hitSlop={{ top: 4, right: 4, bottom: 4, left: 4 }} testID="done_button">
					<View testID="needed_for_touchable">
						<Text style={[defaultStyles.done]}>{translate("Done")}</Text>
					</View>
				</TouchableWithoutFeedback>
			</View>
		
	}

	render() {
		const {
			inputAccessoryViewID,
			refName,
			inputType,
			placeholderText,
			itemObj,
			inputText,
			errorMsg,
			iconPath,
			styless,
			lang
		} = this.props;

		const placeholderPicker = {
			label: placeholderText,
			value: null,
			color: Colors.white,
		};
		const pickerStyle = {
			inputIOS: {
				color: Colors.white,
				fontSize: 24,
				height: 61,
				paddingLeft: 16,
				borderRadius: 12,
				borderWidth: 1,
				borderColor: '#d6d7da',
			},
			inputAndroid: {
				color: Colors.white,
				fontSize: 24,
				height: 61,
				paddingLeft: 16,
				borderRadius: 12,
				borderWidth: 1,
				borderColor: '#d6d7da',
			},
			placeholderColor: Colors.white,
			underline: { borderTopWidth: 0 },
			icon: {
				width: 24,
				height: 24,
			},
			iconContainer: {
				height: 61,
				width: 40,
				flex: 1,
				justifyContent: 'center',
				alignItems: 'center',
			},
		};
		if (inputType == 1) {
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput 
						 ref={refName}
						 inputAccessoryViewID={inputAccessoryViewID}
						 onSubmitEditing={() => this.props.returnKeyEvent(inputAccessoryViewID)}
						 secureTextEntry={this.state.showPassword} selectionColor={Colors.white} 
						 returnKeyType='done' 
						 onChangeText={this.textHandler} value={inputText} 
						 placeholder={placeholderText} 
						 placeholderTextColor={Colors.placeHoderGrey} 
						 style={[{ fontFamily:  Styles.FontFamily(lang).ProximaNovaSemiBold }, lang == 'ar' ? styles.rightContainerArabic(lang) : styles.leftContainerEnglish, styless ,this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}/>

						<TouchableOpacity 
							onPress={this.toggleSwitch} 
							style={[styles.rightContainerIcon, lang == 'ar' ? styles.leftIconSet : styles.rightIconset]}>
								<Image style={[styles.iconStyle]} source={this.state.showPassword ? Images.icons.eyeOpen : Images.icons.eyeClose} />
						</TouchableOpacity>
					</View>
					<Text style={[errorMsg?Styles.common.errorMsg: '', styless]}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		} else if (inputType == 2) {
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput 
						 ref={refName}
						 inputAccessoryViewID={inputAccessoryViewID}
						 onSubmitEditing={() => this.props.returnKeyEvent(inputAccessoryViewID)} 
						 autoCapitalize = 'none' returnKeyType='done' 
						 selectionColor={Colors.white} 
						 keyboardType={'email-address'} 
						 onChangeText={this.textHandler} 
						 value={inputText} 
						 placeholder={placeholderText} 
						 placeholderTextColor={Colors.placeHoderGrey} 
						 style={[{ fontFamily:  Styles.FontFamily(lang).ProximaNovaSemiBold },  styles.leftContainerEnglish , styless,this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}/>
						<TouchableOpacity style={[styles.rightContainerIcon, styles.rightIconset]}>
							<Image style={[styles.iconStyle]} source={iconPath} />
						</TouchableOpacity>
					</View>
					<Text style={[errorMsg?Styles.common.errorMsg: '', styless]}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		} else if (inputType == 3) {
			return (
				<View>
					<TouchableOpacity onPress={() => this.openDatepicker()} style={[styles.inputContainer]}>
						<View style={[styles.leftContainerEnglish, inputText != ''?styles.textInputFocus:'']}>
							<Text 
								style={[inputText?styles.textStyle(lang):styles.placeHoderTxt(lang), styless]}>{inputText?moment(inputText).format('DD-MMM-YYYY'): placeholderText}
							</Text>
						</View>
						<View style={styles.rightIconset}><Image style={[styles.iconStyle]} source={iconPath} /></View>
					</TouchableOpacity>
					<Text style={[errorMsg?Styles.common.errorMsg: '',styless]}>{errorMsg?translate(errorMsg): ''}</Text>
					
					<DatePicker
						selecteddate={inputText} 
						refName={refName}
						onSubmitEditing={() => this.props.returnKeyEvent(inputAccessoryViewID)}
						ref={refName}
						maximumDate={new Date()} selectedReturn={this.textHandler}></DatePicker>
				</View>
			);
		} else if(inputType == 4) {
			// Full border with right text
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput
						ref={refName}
						onSubmitEditing={() => this.props.returnKeyEvent(inputAccessoryViewID)}
						inputAccessoryViewID={inputAccessoryViewID}
						 keyboardType={'decimal-pad'} returnKeyType='done' selectionColor={Colors.white} onChangeText={this.textHandler} value={inputText != ''?inputText:""} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[{ fontFamily:  Styles.FontFamily(lang).ProximaNova }, styles.leftContainerBorder, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocusFullBorder : '', this.state.nameInputOneFocus ? styles.textInputFocusFullBorder : '']}/>					
						<Text style={[styles.inputRightText(lang)]}>{iconPath}</Text>
					</View>
					<Text style={errorMsg?Styles.common.errorMsg: ''}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		} else {
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput
							 ref={refName}
							 inputAccessoryViewID={inputAccessoryViewID}
							 onChangeText={this.textHandler} 
							 selectionColor={Colors.white} 
							 value={inputText} placeholder={placeholderText} 
							 placeholderTextColor={Colors.placeHoderGrey} 
							 style={[{ fontFamily:  Styles.FontFamily(lang).ProximaNova }, lang == 'ar' ? styles.rightContainerArabic(lang) : styles.leftContainerEnglish, styless,this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}/>
						<TouchableOpacity style={[styles.rightContainerIcon]}><Image style={[styles.iconStyle]} source={iconPath} /></TouchableOpacity>
					</View>
					<Text style={[errorMsg?Styles.common.errorMsg: '', lang == "ar" ? Styles.common.errorMsgArabic : Styles.common.errorMsg]}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		}
	}
}


const styles = StyleSheet.create({
	inputContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',	
		//backgroundColor: 'yellow'
	},
	leftContainer:{
		borderColor: "rgba(241, 242, 246, 1)",
		borderBottomWidth: 1,
		height: 59,
		width: '100%',
		color: "white",
		fontSize: 24,
		paddingStart: 29,
		//paddingEnd: 29,
		justifyContent: 'center',
		textAlign: I18nManager.lang == 'ar' ? 'right' : 'left',
	},
	leftContainerEnglish:{
		borderColor: "rgba(241, 242, 246, 1)",
		borderBottomWidth: 1,
		height: 59,
		width: '100%',
		color: "white",
		fontSize: 24,
		paddingEnd: 29,
		justifyContent: 'center',
		textAlign: I18nManager.lang == 'ar' ? 'right' : 'left',
	},
	rightContainerArabic: (lang) => ({
		borderColor: "rgba(241, 242, 246, 1)",
		borderBottomWidth: 1,
		height: 59,
		width: '100%',
		color: "white",
		fontSize: 24,
		paddingStart: 29,
		justifyContent: 'center',
		textAlign: lang == 'ar' ? 'right' : 'left',
	}),
	leftContainerText:{
		fontSize: 24,
		justifyContent: 'flex-start',
		textAlign: 'left'
	},
	leftContainerBorder:{
		borderColor: "rgba(241, 242, 246, 1)",
		borderWidth: 1,
		height: 59,
		width: '100%',
		color: Colors.white,
		fontSize: 24,
		paddingEnd: 55,
		paddingStart: 10,
		justifyContent: 'flex-start',
		alignItems: 'center',
		borderRadius: 12,
		textAlign: I18nManager.isRTL ? 'right' : 'left',
	},
	textInputFocusFullBorder: {
		borderColor: Colors.white,
		borderWidth: 1,
	},
	rightContainerIcon: {
		right: I18nManager.lang == 'ar' ? null :10,
		left: I18nManager.lang == 'ar' ? 10: null,
		position: 'absolute',
		justifyContent: "center",
		height: 24,
		width: 24,			
	},
	rightIconset:{
		right: 10,
		position: 'absolute',
		justifyContent: "center",
		height: 24,
		width: 24,			
	},
	leftIconSet:{
		left: 10,
		position: 'absolute',
		justifyContent: "center",
		height: 24,
		width: 24,			
	},
	iconStyle: {
		height: 24,
		width: 24,	
	},
	textStyle: (lang) => ({
        color: Colors.white,
        fontSize: Styles.FontSize.fnt24,
		fontFamily:  Styles.FontFamily(lang).ProximaNovaSemiBold,
		textAlign: 'left'
	}),
	placeHoderTxt: (lang) => ({
		color: Colors.placeHoderGrey,
        fontSize: Styles.FontSize.fnt24,
		fontFamily:  Styles.FontFamily(lang).ProximaNovaSemiBold,
		textAlign: 'left'
	}),
	inputRightText: (lang) => ({
		right: 10,
		paddingTop: 5,
		position: 'absolute',
		height: 28,
		width: 42,	
		color: Colors.white,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
		lineHeight: 20,
		backgroundColor: 'rgba(248,68,66, 1)',
		borderRadius: 14,
		textAlign: 'center',
	}),
	textInputFocus: {
		borderBottomColor: Colors.white,
	},
});
