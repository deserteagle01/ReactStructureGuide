import React, { PureComponent } from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
    View,
    Text,
    StyleSheet,
    ImageBackground,
    StatusBar,
    SafeAreaView,
    Image,
    TouchableOpacity } from "react-native";
import { Images, Colors, Styles, Validations } from "@common";
import { translate, setI18nConfig } from "@languages";
import { FullButton, OutlineButton, NeedHelp, LanguageSwitcher, TextWithCounter, PromoCode, ProteinSelection, InputTextString, Spinner, Toast } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { firebase } from '@react-native-firebase/analytics';

class ConfirmDetail extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            txtMobile: '',
            shiftTitle: '',
            shiftSubTitle: ''
        };
    }

    init() {
        firebase.analytics().setCurrentScreen("Confirm Exist Detail Screen");
        this.setState({ txtMobile: this.props.userDetail.mobile });
        let data = this.props.fetchData.delivery_shifts;
        if (data.length > 0) {
            for (var i = 0; i < data.length; i++) {
                if (this.props.userDetail.shift_id == data[i].value) {
                    this.setState({ shiftTitle: data[i].label, shiftSubTitle: data[i].subTitle })
                }
            }
        }
    }

    validate(param) {
        return new Promise((resolve, reject) => {
            if(param == "startdate"){
                resolve ({result : -1, nextSlide: "startdate"})
            }else{
                resolve ({result : -1, nextSlide: "address1"})
            }
        });
    }

    render() {
        return (
            <View style={styles.container}>
                <Image
                    source={Images.icons.confirmation}
                    style={styles.imglogo}
                    resizeMode="cover" />

                <Text style={styles.subtitle(this.props.userDetail.com_lang)}>{translate("txtConfirm")}</Text>
                    <View style={styles.insideContainer}>
                        <View style={styles.viewRow}>
                            <Text style={styles.headertxt(this.props.userDetail.com_lang)}>Name: </Text>
                            <Text style={styles.txtdetail(this.props.userDetail.com_lang)}>{this.props.userDetail.first_name}  {this.props.userDetail.last_name}</Text>
                        </View>

                        <View style={styles.viewMiddle}>
                            <Text style={styles.headertxt(this.props.userDetail.com_lang)}>Address: </Text>
                            <Text style={styles.txtdetail(this.props.userDetail.com_lang)}>{this.props.userDetail.area_name}, {this.props.userDetail.block_id}, {this.props.userDetail.block_name}, {this.props.userDetail.street}, {this.props.userDetail.street2}, {this.props.userDetail.avenue} </Text>
                        </View>

                        <View style={styles.viewRow}>
                            <Text style={styles.headertxt(this.props.userDetail.com_lang)}>Shift: </Text>
                            <View style={{flex:1}}>
                                <Text style={styles.txtdetail(this.props.userDetail.com_lang)}>{this.state.shiftTitle} </Text>
                                <Text style={styles.txtdetail(this.props.userDetail.com_lang)}>{this.state.shiftSubTitle} </Text>
                            </View>
                        </View>

                    </View>

                    <FullButton
                        onPress={() => this.props.ContinueOrModifyPress("startdate")}
                        btnStyle={styles.btnContinue}
                        textStyle={styles.txtFullbt(this.props.userDetail.com_lang)}
                        label={translate("Continue")} />

                    <TouchableOpacity onPress={() => this.props.ContinueOrModifyPress("address1")}>
                        <Text style={styles.txtModi(this.props.userDetail.com_lang)}>{translate("txtModify")}</Text>
                    </TouchableOpacity>

                    <Toast refrence={(refrence) => this.toast = refrence} />
                </View>
        );
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: {
            UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
        }
    };
}

const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    userDetail: state.updateUserReducer,
    fetchData: state.fetchMasterListReducer
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true})(ConfirmDetail);