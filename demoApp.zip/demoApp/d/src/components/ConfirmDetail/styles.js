import { StyleSheet, Dimensions } from "react-native";
import { Images, Styles, Colors } from "@common";
const screen = Dimensions.get("window");

export default  styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center'
    },
    viewRow:{
        flexDirection:'row',
        width:'100%',
        marginVertical:10,
        paddingVertical:10
    },
    viewMiddle:{
        flexDirection:'row',
        width:'100%',
        marginTop:0,
        paddingVertical:10
    },
    headertxt:(lang) => ({
        marginLeft:10,
        fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
        fontSize: 17,
        color: Colors.black,  
    }),
    btnContinue: {
        backgroundColor: Colors.white,
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
		borderWidth: 1,
        borderColor: Colors.white,
        height: 50,
        marginTop:0,
        marginHorizontal:screen.width*0.05,
    },
    txtModi: (lang) => ({
        fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
        fontSize: 15,
        color: Colors.white,
        marginTop: screen.height*0.05,
        alignSelf: 'center'  
    }),
    txtFullbt: (lang) => ({
        fontSize: 17,
        marginVertical:5,
        color: Colors.pinkishRed,
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
    }),
    txtdetail: (lang) => ({
        width: '70%',
        fontFamily: Styles.FontFamily(lang).proximaNova,
        fontSize: 15,
        color: Colors.black,  
    }),
    title:{
        alignSelf:'center',
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 19,
        color: Colors.white,  
        marginTop: screen.height*0.02
    },
    insideContainer:{
        marginHorizontal:screen.width*0.05,
        backgroundColor: Colors.white,
        borderRadius: 10,
        marginVertical:screen.height*0.04
    },
    subtitle: (lang) => ({
        fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
        fontSize: 22,
        color: Colors.white,  
        marginTop: 20,
        marginHorizontal:screen.width*0.05,
        alignSelf: 'center'
    }),
    continueBt:{
        width:'80%',
        alignSelf:'center',
        marginTop:30,
        backgroundColor:'black',
        alignItems:'center',
        justifyContent:'center',
    },
    txtcontinue:{
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 17,
        color: Colors.white,
        marginVertical:5
    },
    imglogo:{
        height: screen.width*0.25, 
        width: screen.width*0.25, 
        alignSelf: 'center'
    }
  });
  