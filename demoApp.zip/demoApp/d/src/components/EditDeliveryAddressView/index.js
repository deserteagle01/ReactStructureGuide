import React, { Component } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Image, FlatList, I18nManager,Dimensions } from "react-native";
import { connect } from "react-redux";
import { Styles, Colors, Images } from "@common";
import { Toast, EditAddressModal ,GradientButton,Fade,AnimatedMove,AddressShowMore,Badge} from "@components";
import { translate } from "@languages";
import moment from 'moment';
import { bindActionCreators } from "redux";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { ScrollView } from "react-native-gesture-handler";
import { getDay } from "date-fns";
const { height, width } = Dimensions.get("window");
class EditDeliveryAddressView extends Component {
	constructor(props) {
		super(props);
		this.state = {
			addresses: this.props.userInfo.addresses,
			numberAddresses:[
				'SecondAddress',
				'ThirdAddress',
				'FourthAddress',
				'FifthAddress',
				'SixthAddress',
				'SeventhAddress',
			],		
		};
		this._gotoAddressPage=this._gotoAddressPage.bind(this);
	}

	componentWillReceiveProps(nextProps) {
		if (nextProps.userInfo.addresses !== this.props.userInfo.addresses) {
			this.setState({ addresses: nextProps.userInfo.addresses });
		}
	}
	
	componentDidMount(){
		if (this.props.connected) {
			this.props.actions.MasterList.fetchDayList();
			this.props.actions.MasterList.PreloadedDataAction();
		} else {
			this.showUpdateMsg("InternetToast");
		}
	}
	_gotoAddressPage = (modalVisible, newAddAddress, item,numberOfAddress) => {
		this.props.modalAddinsideMainScreen(modalVisible, newAddAddress, item,numberOfAddress);
	}
	renderPrimary() {
		const primaryAddress = this.state.addresses[0];
		const st_date = new Date(primaryAddress.delivery_start_from);
		const current_date=new Date();
		var isAfterDate=moment(current_date).isAfter(st_date);
		const shiftId = primaryAddress.shift_id;
		
		var ShiftTime = '';
		if (this.props.deliveryItem.length > 0) {
			var selectedDeliveryShift = this.props.deliveryItem.filter(function (item) {
				return item.value == shiftId;
			})
			if (selectedDeliveryShift.length > 0) {
				ShiftTime = selectedDeliveryShift[0].label;	
			}
		}
		return (
			<View style={styles.addressBox}>
				<View style={styles.addressHeaderContainer}>
					<View style={styles.addressHeadLeft}>
						<Text numberOfLines={1} style={styles.addressHeadLeftTx}>{translate("PrimaryAddress")}</Text>
					</View>
					<TouchableOpacity style={styles.addressHeadRight} onPress={() => { this._gotoAddressPage(true, false, primaryAddress,'LetPrim') }}>
						<Text style={styles.addressHeadRightTx}>{translate("ChangeAddress")}</Text>
					</TouchableOpacity>
				</View>

				<View style={styles.addressContainer}>
					<View style={styles.addressPartTop}>
						<Text style={[styles.addressPartBottomTx,{marginBottom:5}]}>{translate("YourAddress")}</Text>
						<AddressShowMore item={primaryAddress}/>
					</View>
					<View style={[styles.addressPartBottom,{backgroundColor: isAfterDate? Colors.cardGreen : Colors.cardYellow,}]}>
						{this.renderDays(primaryAddress, "prim",ShiftTime)}
						<Text style={styles.addressPartBottomTx}>{ShiftTime? ShiftTime.toUpperCase()  : ''}</Text>
					</View>
				</View>
			</View>

		);
	}
	showUpdateMsg = (msg) => {
			if (msg == "InternetToast" || msg == "ThereSomthingWrong") {
				this.toast.show(translate(msg))
			} else {
				this.toast.show(this.props.userInfo.error)
			}
	}

	renderDays(item, type,ShiftTime) {
		var editedDaysArray = [];
		var days=this.props.daysList;
		var daysArray=item.daysArray.sort();
		var day="";
		if (days !== undefined) {
			for (i = 0; i < daysArray.length; i++) {
				for (j = 0; j < days.length; j++) {
					if (days[j].key == daysArray[i]) {
						// for display design like MON|TUE 
						day=days[j].day;
						editedDaysArray.push(translate(day));
						break;
					}
				}
			}
		}
		return(
			<View style={{flexDirection:"row"}}>
				{this.renderDay(type, editedDaysArray)}
			</View>
		);
	}
	renderDay(type, editedDaysArray) {
		if(editedDaysArray.length == 7){
		return (
			<Text style={type == "prim" ? styles.addressPartBottomGreen : styles.addressPartBottomBlack}>{translate("AllDays")}</Text>
		)
		} else {
		return editedDaysArray.map((item,index) => {		
			return (
				<Badge 
					value={item}
					badgeStyle={[styles.addressDaysBadge,type != "prim"?{backgroundColor:Colors.black}:{}]}
					textStyle={styles.addressDaysText}
					containerStyle={[styles.addressDaysContainer]} 
					key={index}/>
			);
		});
	}

	}

	addressContainerArea(item) {
		const st_date = new Date(item.delivery_start_from);
		const current_date=new Date();
		var isAfterDate=moment(current_date).isAfter(st_date);
		const addressItem = item;
		const shiftId = addressItem.shift_id;
		var ShiftTime = '';
		if (this.props.deliveryItem.length > 0) {
			var selectedDeliveryShift = this.props.deliveryItem.filter(function (item) {
				return item.value == shiftId;
			})
			if (selectedDeliveryShift.length > 0) {
				ShiftTime = selectedDeliveryShift[0].label;	
			}
		}
	
		return (
			<View style={styles.addressContainer}>
				<View style={styles.addressPartTop}>
				<Text style={[styles.addressPartBottomTx,{color:item.isDisable?Colors.colorAddressDisable:Colors.black06,marginBottom:5}]}>
						{translate("YourAddress")}</Text>
						<AddressShowMore item={item}/>
				</View>

				
				<View style={[styles.addressPartBottom,{backgroundColor:item.isDisable? Colors.paleGreyTwo : isAfterDate ?  Colors.cardGreen : Colors.cardYellow,}]}>
					
					<View style={[styles.addressContainerBelow,{}]}>
						{item.isDisable ?
							<View>
								<Text style={styles.addressPartBottomTx3Disable}>{translate("Disable")}</Text>
								<Text style={[styles.addressPartBottomTx2, { 
									color:Colors.colorReEnable
								 }]}>{translate("reEanbleAddress")}</Text></View>
							:
							<View style={[styles.bottomSecondary,{}]}>
								<View style={{flexDirection: "row"}}>
									<Text style={styles.addressPartBottomTx2}>{translate("DeliveryStartFrom")}</Text>
									<Text style={styles.addressPartBottomTx3}>{moment(st_date).format("DD MMM YYYY")}</Text>
								</View>
								<View style={{flexDirection:"row"}}>
								{this.renderDays(item, "second",ShiftTime)}
								</View>
								<Text style={styles.addressPartBottomTx}>{ShiftTime? ShiftTime.toUpperCase()  : ''}</Text>
							</View>	
						}
					</View>
				</View>
			</View>)
	}

	renderAddressCount=(i)=>{
		return(<Text  numberOfLines={1} style={styles.addressHeadLeftTx}>{
				this.state.numberAddresses!= undefined?translate(this.state.numberAddresses[i]):""}
			</Text>
		);
	
	}
	renderAddress = () => {
		return this.state.addresses.slice(1).map((item,index) => {
			return (
				<View style={styles.addressBox} key={index}>
					<View style={styles.addressHeaderContainer}>
						<View style={styles.addressHeadLeft}>
							{this.renderAddressCount(index)}
						</View>
						<TouchableOpacity style={styles.addressHeadRight} onPress={() => 
							this.props._openEditAddressModal(item,
								translate(this.state.numberAddresses[index]),
								this.props.numberAddressesEdit!==[]?this.props.numberAddressesEdit[index]:"")
								}>

							<Image
								defaultSource={Images.icons.moreHori}
								source={Images.icons.moreHori}
								style={styles.rightIcon}
							/>
						</TouchableOpacity>
					</View>
					{this.addressContainerArea(item)}
				</View>
			)
		})
	}
	render() {
		return (
			<View style={{flexDirection:"column"}}>
				<ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingHorizontal: 16}}>
					{this.renderPrimary()}
					{this.renderAddress()}		
					
				</ScrollView>
				{
					this.state.addresses.length == 1 ?<GradientButton style={styles.btnContinue}
					onPressAction={() => {this._gotoAddressPage(true, true, null,this.props.numberAddressesAdd[0])  }}
					text={translate("AddMoreAddress")} 	
					/>
							: null
				}
				<Toast refrence={(refrence) => this.toast = refrence} />
			</View>	
		);
	}
}

const styles = StyleSheet.create({
	mainContainer: {
		flex: 1,
	},
	addressBox: {
		marginBottom: 18,
		width: '100%',
		backgroundColor: Colors.white,
		alignSelf: 'center',
		borderRadius: 16,
		shadowColor: 'rgba(0, 0, 0, 0.6)',
		shadowOffset: {
			width: 0,
			height: 2,
		},
	},
	addressHeaderContainer: {
		flexDirection: 'row',
		height: 56,
		alignItems: 'center',
		borderColor: 'rgba(233, 233, 233, 0.24)',
		borderWidth: 1,
	},
	addressHeadLeft: {
		flex: 0.6,
		paddingStart: 16,
	},
	addressHeadLeftTx: {
		flex: 0.6,
		textAlign: 'left',
		color: 'rgba(38, 39, 58, 1)',
		fontSize: Styles.FontSize.fnt19,
		fontFamily: Styles.FontFamily().ProximaNovaBold,
	},
	addressHeadRight: {
		flex: 0.5,
		paddingEnd: 16,
		alignItems: "flex-end"
	},
	addressHeadRightTx: {
		textAlign: 'right',
		lineHeight: 24,
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		fontSize: Styles.FontSize.fnt17,
		color: Colors.pinkishRed
	},
	addressContainer: {
		flex: 1,
		paddingHorizontal: 16,
	},
	addressPartTop: {
		marginVertical: 16,
		flexDirection:"column"
	},
	addressPartTopTxInvisible: {
		color: 'rgba(0,0,0,0.090)',
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily().ProximaNova,
		lineHeight: 25,
	},
	addressPartTopTx: {
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily().ProximaNova,
		color: Colors.black,
		lineHeight: 25,
	},
	addressPartBottomInvisible: {
		backgroundColor: 'rgba(0,0,0,0.030)',
		zIndex: 1,
	},
	addressPartBottom: {
		marginBottom: 18,
		paddingTop:18,
		paddingBottom:18,
		backgroundColor:Colors.paleGrey,
		alignItems: 'center',
		justifyContent: 'center',
		borderRadius: 8,
		zIndex: 0,
		flexDirection:'column'
	},
	addressPartBottomTx: {
		color: Colors.black06,
		fontSize: Styles.FontSize.fnt12,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		lineHeight: 14,
	},
	addressPartBottomTx2: {
		color: Colors.black,
		fontSize: Styles.FontSize.fnt10,
		fontFamily: Styles.FontFamily().ProximaNova,
		lineHeight: 16,
	},
	addressPartBottomTx3: {
		color: Colors.orangeyYellow,
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		fontSize: Styles.FontSize.fnt10,
		lineHeight: 16,
		marginLeft: 4
	},
	addressPartBottomTx3Disable: {
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		color: Colors.black,
		fontSize: Styles.FontSize.fnt15,
		lineHeight: 21,
		marginVertical:4,
		textAlign: "center",
	},
	addressPartBottomGreen: {
		color: Colors.shamrockGreen,
		fontSize: Styles.FontSize.fnt15,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		lineHeight: 21,
		marginVertical: 4
	},
	addressPartBottomBlack: {
		color: Colors.black,
		fontSize: Styles.FontSize.fnt15,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		lineHeight: 21,
		marginVertical: 4
	},	
	addressDaysText: {
		fontSize: Styles.FontSize.fnt14,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
	},
	addressDaysContainer: {
		margin:2
	},
	addressDaysBadge: {
		backgroundColor: Colors.shamrockGreen
	},
	addressPartBottomBlack: {
		color: Colors.black,
		fontSize: Styles.FontSize.fnt15,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		lineHeight: 21,
		marginVertical: 4
	},
	btnContinue: {
		height: 56,
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
	},
	textStyle: {
		color: Colors.white,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily().ProximaNovaBold
	},
	rightIcon: {
		width: 28,
		height: 28,
	},
	bottomSecondary: {
		alignItems: 'center',
		justifyContent: 'center',
		flexDirection:"column"
	},
	addressContainerBelow: {
		flexDirection: "row",
		lineHeight: 16,
	},
	
});

const mapStateToProps = (state) => {
	return {
		userInfo: state.updateUserReducer,
		connected: state.updateNetInfoReducer.isConnected,
		deliveryItem: state.fetchMasterListReducer.delivery_shifts,
		daysList: state.fetchMasterListReducer.daysList,
		days:state.fetchMasterListReducer.days,
		numberAddressesAdd:state.fetchMasterListReducer.numberAddressesAdd,
		numberAddressesEdit:state.fetchMasterListReducer.numberAddressesEdit,
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}
export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(EditDeliveryAddressView);
