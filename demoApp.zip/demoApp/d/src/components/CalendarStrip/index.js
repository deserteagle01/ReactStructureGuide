import React, { Component, PureComponent } from "react";
import { View, StyleSheet, Text, Image, TouchableOpacity, FlatList, Animated } from "react-native";
import { ProductRateModel } from "@components";
import { Images, Styles, Colors, Constants } from "@common";
import { translate } from "@languages";
import moment from 'moment';
import 'moment/locale/ar';
import 'moment/locale/en-gb';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as mealsAction from "../../redux/Actions/mealsAction";
import FastImage from 'react-native-fast-image'
var Deferred = require('promise-deferred');

class CalendarStrip extends PureComponent {
	constructor(props) {
		super(props);
		this.state = {
			dateArr:[]
		}
		this.iconArr = {
			'choose-meal': Images.icons.ChooseMeal,
			'choose-filled': Images.icons.ChooseMealFilled,
			'delivered': Images.icons.Delivered,
			'meal-assign': Images.icons.MealAssign,
			'off': Images.icons.Off,
			'pause': Images.icons.Pause,
			'prepare': Images.icons.Prepare,
			'rate': Images.icons.Rate,
		};
		this.dateArr = [];
		this.date = this.props.date;
		this.status_deferred=undefined;
	}

	componentDidMount() {
		if (this.props.onRef) {
			this.props.onRef(this);
		}
	}

	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

	componentWillReceiveProps(nextProps){
		if(this.props.date !== nextProps.date){
			this.getDateArray(nextProps.date, nextProps);
		} else if(this.props.mealsDetail.userProduct[this.props.date] !== nextProps.mealsDetail.userProduct[this.props.date]){
			this.changeDateIcon(this.props.date,nextProps.mealsDetail.userProduct[this.props.date].status);
		}
		if(this.props.mealsDetail.action_type != nextProps.mealsDetail.action_type && nextProps.mealsDetail.action_type == "FETCH_USER_PRODUCT_PLAN_SUCCESS"){
			this.setCalendarData(nextProps.date, nextProps);
		}
	}

	componentWillMount() {
		this.getDateArray(this.props.date, this.props);
	}

	dateBeoforeAfterDay(date, dateVal, format) {
		return moment(date).add(dateVal, 'days').lang("en-gb").format(format);
	}

	setCalendarData(date, nextProps){
		this.dateArr = [];
		for(let i = -3; i <= 3 ; i++){
			let status = (nextProps.mealsDetail.userProduct[this.dateBeoforeAfterDay(date, i, Constants.dateFormate)] != undefined ? nextProps.mealsDetail.userProduct[this.dateBeoforeAfterDay(date, i, Constants.dateFormate)].status : undefined);
			let obj = {
				date: this.dateBeoforeAfterDay(date, i, 'D'),
				val: i,
				status: status,
			}
			this.dateArr.push(obj);
		}
		this.setState({dateArr: this.dateArr},()=>{
			this.date = date;
		});
	}

	getDateArray(date, nextProps) {
		this.setCalendarData(date, nextProps);
		let isStatusundefined = this.dateArr.filter(el => el.status === undefined);
		if(isStatusundefined.length > 0){
			this.fetchNextDateData(date);
		}
	}

	changeDateIcon(date,newStatus){
		let dateVal = this.dateBeoforeAfterDay(date, 0, 'D');
		let dateForIconChange = this.dateArr.filter(el => el.date == dateVal);
		if(dateForIconChange.length > 0){
			dateForIconChange[0].status = newStatus || dateForIconChange[0].status;
			this.setState({dateArr: [...this.dateArr]});
		}
	}

	fetchNextDateData(date){
		let end_date;
		let start_date;
		start_date = moment(date).add(-3, 'days').format(Constants.dateFormate);
		end_date = moment(date).add(3, 'days').format(Constants.dateFormate);
		let params = {
			'start_date': start_date,
			'end_date': end_date,
			'expand': true
		}
		this.props.actions.Meal.fetchUserProductList(false, params, date);
	}
	
	onDateClick(val){
		date = this.dateBeoforeAfterDay(this.date, val, Constants.dateFormate);
		if (this.props.mealsDetail.userProduct[date] != undefined && this.props.mealsDetail.userProduct[date].status &&
			this.props.mealsDetail.userProduct[date].status != "off") {
				this.props.onDateClick(date);
		}
	}

	_dateItem = ({ index, item }) => {
		let width = Styles.width / 7 - 1;
		let backColor = Colors.white;
		let borderWidth = 0;
		let sideBorderColor = Colors.white;
		let iconColor = Colors.battleshipGrey;
		let textColor = Colors.battleshipGrey;
		let	dateIcon = this.iconArr[item.status != undefined ? item.status : ''];

		if (index == 3) {
			backColor = Colors.pinkishRed;
			borderRadius = 8;
			width = 44;
			iconColor = Colors.white;
			textColor = Colors.white;
			dateIcon = this.iconArr[item.status == 'choose-meal' ? 'choose-filled' : item.status];
		}
		if (index == 0 || index == 1 || index == 4 || index == 5) {
			sideBorderColor = Colors.warmGrey10;
			borderWidth = 1;
		}

		return (
			<TouchableOpacity key={Math.random() * index * 999} style={[styles.calenderItemView, { backgroundColor: backColor, width: width }]} onPress={() => this.onDateClick(item.val)}>
				<View style={styles.calenderDateTextView}>
					<Text style={[styles.calenderDateText, { color: textColor }]}>{item.date}</Text>
				</View>
				<View style={[styles.calenderDateIconView, { borderRightColor: sideBorderColor, borderRightWidth: borderWidth }]}>
					{dateIcon != undefined &&
						<FastImage
							source={dateIcon}
							tintColor={item.status == 'rate' ? Colors.orangeYellow : iconColor}
							style={styles.calenderDateIcon} />
					}
				</View>
			</TouchableOpacity>
		);
	}

	_keyExtractor = (item, index) => index.toString();
	render() {
		return (
			<FlatList
				contentContainerStyle={styles.calendarListView}
				horizontal={true}
				scrollEnabled={false}
				data={this.state.dateArr}
				extraData={this.state}
				keyExtractor={this._keyExtractor}
				renderItem={this._dateItem}
			/>
		);
	}
}

const styles = StyleSheet.create({
	calendarContainer: {
		top: 80,
		position: 'absolute',
		width:'100%',
		height: 44,
		backgroundColor: Colors.white,
		shadowColor: Colors.warmGrey,
		shadowOffset: {
			width: 0,
			height: 2
		},
		borderTopWidth: 0,
		shadowRadius: 10,
		shadowOpacity: 0.3,
		elevation: 5
	},
	calendarListView: {
		backgroundColor: Colors.white,
		alignSelf: 'center',
		justifyContent: 'center',
		alignItems: 'center'
	},
	calenderItemView:{borderRadius:8,height:36,margin:1,justifyContent:'center'},
	calenderDateTextView:{top:2,right:5,padding:0,position:'absolute'},
	calenderDateText:{fontSize:10, fontFamily: Styles.FontFamily().ProximaNova},
	calenderDateIconView:{height:24,alignItems:'center',justifyContent:'center'},
	calenderDateIcon:{width:18,height:18},
});

const mapStateToProps = (state) => {
	return {
		mealsDetail: state.mealsReducer,
	};
};

function mergeProps(stateProps, dispatchProps, ownProps) {
        const { dispatch } = dispatchProps;
        return {
            ...ownProps,
            ...stateProps,
            actions: {
				mealsAction: bindActionCreators(mealsAction, dispatch),
				Meal: mealsAction.bindActionCreators(dispatch, stateProps),
            }
    	};
}
export default connect(mapStateToProps, undefined, mergeProps)(CalendarStrip);
