import { StyleSheet, Dimensions } from "react-native";
import { Images, Styles, Colors } from "@common";
const screen = Dimensions.get("window");

export default  styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
    },
    title: (lang) => ({
        marginTop:screen.height*0.14,
        fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
        fontSize: 22,
        color: Colors.white,
    }),
    insideContainer:{
        width:'100%',
        //alignItems: 'center',
    },
    txtpass:{
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 17,
        color: Colors.black,
        width:'80%',
        marginTop:10,
        borderColor:'black',
        borderWidth:1,
        padding:5
    },
    btnContinue: {
        width:'100%',
		backgroundColor: Colors.white,
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
		borderWidth: 1,
        borderColor: Colors.white,
        height: 50,
        marginTop:20
    },
    seprator: {
        width:'100%',
        height: 0,
        marginTop: screen.height * 0.03,
    },
    continueBt:{
        width:'80%',
        marginTop:15,
        backgroundColor:'black',
        alignItems:'center',
        justifyContent:'center'
    },
    txtcontinue: (lang)  => ({
        fontSize: 17,
        marginVertical:5,
        color: Colors.pinkishRed,
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
    }),
    orTxt:{
        marginTop:screen.height*0.05,
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 20,
        color: Colors.white,
        alignSelf: 'center'
    },
    txtForget: (lang) => ({
        marginTop:screen.height*0.05,
        fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
        fontSize: 14,
        color: Colors.white,
        alignSelf: 'center'
    }),
    modal:{
        height:140,
    },
  });
  