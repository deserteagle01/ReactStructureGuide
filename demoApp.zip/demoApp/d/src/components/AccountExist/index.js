import React, { Component, PureComponent } from "react";
import {
    View,
    Text,
    StyleSheet,
    ImageBackground,
    StatusBar,
    SafeAreaView,
    TouchableOpacity,
    Dimensions
} from "react-native";
import { connect } from "react-redux";
import { Styles, Colors, Images } from "@common";
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import { firebase } from '@react-native-firebase/analytics';
import HTTP from "../../webservice/http";
import styles from "./styles";
import {  InputTextString, Spinner, Toast, SimpleMessageModal, FullButton, ChoosePlanModal } from "@components";
import * as UpdateUser from "../../redux/Actions/updateUserAction";
const { height, width } = Dimensions.get("window");

class AccountExist extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            txtPassword: '',
            txtMobile: ''
        };
    }

    componentDidMount(){
        
    }

    init() {
        firebase.analytics().setCurrentScreen("Account Exist Screen");
        this.setState({txtMobile: this.props.userDetail.mobile});
    }

    onClose = () => {
        this.refs.simpleMessageModal.toggleModal(false);
    };

    validate(param) {
        return new Promise((resolve, reject) => {
        if(param == "ConfirmDetail") {
        if (this.state.txtPassword.length > 4) {
            if (this.props.Connected) {
                this.props.actions.UpdateUser.UserLoginAction(this.state.txtMobile, this.state.txtPassword).then(() => {
                    if (this.props.userDetail.error) {
                        this.refs.simpleMessageModal.toggleModal(true,this.props.userDetail.error,translate("Error"));
                        resolve ({result :0})
                    } else {
                        firebase.analytics().logEvent("login", {method: "OTP Password"});
                        var reqParam = {
                            password: this.state.txtPassword,
                            isLogin: true
                        }
                        this.props.actions.UpdateUser.updateUserDetails(reqParam);	// Update this field value only});
                        HTTP.setNumberandPassword(this.state.txtMobile, this.state.txtPassword);
                        if(this.props.planData.is_book_appointment){
                            resolve ({result : 0})
                            this.props.navigation.navigate('Appointment1', {isDirectlyOpenPayment:  true});
                        }else{
                            if(this.props.userDetail.plan_data.warning_list.length > 0){
                                resolveReferralUserCase = () => {
                                    resolve ({result : -1, nextSlide: "confirmdetail"})
                                } 
                                this.refs.refChoosePlanModal.show("referralUserExists");
                            }
                            else{
                                resolve ({result : -1, nextSlide: "confirmdetail"})    
                            }
                        }
                    }
                })
            } else {
                this.toast.show(translate("InternetToast"));
                resolve ({result :0})
            }
        }
        else {
            this.refs.simpleMessageModal.toggleModal(true,"Please select Password 5 or more character",translate("Error"));
            resolve ({result :0})
        }
    }
    else{
        resolve ({result : -1, nextSlide: "forgetpass"});
    }
    });
}
    
render() {
        return (
            <View style={styles.container}>

                        <Text style={styles.title(this.props.userDetail.com_lang)}>{translate("alreadyExistTitle")} </Text>

                        <View style={styles.insideContainer}>
                            <View style={styles.seprator} />

                            <InputTextString
                                textHandler={(text) => this.setState({ txtPassword: text })}
                                refName={"street"}
                                errorMsg={this.state.singUpStreetError}
                                inputText={this.state.txtPassword}
                                placeholderText={translate("passwordplaceholder")}
                                inputAccessoryViewID={"street"}
                                lang={this.props.userDetail.com_lang}
                                returnKeyEvent={(refIndex) => console.log('')} 
                                styless={this.props.userDetail.com_lang == 'ar' ? Styles.common.globalArabictxt:Styles.common.globalEnglishtxt } />

                            <FullButton
                                onPress={() => this.props.onContinueClick("ConfirmDetail")}
                                btnStyle={styles.btnContinue}
                                textStyle={styles.txtcontinue(this.props.userDetail.com_lang)}
                                label={translate("Continue")} />

                            

                            <TouchableOpacity onPress={() => this.props.onContinueClick("sendOTP")}>
                                <Text style={styles.txtForget(this.props.userDetail.com_lang)}>{translate("txtforget")}</Text>
                            </TouchableOpacity>

                        </View>
                        {this.renderChoosePlanModal()}
                        <Toast refrence={(refrence) => this.toast = refrence} />
                        <SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} modalStyle={styles.modal} />
                    </View>
        );
    }

    renderChoosePlanModal() {
        return (
            <ChoosePlanModal {...this.props}
                ref="refChoosePlanModal" navigation ={this.props.navigation}
                onContinue = {() => resolveReferralUserCase()}
                onModalClose = {() => console.log("close call")} />
        )
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: {
            UpdateUser: bindActionCreators(UpdateUser, dispatch),
        }
    };
}

const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    userDetail: state.updateUserReducer,
    planData: state.PlanReducer
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true})(AccountExist);