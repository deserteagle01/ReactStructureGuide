import React, { PureComponent } from "react";
import { connect } from "react-redux";
import ProductListScreen from "../../screens/ProductListScreen";
 import Model from "react-native-modal";
import {Modal, Platform,DeviceEventEmitter } from "react-native";
class ProductListModal extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            is_model_visible: false,
            selectedDate: null
        };
        this.modelAnimationOut = Platform.OS === 'android' ? 'slideOutDown' : 'fadeOut';
    }
    show(newSelectedDate){
        this.setState({
            is_model_visible: true,
            selectedDate: newSelectedDate || this.state.selectedDate
        });
    }
    hide = () => {
         this.setState({ is_model_visible: false });
    }
    onDateChange = (newSelectedDate) => {
        this.setState({
            selectedDate: newSelectedDate || this.state.selectedDate
        });
    }
    render(){
        return (
            <Model
                hideModalContentWhileAnimating={true}
                useNativeDriver={true}
                isVisible={this.state.is_model_visible}
                style={{ margin: 0}}
                animationIn={'fadeIn'}
                animationOut={this.modelAnimationOut}
                onBackButtonPress={()=>{
                    this.setState({is_model_visible: false});
                }}
            >
             <ProductListScreen selectedDate={this.state.selectedDate} onDateChange={this.onDateChange} closeModel={this.hide}/>
            </Model>
        );
    }
}
export default connect(null, null, null, { forwardRef: true})(ProductListModal);