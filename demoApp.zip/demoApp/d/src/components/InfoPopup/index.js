import React, { PureComponent } from "react";
import { Animated, Dimensions, View, Text, Image, StyleSheet, TouchableOpacity } from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const { height, width } = Dimensions.get("window");
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Appointment from "../../redux/Actions/Appointment";
import { languageNameGetter} from "../../common/Utility";
import Modal from "react-native-modal";
import HTML from 'react-native-render-html';
import {CachedImage} from "react-native-img-cache";
class InfoPopup extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            isVisible: false,
            currentInfo: {}
        };
    }

    componentDidMount() {   
        
    }

    show(currentInfo) {
        this.setState({currentInfo: currentInfo, isVisible: true});
    }

    hide() {
        this.setState({isVisible:false});
    }

   
     render() {
        return (
            <Modal
                    hasBackdrop
                    isVisible={this.state.isVisible}
                    hideModalContentWhileAnimating={true}
                    transparent={true}
                    backdropOpacity={0.8}
                    useNativeDriver={true}
                    style={styles.modalStyle}
                    onBackdropPress={() => this.hide()}
                    onModalHide = {() => this.hide()}>

                    <View style={styles.ModalContainer} >
                        <CachedImage
                          defaultSource={Images.placeholder}
                          source={{ uri: this.state.currentInfo.image_url }}
                          style={styles.proimg} />

                        <TouchableOpacity style={styles.closeBt} onPress={() => this.setState({isVisible: false})}>
                            <Image
                                resizeMode="contain"
                                source={Images.icons.closeBox}
                                style={styles.closeImg} />
                        </TouchableOpacity>

                        <Text style={styles.infoTitle}>{ this.props.getData(this.state.currentInfo,"name") }</Text>
                        <View style={styles.expContainer}>
                            <Text style={styles.txtprofession}>{ this.props.getData(this.state.currentInfo,"job_title") }</Text>
                            <Text style={styles.txtExperience}>{ translate("Exp")+" "+ this.state.currentInfo.experience+"+"+" "+ translate("Yearss") }</Text>
                        </View>
                        <View style={styles.seprator}></View>
                        <Text style={styles.txtAboutMe}>{translate("aboutme")}</Text>

                        <HTML 
                            containerStyle={styles.txtMulti} 
                            html={this.props.getData(this.state.currentInfo,"about_me_info")}  />
                        <View style={styles.seprator2}></View>
                    </View>
                </Modal>
        )
    }
}

const styles = StyleSheet.create({
	closeBt: {
        alignSelf: 'flex-end',
        margin: 16
    },
    closeImg: {
        height: 28,
        width: 28,
    },
    seprator:{
        width:'100%',
        height: 1,
        backgroundColor:'rgba(0, 0, 0, 0.08)',
        marginVertical: 16
    },
    seprator2:{
        height:34,
        width:'100%'
    },
    infoTitle:{
        marginVertical: 8,
        marginHorizontal:'10%',
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        color: Colors.black,
        fontSize: 24,
        alignSelf:'flex-start',
    },
    txtprofession: {
        marginHorizontal:'10%',
        fontFamily: Styles.FontFamily().ProximaNova,
        color: Colors.black,
        fontSize: 14,
    },
    txtExperience: {
        fontFamily: Styles.FontFamily().ProximaNova,
        color: Colors.black,
        fontSize: 12,
        marginHorizontal:'5%'
    },
    expContainer:{
        justifyContent:'space-between',
        alignItems:'center',
        flexDirection: 'row', 
        width:'100%',
    },
    txtAboutMe:{
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        color: Colors.lightBlack,
        fontSize: 12,
        marginHorizontal:'10%',
        marginVertical: 16
    },
    ModalContainer: {
        position:'absolute',
        bottom: 34,
        backgroundColor: Colors.white,
        width:'90%',
        borderRadius: 24,
        marginHorizontal: '5%'
    },
    txtMulti:{
        marginHorizontal:'10%',
        flexDirection:"column",
    },
    modalStyle:{
        padding:0, 
        margin:0,
      },
    row: {
        marginHorizontal: 16, 
        borderRadius: 16, 
        flexDirection: 'row', 
        alignItems:'center',
        paddingVertical: 8,
        borderColor: Colors.cardBorder,
        borderWidth: 1.0,
    },
   proimg:{
        position:'absolute',
        top:-48,
        height: 96,
        width: 96,
        borderRadius: 48,
        left: width * 0.08
    },
});


function mapDispatchToProps(dispatch) {
    return {
      actions: {
        Appointment: bindActionCreators(Appointment, dispatch),
      }
    };
  }
  
  const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    appointmentData: state.appointmentReducer,
    getData: languageNameGetter(state)
  });

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(InfoPopup);


