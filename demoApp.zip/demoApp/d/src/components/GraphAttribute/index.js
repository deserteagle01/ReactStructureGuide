import React, { Component } from "react";
import { View, Text, StyleSheet,Platform, I18nManager,Dimensions, Image, TouchableOpacity } from "react-native";
import { connect } from "react-redux";
import { Styles, Colors, Images } from "@common";
import { translate } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
const { height, width } = Dimensions.get("window");

class GraphAttribute extends Component {
	otpRef = React.createRef();
	constructor(props) {
		super(props);
		this.state = {
			
		};
	}

	componentDidMount() {

	}

    render() {
        const {title, color, amount, diffrence, unit} = this.props;
        return (
			<View style={styles.container}>
                <View style={styles.topContainer}>
                    <Text style={styles.txtTitle}>{title}</Text>
                    <View style={styles.colorView(color)}></View>
                </View>
                <Text style={styles.txtamount}>{amount} {unit}</Text>
                {diffrence != 0 ?
                    <Text style={styles.txtDiffrence}>{diffrence} {unit}</Text>
                    :
                    <Text style={styles.txtDiffrence}></Text>
                }
                
                
            </View>
		);
	}
}

const styles = StyleSheet.create({
	inputStyle:{
		textAlign:'center',
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize: 25,
		width:'100%',
		height:'100%',
    },
    container:{
        borderRadius:8, 
        borderColor:Colors.lightGray, 
        borderWidth: 1,
        width: (width-64)/3,
        backgroundColor:Colors.white,
		shadowColor: 'rgba(0,0,0,0.12)',
		shadowOffset: { width: 0, height: 3 },
		shadowRadius: 7,
		shadowOpacity: 0.8,
        elevation: 6,
    },
    txtTitle:{
        textAlign:'center',
		fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 11,
        flex:1,
        color: "rgba(0,0,0,0.6)"
    },
    txtamount:{
        textAlign:'center',
		fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 17,
        alignSelf: 'center',
        color: Colors.darkGray,
        marginHorizontal:width*0.05
    },
    txtDiffrence: {
        textAlign:'center',
		fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 12,
        alignSelf: 'center',
        color: Colors.diffTxt,
        marginVertical:8
    },
    colorView:(color) => ({
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor:color ? color : "red",
        alignItems: 'flex-end',
        position:'absolute',
        right: 8
    }),
    topContainer:{
        flexDirection: 'row', 
        marginVertical: 8, 
        alignItems: 'center',
    },
	txtResend: (lang) => ({
		textAlign: lang == "ar" ? "right" : "left",
		fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
		fontSize: 16,
	}),
});

const mapStateToProps = (state) => ({
	Connected: state.updateNetInfoReducer.isConnected,
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(GraphAttribute);

