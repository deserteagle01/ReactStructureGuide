import React, { Component } from "react";
import { Animated , Dimensions,Easing} from 'react-native';
import { connect } from "react-redux";
const { height, width } = Dimensions.get("window");

class AnimatedMove extends Component {
  componentWillMount() {
    this.animatedValue = new Animated.Value(this.props.animate ? 1 : 0);
    this.fromSize = null;
    this.toSize = null;
    this.duration = 350;
    this.heightAnimatedValue = null;
    this.fromHeight = null;
    this.toHeight = null;
    this.widthAnimatedValue = null;
    this.fromWidth = null;
    this.toWidth = null;
  }

  componentWillReceiveProps(nextProps) {
    if(this.props!=nextProps) {
      let animations = [];
      if (nextProps.fromSize){
        this.fromSize = nextProps.fromSize;
      }
      if (nextProps.fromHeight){
        this.fromHeight = nextProps.fromHeight;
      }
      if (nextProps.toHeight){
        this.toHeight = nextProps.toHeight;
      }
      if (nextProps.fromWidth){
        this.fromWidth = nextProps.fromWidth;
      }
      if (nextProps.toWidth){
        this.toWidth = nextProps.toWidth;
      }
      
      if (nextProps.toSize){
        this.toSize = nextProps.toSize;
      }
      if (nextProps.duration){
        this.duration = nextProps.duration;
      }
      animations.push(Animated.timing(this.animatedValue, {
        toValue: nextProps.animate?1:0,
        duration: this.duration ,
        easing: Easing.linear
      }));
      if(this.fromHeight|| this.toHeight){
        if(nextProps.animate || this.heightAnimatedValue!=null){
          if(this.heightAnimatedValue==null) {
            this.heightAnimatedValue = new Animated.Value(nextProps.animate?this.fromHeight:this.toHeight);
          }
          animations.push(Animated.timing(this.heightAnimatedValue, {
            toValue: nextProps.animate?this.toHeight:this.fromHeight,
            duration: this.duration ,
            // easing: Easing.linear
          })); 
        }
      }
      if(this.fromWidth|| this.toWidth){
        if(this.widthAnimatedValue==null) {
          this.widthAnimatedValue = new Animated.Value(nextProps.animate?this.fromWidth:this.toWidth);
        }
        Animated.timing(this.widthAnimatedValue, {
          toValue: nextProps.animate?this.toWidth:this.fromWidth,
          duration: this.duration ,
          // easing: Easing.linear
        }).start();  
      }      
      if(animations.length>0){
        Animated.parallel(animations).start();
      }
    }
  }

  render() {
    const { visible, style, children, ...rest } = this.props;
    const transform = [];
    if("height" in this.props){
      transform.push({
        translateY: this.animatedValue.interpolate({
          inputRange: [0, 1],
          outputRange: [0, this.props.height]
        })
      });
    } 
    if("width" in this.props){
      transform.push({
        translateX: this.animatedValue.interpolate({
          inputRange: [0, 1],
          outputRange: [0, this.props.width]
        })
      });
    } 
    if(this.fromSize || this.toSize){
      transform.push({
        scaleX: this.animatedValue.interpolate({
          inputRange: [0, 1],
          outputRange: [this.fromSize, this.toSize]
        })
      });
      transform.push({
        scaleY: this.animatedValue.interpolate({
          inputRange: [0, 1],
          outputRange: [this.fromSize, this.toSize]
        })
      });  
    }
    
    const animatedStyle = {};
    if(transform.length>0) {
      animatedStyle.transform = transform;
    }
    if(this.heightAnimatedValue){
      animatedStyle.height = this.heightAnimatedValue;
    }
    if(this.widthAnimatedValue){
      animatedStyle.marginHorizontal = this.widthAnimatedValue;
    }

    const combinedStyle = [];
    if(style){
      combinedStyle.push(style);
    }
    if(animatedStyle){
      combinedStyle.push(animatedStyle);
    }
    
    return (
      <Animated.View style={combinedStyle} {...rest}>
        {children}
      </Animated.View>
    );
  }
}
const mapStateToProps = (state) => ({
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(AnimatedMove);

