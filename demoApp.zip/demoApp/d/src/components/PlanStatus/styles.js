import { StyleSheet, Dimensions, Platform, I18nManager } from "react-native";
import { Images, Styles, Colors } from "@common";
import { FontScalling } from '../../common/Utility';

const screen = Dimensions.get("window");
export default styles = StyleSheet.create({
	cardMain: { 
		marginHorizontal:16,
		flexDirection: "row",
		height:(screen.height*114)/812,	
		backgroundColor: Colors.white,
		borderRadius: 16,
	},
	cardBook:{
		marginTop:16,
		marginHorizontal:16,
		flexDirection: "row",
		height:(screen.height*114)/812,	
		paddingVertical:16,
		backgroundColor: Colors.white,
		borderRadius: 16,
	},
	// left card style
	planPay: {
		justifyContent: 'flex-end',
		height: "50%",
	},
	planLeftSection: {
		width: "64.73%",
		paddingStart: "4.46%",
	},
	planLeftBookSection:{
		width: "84.73%",
		paddingStart: "4.46%",
	},
	subContainer:
	{
		justifyContent: 'center',
		height: "50%"
	},
	changeAllow:
	{
		textAlign: "left",
		color: Colors.pinkishRed,
		fontSize: 14,
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		justifyContent: 'center',
		alignItems: 'center'
	},
	reNewStyle: {
		height: "50%",
		textAlign: "left",
		color: Colors.pinkishRed,
		fontSize: FontScalling(17, 4),
		fontFamily: Styles.FontFamily().ProximaNovaBold
	},
	reNewStyleNew: {
		fontSize: FontScalling(17, 4),
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		color: Colors.pinkishRed,
		height: "100%",
		alignItems: 'center',
		justifyContent: 'center',
	},
	reNewRedStyle: {
		// marginTop: 16
	},
	subscriptionBottom: {
		height: "50%",
		flexDirection: 'row'
	},
	subscriptionBookBottom: {
		marginTop: 10,
		height:"33.33%",
		// paddingTop:8,
	},
	subscriptionBookBottomAppointment:{
		height:"33.33%",
	},
	rightSideShimmer:{
		width:"80%", 
		height:"100%", 
		borderRadius: 10
	},
	shimmerBorder:{
		borderRadius:2
	},
	rightSectionShimmer:{
		height:"70%", 
		width:"70%", 
		alignItems:'center', 
		justifyContent:'center'
	},
	fullrightSectionShimmer:{
		height: "100%", 
		width: "100%", 
		borderRadius: 10
	},	
	subEnd: {
		color: Colors.black06,
		fontSize: FontScalling(14, 4),
		fontFamily: Styles.FontFamily().ProximaNova,
	},
	endDate: {
		color: Colors.black06,
		fontSize: FontScalling(14, 4),
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		left: 5,
	},
	subTitleStyle: {
		color: Colors.black08
	},

	planRenewDivider: {
		width: 1,
		height: "80%",
		alignSelf: "center",
		backgroundColor: Colors.whiteTwo
	},
	plannewDivider: {
		height: '90%',
		width: 1,
		backgroundColor: Colors.whiteTwo,
		marginHorizontal: 8,
	},
	// option change plan
	currentTxt: {
		color: Colors.black04,
		fontSize: FontScalling(12, 2),
		fontFamily: Styles.FontFamily().ProximaNova,
		textAlign: 'left',
		alignItems: 'center',
		justifyContent: "center"
	},
	currentTxtShimmer:{
		height: "25%",
	},
	currentTxtTop:{
		//height: "33.33%",
		color: Colors.black04,
		fontSize: FontScalling(12, 2),
		fontFamily: Styles.FontFamily().ProximaNova,
		textAlign: 'left',
		alignItems: 'center',
		justifyContent: "center"
	},
	currentTxtTopView:{
		height: "33.33%",
	},
	shimmercurrentTxtTop:{
		alignItems: 'center',
		justifyContent: "center",
		borderRadius:2
	},
	ChangePlan: {
		flexDirection: "row",
		alignItems: 'center',
		height: '100%',
	},
	ChangePlanMainView:{
		height: '50%',
		justifyContent: 'center',
	},
	bodyTxt: {
		fontSize: 13,
		fontFamily: Styles.FontFamily().ProximaNova,
		color: Colors.black08,
		alignSelf: "flex-start",
	},
	bodyTxtShimmer:{
		height: "25%",
	},
	rightArrow: {
		width: 16,
		height: 16,
		height: "100%",
		marginLeft:8,
		alignSelf: 'center',
	},
	allowChange:
		{ paddingTop: 0, height: "100%", textAlign: "left" },
	// right card style
	planRightSection: {
		width: "34.98%",
		alignItems: "center",
		justifyContent: "center",
		flexDirection:"column",
	},
	planRightSectionBook:{
		width: "31.27%",
		alignItems: "center",
		justifyContent: "center",
		flexDirection:"column",
	},
	circleDays:{
		alignItems:"center",
		justifyContent:"center",
		width:(screen.height * 78) / 812,
		height:(screen.height * 78) / 812,
		aspectRatio: 1,
		borderRadius: 150 / 2,
		flexDirection: "column", 
		position: 'absolute',
	},
	payButtonView: {
		width: "65%",
		aspectRatio: 1,
		alignItems: 'center',
		justifyContent: 'center'
	},
	payButton: {
		height: "100%",
		aspectRatio: 1,
		borderRadius: 150 / 2,
		alignItems: "center",
		justifyContent: "center",
		flexDirection: 'column',
	},
	outlineBtnText: {
		alignItems: "center",
		justifyContent: 'center',
		color: Colors.white,
		fontSize: FontScalling(25, 4),
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold
	},
	daysLeft: {
		fontSize: 21,
		color: Colors.pinkishRed,
		alignSelf:"center",
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
	},
	daysText: {
		fontSize: 10,
		fontFamily: Styles.FontFamily().ProximaNova,
		color:Colors.brownishGrey,
		opacity:0.5,
	},
	datePlan:
	{
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		color: Colors.brownishGrey,
		fontSize: 8,
		height: 14,
	},
	typePlanStyle: {
		paddingTop: 16,
		paddingBottom: 10,
	},
	reNewStyle2: {
		color: Colors.pinkishRed,
		fontSize: 15,
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		justifyContent: "center",
		alignItems: 'center',
	},
	centerText:{
		flexDirection:"row",
		alignItems:"center",
		justifyContent:"center",
	},
	changeRenew:
	{
		flexDirection: "row",
		alignItems: 'center',
		fontSize: FontScalling(17, 4),
		fontFamily: Styles.FontFamily().ProximaNova, color: Colors.pinkishRed
	},
	newChangePlan: {
		alignItems: 'center',
		justifyContent: 'center',
	},
	newChangePlanShimmer: {
		position:'absolute',
		width:"100%",

	},
	// wallet
	walletIcon:{
		alignSelf:"center",
		width:(screen.height*60)/812,
		height:(screen.height*60)/812,
		tintColor:Colors.pinkishRed
	},
	walletBottomData:{
		fontSize:16,
		color: Colors.black,
		lineHeight:25,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
	},
	infoIcon:{
		width:(screen.height*16)/812,
		height:(screen.height*16)/812,
		marginLeft:4,
		alignItems:"center",
		justifyContent:"center",
	},
	subEndWallet: {
		textAlign:"left",
		alignItems:"center",
		lineHeight:20,
		color: Colors.black06,
		fontSize: FontScalling(12, 4),
		fontFamily: Styles.FontFamily().ProximaNova,
	},
	subEndAppoint:{
		textAlign:"left",
		alignItems:"center",
		justifyContent:"center",
		lineHeight:20,
		color: Colors.black06,
		fontSize: 12,
		fontFamily: Styles.FontFamily().ProximaNova,
	},
	subContainerWallet:
	{
		//height:"33.33%",
		flexDirection:"row",
		alignItems:"center",
		//justifyContent:'center',
		//backgroundColor:'yellow'
	},
	subContainerWalletAppointment:
	{
		height:"33.33%",
		flexDirection:"row",
		marginTop: 13,
		//backgroundColor:'red'
		//justifyContent:'center',
	},
	subContainerWalletShimmer:{
		//flexDirection:"row",
		//alignItems:"center",
		//justifyContent:'center'
		borderRadius:2
	},
	upComingWallet:{
		color: Colors.black,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		alignItems:"center",
		justifyContent:"center",
		height:"100%",
		fontSize:12,
	},
	txtdate:{
		color: Colors.black,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize:24,
		marginLeft:-10
	},
	typePlanStyleWallet:{
		width: "68.73%",
		paddingStart: "4.46%",
	},
	inviteFrd:{
		alignItems:"center",
		justifyContent:"center",
	},
	walletCenterStyle: {
		textAlign:"center",
		color: Colors.pinkishRed,
		fontSize: 15,
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		// height: "100%",
	},
});