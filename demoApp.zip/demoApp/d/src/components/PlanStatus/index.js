import React, { Component } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet, I18nManager, ImageBackground, Circle,TouchableWithoutFeedback,Dimensions } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import {AnimatedCircularProgress, Shimmer }from '@components';
import { Styles, Images, Colors,Utility } from "@common";
import styles from './styles';
import moment from 'moment';
import { translate, setI18nConfig } from "@languages";
const screen = Dimensions.get("window");
import { convertToLocalDatetime} from "../../common/Utility";
export default class PlanStatus extends Component {

    constructor(props) {
        super(props);
    }
    renderWallet = (planType) => {
        return(
            <TouchableWithoutFeedback onPress={() => {
                this.props.onPress();
            }}>
            <View style={styles.cardBook}>
             
                <View style={styles.typePlanStyleWallet}>
                        <View style={styles.currentTxtTopView}>
                        <Shimmer style={styles.shimmercurrentTxtTop} visible={!this.props.isShimmer}>
                        <Text style={styles.currentTxtTop}>
                                {translate("Wallet")}
                        </Text>
                        </Shimmer>
                        </View>
                        
                        
                        <Shimmer style={styles.subContainerWalletShimmer} visible={!this.props.isShimmer}>
                            <View style={styles.subContainerWallet}>
                                <TouchableOpacity onPress={()=>this.props.goToInviteFriends()}>
                                    <Text style={styles.walletCenterStyle}>{translate("InviteFriends")}</Text>
                                </TouchableOpacity>    
                                <TouchableOpacity onPress={()=>this.props.addCompanyInfo()} style={styles.inviteFrd}>
                                    {!this.props.isShimmer &&
                                        <Image source={Images.icons.info_ic} style={styles.infoIcon} />
                                    }
                                </TouchableOpacity>
                            </View> 
                        </Shimmer>
                       
                        
                        <View style={styles.subscriptionBookBottom}>
                        <Shimmer visible={!this.props.isShimmer} style={styles.shimmerBorder}>
                            <Text style={styles.subEndWallet}>
                                {translate("YouInvited")}
                                {this.props.homeData.referred_by_count}
                                {translate("Friends")}
                            </Text>
                        </Shimmer>
                        </View>
                        
                </View>
                <View style={styles.planRightSectionBook}>
                    <Shimmer visible={!this.props.isShimmer} style={styles.rightSideShimmer}>
                        <Image source={Images.icons.wallet} style={styles.walletIcon} />         
                        <Text style={styles.walletBottomData}>
                            {parseFloat(this.props.totalAmount).toFixed(2)+" "+translate("KD")}
                        </Text>
                    </Shimmer>
                </View>
             </View>
             </TouchableWithoutFeedback>
        )
    }
    renderBookAppoint = (planType) => {
        return(
            <TouchableWithoutFeedback onPress={
                () => this.props.onPress()}
            >
            <View style={styles.cardBook}>
                <View style={styles.typePlanStyleWallet}>
                        <Shimmer visible={!this.props.isShimmer} style={styles.shimmerBorder}>
                            <Text style={styles.currentTxtTop}> { this.props.firstAppointmentDate.length > 0 ? translate("txtyouearb") : translate("CONSULTATION") }</Text>
                        </Shimmer>
                        <View style={styles.subContainerWalletAppointment}>
                            <Shimmer visible={!this.props.isShimmer} style={styles.shimmerBorder}>
                            <Text style={this.props.firstAppointmentDate.length > 0 ? styles.txtdate :styles.upComingWallet} numberOfLines={1}>  {this.props.firstAppointmentDate.length > 0 ?  convertToLocalDatetime(this.props.firstAppointmentDate,"DD-MMMM-YYYY") : translate("NoUpcomingAppointments") }</Text>
                            </Shimmer>
                        </View>
                        <View style={styles.subscriptionBookBottomAppointment}>
                            <Shimmer visible={!this.props.isShimmer} style={styles.shimmerBorder}>
                            <Text style={styles.subEndAppoint}>{this.props.firstAppointmentDate.length > 0 ? translate("txtFirststr") : translate("ClickForBookAppoint") }</Text>
                            </Shimmer>
                        </View>
                    </View>
                    
                <View style={styles.planRightSectionBook}>
                    <Shimmer visible={!this.props.isShimmer} style={styles.rightSideShimmer}>
                    <Image source={Images.icons.meeting} style={styles.walletIcon} />
                    </Shimmer>
                </View>
             </View>
             </TouchableWithoutFeedback>
        )
    }

    centerPanel() {
        return (
            <View style={styles.planRenewDivider}>
            </View>);
    }
    rightPanel() {
        const end_date = new Date(this.props.homeData.plan_end_date);
        var size = parseInt(screen.height * 86 / 812);
        var fill_multiplier = this.props.homeData.days_remaining / this.props.homeData.total_days_plan;
        return (
            <View style={styles.planRightSection}>
                <View style={styles.rightSectionShimmer}>
                {
                    this.props.isShimmer ?
                    <Shimmer style={styles.fullrightSectionShimmer} visible={!this.props.isShimmer}>
                    </Shimmer> :
                    <AnimatedCircularProgress
                    style={styles.circleDays}
                    rotation={180}
                    size={size}
                    width={4}
                    fill={100 * fill_multiplier}                    
                    isClockwise={true}
                    segments={16}
                    beginColor={"#ff6e00"}
                    endColor={Colors.pinkishRed}
                    duration={1000 + (1500 * fill_multiplier)}
                    backgroundColor={Colors.pinkishRed24}
                    linecap="round"
                    >
                    {fill => (<View style={styles.circleDays}>
                        <Text style={styles.daysLeft}>
                            {this.props.homeData.days_remaining}
                        </Text>
                        <Text style={styles.daysText} numberOfLines={1}>
                            {translate("DaysLeft")}
                        </Text>
                        <Text style={styles.datePlan} numberOfLines={1}>
                            {moment(end_date).format("DD-MM-YY")}
                        </Text>
                    </View>
                    )}
                </AnimatedCircularProgress>

                }
                </View>
            </View>)

    }
    renderPay = (planType) => {
        const {
            allow_payment,
            allow_change_plan,
            allow_renew,
            plan_name,
            plan_name_ar,lang
        } = this.props.homeData;
        const { onPress } = this.props;
        if (allow_payment == true) {
            return <View style={styles.cardMain}>
                {/* left panel */}
                <View style={styles.planLeftSection}>
                    <View style={styles.subContainer}>
                        <Text style={[styles.reNewStyle, styles.reNewRedStyle]}>
                            {translate("RenewPlan")}
                        </Text>
                    </View>
                    <View style={styles.subContainer}>
                        <View style={styles.subscriptionBottom}>
                            <Text style={styles.subEnd}>
                                {translate("SubscripEnd")}
                            </Text>
                            <Text style={styles.endDate}>
                                {moment(new Date(this.props.homeData.plan_end_date)).format("DD MMM YYYY")}

                            </Text>
                        </View>
                    </View>
                </View>
                {this.centerPanel()}

                {/* right panel */}
                <View style={styles.planRightSection}>
                    <TouchableOpacity onPress={() => onPress("pay")}>
                        <View style={styles.payButtonView}>
                            <LinearGradient colors={[Colors.pinkishRed, Colors.brightOrange]}
                                style={styles.payButton}>
                                <Text style={styles.outlineBtnText}>
                                    {translate("Pay")}
                                </Text>
                            </LinearGradient>
                        </View>
                    </TouchableOpacity>

                </View>
            </View>
        }
        else if (allow_renew == true || allow_change_plan == true) {
            return (
                <View style={styles.cardMain}>
                    <View style={styles.planLeftSection}>
                        <View style={styles.typePlanStyle}>
                            <View style={styles.currentTxtShimmer}>
                            <Shimmer visible={!this.props.isShimmer} style={styles.shimmerBorder}>
                            <Text style={styles.currentTxt}>{translate("CurrentPlan")}</Text>
                            </Shimmer>
                            </View>
                            <View style={styles.bodyTxtShimmer}>
                                <Shimmer visible={!this.props.isShimmer} style={styles.shimmerBorder}>
                                    <Text style={styles.bodyTxt}>{plan_name}</Text>
                                </Shimmer>
                            </View>
                            
                            <View style={styles.ChangePlanMainView}>
                            <Shimmer visible={!this.props.isShimmer} style={styles.shimmerBorder}>
                            <View style={styles.ChangePlan}>

                            <TouchableOpacity style={styles.newChangePlan} onPress={() => allow_renew ? onPress("renew") : onPress("changePlan") }>
                                <Text style={styles.reNewStyle2}>{allow_renew ? translate("Renew") : translate("ChangePlan")}</Text>
                            </TouchableOpacity>

                            { allow_renew && allow_change_plan ?
                                        <View style={styles.plannewDivider}></View>
                                    :
                                        <Image
                                            resizeMode="contain"
                                            resizeMethod={"resize"}
                                            source={Images.icons.redRightArrow}
                                            style={styles.rightArrow} />
                            }

                            { allow_renew && allow_change_plan &&
                                <TouchableOpacity style={styles.newChangePlan} onPress={() => onPress("changePlan")}>
                                    <Text style={styles.changeRenew}>{translate("ChangePlan")}</Text>
                                </TouchableOpacity>
                            }
                            </View>
                            </Shimmer>
                            </View>
                        </View>
                    </View>

                    {this.centerPanel()}
                    {this.rightPanel()}
                </View>
            );
        }
    }

    renderPlanStatus(){
        if (this.props.type == "planChange") {
            return (
                    this.renderPay(this.props.type)
            )
        }
        else if(this.props.type == "wallet"){
            return(
                
                    this.renderWallet(this.props.type)
               
            )
        }
        else if(this.props.type == "bookAppoint"){
            return(
                this.renderBookAppoint(this.props.type)
                )
        }else{
            return(null);
        }
    }
    render() {
        return(<View>

            {this.renderPlanStatus()}
            </View>)
    }
}



