import React, { Component } from "react";
import { View, Text, StyleSheet, Platform, Keyboard, Dimensions, Animated, Image } from "react-native";
import { connect } from "react-redux";
import { Styles, Validations, Colors } from "@common";
import InputTextString from "../InputTextString"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { firebase } from '@react-native-firebase/analytics';
import InputAccessory from "../InputAccessory";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const { height, width } = Dimensions.get("window");
import Images from "../../common/Images";
import ButtonOk from  "../ButtonOk";
import { TouchableOpacity } from "react-native-gesture-handler";
class SignupFamilyName extends Component {
	constructor(props) {
		super(props);
		this.state = {
			singUpFamilyName: "",
			singUpFamilyNameError: null
		};
	}

	componentDidMount(){
		
	}

	init(){
		firebase.analytics().setCurrentScreen("Signup FamilyName Screen");
		this.setState({
			singUpFamilyName: this.props.signupDetail.last_name,
			singUpFamilyNameError: null
		});
	}

	textHandler = (text) => {
		this.setState({ singUpFamilyName: text })
	}

	validate(param) {
		return new Promise((resolve, reject) => {
		let option = { fullMessages: false };
		let singUpFamilyNameError = Validations('reqField', this.state.singUpFamilyName, option);
		this.setState({ singUpFamilyNameError: singUpFamilyNameError })
		if (!singUpFamilyNameError) {
			const { updateSignupDetails } = this.props;
			const reqParams = {
				last_name: this.state.singUpFamilyName,   // Update this field value only
			};
			this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
			firebase.analytics().logEvent("checkout_progress", {checkout_step: "Signup FamilyName Screen"});
			resolve ({result: 1});
		}else{
			resolve ({result: 0});
		}
	});
	}

	onDownArrowClicked(refs){
		this.validate();
	}
	
	onUpArrowClicked(refs){
		this.props.gotoPrev();
    }
	
	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView enableOnAndroid={true} keyboardShouldPersistTaps={'always'}>
					<View>
						<Text style={this.props.signupDetail.com_lang == 'ar' ? [styles.label(this.props.signupDetail.com_lang), Styles.common.globalArabictxt] : styles.label(this.props.signupDetail.com_lang)}>{translate("Hey")} {this.props.signupDetail.first_name} {translate("TellMeYourFamilyName")}</Text>
					</View>
					<View style={styles.inputNameContainer}>
						<InputTextString autoFocus={false} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)} textHandler={this.textHandler} errorMsg={this.state.singUpFamilyNameError} inputText={this.state.singUpFamilyName} placeholderText="" inputAccessoryViewID={"familyName"}
							styless={ [styles.inputlabel(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt : Styles.common.globalEnglishtxt] } />
					</View>
					{this.state.singUpFamilyName.length > 0 &&
					<TouchableOpacity onPress={this.props.onOkClick}>
						<ButtonOk  lang={this.props.signupDetail.com_lang} />
					</TouchableOpacity>
					}
				</KeyboardAwareScrollView>
				{Platform.OS == 'ios' &&
					<InputAccessory inputAccessoryViewID={"familyName"} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} onUpArrowClick={() => this.onUpArrowClicked('familyName')} onDownArrowClick={() => this.onDownArrowClicked('familyName')}/>
				}
			</View>
		);
	}	
}

const styles = StyleSheet.create({
	detailContainer: {
		flex:1
	},
	label: (lang) => ({
		marginTop: height*0.14,
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		textAlign: 'left'
	}),
	inputlabel: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
	}),
	inputNameContainer: {
		marginTop: 36,
	},
});

const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}
export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SignupFamilyName);