import React, { PureComponent } from "react";
import { InfoPopup, Toast, Fade, GradientButton, Shimmer } from "@components";
import { Animated, Dimensions, View, Text, FlatList, Image, StyleSheet, TouchableOpacity } from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const { height, width } = Dimensions.get("window");
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Appointment from "../../redux/Actions/Appointment";
import { languageNameGetter, convertToLocalDatetime} from "../../common/Utility";
import {CachedImage} from "react-native-img-cache";
class AvailableDietition extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            selected: null,
            strDate: "",
            strTime: ""
        };
    }

    componentDidMount() {   
        setTimeout(() => {
            this.getFirstAvailableData();
        }, 300);
    }

    getFirstAvailableData() {
        if (this.props.Connected) {
            this.props.actions.Appointment.getAvailableDietition(false)
        }
        else {
            this.toast.show(translate("InternetToast"));
        }
    }

    componentWillReceiveProps(nextProps){
        if(this.props.appointmentData != nextProps.appointmentData){
            if(nextProps.error != null){
                this.toast.show(nextProps.error)
            }
            if(nextProps.type == "AVAILABLE_DIETITION_SUCCESS"){
                this.props.updateHeight(this.props.appointmentData.availableList.length);        
            }
        }
    }


    _renderItem = ({ item, index }) => {
        var strUTC = this.props.getData(item,"datetime");
        var time = convertToLocalDatetime(strUTC,'h:mm A');
        var date = convertToLocalDatetime(strUTC,'DD MMMM YYYY');
        const { isFetching } = this.props;
        return (
            <TouchableOpacity style={styles.row} onPress={() => this.setState({selected: index, strDate: date, strTime: time})}>
                <Shimmer style={styles.profileImg} visible={!isFetching}>
                <CachedImage
                    source={{url: item.image_url}}
                    style={styles.profileImg} />
                </Shimmer>
                <View style={{flex:1}}>
                    {   index == this.state.selected ?
                        <Text style={styles.optionalTitle}>{this.props.getData(item,"name")}</Text>
                    :
                    <Shimmer style={styles.firstlineView} visible={!isFetching}>
                        <View style={styles.firstlineView}>
                            <Text style={styles.optionalTitle}>{ time }</Text>
                            <View style={styles.sepratorView}></View>
                            <Text style={styles.datetxt}>{ date }</Text>
                        </View>
                    </Shimmer>
                    }
                    <Shimmer style={styles.optionalSubtitle(false)} visible={!isFetching}>
                        <Text style={this.state.selected == index ? styles.optionalSubtitle(true) :styles.optionalSubtitle(false) }>{index == this.state.selected ? this.props.getData(item,"job_title") : translate("withDr")+" "+this.props.getData(item,"name") }</Text>
                    </Shimmer>
                </View>

                {this.state.selected == index && 
                    <Image
                        resizeMode="contain"
                        source={Images.icons.leftCheckedOrange}
                        style={styles.infobt} />
                    
                }
            </TouchableOpacity>
        );
    }
    
    _renderSeparator() {
        return(
            <View style={{height:16}}>
            </View>
        );
    }

    bookDietition() {
        this.props.onSubmitAppointment(this.props.appointmentData.availableList[this.state.selected].id);
    }

    render() {
        return (
            <View style={{ flex: 1 }}>
                <FlatList
                    style={styles.flatliststyle}
                    data={this.props.appointmentData.availableList}
                    showsVerticalScrollIndicator={false}
                    renderItem={this._renderItem}
                    ItemSeparatorComponent={this._renderSeparator}
                    keyExtractor={(item, index) => index.toString()}
                    extraData={this.state} />

                    <Fade remove={this.state.selected == null } visible={this.state.selected!=null} duration={300} style={{flex:0.3}}>
                        <View style={styles.bottomContainer}>
                            <Text style={styles.datetimetxt}>{this.state.strDate + " "+ translate("at") + " " + this.state.strTime}</Text>
                            <View style={styles.btnBook}>
                                <GradientButton
                                    onPressAction={() => this.bookDietition()}
                                    text={translate("BookApointment")}/>
                            </View>
                        </View>
                    </Fade>

                <Toast refrence={(refrence) => this.toast = refrence} />
            </View>
        )
    }
}

const styles = StyleSheet.create({
	flatliststyle: {
        flex:1,
    },
    row: {
        marginHorizontal: 16, 
        borderRadius: 16, 
        flexDirection: 'row', 
        alignItems:'center',
        paddingVertical: 8,
        borderColor: Colors.cardBorder,
        borderWidth: 1.0,
    },
    optionalTitle: {
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 17,
        color: Colors.black,
        marginLeft:  0,
        alignSelf:'flex-start'
    },
    firstlineView:{
        flexDirection: 'row', 
        alignItems:'center'
    },
    sepratorView:{
        marginHorizontal: 4,
        height: '70%', 
        width: 1, 
        backgroundColor: "rgb(216, 216, 216)"
    },
    datetxt: {
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 17,
        color: Colors.black,
    },
    bottomContainer:{
        position:'absolute', 
        bottom: 0,
        width: '100%', 
        alignItems:'center',
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        backgroundColor:Colors.white,
        shadowColor: '#000',
        shadowOffset: { width: 4, height: 5 },
        shadowRadius: 10,
        shadowOpacity: 0.25,
        elevation: 2,
    },
    btnBook:{
        justifyContent: 'center',
        marginBottom: 40,
        width: '100%',
    },
    datetimetxt: {
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 13,
        color: Colors.black08,
        marginVertical:16
    },
    availabletxt:{
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 13,
        color: Colors.pinkishRed,
        marginLeft: 0,
        alignSelf:'flex-start'
    },
    optionalSubtitle: (isSelected) =>  ({
        marginVertical: 4,
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 13,
        color: isSelected ? Colors.lightBlack : Colors.black,
        marginLeft: 0,
        alignSelf:'flex-start'
    }),
    infobt:{
        marginHorizontal: 16,
        
    },
    calender: {
        width: 80,
        height: 80,
        tintColor:Colors.pinkishRed,
        marginLeft:16
    },
    profileImg: {
        height: 80,
        width: 80,
        borderRadius: 40,
        marginHorizontal: 16
    },
});


function mergeProps(stateProps, dispatchProps, ownProps) {
        const { dispatch } = dispatchProps;
        return {
            ...ownProps,
            ...stateProps,
            actions: {
                Appointment: Appointment.bindActionCreators(dispatch , stateProps),
            }
        };
}
  
  const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    appointmentData: state.appointmentReducer,
    isFetching: state.appointmentReducer.isLoadingForAvailable,
    error: state.appointmentReducer.error,
    type: state.appointmentReducer.type,
    getData: languageNameGetter(state)
  });
  
  export default connect(mapStateToProps, undefined, mergeProps, { forwardRef: true })(AvailableDietition);



