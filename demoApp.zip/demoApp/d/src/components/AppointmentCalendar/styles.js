import { StyleSheet, Dimensions ,Platform} from "react-native";
import { Colors, Styles } from "@common";
const dimensionsWidth = Dimensions.get('window').width;
const dimensionsHeight = Dimensions.get('window').height;

export default  styles = StyleSheet.create({
    
    container: {
        flex:1,
    },
    calDateRow:{
        flexDirection: 'row',
        paddingHorizontal: 5,
        width: dimensionsWidth,
        height: 68,
    },
    calDateContainer:{
        backgroundColor: Colors.white,
        paddingStart: 0,
        paddingEnd: 0,
    },
    emptyscrollContainer: {
        flexGrow: 1,
    },
    flatliststyle:{
        width:'100%',
    },
    strSelected: {
        marginVertical: 16,
        color: Colors.black08,
        fontSize: 13,
        fontFamily: Styles.FontFamily().ProximaNova,
        textAlign: 'center',
    },
    bottomContainer: {
        position: "absolute",
        bottom: 0,
        width: '100%',
        backgroundColor: Colors.white,
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        shadowColor: '#000',
        shadowOffset: { width: 4, height: 5 },
        shadowRadius: 10,
        shadowOpacity: 0.12,
        elevation: 2,
    },
    notificationBtnCont:{
        marginBottom: 34,
		shadowColor: Platform.OS === 'ios'?'rgba(0, 0, 0, 0.12)':'#f6f6f6',
        shadowOffset: {
            width: 0,
            height: 12,
        },
        shadowOpacity: Platform.OS === 'ios'?0.1: 0.01,
        shadowRadius: Platform.OS === 'ios'?16:50,
        elevation: Platform.OS === 'ios'?5:10,
	},
    txtTime:{
        marginBottom: 16,
        color: Colors.black,
        fontSize: 15,
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
        textAlign: 'center',
    },
    calDayTitleView: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 7,
        marginVertical: 0,
        borderRightWidth: 1,
        borderColor: 'rgba(106, 109, 122, 0.1)',
    },
    calDayTitle: {
        color: "rgba(106, 109, 122,0.6)",
        fontSize: 14,
        fontFamily: Styles.FontFamily().ProximaNova,
        lineHeight: 18,
        width: (dimensionsWidth / 7) - 5,
        textAlign: 'center',
    },
    calDayContainer:{
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 5,
        backgroundColor: Colors.white,
    },
    calMonthContainer:{
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: Colors.white,
    },
    inactiveMonth:{
        color: 'rgba(255, 255, 255, 0.4)',
        fontSize: 15,
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    },
    activeMonth:{
        color: Colors.pinkishRed,
        fontSize: 17,
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    },
});
