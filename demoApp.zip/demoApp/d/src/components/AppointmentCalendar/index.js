import React, { PureComponent } from "react";
import { InfoPopup, Toast, Fade, GradientButton, AppointmentBox, SlotBox } from "@components";
import { CalendarList } from '../../lib/react-native-calendars/index';
import { Animated, Dimensions, View, Text, FlatList, Image, StyleSheet, ScrollView, TouchableOpacity, InteractionManager } from "react-native";
import { Images, Styles, Colors, Constants } from "@common";
import { translate, setI18nConfig } from "@languages";
const { height, width } = Dimensions.get("window");
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Appointment from "../../redux/Actions/Appointment";
import { languageNameGetter, convertToLocalDatetime} from "../../common/Utility";
import Moment from 'moment';
import styles from "./styles";
import LinearGradient from 'react-native-linear-gradient';

const theme = {
	'stylesheet.calendar.header': {
		header: {
			...styles.calMonthContainer
		},
		monthText: {
			...styles.activeMonth
		},
		week: {
			...styles.calDayContainer
		},
		dayHeader: {
			...styles.calDayTitleView,...styles.calDayTitle,
			textTransform: 'uppercase'
		},
	},
	'stylesheet.calendar.main': {
		container: {
			...styles.calDateContainer,
		},
		monthView: {
			paddingTop: 9,
			paddingBottom: 8,
			paddingStart: 2,
			paddingEnd: 3,
            height: 455,
        },
		week: {
			...styles.calDateRow
		}
	},
	'stylesheet.calendar-list.main': {
		calendar: {
			paddingLeft: 0,
      		paddingRight: 0
		}
    }
};

class AppointmentCalendar extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            calendarData: [],
            currentDate: null
        };
        this.startCounter = 0;
        this.endCounter = 3;
        this.currentMonth = 0;
    }

    componentDidMount() {   
        let strCurrentMonth = Moment(new Date()).format("YYYY-MM-DD");
        this.dateInitialization(strCurrentMonth);
    }

    dateInitialization(strCurrentMonth) {
        var date = new Date();
        var firstDay = new Date(date.getFullYear(), date.getMonth() + this.startCounter, 1);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + this.endCounter, 0);
        lastDay.setHours(23);
        lastDay.setMinutes(59);
        lastDay.setSeconds(59);
        let strFirstday = Moment.utc(firstDay).format("YYYY-MM-DD HH:mm:ss");   
        let strLAstday = Moment.utc(lastDay).format("YYYY-MM-DD HH:mm:ss");   
        this.getCalendarData([this.props.item.dietitian_id], strFirstday, strLAstday, strCurrentMonth);
    }

    getCalendarData(dietitionId,startDate, endDate, strCurrentMonth) {
        let params = { dietitian_id: dietitionId, start_date: startDate, end_date: endDate };
        if (this.props.Connected) {
            this.props.actions.Appointment.getDietitionCalendar(false, params, strCurrentMonth);
        }
        else {
            this.toast.show(translate("InternetToast"));
        }
    }

    componentWillReceiveProps(nextProps){
        if(this.props.appointmentData != nextProps.appointmentData){
            if(nextProps.appointmentData.errorDietitionCalendar != null){
                this.toast.show(nextProps.appointmentData.errorDietitionCalendar);
            }
            if(nextProps.appointmentData.type == "CALENDAR_DIETITION_SUCCESS"){
                //this.setState({ calendarData: this.props.appointmentData.calendarList});
                console.log("~~~~API called from inside calendar view~");
            }
        }
    }

    _handleChange(months) {
        InteractionManager.runAfterInteractions(() => { 
        if(months.length > 0) {
            if(this.currentMonth == 0) {
                this.currentMonth = months[0].month;
            }
            else{
                this.props.actions.Appointment.clearSelectedDate();
                var strCurrentMonth = Moment(months[0].dateString).format('YYYY-MM-DD');


                let tempCalendarMonth = months[0].month + (months[0].year * 12);
                let currentdate = new Date();
                let month = 1 + Moment(currentdate, 'YYYY/MM/DD').month();
                let year = Moment(currentdate, 'YYYY/MM/DD').year();
                let tempCurrentMonth = month + (year * 12);
                

                this.startCounter =  tempCalendarMonth - tempCurrentMonth;
                this.endCounter = 3 + (tempCalendarMonth - tempCurrentMonth);

                

                 this.dateInitialization(strCurrentMonth);
                 this.currentMonth = months[0].month;
                
            }
        }
        }); 
    }

    onPressBook() {
        this.props.onSubmitAppointment(this.props.appointmentData.slotList[this.props.appointmentData.selectedTimeSlot].id);
    }

   _renderDayComponent = ({date, state}) => {
        return (
            <AppointmentBox boxDate={Moment(date.dateString, Constants.dateFormate).toDate()} dietitionId={this.props.item.dietitian_id}/>
        );
    }

    _renderItem = ({ item, index }) => {
            return(
              <SlotBox  item={item} index={index}/>
            );
    }

    _renderSeparator() {
        return(
            <View style={{width: width*0.03}}>
            </View>
        );
    }

    render() {
        return (
            <View style={styles.container}>
                <ScrollView contentContainerStyle={styles.emptyscrollContainer} showsVerticalScrollIndicator={false}>
                   <CalendarList
						onVisibleMonthsChange={(months) => this._handleChange(months)}
						pastScrollRange={0}
						futureScrollRange={10}
						scrollEnabled={true}
						horizontal={true}
						dayComponent={({date, state}) => {
                            return this._renderDayComponent({date, state})
						}}
						theme={theme}
						calendarHeight={455}
						pagingEnabled={true}
						current={this.state.currentDate || null}
						loadingIndicatorText = {translate("Loading")} />
                    {
                        this.props.appointmentData.slotList && this.props.appointmentData.slotList.length > 0 &&
                        <View style={{marginTop: 0}}>
                            <Text style={styles.txtTime}>{translate("txtAppointmentTime")}</Text>
                            <View style={{marginHorizontal: 16}}>
                                <FlatList
                                    style={styles.flatliststyle}
                                    horizontal={true}
                                    data={this.props.appointmentData.slotList}
                                    showsHorizontalScrollIndicator={false}
                                    renderItem={this._renderItem}
                                    ItemSeparatorComponent={this._renderSeparator}
                                    keyExtractor={(item, index) => index.toString()}
                                    extraData={this.state} />
                                    <View style={{height:150, width:'100%'}}></View>
                            </View>
                        </View>
                    }
                    
                    </ScrollView>           

                {
                    this.props.appointmentData.selectedTimeSlot != null && this.props.appointmentData.slotList.length >= this.props.appointmentData.selectedTimeSlot + 1   &&
                    <View style={styles.bottomContainer}>
                        <Text style={styles.strSelected}>{convertToLocalDatetime(this.props.appointmentData.slotList[this.props.appointmentData.selectedTimeSlot].start_datetime, "DD MMMM YYYY") +" "+ translate("at") +" "+ convertToLocalDatetime(this.props.appointmentData.slotList[this.props.appointmentData.selectedTimeSlot].start_datetime, "hh:mm A") }</Text>
                        <View style={styles.notificationBtnCont}>
                            <GradientButton 
                                onPressAction={() => this.onPressBook()}
							    text={translate("BookApointment")} />
					    </View>
                    </View>
                }
                
                <Toast refrence={(refrence) => this.toast = refrence} />
            </View>
        )
    }
}

function mergeProps(stateProps, dispatchProps, ownProps) {
    const { dispatch } = dispatchProps;
    return {
        ...ownProps,
        ...stateProps,
        actions: {
            Appointment: Appointment.bindActionCreators(dispatch, stateProps),
        }
    };
}

  const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    appointmentData: state.appointmentReducer,
    getData: languageNameGetter(state)
  });
  
export default connect(mapStateToProps, undefined, mergeProps, { forwardRef: true })(AppointmentCalendar);