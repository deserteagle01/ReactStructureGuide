import React, { Component } from "react";
import { View, Text, StyleSheet, Platform, Dimensions, Animated } from "react-native";
import { connect } from "react-redux";
import InputTextString from "../InputTextString"
import { Styles, Validations, Colors, Images } from "@common";
import {Fade} from "@components";
import InputSelectionPicker from "../InputSelectionPicker"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { firebase } from '@react-native-firebase/analytics';
import InputAccessory from "../InputAccessory";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { communicationNameGetter} from "../../common/Utility";
const { height, width } = Dimensions.get("window");
class SignupAddress extends Component {
	constructor(props) {
		super(props);
		this.state = {
			singUpArea: "",
			singUpAreaError: null,
			singUpBlock: "",
			singUpBlockError: null,
			singUpFilterBlock: [],
		};
		this.inputRefs = {};
	}

	componentDidMount() {
	}

	async init() {
		firebase.analytics().setCurrentScreen("SignupDeliveryAddress");
		var filterBlock = []
		filterBlock = this.props.blockItem.filter(item => {
			return item.area_id == this.props.signupDetail.area_id
		})
		let areaItem = [];
		this.props.governorate_areas.forEach((governate)=> {
			areaItem.push({
				label: governate.gover_name,
				label_ar: governate.gover_name_ar
			});
			governate.gover_areas.forEach((area)=>{
				areaItem.push(area);
			});
		});

		let finalState = {
			singUpAreaError: null,
			singUpBlockError: null,
			singUpFilterBlock: filterBlock

		};
		if(this.state.singUpArea!=this.props.signupDetail.area_id){
			finalState.singUpArea = this.props.signupDetail.area_id;
		}
		if(this.state.singUpBlock!=this.props.signupDetail.block_id){
			finalState.singUpBlock = this.props.signupDetail.block_id;
		}
		finalState.areaItem = areaItem;
		await this.setState(finalState);
	}

	selectedAreaHandler = (item) => {
		let filterBlock = [];
		let text = item && item.value;
		if(text) {
			filterBlock = this.props.blockItem.filter(item => {
				return item.area_id == text
			});
		}
		let finalState = {singUpAreaError:"",singUpArea: text, singUpFilterBlock: filterBlock};
		if(text!=this.state.singUpArea) {
			finalState.singUpBlockError = "";
			finalState.singUpBlock = "";
		}
		this.setState(finalState);
	}

	selectedBlockHandler = (item) => {
		this.setState({ singUpBlockError:"",singUpBlock: item && item.value })
		if(item) {
			setTimeout(()=>{
				this.props.gotoNext();
			},50);
	
		}
	}

	validate() {
		return new Promise((resolve, reject) => {
		let option = { fullMessages: false };
		let singUpAreaError = Validations('reqField', this.state.singUpArea, option);
		let singUpBlockError = Validations('reqField', this.state.singUpBlock, option);
		this.setState({ singUpAreaError: singUpAreaError, singUpBlockError: singUpBlockError });
		if (!singUpAreaError && !singUpBlockError) {
			const reqParams = {
				area_id: this.state.singUpArea,
				block_id: this.state.singUpBlock,				
			};
			this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
			firebase.analytics().logEvent("checkout_progress", {checkout_step: "Signup Address"});
			resolve({result: 1});
		}
		else{
			resolve({result: 0});
		}
	});
	}

	render() {
		this.props.singUpLoading(this.props.isLoading);
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView enableOnAndroid={true} extraScrollHeight={Platform.OS === 'ios' ? 50 : 100} keyboardShouldPersistTaps={'always'}>
					<View>
						<Text style={this.props.signupDetail.com_lang  == 'ar' ?  [styles.label(this.props.signupDetail.com_lang), Styles.common.globalArabictxt]: styles.label(this.props.signupDetail.com_lang)}>{translate("YourDeliveryAddressarea")}</Text>
					</View>
					<View style={[styles.inputNameContainer]}>
						<InputSelectionPicker
							ref = {"area"}
							value = {this.state.singUpArea}
							data = {this.state.areaItem}
							onSelectItem = {(item) => this.selectedAreaHandler(item)}
							valueExtractor = {(item) => this.props.getCName(item,"label")}
							placeholder={translate("SelectArea")}
							style = {{color:Colors.white, fontFamily:Styles.FontFamily(this.props.signupDetail.com_lang).ProximaNova}}
							lang={this.props.signupDetail.com_lang}
							errorMsg = {this.state.singUpAreaError?translate(this.state.singUpAreaError):""}
							isGroupView={true}
						/>		
					</View>
					
					<View style={[styles.blockstyle]}>
						<Fade visible={this.state.singUpArea || this.state.singUpBlock}>
							<InputSelectionPicker 
								ref={"block"}
								value = {this.state.singUpBlock}
								data = {this.state.singUpFilterBlock}
								onSelectItem = {(item) => this.selectedBlockHandler(item)}
								placeholder={translate("Block")}
								style = {{color:Colors.white, fontFamily:Styles.FontFamily(this.props.signupDetail.com_lang).ProximaNova}}
								lang={this.props.signupDetail.com_lang}
								errorMsg = {this.state.singUpBlockError?translate(this.state.singUpBlockError):""}
							/>
						</Fade>
					</View>
					
				</KeyboardAwareScrollView>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		textAlign: 'left',
		marginTop: height*0.14,
	}),
	inputNameContainer: {
		marginTop: 44,
	},
	blockstyle:{
		marginTop:10
	}
});

const mapStateToProps = (state) => {
	return {
		isLoading: state.fetchMasterListReducer.isLoading,
		signupDetail: state.updateUserReducer,
		governorate_areas: state.fetchMasterListReducer.governorate_areas,
		blockItem: state.fetchMasterListReducer.blocks,
		connected: state.updateNetInfoReducer.isConnected,
		getCName: communicationNameGetter(state),		
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SignupAddress);
