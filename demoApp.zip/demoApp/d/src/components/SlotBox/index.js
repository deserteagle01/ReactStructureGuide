import React, { PureComponent } from "react";
import { Animated, Dimensions, View, Text, Image, StyleSheet, TouchableOpacity } from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const { height, width } = Dimensions.get("window");
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Appointment from "../../redux/Actions/Appointment";
import { languageNameGetter, convertToLocalDatetime} from "../../common/Utility";
import Modal from "react-native-modal";
import HTML from 'react-native-render-html';
import {CachedImage} from "react-native-img-cache";
import LinearGradient from 'react-native-linear-gradient';
const dimensionsWidth = Dimensions.get('window').width;
const dimensionsHeight = Dimensions.get('window').height;

class SlotBox extends PureComponent {
    constructor(props) {
        super(props);
        
    }

    componentDidMount() {   
        
    }

    render() {
        const { item, index } = this.props;
        var time = convertToLocalDatetime(item.start_datetime, "h:mm");
        var lastState = convertToLocalDatetime(item.start_datetime, "a");
        return (

            this.props.appointmentData.selectedTimeSlot == index ?

                <LinearGradient colors={[Colors.pinkishRed, Colors.brightOrange]} style={styles.linearGradient}>
                    {this._renderSlotButton(time,lastState,item, index, true)}
                </LinearGradient>
            :
                
            this._renderSlotButton(time,lastState,item, index, false)

        );
    }

    _renderSlotButton(time,lastState, item, index, isGradient) {
        return(
            <TouchableOpacity disabled={item.state != "available" ? true: false } style={styles.timeView} onPress={() => this.onPressSlot(item, index)}>
                <Text style={[styles.txtTimestate, isGradient && {color: Colors.white}, item.state != "available" && styles.txtStrike]}>{time}</Text>
                <Text style={[styles.txtAM, isGradient && {color: Colors.white}]}>{lastState}</Text>
            </TouchableOpacity>
        );
    }

    onPressSlot(item, index) {
        let param = {
            selectedTimeSlot: index
        }
        this.props.actions.Appointment.updateSelecteDate(param);
    }
}

const styles = StyleSheet.create({
    txtStrike:{
        textDecorationLine: 'line-through', textDecorationStyle: 'solid',
        color: "rgb(179,179,185)",
        fontSize: 15,
        fontFamily: Styles.FontFamily().ProximaNova,
        textAlign: 'center',
    },
    txtAM:{
        marginTop:0,
        marginBottom: 9,
        color: Colors.amColor,
        fontSize: 12,
        fontFamily: Styles.FontFamily().ProximaNova,
        textAlign: 'center',
    },
    txtTimestate:{
        marginTop:15,
        marginHorizontal: 20,
        color: Colors.black,
        fontSize: 15,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        textAlign: 'center',
    },
    linearGradient:{
        borderRadius: 6,
        shadowColor: 'rgba(0, 0, 0, 0.6)',
        shadowOffset: { width: 0, height: 8 },
        shadowRadius: Platform.OS === 'ios'?16:32,
        shadowOpacity: 0.24,
        elevation: Platform.OS === 'ios'?5:10,
    },
	timeView: {
        borderRadius: 6,
        borderWidth: 1,
        borderColor: "rgb(233, 236, 239)",
        width: dimensionsWidth * 0.25,
    },
});


function mapDispatchToProps(dispatch) {
    return {
      actions: {
        Appointment: bindActionCreators(Appointment, dispatch),
      }
    };
  }
  
  const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    appointmentData: state.appointmentReducer,
    getData: languageNameGetter(state)
  });

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SlotBox);


