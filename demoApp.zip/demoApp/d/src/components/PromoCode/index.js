import React, { Component } from "react";
import { View, ScrollView, StyleSheet, Text, Dimensions, TouchableOpacity, Image, I18nManager, TextInput } from "react-native";
import Modal from "react-native-modal";
import { translate, setI18nConfig } from "@languages";
import { GradientButton } from "@components";
import { Images, Styles, Colors, Validations } from "@common";
const screen = Dimensions.get("window");

export default class PromoCode extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isPromocodeVisible: false,
            errorMsg: true,
            txtPromo: '',
            validPromocode: true,
            isFrom: ""
        };
        this.togglePromocodeModal = this.togglePromocodeModal.bind(this);
        this.displayValidateAlert = this.displayValidateAlert.bind(this);
    }

    componentWillMount() {
        this.setState({ txtPromo: this.props.promocodetext });
    }

    togglePromocodeModal = visible => {
        this.setState({ isPromocodeVisible: visible });
        this.handleCodeChange(this.props.promocodetext);
    };

    displayValidateAlert = visible => {
        this.setState({ validPromocode: visible });
    }

    acceptContinue = visible => {
        this.setState({ isPromocodeVisible: visible });
    };

    validatePromocode(text) {
        this.setState({ validPromocode: true, isPromocodeVisible: false, isFrom: text });
    }

    onModalHide() {
        if(this.state.isFrom.length > 0) {
            this.setState({ isFrom: "" });
            this.props.onClose(true, this.state.txtPromo);
        }
    }

    handleCodeChange(text) {
        this.setState({ txtPromo: text });
        if(this.props.promocodesArr.filter((e) => (e.code).toUpperCase() === text.toUpperCase()).length > 0 ) {
            this.setState({errorMsg: false });
        }else{
            this.setState({errorMsg: true });
        }
    }

    render() {
        return (
            <Modal
                hasBackdrop
                isVisible={this.state.isPromocodeVisible}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={0.5}
                useNativeDriver={true}
                style={{}}
                onModalHide={() => this.onModalHide()}
                onBackdropPress={() => {
                    this.togglePromocodeModal(false);
                }}>
                <View style={styles.mainModalContainer}>
                    <View style={styles.promocodeview}>
                        <View style={styles.titleView}>
                            <Text style={styles.txtTitle}>{translate("Promocode")}</Text>
                            <TouchableOpacity onPress={() => this.acceptContinue(false)} style={styles.closebt}>
                                <Image source={Images.icons.closeBox} style={styles.cancelLogo} />
                            </TouchableOpacity>
                        </View>

                        <View style={styles.txtPromoView}>
                            <TextInput
                                selectionColor={Colors.black}
                                returnKeyType='done'
                                value={this.state.txtPromo}
                                underlineColorAndroid='transparent'
                                style={styles.txtPhone1}
                                autoCapitalize="characters"
                                editable={true}
                                onChangeText={(text) => this.handleCodeChange(text)}
                            />

                            { !this.state.errorMsg  ?
                                <Image source={Images.icons.successRed} style={styles.imgEndView} />  
                                :
                                <Image source={Images.icons.successGrey} style={styles.imgEndView} /> 
                            }
                            
                        </View>

                        <GradientButton style={styles.acceptBtnContainer}
                            onPressAction={() => {
                                this.validatePromocode("add");
                            }}
                            text={translate("Add")} />
                    </View>

                </View>
            </Modal>
        );
    }
}

const styles = StyleSheet.create({
    imgEndView: {
        alignSelf: 'center',
        height: 28,
        width: 28,
        position: 'absolute',
        right: 16
    },
    fixedBottomView: {
        height: 25,
        justifyContent: 'center'
    },
    txtPhone1: {
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 17,
        color: Colors.black,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        flex: 1,
        height: 50,

    },
    errorMsg: {
        marginLeft: 20,
        marginTop: 5
    },
    txtPromoView: {
        backgroundColor: Colors.paleGray,
        height: 60,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: Colors.pinkishRed,
        marginHorizontal: 16,
        paddingLeft: 18,
        paddingRight: 18,
        flexDirection: 'row',
        alignItems: 'center'
    },
    mainModalContainer: {
        height: '100%',
        width: '100%',
        justifyContent: 'center'
    },
    promocodeview: {
        marginHorizontal: 10,
        backgroundColor: 'white',
        borderRadius: 16
    },
    cancelLogo: {
        height: 28,
        width: 28
    },
    titleView: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginHorizontal: 16,
        marginVertical: 20
    },
    closebt: {
        position: 'absolute',
        top: -5,
        right: 10,
    },
    txtTitle: {
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        textAlign: 'center',
        fontSize: 17,
        color: Colors.blacktextPromocode,
    },
    acceptBtnContainer: {
        marginVertical: 20
    }
});