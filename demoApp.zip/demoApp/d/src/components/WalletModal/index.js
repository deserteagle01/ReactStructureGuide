import React, { Component } from "react";
import { View, Text, Dimensions, TouchableOpacity, Image, StyleSheet, I18nManager, Platform } from "react-native";
import Modal from "react-native-modal";
import { ModalButton, GradientButton, SimpleMessageModal } from "@components";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const screen = Dimensions.get("window");

export default class WalletModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isVisible: false,
			usingAmount: 0,
			totalAmount: 0,
			maxUsing: 0
		};
		this.toggleModal = this.toggleModal.bind(this);
	}

	toggleModal = (visible, usingWallet, totalWallet, maxUsing) => {
		this.setState({ isVisible: visible,  usingAmount: usingWallet, totalAmount: totalWallet, maxUsing: totalWallet < maxUsing ? totalWallet : maxUsing});
	};

	incrementPress() {
		this.setState({usingAmount: this.state.usingAmount + 1 });	
	}

	decrementPress() {
		this.setState({usingAmount: this.state.usingAmount - 1 });
	}	

	addClick() {
		if(this.state.usingAmount > this.state.totalAmount){
			alert("Your wallet han't sufficient balance");
		}
		else{
			this.setState({isVisible: false });
			this.props.onModalHide(this.state.usingAmount);
		}
	}
	
	infoPress() {
		let options  = 
		{
			htmlContent:I18nManager.isRTL?this.props.fetchData.wallet_help_text_ar:this.props.fetchData.wallet_help_text,
        };
        
        this.refs.simpleMessageModal.toggleModal(true,"", translate("Info"),options);
	}

	onClose = () => {
        this.refs.simpleMessageModal.toggleModal(false);
    };

	render() {
		return (
			<Modal
				hasBackdrop
				isVisible={this.state.isVisible}
				hideModalContentWhileAnimating={true}
				useNativeDriver={true}
				style={styles.modal}
				onModalHide={() => {
					this.props.onModalHide();
				}}
				onBackdropPress={() => this.toggleModal(false)}
				onRequestClose={()=>this.toggleModal(false)}
				>
				<View style={styles.modalConatiner}>
					<View style={styles.topContainer}>
						<Text style={styles.txtTitle}>{translate("txtWallet")}</Text>
						<TouchableOpacity
							style={styles.closeConatiner}
							onPress={() => {
								this.setState({
									isVisible: false})
							}}>
							<Image source={Images.icons.closeBox} />
						</TouchableOpacity>
					</View>
					
					<Text style={styles.txtTotal}> {translate("txtyouhave") + " " + this.state.totalAmount + " " +translate("KWD") } </Text>

					<View style={styles.viewmax}>
						<Text style={styles.txtmax}>{translate("txtmaxxWallet")+" "+this.state.maxUsing+" "+translate("KWD")}</Text>
						<TouchableOpacity style={styles.infobt} onPress={() => this.infoPress()}>
							<Image style={styles.infoIcon} source={Images.icons.info_ic} />
						</TouchableOpacity>
					</View>

					<View style={styles.btContainer}>
						<TouchableOpacity disabled={this.state.usingAmount <= 0 ? true: false} onPress={() => this.decrementPress()}>
							<Image source={Images.icons.remove} />
						</TouchableOpacity>
						
						<View style={styles.circleContainer}>
							<Text style={styles.txtmaxvalu}>{this.state.usingAmount}</Text>
							<Text style={styles.txtkwd}>KWD</Text>
						</View>
						<TouchableOpacity disabled={this.state.usingAmount >= this.state.maxUsing} onPress={() => this.incrementPress()}>
							<Image source={Images.icons.addRounded} />
						</TouchableOpacity>
					</View>
					
					<GradientButton
                    	style={styles.gradientbt}
                    	text={translate("Add")}
                    	onPressAction={() => this.addClick()} />

					<SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} />
					
				</View>
			</Modal>
		);
	}
}
const styles = StyleSheet.create({
	modal: {
		alignItems: "center",
		justifyContent: "center"
	},
	circleContainer:{
		height: 70,
		width: 70,
		borderRadius: 35,
		marginHorizontal:16,
		alignItems:'center',
		justifyContent: 'center',

		backgroundColor:Colors.white,
    	shadowColor: '#000',
    	shadowOffset: { width: 4, height: 5 },
    	shadowRadius: 10,
    	shadowOpacity: 0.12,
    	elevation: 5,
	},
	gradientbt:{
		marginTop: 24,
		marginBottom: 20
	},
	btContainer:{
		marginTop: 16,
		flexDirection:'row',
		justifyContent:'center',
		alignItems:'center'	
	},
	modalConatiner: {
		alignSelf: 'center',
		width: screen.width - 32,
		borderRadius: 20,
        backgroundColor: Colors.white,
    }, 
	topContainer: {
		flexDirection: "row",
		alignItems: "center",
		height: 44,
		marginTop: 8,
	},
	txtkwd:{
		fontFamily: Styles.FontFamily().ProximaNova,
		fontSize: 12,
		alignSelf: "center",
		textAlign: "center",
		color: Colors.black06,
	},
	txtmaxvalu:{
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize: 28,
		alignSelf: "center",
		textAlign: "center",
		color: Colors.tabbarTint,
	},
	txtTitle: {
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		fontSize: 17,
		alignSelf: "center",
		textAlign: "center",
		flex: 1,
		color: Colors.blacktextPromocode,
	},
	infobt:{
		marginLeft: 2.5
	},
	infoIcon:{
		height: 16,
		width: 16
	},
	txtmax:{
		fontFamily: Styles.FontFamily().ProximaNova,
		fontSize: 12,
		textAlign: "center",
		color: Colors.black06,
	},
	viewmax:{
		marginTop: 8,
		flexDirection: 'row',
		justifyContent:'center',
		alignItems:'center'
	},
	txtTotal: {
		marginTop:3,
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		fontSize: 12,
		textAlign: "center",
		color: Colors.black06,
	},
	bottomText: {
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize: 17,
		marginBottom: 8,
		marginTop: 8,
		justifyContent: 'center',
		textAlign: "center",
		color: Colors.pinkishRed,
	},
	closeConatiner: {
		position: "absolute",
		right: 16
	},

});
