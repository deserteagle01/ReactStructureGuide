import React, { Component } from "react";
import { View, Text, TouchableOpacity, Image, I18nManager, FlatList } from "react-native";
import Modal from "react-native-modal";
import { translate, setI18nConfig } from "@languages";
import { Spinner } from "@components";
import { Images, Styles } from "@common";
import { WebViewModal} from "@components";
import styles from "./styles";


export default class ProteinSelection extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isSelectionVisible: false,
        };
        this.toggleProteinModal = this.toggleProteinModal.bind(this);
    }

    toggleProteinModal = visible => {
        this.setState({ isSelectionVisible: visible });
    };

    donePress = visible => {
        this.setState({ isSelectionVisible: visible });
        this.props.extraSelectionDone();
    };

    cancelPress = visible => {
        this.setState({ isSelectionVisible: visible });
        this.props.cancelProteinSelection();
    };

    _renderItem = ({ item, index }) => {
        return (
            <View style={styles.rowView}>
                <View style={styles.flexView}>
                    <TouchableOpacity style={(this.props.selectedProtein-1) == index ? styles.selectionView : styles.unselectionView} onPress={() => this.props.onChangeProteinIndex(index)}>
                        {(this.props.selectedProtein-1) == index ?
                            <Image source={Images.icons.successRed} style={styles.checkicon} />
                            :
                            null
                        }
                        <View style={styles.superScriptView}>
                            <Text style={styles.valuetxt}>{item}</Text>
                            <Text style={styles.gtxt}>g</Text>
                        </View>
                    </TouchableOpacity>
                </View>
                <View style={styles.seprator2}>
                </View>
                <View style={styles.flexView}>
                    <TouchableOpacity style={[(this.props.selectedCarb-1) == index ? styles.selectionView : styles.unselectionView, { alignSelf: 'flex-start' }]} onPress={() => this.props.onChangeCarbIndex(index)}>
                        {(this.props.selectedCarb - 1) == index ?
                            <Image source={Images.icons.successRed} style={styles.checkicon} />
                            :
                            null
                        }
                        <View style={styles.superScriptView}>
                            <Text style={styles.valuetxt}>{this.props.carbData[index]}</Text>
                            <Text style={styles.gtxt}>g</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }


    render() {
        const { selectedProtein ,carbData, proteinData, onChangeProteinIndex, onChangeCarbIndex, extraProtCarbPrice, FinalTotal, extraSelectionDone } = this.props;
        //console.log('updated protein ='+this.props.selectedProtein);
        return (
            <Modal
                hasBackdrop
                isVisible={this.state.isSelectionVisible}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={0.5}
                useNativeDriver={true}
                style={{ margin: 0 }}
                onBackdropPress={() => {
                    this.toggleProteinModal(false);
                }}>
                <View style={styles.mainModalContainer}>

                    <View style={styles.fixedBottomView}>
                        <View style={styles.extraChargeView}>
                            <Text style={styles.txtextra}>{translate("Protiens") + ' ' + proteinData[this.props.selectedProtein-1] + translate("GM") +' & ' + translate("Carbs") + ' ' + carbData[this.props.selectedCarb-1]  + translate("GM") }</Text>
                            <Text style={styles.txtextraPrice}>+{extraProtCarbPrice}</Text>
                        </View>
                        <View style={styles.sepratorView} />
                        <View style={styles.totalView}>
                            <Text style={styles.txtTitleTotal}>{translate("GrandTotal")}</Text>
                            <View style={styles.priceview}>
                                <Text style={styles.txtkwd}>{translate("KWD")}</Text>
                                <Text style={styles.totalPrice}>{FinalTotal}</Text>
                            </View>
                        </View>
                    </View>


                    <View style={styles.insideView}>

                        <View style={styles.header}>
                            <TouchableOpacity onPress={() => this.cancelPress(false)}>
                                <Image source={Images.icons.closeBox} style={styles.cancelLogo} />
                            </TouchableOpacity>
                            <Text style={styles.chooseTitle}>{translate("Choose")}</Text>
                            <TouchableOpacity onPress={() => this.donePress(false)}>
                                <Text style={styles.donebtn}>{translate("Done")}</Text>
                            </TouchableOpacity>
                        </View>

                        <WebViewModal ref="refBestProteinsCarbs" sourceUri={this.props.best_protein_carb_url || "http://thedietstation.com"}/>
                        <TouchableOpacity onPress={() => this.refs.refBestProteinsCarbs.show()} style={styles.textView}>
                            <Text style={styles.txtLbl}>{translate("WhatisBestProteinsCarbs")}</Text>
                            <Image source={Images.icons.info_ic} style={styles.infologo} />
                        </TouchableOpacity>


                        <View style={styles.listContainerView}>

                            <View style={styles.proteinrowView}>
                                <View style={styles.flexView}>
                                    <View style={styles.flexViewTop}>
                                        <Text style={styles.txtHeaders}>{translate("Protiens")}</Text>
                                    </View>
                                </View>

                                <View style={styles.flexView}>
                                    <View style={styles.carbRow}>
                                        <Text style={styles.txtHeaders}>{translate("Carbs")}</Text>
                                    </View>
                                </View>
                            </View>

                            <View style={styles.flexDividedView}>
                                <FlatList
                                    style={styles.listStyle}
                                    data={proteinData}
                                    extraData={this.props}
                                    keyExtractor={(item, index) => index}
                                    renderItem={(item, index) => this._renderItem(item, index)} />
                            </View>

                            <View style={styles.bottomTextView}>
                                <Image source={Images.icons.info_ic} style={styles.alertic} />
                                <Text style={styles.txtWarning}>{translate("Warning")}</Text>
                            </View>

                        </View>

                    </View>

                </View>

            </Modal>
        );
    }
}