import { StyleSheet, Platform, Dimensions,  PixelRatio, I18nManager } from "react-native";
import { Images, Styles, Colors } from "@common";
import { FontScalling } from "../../common/Utility";
const { height, width } = Dimensions.get("window");
const screen = Dimensions.get("window");
export default (styles = StyleSheet.create({
    seprator2: {
        flex: 0.005, backgroundColor: Colors.lightGray
    },
    extraChargeView: {
        flexDirection: 'row',
        marginVertical: 15,
        paddingHorizontal: 24,
        justifyContent: 'space-between'
    },
    priceview: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    totalView: {
        flexDirection: 'row',
        paddingHorizontal: 24,
        marginTop: 17,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    sepratorView: {
        width: '100%',
        height: 1,
        backgroundColor: Colors.lighterBlack
    },
    sepratorView2: {
        marginTop: screen.height/screen.width > 1.7 ? 0 : 0,
        width: '100%',
        height: 1,
    },
    totalPrice: {
        marginLeft: 10,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 24,
        color: Colors.pinkishRed,
    },
    txtkwd: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 12,
        color: Colors.black,
    },
    txtTitleTotal: {
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 13,
        color: Colors.black,
    },
    txtextra: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 14,
        color: Colors.darkGray,
    },
    txtextraPrice: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 16,
        color: Colors.pinkishRed,
    },
    imgEndView: {
        alignSelf: 'center',
        height: 28,
        width: 28,
        position: 'absolute',
        right: 16
    },
    superScriptView: {
        flexDirection: 'row',
        alignItems: 'flex-start'
    },
    valuetxt: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 24,
        color: Colors.darkGray,
        lineHeight: 30
    },
    gtxt: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 12,
        color: Colors.lightBlack,
        lineHeight: 35
    },
    selectionView: {
        height: 56,
        width: 106,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: Colors.pinkishRed,
        marginVertical: 4,
        alignSelf: 'flex-end',
        paddingRight: 10,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.white,
        shadowColor: '#000',
        shadowOffset: { width: 4, height: 5 },
        shadowRadius: 10,
        shadowOpacity: 0.12,
    },
    checkicon: {
        position: 'absolute',
        height: 24,
        width: 24,
        right: 4, top: 4
    },
    flexView: {
        flex: 0.49,
        paddingHorizontal: 16,
    },
    flexViewTop: {
        width: 106,
        alignSelf: 'flex-end',
        alignItems: 'center'
    },
    flexDividedView:{ 
        flex: 0.70 
    },
    listStyle:{ 
        flex: 1, marginVertical: 5 
    },
    carbRow:{
        width: 106,
        alignSelf: 'flex-end',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    unselectionView: {
        height: 56,
        width: 106,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: Colors.lightGray,
        marginVertical: 4,
        alignSelf: 'flex-end',
        alignItems: 'center',
        justifyContent: 'center'
    },
    rowView: {
        flexDirection: "row",
    },
    proteinrowView:{
        flexDirection: "row",
        marginVertical: 8
    },
    alertic: {
        height: 14,
        width: 14,
        tintColor: Colors.infoYellow
    },
    listContainerView: {
        flex: 1,
        overflow: 'hidden'
    },
    txtWarning: {
        marginHorizontal: 24,
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 10,
        color: Colors.lightBlack,
        marginVertical: 8,
        textAlign: 'center'
    },
    bottomTextView: {
        alignItems: 'center',
        flex: 0.3,
    },
    textView: {
        marginTop: 8,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    txtHeaders: {
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 12,
        color: Colors.lightBlack,
        letterSpacing: -0.14,
        alignSelf: 'center',
        textAlign: 'center'

    },
    txtLbl: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 13,
        color: Colors.black,
        letterSpacing: -0.14
    },
    chooseTitle: {
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
        fontSize: 15,
        color: Colors.black,
    },
    donebtn: {
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 17,
        color: Colors.pinkishRed,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 20,
        paddingHorizontal: 18
    },
    fixedBottomView: {
        height: screen.height * 0.19,
        backgroundColor: Colors.white,
        width: '100%',
        position: 'absolute',
        bottom: 0,
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24
    },
    insideView: {
        marginHorizontal: 15,
        height: 0.66 * screen.height,
        backgroundColor: Colors.white,
        borderRadius: 16,
        marginBottom: screen.height*0.10
    },
    txtPhone1: {
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 17,
        color: Colors.black,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        flex: 1,
        height: 50,
    },
    errorMsg: {
        marginLeft: 20,
        marginTop: 5
    },
    txtPromoView: {
        height: 60,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: Colors.pinkishRed,
        marginHorizontal: 16,
        paddingLeft: 18,
        paddingRight: 18,
        flexDirection: 'row',
        alignItems: 'center'
    },
    mainModalContainer: {
        height: '100%',
        width: '100%',
        justifyContent: 'center',
    },
    promocodeview: {
        marginHorizontal: 15,
        backgroundColor: 'white',
        backgroundColor: 'yellow',
        borderRadius: 16
    },
    cancelLogo: {
        height: 28,
        width: 28
    },
    infologo:{
        height: 18,
        width: 18,
        marginLeft: 4
    },
    titleView: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginHorizontal: 16,
        marginVertical: 20
    },
    closebt: {
        position: 'absolute',
        top: -5,
        right: 10,
    },
    txtTitle: {
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        textAlign: 'center',
        fontSize: 17,
        color: Colors.blacktextPromocode,
    },
    acceptBtnContainer: {
        marginVertical: 20
    }

}));

