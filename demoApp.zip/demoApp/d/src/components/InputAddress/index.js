import React, { Component } from "react";
import { StyleSheet, TextInput, Image, Text, I18nManager, TouchableOpacity, TouchableWithoutFeedback } from "react-native";
import { Styles, Colors, Images } from "@common";
import { View } from "react-native-animatable";
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { translate, setI18nConfig } from "@languages";


export default class InputAddress extends Component {
	constructor(props) {
		super(props);
		this.state = {};
		// this.returnRef = this.returnRef.bind(this);
	}

	componentDidMount() {
		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}
	componentDidUpdate(){
		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}
	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

	handlerFocus = (input) => {
		this.setState({
			[input]: true
		});
	};

	handlerBlur = (input) => {
		this.setState({
			[input]: false
		});
	};
	// returnRef(){
		// console.log("thisRetyn",this.props.onRef);
		// if (this.props.onRef) {
		// 	this.props.onRef(this.refs['block']);
		// }
	// }

	textHandler = (text) => {
		this.props.textHandler(text);
	}

	updateRef(name, refs) {
		this[name] = refs;
	}

	InputAccessoryView = () => {
		return (
			<View style={[defaultStyles.modalViewMiddle]} testID="input_accessory_view">
				<View style={[defaultStyles.chevronContainer]}></View>
				<TouchableWithoutFeedback
					onPress={() => {
					}}
					hitSlop={{ top: 4, right: 4, bottom: 4, left: 4 }}
					testID="done_button">
					<View testID="needed_for_touchable">
						<Text style={[defaultStyles.done]}>{"Done"}</Text>
					</View>
				</TouchableWithoutFeedback>
			</View>);
	}
	// inputAccessoryViewForDisable=(disableUpArrow,disableDownArrow,hideDoneBar,refName)=>{
		
	// 	return (
	// 		<View style={[defaultStyles.modalViewMiddle]} testID="input_accessory_view">
    //                 <View style={[defaultStyles.chevronContainer]}>
    //                     <TouchableOpacity disabled={disableUpArrow?disableUpArrow:false} activeOpacity={disableUpArrow ? 0.5 : 1} onPress={(item) => {this.props.onUpArrowFun(refName)}}>
    //                         <View style={[defaultStyles.chevron,
    //                             I18nManager.isRTL? styles.chevronUpArrowRTL:defaultStyles.chevronUp,
    //                              disableUpArrow ? {}: [defaultStyles.chevronActive]]}/>
    //                     </TouchableOpacity>
    //                     <TouchableOpacity disabled={disableDownArrow?disableDownArrow: ""} activeOpacity={disableDownArrow ? 0.5 : 1} onPress={(item) => {this.props.onDownArrowFun(refName)}}>
    //                         <View style={[defaultStyles.chevron,
    //                             I18nManager.isRTL? styles.chevronDownArrowRTL:defaultStyles.chevronDown,
    //                              disableDownArrow ? {}: [defaultStyles.chevronActive]]}/>
    //                     </TouchableOpacity>
    //                 </View>
    //                  {!hideDoneBar &&
    //                     <TouchableWithoutFeedback onPress={(item) => {this.props.onDownArrowFun(this.props.refName)}} hitSlop={{ top: 4, right: 4, bottom: 4, left: 4 }} testID="done_button">
    //                         <View testID="needed_for_touchable">
    //                             <Text style={[defaultStyles.done]}>{translate("Done")}</Text>
    //                         </View>
    //                     </TouchableWithoutFeedback>
    //                 } 
    //             </View>);
		
	// }
	render() {
		const {
			inputType,
			placeholderText,
			itemObj,
			inputText,
			errorMsg,
			onUpArrowFun,
			onDownArrowFun,
		} = this.props;
		const pickerStyle = {
			inputAndroidContainer: {
				flex: 1,
				height: 61,
				borderRadius: 12,
				borderWidth: 1,
				borderColor: "#D6D7DA",
				overflow: "hidden",
				justifyContent: "center",
			},
			inputIOSContainer: {
				flex: 1,
				height: 61,
				borderRadius: 12,
				borderWidth: 1,
				borderColor: "#D6D7DA",
				overflow: "hidden",
				justifyContent: "center",
			},
			inputIOS: {
				color: Colors.black,
				fontSize: 24,
				width: '85%',
				paddingLeft: 16,
				fontFamily: Styles.FontFamily().ProximaNova,
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			inputAndroid: {
				color: Colors.black,
				fontSize: 24,
				width: '85%',
				paddingLeft: 16,
				fontFamily: Styles.FontFamily().ProximaNova,
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			underline: { borderTopWidth: 0 },
			icon: {
				width: 24,
				height: 24,
			},
			iconContainer: {
				height: 61,
				width: 40,
				flex: 1,
				paddingRight: 16,
				justifyContent: 'center',
				alignItems: 'center',
			},
			chevronUp :I18nManager.isRTL?styles.chevronUpArrowRTL:{},
            chevronDown:I18nManager.isRTL?styles.chevronDownArrowRTL:{},
		};

		const placeholderPicker = {
			label: this.props.placeholderText,
			value: null,
			color: Colors.black,
		};

		if (inputType == 1) {
			return (
				<View>
					<TextInput ref={this.props.refName ? this.props.refName : 'email'} autoCapitalize='none' selectionColor={Colors.black} returnKeyType='done' keyboardType={'email-address'} onChangeText={this.textHandler} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.blackTwo} value={this.state.text} style={[{ fontFamily: Styles.FontFamily().ProximaNova }, Styles.common.textInput, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '']}
						onFocus={() => this.handlerFocus('nameInputOneFocus')}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} />
					<Text style={errorMsg ? styles.errorMsgAdd : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			);
		} else if (inputType == 2) {
			return (
				<View>
					<TextInput ref={this.props.refName ? this.props.refName : 'phone'} keyboardType={'phone-pad'} selectionColor={Colors.black} returnKeyType='done' onChangeText={this.textHandler} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.blackTwo} style={[{ fontFamily: Styles.FontFamily().ProximaNova }, Styles.common.textInput, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}
						onFocus={() => this.handlerFocus('nameInputOneFocus')}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} />
					<Text style={errorMsg ? styles.errorMsgAdd : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			)
		} else if (inputType == 3) {
			// Drop Down
			return (
				<View style={styles.textViewMargin}>
					<RNPickerSelect
						pickerProps={style = { fontFamily: Styles.FontFamily().ProximaNovaBold }}
						placeholderTextColor={Colors.black}
						ref={this.props.refName}
						onValueChange={this.textHandler} value={inputText} useNativeAndroidPickerStyle={false}
						items={itemObj}
						// key={itemObj.id}
						textInputProps={{
							numberOfLines: 1,
							selection:{ start: 0, end: 0 }
						}}
						style={pickerStyle}
						// InputAccessoryView={this.props.InputAccessoryViewDisable?()=>this.inputAccessoryViewForDisable(true,false,false,this.props.refName):null}
						placeholder={placeholderPicker.label != null?placeholderPicker:{}}
						Icon={() => <Image source={Images.icons.down} style={{ tintColor: Colors.battleshipGrey, marginBottom: 8 }} />}
						onUpArrow={() => onUpArrowFun(this.props.refName)}
						onDownArrow={() => onDownArrowFun(this.props.refName)}
					/>
					<Text style={errorMsg ? styles.errorMsgAdd : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			)
		} else {
			return (
				<View>
					<TextInput 
					inputAccessoryViewID={this.props.inputAccessoryViewID}
					 onSubmitEditing={() => this.props.returnKeyEvent(this.props.inputAccessoryViewID)}
					ref={this.props.refName ? this.props.refName : 'string'} 
					onChangeText={this.textHandler} selectionColor={Colors.black} 
					value={inputText} 
					placeholder={placeholderText}
					 placeholderTextColor={Colors.blackTwo}
					  style={styles.textInputCommon}
						onFocus={() => this.handlerFocus('nameInputOneFocus')}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} />
					<Text style={errorMsg ? styles.errorMsgAdd : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			);
		}
	}
}


const styles = StyleSheet.create({
	textInputCommon: {
		borderColor: 'rgba(157, 157, 157, 1)',
		borderBottomWidth: 2,
		height: 59,
		width: '100%',
		padding: 5,
		color: Colors.black,
		fontSize: 24,
		alignSelf: 'flex-start',
		fontFamily:Styles.FontFamily().ProximaNova,
		textAlign: I18nManager.isRTL ? 'right' : 'left',
	},
	textInputFocus: {
		borderBottomColor: Colors.black,
	},
	errorMsg: {
		alignSelf: 'flex-start',
		color: 'red',
		fontSize: 14,
		fontFamily:  Styles.FontFamily().ProximaNova,
		marginTop: 5,
		marginBottom: 5,
		marginLeft: 20
	},
	errorMsgAdd: {
		alignSelf: 'flex-start',
		color: 'red',
		fontSize: 14,
		fontFamily:  Styles.FontFamily().ProximaNova,
		marginTop: 5,
		marginBottom: 5,
		marginLeft: 5
	},
	chevronUpArrowRTL: {
        marginLeft: 11,
        transform: [{ translateY: 4 }, { rotate: '45deg' }],
    },
   chevronDownArrowRTL: {
       marginLeft: 22,
        transform: [{ translateY: -5 }, { rotate: '-135deg' }],
	}
});

