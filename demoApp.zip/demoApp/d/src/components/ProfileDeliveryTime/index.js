import React, { Component } from "react";
import { View, FlatList, Text, Image, TouchableOpacity, StyleSheet, I18nManager, Dimensions } from "react-native";
import { connect } from "react-redux";
import { Styles, Images, Colors, Validations } from "@common";
import { translate } from "@languages";
import { GradientButton } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const screen = Dimensions.get("window");

class ProfileDeliveryTime extends Component {
	constructor(props) {
		super(props);
		this.state = {
			singUpDeliveryTime:"",
			singUpDeliveryTimeError: null,
		};

		
	}

	componentDidMount() {
		// changeAddress
		if(this.props.addressVal !== null){
			this.setState({singUpDeliveryTime : this.props.addressVal.shift_id})
		}else{
			var areaId=this.props.signupDetail.changeAddress.area_id;
			if(this.props.areaItem!==[]){
			if( this.props.areaItem.length > 0 && areaId){
				var	selectedAreaArr = this.props.areaItem.filter(function(item){
						return item.value == areaId;	
					})
					this.setState({singUpDeliveryTime : selectedAreaArr[0].default_shift_id})
				}			
				
		}
		}
	}

	selecteDeliveryTime = (item) => {
		this.setState({ singUpDeliveryTime: item.value })
	}

	async validateDeliveryTime() {
		const reqParams = {
			shift_id: this.state.singUpDeliveryTime,
		};
		if(this.state.singUpDeliveryTime!==""){
			await this.props.actions.UpdateUserAction.updateUserAddress(reqParams);
			this.props.gotoNext();
		}
		
	}

	_renderItem = ({ item }) => {
		return (
			<TouchableOpacity onPress={() => this.selecteDeliveryTime(item)} style={[styles.outlineBtn, this.state.singUpDeliveryTime == item.value ? styles.whiteBg : null]}>
				<Text style={[styles.textStyle, this.state.singUpDeliveryTime == item.value ? styles.redText : null]}>
					{item.label}
				</Text>
				<Text style={[styles.textSmall, this.state.singUpDeliveryTime == item.value ? styles.redText : null]}>
					{item.subTitle}
				</Text>
				{this.state.singUpDeliveryTime == item.value &&
					<Image source={I18nManager.isRTL ? Images.icons.rightCheckedOrange : Images.icons.leftCheckedOrange} style={styles.checkLogo} />
				}
			</TouchableOpacity>
		);
	}

	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView enableOnAndroid={true} keyboardShouldPersistTaps={'always'} showsVerticalScrollIndicator={false}>
				
				<View>
					<Text style={styles.label}>{translate("ProfilePreferedDelivery")}</Text>
				</View>
				<View style={styles.delivertyListContainer}>
					<Text style={this.state.singUpDeliveryTimeError?Styles.common.errorMsg:''}>{this.state.singUpDeliveryTimeError?translate(this.state.singUpDeliveryTimeError): ''}</Text>
					{this.props.deliveryItem &&
						<FlatList
							data={this.props.deliveryItem}
							extraData={this.state}
							keyExtractor={(item, index) => index.toString()}
							renderItem={this._renderItem}
						/>
					}
				</View>
				</KeyboardAwareScrollView>
				<View style={styles.addressBtnConti}>
					<GradientButton 
						onPressAction={() => { this.validateDeliveryTime()}}
						text={translate("submitAddBtn")}
					/>
				</View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
		// height: screen.height - 110,
	},
	label: {
		fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
		fontSize: 28,
		marginLeft: 16,
		color: Colors.black,
		lineHeight: 36,
		letterSpacing: -1,
		textAlign: 'left',
		
	},
	whiteBg: {
		borderWidth: 0,
		width: screen.width- 32,
		backgroundColor: Colors.white,
		shadowColor: "#000",
		shadowOffset: {
			width: 0,
			height: 6,
		},
		shadowOpacity: 0.15,
		shadowRadius: 7.49,
		elevation: 12,
	},
	delivertyListContainer:{
		marginTop: 14,
	},
	outlineBtn: {
		height: 56,
		width: screen.width- 32,
		borderRadius: 10,
		alignItems: "flex-start",
		justifyContent: "center",
		borderWidth: 1,
		borderColor: "rgba(224, 224, 224, 1)",
		marginBottom: 16,	
		marginHorizontal: 16,
		paddingLeft: 16,
	},
	textStyle: {
		color: Colors.black,
		fontSize: Styles.FontSize.fnt18,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		alignSelf: 'flex-start',
		lineHeight: 25
	},
	textSmall: {
		color: Colors.black,
		fontSize: Styles.FontSize.fnt12,
		fontFamily: Styles.FontFamily().ProximaNova,
		alignSelf: 'flex-start',
		lineHeight: 18
	},
	redText: {
		color: Colors.pinkishRed,
	},
	checkLogo: {
		width: 28,
		height: 28,
		position: "absolute",
		justifyContent: "center",
		right: 16
	},
	addressBtnConti:{
		position: "absolute",
		bottom: Dimensions.get("window").height >= 812?41:21,
		width: "100%",
		shadowColor: "#000",
		shadowOffset: {
			width: 0,
			height: 6,
		},
		shadowOpacity: 0.15,
		shadowRadius: 7.49,
		elevation: 12,
	}
});

const mapStateToProps = (state) => {
	return {
		signupDetail: state.updateUserReducer,
		deliveryItem: state.fetchMasterListReducer.delivery_shifts,
		areaItem: state.fetchMasterListReducer.areas,
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(ProfileDeliveryTime);