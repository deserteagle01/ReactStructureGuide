import React, { Component } from "react";
import { View, Text, Dimensions, TouchableOpacity, Image, StyleSheet,StatusBar, I18nManager } from "react-native";
import Modal from "react-native-modal";
import { GradientButton, ModalButton } from "@components";
import { Images, Styles, Colors } from "@common";
import { translate } from "@languages";

const screen = Dimensions.get("window");

export default class LogoutModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isVisible: false
		};
		this.toggleModal = this.toggleModal.bind(this);

	}

	toggleModal = visible => {
		this.setState({ isVisible: visible });
	};

	onLogout = () => {
		this.props.onLogout();
	}
	onCancel = () => {
		this.props.onCancel();
	}

	render() {
		return (
			
			<Modal
				hasBackdrop
				isVisible={this.state.isVisible}
				hideModalContentWhileAnimating={true}
				useNativeDriver={true}
				style={styles.modal}
				onBackdropPress={() => {
					this.toggleModal(false);
				}} >
				<View style={styles.mainContainer} >
					<View style={styles.titleContainer} >
						<Text style={styles.titleText} > {translate("Logout")} </Text>
					</View>
					<View style={styles.descContainer} >
						<Text style={styles.descText} > {translate("logoutModalMessage")} </Text>
					</View>
					<View style={styles.btnContainer}>
						<View style={styles.leftContainer}>
								<ModalButton btnStyle={styles.modalBtn} isCheckedVisible={false} onPress={() => {this.onCancel()}} label={translate("no")} />
						</View>
						<View style={styles.rightContainer}>
								<GradientButton style={styles.gradientBtn} isCheckedVisible={false} onPressAction={() => {this.onLogout()}} text={translate("yes")} />
						</View>
					</View>
				</View>
			</Modal>
		);
	}
}

const styles = StyleSheet.create({
	modal:{ 
		flex:1,
		alignItems: "center",
	 	justifyContent: "center" ,
	},
	mainContainer:{
			position: "absolute",
			// bottom: 34,
			height: 190,
			width: '90%',
			borderRadius: 20,
			backgroundColor: Colors.white,
	},
	titleContainer:{
			// flex:0.3,
			flexDirection: "row",
			alignItems: "center",
			marginTop: 8,
	},
	titleText:{
			fontFamily: Styles.FontFamily().ProximaNovaBold,
			fontSize: 17,
			alignSelf: "center",
			marginVertical: 12,
			textAlign: "center",
			flex: 1,
			color:Colors.darkNavyBlue
	},
	descContainer:{
			// flex:0.3,
			flexDirection: "row",
			alignItems: "center",
			marginBottom: 16,
	},
	descText:{
				fontFamily: Styles.FontFamily().ProximaNova,
				fontSize: 14,
				alignSelf: "center",
				marginVertical: 12,
				textAlign: "center",
				flex: 1,
				color:Colors.black08
	},
	btnContainer:{
		flexDirection:'row',
		height:56,
		bottom:0,
	},
	leftContainer:{
		flex:1,
		paddingLeft:20,
		paddingRight:15,
	},
	rightContainer:{
		flex:1,
		paddingRight:20
	},
	modalBtn:{
		flex:1,
		marginTop: 0,
		marginHorizontal:0,
		alignSelf:'flex-end',
		width: '100%'
	},
	gradientBtn:{
		flex:1,
		marginHorizontal:0,
		alignSelf:'flex-start',
		width: '100%'
	},

})
