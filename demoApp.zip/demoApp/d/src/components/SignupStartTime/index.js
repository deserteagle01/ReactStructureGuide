import React, { Component } from "react";
import { View, Text, Image, StyleSheet, Dimensions } from "react-native";
import { connect } from "react-redux";
import { Styles, Images, Colors, Validations } from "@common";
import DatePicker from "../DatePicker";
import moment from 'moment';
import InputTextString from "../InputTextString"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { firebase } from '@react-native-firebase/analytics';
const { height, width } = Dimensions.get("window");
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
class SignupStartTime extends Component {
    constructor(props) {
        super(props);
        this.state = {
            singUpStartDate: "",
            singUpStartDateError: null,
        };
        this.inputRefs = {};
    }

    componentDidMount() {
        this.init();
    }

    init() {
        firebase.analytics().setCurrentScreen("Signup StartDate Screen");
        this.setState({ 
            singUpStartDate: this.props.signupDetail.expected_plan_start_date ? this.props.signupDetail.expected_plan_start_date : "",
            singUpStartDateError: null,
        });
        const reqParams = {
            expected_plan_start_date: moment(this.state.singUpStartDate).format('YYYY-MM-DD'),                     // Update this field value only
        };
        this.props.actions.UpdateUserAction.updateUserDetails(reqParams); 

        if (this.props.connected) {
            this.props.actions.MasterList.getPlanStartDate().then(() => {
                if(this.props.masterData.error) {
                    this.toast.show(this.props.masterData.error);
                } 
                else{
                    if (this.props.masterData.planStartDate.length > 0) {
                        this.setState({ singUpStartDate: this.props.masterData.planStartDate[0].value })
                        let date_start = moment(this.props.masterData.planStartDate[0].value);
                        date_start.locale('en');
                        const reqParams = {
                            expected_plan_start_date: date_start.format('YYYY-MM-DD'),                     // Update this field value only
                        };
                        this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
                    }
                }
            })
        } else {
            this.props.singUpToast(translate("InternetToast"))
        }
    }

    validate(isForDate) {
        if(isForDate){
            let option = { fullMessages: false };
            let singUpStartDateError = Validations('reqField', this.state.singUpStartDate, option);
            this.setState({ singUpStartDateError: singUpStartDateError })
            if (!singUpStartDateError) {
                const reqParams = {
                    expected_plan_start_date: moment(this.state.singUpStartDate).format('YYYY-MM-DD'),                     // Update this field value only
                };
                this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
                firebase.analytics().logEvent("checkout_progress", {checkout_step: "Signup StartDate Screen"});
            }
        }else{
            return new Promise((resolve, reject) => {
                    resolve ({result: 1 });
            });
        }
    }

    openDatepicker = () => {
        this.refs.refDatePicker.showDateTimePicker();
    }

    selectedDate = (date) => {
        this.setState({
            singUpStartDate: date
        }, () => {
            this.validate(true);
        })
    }

    onDropDownToggle = (refs) => {
        this.inputRefs["startPlan"].togglePicker(false);        
    }

    render() {
        return (
            <View style={[styles.detailContainer, this.props.isOpenFrom ? {width: '90%', alignSelf:'center'} : {}]}>
                <KeyboardAwareScrollView enableOnAndroid={true} extraScrollHeight={Platform.OS === 'ios' ? 50 : 100} keyboardShouldPersistTaps={'always'}>
                <View style={styles.calendarImgContainer}>
                    <Image style={[styles.calendarImage,this.props.isOpenFrom ? {tintColor: Colors.pinkishRed} : null]} source={Images.calendarImage} />
                </View>
                <View style={styles.selectDateContainer}>
                    <Text style={[styles.label(this.props.signupDetail.com_lang),this.props.isOpenFrom ? {color: Colors.pinkishRed, } : null ]}>{translate("WhenToStart")}</Text>
                    <Text style={Styles.common.errorMsg}>{this.state.singUpDeliveryTimeError}</Text>
                </View>
                {
                    this.props.masterData.planStartDate != undefined && this.props.masterData.planStartDate.length > 0  ?
                        <InputTextString
                            arrowHide={true}
                            refName={"startPlan"}
                            onRef={(el) => { this.inputRefs["startPlan"] = el }}
                            onDropDownToggleFun={this.onDropDownToggle}
                            onUpArrowFun={this.onUpArrowClicked}
                            onDownArrowFun={this.onDownArrowClicked}
                            fontFamily={Styles.FontFamily(this.props.signupDetail.com_lang).ProximaNovaBold}
                            fontSize={20} textHandler={this.selectedDate}
                            inputText={this.state.singUpStartDate}
                            errorMsg={this.state.singUpStartDateError}
                            inputType="3"
                            isOpenFrom={this.props.isOpenFrom}
                            itemObj={this.props.masterData.planStartDate} />
                            :
                            null
                }
                </KeyboardAwareScrollView>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    detailContainer: {
        flex: 1,
    },
    calendarImgContainer: {
        alignItems: 'center',
        marginBottom: 24,
        width: "100%",
        height: 108,
        marginTop: height*0.14,
    },
    calendarImage: {
        width: 108,
        height: 108,
    },
    inputNameContainer:{
        height: 61
    },
    selectDateContainer: {
        paddingLeft: 30,
        paddingRight: 30,
    },
    label: (lang) => ({
        marginTop: 24,
        fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
        fontSize: 28,
        color: Colors.white,
        textAlign: 'center',
    }),
    outlineBtn: {
        height: 60,
        borderRadius: 10,
        alignItems: "flex-start",
        justifyContent: "center",
        borderWidth: 1,
        borderColor: Colors.lightWhite,
        marginTop: 38,
        paddingLeft: 16,
    },
    textStyle: {
        color: Colors.white,
        fontSize: Styles.FontSize.fnt20,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        lineHeight: 25
    },
    calendarIcon: {
        width: 28,
        height: 28,
        position: "absolute",
        justifyContent: "center",
        right: 16
    }
});

const mapStateToProps = (state) => {
    return {
        isLoading: state.fetchMasterListReducer.isLoading,
        connected: state.updateNetInfoReducer.isConnected,
        masterData: state.fetchMasterListReducer,
        signupDetail: state.updateUserReducer,
    };
};

function mapDispatchToProps(dispatch) {
    return {
        actions: {
            MasterList: bindActionCreators(MasterList, dispatch),
            UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
        }
    };
}
export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SignupStartTime);