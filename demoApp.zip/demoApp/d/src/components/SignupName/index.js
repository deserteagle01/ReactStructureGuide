import React, { Component } from "react";
import { View, Text, StyleSheet, Platform, I18nManager, Dimensions,Keyboard, Animated, Image } from "react-native";
import { connect } from "react-redux";
import { Styles, Validations, Colors } from "@common";
import InputTextString from "../InputTextString";
import InputAccessory from "../InputAccessory";
import ButtonOk from  "../ButtonOk";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { translate } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { firebase } from '@react-native-firebase/analytics';
import Images from "../../common/Images";
import { TouchableOpacity } from "react-native-gesture-handler";
const { height, width } = Dimensions.get("window");
class SignupName extends Component {
	constructor(props) {
		super(props);
		this.state = {
			singUpName: this.props.signupDetail.first_name,
			singUpNameError: null
		};
		this.inputRefs = {};
	}

	init() {
		firebase.analytics().setCurrentScreen("Signup Name Screen");
		this.setState({ singUpName: this.props.signupDetail.first_name, singUpNameError: null });
	}

	textHandler = (text) => {
		this.setState({ singUpName: text })
	}

	validate() {
		return new Promise((resolve, reject) => {
		let option = { fullMessages: false };
		let singUpNameError = Validations('reqField', this.state.singUpName, option);
		this.setState({ singUpNameError: singUpNameError })
		if (!singUpNameError) {
			const reqParams = {
				first_name: this.state.singUpName,				// Update this field value only
			};
			this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
			firebase.analytics().logEvent("checkout_progress", {checkout_step: "Signup Name Screen"});
			resolve ({result: 1});
		}else{
			resolve ({result: 0});
		}
	});
	}

	onDownArrowClicked(refs){
		this.validate();
	}
	
	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView enableOnAndroid={true} keyboardShouldPersistTaps={'always'}>
					<View>
						<Text style={[styles.label(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt : null ] }>{translate("WhatsYourName")}</Text>
					</View>
					<View style={styles.inputNameContainer}>
						<InputTextString 
							autoFocus={false} 
							returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)} 
							textHandler={this.textHandler} 
							errorMsg={this.state.singUpNameError} 
							inputText={this.state.singUpName} 
							placeholderText="" 
							inputAccessoryViewID={"fName"}
							styless={[styles.fontSet(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == "ar" ? Styles.common.globalArabictxt :Styles.common.globalEnglishtxt ]} />
							
					</View>	

					{this.state.singUpName.length > 0 &&
					<TouchableOpacity onPress={this.props.onOkClick}>
						<ButtonOk  lang={this.props.signupDetail.com_lang} />
					</TouchableOpacity>
					}

				
				{Platform.OS == 'ios' &&
					<InputAccessory inputAccessoryViewID={"fName"} disableUpArrow={true} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} onDownArrowClick={() => this.onDownArrowClicked('fName')}/>
				}
				</KeyboardAwareScrollView> 
				
			</View>
			
		);
	}
}

const styles = StyleSheet.create({
	detailContainer:{
		flex: 1,
	},
	label: (lang) => ({
        marginTop: height*0.14,
        fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
        fontSize: 28,
        color: Colors.white,
        textAlign: 'left'
    }),
	fontSet: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
	}),
	labelArabic:{
		fontFamily: Styles.FontFamily.SansPlain
	},
	noteContainer: {
		marginTop: 8
	},
	labelsmall: {
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		fontSize: 14,
		color: Colors.white,
		textAlign: 'left',
		lineHeight: 18,
	},
	textInputFocus: {
		borderBottomColor: Colors.white,
	},
	inputNameContainer: {
		marginTop: 44,
	},
});

const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer,
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SignupName);