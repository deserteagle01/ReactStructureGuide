import React, { Component } from "react";
import { connect } from "react-redux";
import { Platform, View, StyleSheet, Text, Dimensions, TouchableOpacity, Image, I18nManager } from "react-native";
import Modal from "react-native-modal";
import { translate } from "@languages";
import { ProfileAddress, ProfileDeliveryTime, DotIndicator, CarouselPager, AddDaysAddress} from "@components";
import { Images, Styles, Colors } from "@common";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const screen = Dimensions.get("window");
export default class AddEditAddress extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isAddEditAddressVisible: false,
			visibleSetupAccountView: 0,
			addAddressModal: true,
			addressItem: null,
			numberOfAddress:"",
			
		};
		this.toggleAddEditAddressModal = this.toggleAddEditAddressModal.bind(this);
		this.gotoNextSlider = this.gotoNextSlider.bind(this)
	}

	toggleAddEditAddressModal = (visible, addAddressModal, addressItem,numberOfAddress) => {
		this.setState({ isAddEditAddressVisible: visible, addAddressModal: addAddressModal, addressItem: addressItem,numberOfAddress:numberOfAddress });
		if (!visible) {
			this.setState({ visibleSetupAccountView: 0 });
		}
	};

	gotoNextSlider = () => {
		 if (this.state.visibleSetupAccountView < 3) {
					if(this.state.addressItem!==null && this.state.addressItem.isPrimary){
						this.setState(
							({ visibleSetupAccountView: 2 }),() => {
							  this.carousel.goToPage(this.state.visibleSetupAccountView)}
						  )
					}	
					else{
					this.setState({ visibleSetupAccountView: ++this.state.visibleSetupAccountView});
					this.carousel.goToPage(this.state.visibleSetupAccountView);
					}
		}
	}

	gotoBackSlider = () => {
		if(this.state.addressItem!==null   && this.state.addressItem.isPrimary){
				this.setState(({ visibleSetupAccountView:0}),() => {
					this.carousel.goToPage(this.state.visibleSetupAccountView)}
				)
		}
		else if (this.state.visibleSetupAccountView > 0) {
			this.setState({ visibleSetupAccountView: --this.state.visibleSetupAccountView });
			this.carousel.goToPage(this.state.visibleSetupAccountView);
		}
	}

	closeModelAndSubmitAddress = () => {
		this.toggleAddEditAddressModal(false, false, null,this.state.numberOfAddress);
		this.props.onPressSubmitAddress();
	}

	render() {
		return (
			<Modal
				animationType="slide"
				hasBackdrop
				transparent={true}
				backdropOpacity={0}
				useNativeDriver={true}
				hideModalContentWhileAnimating={true}
				style={{ flex:1,margin:0}}
				isVisible={this.state.isAddEditAddressVisible}
				onBackdropPress={() => {
					this.toggleAddEditAddressModal(false);
				}}>
				 <View style={styles.mainModalContainer}>
				<View style={styles.headerModelContainer}>
						 <View style={styles.leftContainer}>
							{this.state.visibleSetupAccountView !== 0 &&
								<TouchableOpacity
									style={styles.headerIcon}
									onPress={() => this.gotoBackSlider()}>
									<Image
										source={I18nManager.isRTL ? Images.icons.RightGrey : Images.icons.LeftGrey}
										style={styles.backIcon}
									/>
								</TouchableOpacity>
							}
						</View>
						<View style={styles.centerContainer}>
							<Text  style={styles.addModelTitle}>{this.state.addAddressModal ? translate("NewAddress") : translate("EditAddress")}</Text>
							<DotIndicator count={3} filledCount={1 + this.state.visibleSetupAccountView} filleBackgroundColor={Colors.pinkishRed} />
						</View>
						<View style={styles.rightContainer}>
							<TouchableOpacity style={{}} onPress={() => this.toggleAddEditAddressModal(false, false, null)}>
								<Image source={Images.icons.closeBox}
									style={styles.backIcon} />
							</TouchableOpacity>
						</View>
					</View>
					 <View style={styles.addressFieldContainer}> 
						<CarouselPager ref={ref => this.carousel = ref} blurredZoom={1} containerPadding={0}>
							{this.state.visibleSetupAccountView == 0 &&
								<ProfileAddress navigation={this.props.navigation}
								key={'page0'} gotoNext={this.gotoNextSlider} addAddressModal={translate(this.state.numberOfAddress)}
									addressVal={this.state.addressItem}></ProfileAddress>
							}

							{this.state.visibleSetupAccountView == 1 && 
								
								<AddDaysAddress key={'page1'} gotoNext={this.gotoNextSlider} addressVal={this.state.addressItem}></AddDaysAddress>
							}

							{this.state.visibleSetupAccountView == 2 &&
								<ProfileDeliveryTime key={'page2'} gotoNext={this.closeModelAndSubmitAddress}
									addressVal={this.state.addressItem}></ProfileDeliveryTime>
							}
						</CarouselPager>
					</View> 
					
				</View>
			</Modal>
		);
	}
}

const styles = StyleSheet.create({
	mainModalContainer: {
		flex: 1,
		marginTop:screen.height * 0.055,
		backgroundColor: Colors.white,  //Colors.paleGreyTwo,		
		borderTopLeftRadius: 36,
		borderTopRightRadius: 36,
		justifyContent: 'center',
		

	},
	headerModelContainer: {
		borderTopLeftRadius: 36,
		borderTopRightRadius: 36,
		flexDirection: "row",
		alignItems: "center",
		width: "100%",
		height:60,
		paddingHorizontal: 16,
		backgroundColor: Colors.white,
		justifyContent: "center",
	},
	leftContainer: {
		alignItems: "flex-start",
		paddingVertical: 16,
		width: "33.3%",
		height: 60,
	},
	centerContainer: {
		alignItems: "center",
		width: "33.3%",
		height: 60,
	},
	rightContainer: {
		alignItems: "flex-end",
		paddingVertical: 16,
		width: "33.3%",
		height: 60,

	},
	headerIcon: {
		alignItems: 'flex-start',
		justifyContent: 'center',
		width: 28,
		height: 28,
	},
	backIcon: {
		width: 28,
		height: 28,
	},
	addModelTitle: {
		width:"100%",
		fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
		fontSize: Styles.FontSize.fnt15,
		color: Colors.black,
		textAlign: 'center',
		letterSpacing: -0.1,
		paddingTop: 15,
		marginBottom: 12,
	},
	addressFieldContainer: {
		flex:1,
		paddingTop:24,
	}
});