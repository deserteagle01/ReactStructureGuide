import React, { Component } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet ,ScrollView,Dimensions,StatusBar,Platform} from "react-native";
import { translate } from "@languages";
import Modal from "react-native-modal";
import { Images, Styles, Colors } from "@common";
import HTML from 'react-native-render-html';
export default class SimpleMessageModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isVisible: false,
			title: translate('ErrorTitle'),
			message: '',
			options:{},
		};
		this.toggleModal = this.toggleModal.bind(this);
		this.inputHtml = this.inputHtml.bind(this);
	}

	toggleModal = (visible, message, title,options) => {
			this.setState({ message: message, title:title, isVisible: visible,options:options });
	};

	inputHtml = () => {
		if(this.state.message !== "") {
			return (
				<View style={styles.descContainer}>
					<Text style={styles.descText} > {this.state.message} </Text>
					</View>)
		}
		else if (this.state.options!=={} && this.state.options!== undefined && this.state.options.htmlContent ) {
			return (
					<ScrollView style={{paddingRight:20}}
						showsVerticalScrollIndicator={false}
						scrollEnabled={true}>
						<HTML 
						html={this.state.options.htmlContent}
						 />
						 </ScrollView>
			);
		}  
	}
	render() {	
		const { modalStyle } = this.props;	
		return (	
			<Modal
				hasBackdrop
				isVisible={this.state.isVisible}
				hideModalContentWhileAnimating={true}
				useNativeDriver={true}
				style={styles.modalContainer}
				onBackdropPress={() => {
					this.toggleModal(false);
				}}>
				<View style={[styles.mainContainer,modalStyle]}>
					<View style={styles.titleContainer}>
						<Text style={styles.titleText} > {this.state.title} </Text>
					</View>
					<View style={styles.btnContainer}>
						<TouchableOpacity onPress={() => this.props.onClose()}>
							<Image
								source={Images.icons.close}
								style={styles.closeIcon} />
						</TouchableOpacity>
					</View>
					{this.inputHtml()}			
				</View>
			</Modal>	
		);
	}
}

const styles = StyleSheet.create({
	modalContainer:{
		margin:0,
		alignItems: "center",
		justifyContent: "center",
		flex:1,
	},
	mainContainer:{
		flexDirection: 'column',
		position: "absolute",
		minHeight: 140,
		width: Styles.width-32,
		borderRadius: 20,
		marginLeft:16,
		marginRight:16,
		paddingLeft: 41,
		paddingRight: 41,
		paddingBottom: 24,
		paddingTop: 24,
		justifyContent: "center",
		backgroundColor: Colors.white,
	},
	titleContainer: {
		flexDirection: "row",
		paddingBottom: 8,
		paddingLeft:16,
		paddingRight:16,
		alignItems: "center",
		justifyContent: "center",
	},
	titleText: {
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		fontSize: 17,
		textAlign: "center",
		color: Colors.darkNavyBlue
	},
	descContainer: {
		flexDirection: "row",
	},
	descText: {
		fontFamily: Styles.FontFamily().ProximaNova,
		fontSize: 14,
		alignSelf: "center",
		textAlign: "center",
		flex: 1,
		color: Colors.black08
	},
	btnContainer: {
		right: 16,
		top: 24,
		position: 'absolute',
	},
	closeIcon: {
		width: 28,
		height: 28,
	},
})
