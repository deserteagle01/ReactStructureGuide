/** @format */

import React, { Component } from "react";
import { connect } from "react-redux";
import {View, Text, filter, FlatList, StyleSheet, Image, TouchableOpacity, I18nManager, TextInput, Dimensions} from "react-native";
import { Images, Colors, Styles, Validations } from "@common";
import { translate } from "@languages";
import { Spinner, Toast, Badge } from "@components";
import { communicationNameGetter} from "../../common/Utility";
const { height, width } = Dimensions.get("window");
const  MAX_BADGE_LINES = 3;
const BADGE_LINE_SIZE = 36;

export class SelectionRow extends Component {
	constructor(props) {
		super(props);
		this.state = {
			item: this.props.item,
			selectedValue:null,
			isGroupView: props.isGroupView
		}
	}
	onPress = () => {
		let item = this.state.item
		item.isChecked = !item.isChecked;
		this.setState({ item:item});
		if(this.props.onChangeItem) {
			this.props.onChangeItem(item);
		}
		
	}
	render() {
		const { item , ...rest} = this.state;
		return (
			<TouchableOpacity style={[styles.selectionRow,!item.value && {height: 72}]} disabled={!item || !item.value} onPress={() => this.onPress()}>
				{item && item.value && <View style={[styles.viewCheckbox,this.state.isGroupView && {marginLeft: 9}]}>
                	<Image style={[styles.selectionCheckbox]} source={item.isChecked?I18nManager.isRTL ? Images.icons.rightCheckedOrange : Images.icons.leftCheckedOrange: Images.icons.uncheckedIcon} />
				</View>}
				<View style={[styles.selectionItemTextCont,item && item.value && {marginLeft: 9}]}>
					<Text style={[styles.selectionItemText(this.props.lang),item && item.value && {marginLeft: 9},!item.value && styles.headerText]}>{this.props.getCName(item,"label")}</Text>
				</View>
			</TouchableOpacity>
		);
	}
}


class SelectionList extends Component {
	constructor(props) {
		super(props);
		this.state = {
			allData: null,
			data: null,
			selectedValues: [],
			search_text: ''
		}
		this.allDataById = {};
	}
	fetchSelectionData(){
		if(!this.props.data && this.props.fetchSelectionData){
			return this.props.fetchSelectionData();
		}else{
			console.log("This is the data ", this.props.data);
			return new Promise((resolve, reject)=>{
				resolve(this.props.data);
			});
		}
	}
	fetchSelectedValues(nextProps){
		return new Promise((resolve, reject)=>{
			if(!nextProps.selectedValues && nextProps.fetchSelectedValues){
				nextProps.fetchSelectedValues().then((selectedData)=>{
					resolve(selectedData);
				}).catch(e => {
					this.toast.show(e);
					reject(e);
				});
			}else{
				resolve(nextProps.selectedValues || []);
			}
		});
	}	
	componentDidMount() {
		this.fetchSelectionData().then((data) => {
			for (let i = 0; i < data.length; i++) {
				//needs to copy data objects
				data[i].isChecked = false;
				this.allDataById[data[i].value]=data[i];
			}
			this.setState({data:data,allData:data});
			this.processValues(this.props);
		}).catch(e => {
			this.toast.show(e);
		});
	}
	componentWillReceiveProps(nextProps) {
		console.log("Modal Received props ", nextProps," Is prop changed: ",nextProps!=this.props);
		if(this.props!=nextProps) {
			this.processValues(nextProps);
		}
	}
	processValues(nextProps){
		let selectedValues = [];
		this.fetchSelectedValues(nextProps).then((selectedData)=>{
		console.log(this.allDataById);
		for( j = 0; j < selectedData.length; j++){
			let existingItem = this.allDataById[selectedData[j]];
			console.log("Existing item",selectedData,existingItem,selectedData[j]);
			if (existingItem) {
				existingItem.isChecked = true;
				selectedValues.push(existingItem);
			}
		}
		console.log(this.state.data,selectedValues);
		this.setState({selectedValues:selectedValues});
		}).catch((error)=>{
			console.log('Error:',error);
		})

	}

	searchFilter = (text) => {
		console.log("Apply search for ",text);
		let newData = null;
		if(text) {
			const textData = text.toUpperCase();
			newData = this.state.allData.filter(item => {
				const itemData = `${item.label.toUpperCase()} ${item.label.toUpperCase()} ${item.label.toUpperCase()}`;
				return itemData.indexOf(textData) > -1;
			});	
			newData = newData.sort();
			console.log("Final data ", newData);
		} else {
			newData = this.state.allData.sort();
			this.refs.textInput && this.refs.textInput.blur();
		}
		this.setState({ data: newData, search_text: text });
	};

	onChangeItem = (selectItem) => {
		if(this.props.multiSelect) {
			if(selectItem.isChecked) {
				this.state.selectedValues.push(selectItem);
			} else {
				var index = this.state.selectedValues.indexOf(selectItem);
				this.state.selectedValues.splice(index, 1); 
			}
			this.setState({selectedValues:this.state.selectedValues});
		} else {
			if(this.state.selectedValues && this.state.selectedValues[0] && this.state.selectedValues[0]!=selectItem) {
				this.state.selectedValues[0].isChecked = false;
			}
			this.setState({selectedValues:selectItem.isChecked?[selectItem]:null});
			if(selectItem.isChecked && this.props.onSelectItem) {
				this.props.onSelectItem(selectItem);
			}
		}
		// console.log("Call back for sleecte item ", selectItem, this.state.selectedValues);
	}
	_renderItem = ({ item, index }) => {
		return (
			<View>
				<SelectionRow 
					onChangeItem={(itemReturn) => this.onChangeItem(itemReturn)}
					item={item} 
					key={item.value}
					isGroupView={this.props.isGroupView}
					lang={this.props.lang}
					getCName = {this.props.getCName}/>
			</View>
		);
	}

	render() {
		return (
			<View style={styles.selectionListcontainer}>
					{this.props.search ?
					<View style={styles.searchContainer}>
						<Image style={[styles.searchIcon]} source={I18nManager.isRTL ? Images.icons.rightSearchIcon : Images.icons.leftSearchIcon} />
						<TextInput style={[styles.searchText(this.props.lang)]} ref={'textInput'} selectionColor={Colors.black} placeholder={translate('Search')} onChangeText={text => this.searchFilter(text)} autoCorrect={false} value={this.state.search_text} />
						{this.state.search_text ? <TouchableOpacity
							onPress={() => {
								this.searchFilter()
							}}>
							<Image source={Images.icons.closeBox} />
						</TouchableOpacity> : null}
					</View>
					:null
					}
					{this.props.showSelection ?
					<View style={{}}>
						<View ref="refBadgeContainer" style={[styles.selectedValuesContainer,this.state.showMore?{maxHeight:null}:{}]}
							onLayout={()=>{
								this.refs.refBadgeContainer.measure((fx, fy, width, height, px, py)=> {
									let badgeOverflow =  (height>=(BADGE_LINE_SIZE*MAX_BADGE_LINES)-5)?true:false
									if(this.state.badgeOverflow!=badgeOverflow) {
										this.setState({badgeOverflow:badgeOverflow});
									}									
									// console.log('Component width is: ' + width)
									// console.log('Component height is: ' + height)
									// console.log('X offset to frame: ' + fx)
									// console.log('Y offset to frame: ' + fy)
									// console.log('X offset to page: ' + px)
									// console.log('Y offset to page: ' + py)
								});
							}}
							>
							{this.renderSelectedItems()}
							
						</View>
						{this.state.badgeOverflow?
							<View style={{justifyContent:"flex-end",flexDirection:"row", marginRight:16}}>
								<TouchableOpacity onPress={()=>{
									this.setState({showMore:!this.state.showMore});
								}}>
									<Text style={{marginLeft:16,fontWeight:"bold",color:Colors.pinkishRed}}>{!this.state.showMore?"Show More":"Show Less"}</Text>
								</TouchableOpacity>
							</View>:null
						}
					</View>
					:null
					}
					
					<FlatList
						style={styles.selectionListContainer}
						data={this.state.data}
						showsVerticalScrollIndicator={false}
						keyExtractor={(item, index) =>  item.value ? item.value.toString() : index}
						renderItem={this._renderItem}
						extraData={this.state} />

					{this.props.isLoading ? <Spinner mode="overlay" /> : null}
					<Toast refrence={(refrence) => this.toast = refrence} />
			</View>
		);
	}
	renderSelectedItems() {
		return this.state.selectedValues.map((value,index) => {		
			let item = value;
			if(item!=null){
				return (
					<Badge 
						value={item.label}
						badgeStyle={[styles.selectedValueBadge]}
						textStyle={styles.selectedValueBadgeText}
						containerStyle={[styles.selectedValueBadgeContainer]} 
						iconImage={<Image source={Images.icons.cancel_red3x} style={{width: 16,height: 16}}/>}
						key={index}
						onPress={()=>{
							console.log("### Clicked ",item);
							item.isChecked = false;
							this.onChangeItem(item);
						}}
						/>
				);
			}
		});

	}	
}


const styles = StyleSheet.create({
    label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		lineHeight: 36,
		textAlign: 'center',
	}),
	selectedValueBadge: {
		backgroundColor: Colors.pinkishRed,
		height:32,
		borderRadius:30,
		padding:8,
		flexDirection:"row"

	},
	selectedValueBadgeText: {
		fontSize: Styles.FontSize.fnt14,
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
	},
	selectedValueBadgeContainer: {
		margin:2,
	},
	
   selectionListcontainer:{
		flex: 1,
	},
	selectedValuesContainer:{
        flexDirection: 'row',
		marginTop:8,
		paddingHorizontal: 15,
		flexWrap:"wrap",
		maxHeight:MAX_BADGE_LINES*BADGE_LINE_SIZE,
		overflow:"scroll"
	},
    searchContainer:{
        flexDirection: 'row',
        height: 44,
        backgroundColor: 'white',
        borderColor: 'rgba(242, 243, 244, 1)',
        borderWidth: 1,
        borderRadius: 24,
		marginHorizontal: 16,
		marginTop:16,
        paddingHorizontal: 15,
        alignItems: 'center',
        shadowColor: Platform.OS === 'ios'?Colors.black:'#f6f6f6',
        shadowOffset: {
            width: 0,
            height: 4,
        },
        shadowOpacity: Platform.OS === 'ios'?0.1: 0.01,
        shadowRadius: Platform.OS === 'ios'?24:50,
        elevation: Platform.OS === 'ios'?5:10,
    },
    searchText: (lang) => ({
        flex: 1,
        height: 42,
        color: Colors.black,
		fontSize: Styles.FontSize.fnt14,
        fontFamily: Styles.FontFamily(lang).ProximaNova,
        marginLeft: 8,
        //paddingLeft: 10,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    }),
    searchIcon:{
        width: 23,
        height: 24
	},
	selectionListContainer:{
        //flex:1,
		marginHorizontal: 14,
		marginTop: 16,
		flex: 1,
	},
	//Selection row styles
	selectionRow:{
        flexDirection: 'row',
        height: 60,
		alignItems: 'center',
		// backgroundColor:"red",
	},
	viewCheckbox:{
		height:"100%",
		flexDirection:'row',
		justifyContent:"center",
		alignContent:"center",
		alignItems:"center",
		// backgroundColor:"gray",
        // borderBottomColor: 'rgba(242, 243, 244, 1)',
		// borderBottomWidth: 1,
	},
    selectionRowExtraHeight:{
        flexDirection: 'row',
        height: 100,
        alignItems: 'center'
    },
    selectionCheckbox:{
        width: 28,
		height: 28,
		
    },
    selectionItemTextCont:{
		flex:1,
		height: "100%",
        flexDirection:'row',
        borderBottomColor: 'rgba(242, 243, 244, 1)',
		borderBottomWidth: 1,
        paddingVertical:19,
        flexWrap: 'wrap'
    },
    selectionItemText: (lang) => ({
        color: Colors.black,
		fontSize: Styles.FontSize.fnt21,
        fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
        lineHeight: 28,
        textAlign: 'left',

	}),
	headerText:{
		fontSize: 28,
		lineHeight: 40,
		fontWeight: 'bold',
		alignItems: "center",
		letterSpacing: -0.1,
		width: '100%'
	}
});

const mapStateToProps = (state) => {
	console.log("Fetch master list ", state.fetchMasterListReducer);
	return {
		getCName: communicationNameGetter(state),		
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SelectionList);
