import React, { Component } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet, I18nManager } from "react-native";

import { Styles, Images, Colors } from "@common";

export default class DisLikeRow extends Component {
    renderDislikes=()=>{
        const {
			isFrom,app_Lang,lang,item
        } = this.props;
        if(isFrom=="Profile"){
            return( <Text style={styles.dislikeItemTxt(lang)}>
            { app_Lang=="en"?item.label:item.label_ar }
        </Text>)
        }else{
            return(
            <Text style={styles.dislikeItemTxt(lang)}>
            {lang=="en"?item.label:item.label_ar}
        </Text>)
        }
       
    }
	render() {
		const {
			item,
			imageFlag,
            onPress,
        } = this.props;
		return (
			<TouchableOpacity style={item.label.length > 30?styles.dislikeRowExtraHeight:styles.dislikeRow} onPress={() => onPress(item)}>
                <Image style={[styles.dislikeCheckbox]} source={item.isChecked?I18nManager.isRTL ? Images.icons.rightCheckedOrange : Images.icons.leftCheckedOrange: Images.icons.uncheckedIcon} />
				<View style={styles.dislikeItemTxtCont}>
                    {this.renderDislikes()}
                </View>
			</TouchableOpacity>
		);
	}
}


const styles = StyleSheet.create({
	dislikeRow:{
        flexDirection: 'row',
        height: 60,
        alignItems: 'center'
    },
    dislikeRowExtraHeight:{
        flexDirection: 'row',
        height: 100,
        alignItems: 'center'
    },
    dislikeCheckbox:{
        width: 28,
        height: 28
    },
    dislikeItemTxtCont:{
        flex:1,
        flexDirection:'row',
        borderBottomColor: 'rgba(242, 243, 244, 1)',
        borderBottomWidth: 1,
        marginLeft: 9,
        paddingVertical:19,
        flexWrap: 'wrap'
    },
    dislikeItemTxt: (lang) => ({
        color: Colors.black,
		fontSize: Styles.FontSize.fnt21,
        fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
        lineHeight: 21,
        marginLeft: 9,
        textAlign: 'left',
        paddingTop: 3,
    })
});
