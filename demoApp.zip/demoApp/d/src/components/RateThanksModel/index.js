import React, { Component } from "react";
import {View, StyleSheet, Text, TextInput, TouchableOpacity, Image } from "react-native";
import Modal from "react-native-modal";
import moment from 'moment';
import { translate } from "@languages";
import { GradientButton, Toast, } from "@components";
import { Images, Styles, Colors, Constants } from "@common";

export default class RateThanksModel extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isRatingSuccess: false,
			image_url: '',
			product_name: ''
		};
		this.toggleRateThanksModal = this.toggleRateThanksModal.bind(this);
	}

	toggleRateThanksModal = (visible, image, product_name) => {
		console.log("visible==", visible)
		if(image != undefined && product_name != undefined){
			this.setState({ isRatingSuccess: visible, image_url:image, product_name: product_name});
		}else{
			this.setState({ isRatingSuccess: visible});
		}
	}

	_closeOnDone = () => {
		this.toggleRateThanksModal(false);
		this.props.gotoNext();
	}
 
	render() {
		return (
			<View style={styles.modalViewContainer}>				
				<Modal
					hasBackdrop
					hideModalContentWhileAnimating={true}
					transparent={true}
					backdropOpacity={0.5}
					useNativeDriver={true}
					isVisible={this.state.isRatingSuccess}
					style={styles.modalThanks}
					onBackdropPress={() => {
						this._closeOnDone(false);
					}}>
					<View style={styles.modalThankMainContainer}>
						<View style={styles.modelHeaderThanks}>
							<View style={styles.headerThanks}>
								<Image style={styles.mealImageThanks} source={this.state.image_url != ''?{uri: this.state.image_url }: Images.ProductListDefault} />
								<View style={styles.thanksStar}>
									<Image style={styles.starImageThanks} source={Images.icons.RatingWhite} />
									<Image style={styles.starImageThanks} source={Images.icons.RatingWhite} />
									<Image style={styles.starImageThanks} source={Images.icons.RatingWhite} />
									<Image style={styles.starImageThanks} source={Images.icons.RatingWhite} />
								</View>
							</View>
							<View style={styles.modalThanksContainer}>
								<Text numberOfLines={1} ellipsizeMode={"tail"} style={styles.greekRateThanksTx}>{this.state.product_name || ''}</Text>
								<Text style={styles.RateYourFoodThanksTx}>{translate("thanksReviewMsg")}</Text>
								<View style={styles.doneBtnContainer}>
									<GradientButton style={styles.submitBtn}
										onPressAction={() => { this._closeOnDone()}}
										text={translate("Done")}
									/>								
								</View>
							</View>
						</View>
					</View>
					
				</Modal>
			</View>
		);
	}
}

const styles = StyleSheet.create ({
	modalThanks:{
		flex: 1,
		alignItems: 'center',
	},
	modalThankMainContainer:{
		width: Styles.width - 48,
		height: 247,
		backgroundColor: Colors.white,
		borderRadius: 16,
	},
	modelHeaderThanks:{
		width: Styles.width-48,
	},
	headerThanks:{
		position: 'absolute',
		width: 80,
		height: 80,
		alignSelf: 'center',
		top: -40,
		shadowColor: "rgba(0, 0, 0, 0.16)",
		shadowOffset: {
			width: 0,
			height: 4,
		},
		shadowOpacity: 0.30,
		shadowRadius: 4.65,
		elevation: 8,
	},
	mealImageThanks:{
		width: 80,
		height: 80,
		borderRadius: 24
	},
	thanksStar:{
		flexDirection: 'row',
		height: 23,
		backgroundColor: 'rgb(250, 182, 25)',		
		justifyContent: 'center',
		alignSelf: 'center',
		borderRadius: 12,
		width: 70,
		position:'absolute',
		bottom: -3
	},
	starImageThanks:{
		width: 10,
		height: 9,
		alignSelf: 'center',
		marginHorizontal: 1.5,
	},
	modalThanksContainer:{
		alignItems: 'center',
		top: 40,
		marginTop: 16,
	},
	greekRateThanksTx:{
		fontFamily: Styles.FontFamily().ProximaNova,
		color: Colors.black06,
        fontSize: Styles.FontSize.fnt12,
		lineHeight: 14,
		letterSpacing: -0.14,
        textAlign: 'center',
	},
	RateYourFoodThanksTx:{
		marginTop: 8,
		fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
		color: Colors.black,
        fontSize: Styles.FontSize.fnt28,
		lineHeight: 36,
		letterSpacing: -0.1,
        textAlign: 'center',
	},
	
	doneBtnContainer:{
		marginTop: 24,
		marginHorizontal: 16,
		width: Styles.width - 80,
		alignItems: 'center'
	},
	submitBtn:{
		width: "100%"
	}
 })