import { StyleSheet, Dimensions, Platform, I18nManager } from "react-native";
const screen =Dimensions.get("screen");
import { Images, Styles, Colors } from "@common";
import normalize from 'react-native-normalize';
export default styles = StyleSheet.create({
 //wallet list item
 cardWalletList:{
    marginHorizontal:16,
    paddingHorizontal:16,
    flexDirection: "row",
    height:normalize(80),	
    width:screen.width-32,
    marginBottom:8,
    backgroundColor: Colors.white,
    borderRadius: 16,
    alignItems:"center",
    ...Platform.select({
        ios: {
          shadowColor:Colors.black12,
          shadowOpacity: 0.5,
          shadowRadius: 16,
          shadowOffset: {height: 6, width: 0}
        },
        android: {
          elevation: 6
        }
      })
},
rowView:{
    flex:1,
    backgroundColor:Colors.white,
    flexDirection: 'row',
    alignItems: 'center'
},
walletIconType:{
    width:normalize(48),
    height:normalize(48),
    borderRadius:normalize(48)/2,	
    alignItems:"center",
    justifyContent:"center",
    backgroundColor:Colors.lightRed,
},
bellicon:{
    width:normalize(36),
    height:normalize(36),	
},
headerView:{
    flexDirection:"column",
    paddingHorizontal:normalize(16),
    flex:3,
},
txtStatus:{
    textAlign: "left",
    color: Colors.black08,
    fontSize: normalize(15),
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
},
txtTime:{
    textAlign: "left",
    marginTop:5,
    color: Colors.black04,
    fontSize: normalize(12),
    fontFamily: Styles.FontFamily().ProximaNova,
},
walletItemAmount:{
    textAlign: "left",
    fontSize: normalize(20),
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
},
walletContainerAmount:{
    justifyContent:"flex-end",
    alignItems:"center",
    flex:2,
    flexDirection:"row",
},
info:{
    justifyContent:"center",
    alignItems:"center"
},
Confirmed:{
    backgroundColor:Colors.limeGreen,
},
Pending:{
    backgroundColor:Colors.lightYellow,
},
txtColorVermilion:{
    color:Colors.vermillion,
},
txtColorBlack:{
    color:Colors.black
}
});