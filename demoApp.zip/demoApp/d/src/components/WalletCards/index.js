import React from "react";
import { View, Text, Image, I18nManager } from "react-native";
import { Styles, Images, Colors } from "@common";
import { translate } from "@languages";
import styles from "./styles";
import moment from 'moment';
const WalletCards = ({ item }) => {
        var date = moment(item.date).format("DD MMM YYYY"+" | "+"HH:MM");
        let walletTxtDefaultColor = styles.txtColorVermilion;
        if(item.state!='Debit'){
            walletTxtDefaultColor = styles.txtColorBlack;
        }
        return (
            <View style={styles.cardWalletList}>
                <View style={[styles.walletIconType,styles[item.state]]}>
                <Image source={Images.icons.wallet} style={styles.bellicon} resizeMode="contain" />
                </View>
                <View style={styles.headerView}>
                <Text style={styles.txtStatus}>{item.state}</Text> 
                <Text style={styles.txtTime}>{date}</Text> 
                </View> 
                <View style={styles.walletContainerAmount}>
                <Text numberOfLines={1} style={[styles.walletItemAmount,walletTxtDefaultColor]}>{parseFloat(item.amount).toFixed(2)+" "}</Text>
                <Text numberOfLines={1} style={[styles.walletItemAmount,walletTxtDefaultColor]}>{translate("KD")}</Text></View>
             </View>
        );
};
export default WalletCards;