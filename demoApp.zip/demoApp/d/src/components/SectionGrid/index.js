import React, { Component } from 'react';
import {
  View, Dimensions, ViewPropTypes, SectionList
} from 'react-native';
import PropTypes from 'prop-types';
import { generateStyles, calculateDimensions, chunkArray } from './utils';

class SectionGrid extends Component {
  constructor(props) {
    super(props);
    this.onLayout = this.onLayout.bind(this);
    this.renderRow = this.renderRow.bind(this);

    const { staticDimension } = props;

    // Calculate total dimensions and set to state
    let totalDimension = staticDimension;
    if (!staticDimension) {
      totalDimension = Dimensions.get('window').width;
    }

    this.state = {
      totalDimension,
    };
  }

	scrollToLocation(sectionIndex, dataLength){
    setTimeout(() => {
    // alert((dataLength-1) + " - " + sectionIndex)
      this.sectionList.scrollToLocation(
  				{
  					// sectionIndex: count,
  					// itemIndex: 0,

  					animated: true,
  						itemIndex: -1,
  						sectionIndex: sectionIndex,
              // viewPosition:0,
  						viewPosition: (dataLength-1) == sectionIndex ? 0.6 : 0.05, //(dataLength-1) == sectionIndex ? 0.6 : -0.1,
              // viewOffset: '100',
  				}
  			);
    }, 150);

	}

  onLayout(e) {
    const { staticDimension, onLayout } = this.props;
    const { totalDimension } = this.state;

    if (!staticDimension) {
      const { width: newTotalDimension } = e.nativeEvent.layout || {};

      if (totalDimension !== newTotalDimension) {
        this.setState({
          totalDimension: newTotalDimension,
        });
      }
    }

    // call onLayout prop if passed
    if (onLayout) {
      onLayout(e);
    }
  }

  renderRow({
    renderItem,
    rowItems,
    rowIndex,
    section,
    itemsPerRow,
    rowStyle,
    separators,
    isFirstRow,
    containerStyle,
  }) {
    const { spacing, itemContainerStyle } = this.props;

    // Add spacing below section header
    let additionalRowStyle = {};
    if (isFirstRow) {
      additionalRowStyle = {
        marginTop: spacing,
      };
    }

    // console.log("----section grid----", `item_${(rowIndex * itemsPerRow) + 0}` ,rowIndex, itemsPerRow, rowItems);

    return (
      <View style={[rowStyle, additionalRowStyle]}>
        {rowItems.map((item, i) => (
          <View
            // key={`item_${(rowIndex * itemsPerRow) + i}`}
            // key={rowItems[i].product_id}
            style={[containerStyle, itemContainerStyle]}
          >
            {renderItem({
              item,
              index: (rowIndex * itemsPerRow) + i,
              section,
              separators,
              rowIndex,
            })}
          </View>
        ))}
      </View>
    );
  }

  render() {
    const {
      sections,
      style,
      spacing,
      fixed,
      itemDimension,
      staticDimension,
      renderItem: originalRenderItem,
      onLayout,
      ...restProps
    } = this.props;

    const { totalDimension } = this.state;

    const { containerDimension, itemsPerRow, fixedSpacing } = calculateDimensions({
      itemDimension,
      staticDimension,
      totalDimension,
      spacing,
      fixed,
    });

    const { containerStyle, rowStyle } = generateStyles({
      itemDimension,
      containerDimension,
      spacing,
      fixedSpacing,
      fixed,
    });

    const groupedSections = sections.map((section) => {
      const chunkedData = chunkArray(section.data, itemsPerRow);
      const renderItem = section.renderItem || originalRenderItem;
      return {
        ...section,
        renderItem: ({ item, index, section }) => this.renderRow({
          renderItem,
          rowItems: item,
          rowIndex: index,
          section,
          isFirstRow: index === 0,
          itemsPerRow,
          rowStyle,
          containerStyle,
        }),
        data: chunkedData,
        originalData: section.data,
      };
    });

    // console.log("Grouped secion:", item);

    return (
      <SectionList
        sections={groupedSections}
        // keyExtractor={(_, index) => `row_${index}`}
        // keyExtractor={(item, index) => index.toString()}
        style={style}
        onLayout={this.onLayout}
        ref={(sectionList) => { this.sectionList = sectionList; }}
        {...restProps}
        stickySectionHeadersEnabled={true}
        onEndReachedThreshold ={10}
      />
    );
  }
}

SectionGrid.propTypes = {
  renderItem: PropTypes.func,
  sections: PropTypes.arrayOf(PropTypes.any).isRequired,
  itemDimension: PropTypes.number,
  fixed: PropTypes.bool,
  spacing: PropTypes.number,
  style: ViewPropTypes.style,
  itemContainerStyle: ViewPropTypes.style,
  staticDimension: PropTypes.number,
  onLayout: PropTypes.func,
  listKey: PropTypes.string,
	scrollToLocation:PropTypes.func,
};

SectionGrid.defaultProps = {
  fixed: false,
  itemDimension: 120,
  spacing: 10,
  style: {},
  itemContainerStyle: undefined,
  staticDimension: undefined,
  onLayout: null,
  listKey: undefined,
};

export default SectionGrid;
