import React, { PureComponent } from "react";
import { AnimatedMove, ChoosePlanView, Fade, BookDietition, NavigationBar, Toast, Spinner, AvailableDietition, AppointmentCalendar, PaymentComponent, Shimmer} from "@components";
import Modal from "react-native-modal";
import { Animated, Dimensions, View, Text,ImageBackground, Alert } from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Appointment from "../../redux/Actions/Appointment";
import * as PlanAction from "../../redux/Actions/Plan";
import styles from "./styles";
const { height, width } = Dimensions.get("window");
import { languageNameGetter, convertToLocalDatetime} from "../../common/Utility";
import * as PaymentAction from "../../redux/Actions/Payment";
class AppointmentModal extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            isVisible:this.props.isVisible,
            fullWidth: false,
            currentStage: "book-dietition",
            title: "txtDietititonTitle",
            subtitle: null,
            currentItem: null,
        };
        this.setDataState();
    }

    show(isFromBookingPayment) {
        this.setDataState({isVisible:true, currentStage: "book-dietition",title: "txtDietititonTitle"});
        this.getDietitionList();
        if(isFromBookingPayment) {
            this.initiatePayment();
        }
    }

    setDataState(data) {
        let tempDict = {};
        if(data && data.hasOwnProperty("isVisible")){
            tempDict.isVisible = data.isVisible;
        }
        if(data && data.hasOwnProperty("currentStage")){
            tempDict.currentStage = data.currentStage;
        }
        if(data && data.hasOwnProperty("title")){
            tempDict.title = data.title;
        }
        tempDict.dietitionList = [...["First-Available"], ...this.props.appointmentData.dietitionList];
        tempDict.currentStageHeight = this.props.appointmentData.dietitionList.length + 1;
        this.setState(tempDict);
    }
    hide(data) {
        this.setState({isVisible:false, fullWidth:false});
        if(this.props.onModalClose) {
            this.props.onModalClose(data)
        }
        if(this.props.onModalHide) {
            this.props.onModalHide(data);
        }
    }
    
    componentDidMount() {
        
    }

    componentWillReceiveProps(nextProps){
        if(this.props != nextProps){
            if(nextProps.error != null){
                this.toast.show(nextProps.error)
            }
            if(nextProps.type == "GET_DIETITION_SUCCESS"){
                this.setDataState();
            }
        }
    }
    getDietitionList() {
        if (this.props.Connected) {
            this.props.actions.Appointment.getDietitionList(false);
        }
        else {
            this.toast.show(translate("InternetToast"));
        }
    }

   onPressback() {
        if(this.state.currentStage == "book-dietition") {
            this.setState({isVisible: false});
        }
        if(this.state.currentStage == "first-available") {
            this.show();
        }
        if(this.state.currentStage == "appointment-calendar") {
            this.show();
        }
    }

    onPressCancel() {
        this.setState({isVisible: false});
    }

    onPressCard(index, item) {
        if(index == 0){
            this.setState({currentStage: "first-available", title: "txtOptionalTitleNa", subtitle: "txtOptionalSubtitleNa", currentStageHeight: this.props.appointmentData.availableList.length });        
        }
        else{
            this.props.actions.Appointment.clearSelectedDate();
            this.setState({ currentItem: item ,currentStage: "appointment-calendar", title: "txtAppointmentTitle", subtitle: "txtAppointmentSubtitle", currentStageHeight: height*0.95 })
        }
    }

    cancelPress() {
        this.setState({currentStage: "book-dietition" });
        this.cancelAppointment();
    }

    cancelAppointment() {
        if (this.props.Connected) {
            this.props.actions.PlanAction.cancelAppointment(this.props.planData.appointment_id).then(() => {
              if (this.props.planData.error) {
                this.toast.show(this.props.planData.error);
              } else {
                this.setState({dietitionList: [...["First-Available"], ...this.props.appointmentData.dietitionList]});
              }
            });
          }
          else {
            this.toast.show(translate("InternetToast"));
          }
    }
    
    startPayment() {
        Alert.alert(
            translate("txtAlertConfirm"),
            translate('txtBookedWith')+this.props.getData(this.props.planData,"dietitian_name")+" "+translate("on")+" "+convertToLocalDatetime(this.props.planData.start_datetime,"DD MMMM YYYY hh:mm A"),
            [
              {text: translate("ContinuePay"), onPress: () => this.initiatePayment()},
              {text: translate("cancel"), onPress: () => this.cancelAppointment()},
            ],
            { cancelable: false }
          )
    }

    initiatePayment(){ 
        let reqParam = {
			isPayment: null
		}
        this.props.actions.PaymentAction.updatePaymentStatus(reqParam);
        this.setState({currentStage: "payment"});
    }

    paymentCompletes(param) {
        this.hide(param);
    }

    submitAppointment(id) {
        if (this.props.Connected) {
            this.props.actions.PlanAction.bookDietitionAppointment(id).then(() => {
            if (this.props.planData.error) {
                this.toast.show(this.props.planData.error);
            } 
            else {
                if (this.props.userInfo.isLogin) {
                    if(this.props.planData.payment_method == "online") {
                        this.startPayment();
                    }
                    else{
                        this.paymentCompletes(this.props.planData);
                    }
                }
                else{
                    this.hide();
                    if(this.props.onContinue != null) {
                        this.props.onContinue();
                    }else{
                        console.log('onContinue not passed as props');
                    }
                }
            }
        });
        }
        else {
            this.toast.show(translate("InternetToast"));
        }   
    }

    render() {
        return (
            <Modal
                hasBackdrop
                isVisible={this.state.isVisible}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={this.props.userInfo.isLogin ? 0.5 : 0}
                useNativeDriver={true}
                style={styles.modalStyle}
                onBackdropPress={() => this.hide()}
                onModalHide = {() => this.hide()}>
                
                {/* <AnimatedMove duration={300} style={[styles.ModalContainer, {height: this.props.userInfo.isLogin ?  "95%"  :  (this.state.currentStageHeight + 1) * 120, maxHeight: 0.95*height  } ]} animate={this.state.fullWidth} toHeight={height-40} fromHeight={height*0.80} >  */}
                <AnimatedMove duration={300} style={[styles.ModalContainer, {height: this.state.currentStage == "appointment-calendar" ? "95%" : (this.state.currentStageHeight + 1) * 120, maxHeight: 0.95*height  } ]} animate={this.state.fullWidth} toHeight={height-40} fromHeight={height*0.80} > 
                <View style={{flex:1, backgroundColor:Colors.white}}>
                    <NavigationBar 
                        title={translate(this.state.title)}
                        style={this.state.currentStage == "appointment-calendar" && styles.givenHeight }
                        subtitle={this.state.subtitle ?  this.state.subtitle ==  "txtAppointmentSubtitle" ?  translate(this.state.subtitle)+ this.props.getData(this.state.currentItem,"name")  : translate(this.state.subtitle) : null }
                        onPressBack={() => this.onPressback()}
                        onPressCancel={() => this.onPressCancel()}
                        />

                    <Fade remove={this.state.currentStage!="book-dietition"} visible={this.state.currentStage=="book-dietition"} duration={300} style={{flex:1}}>
                        <BookDietition 
                            list={this.state.dietitionList}
                            onPressCard={(index, item) => this.onPressCard(index, item)} />
                    </Fade>

                    <Fade remove={this.state.currentStage!="first-available"} visible={this.state.currentStage=="first-available"} duration={300} style={{flex:1}}>
                        <AvailableDietition onSubmitAppointment={(id) => this.submitAppointment(id)} updateHeight={(count) => this.setState({currentStageHeight: count}) } />
                    </Fade>   

                    <Fade remove={this.state.currentStage!="appointment-calendar"} visible={this.state.currentStage=="appointment-calendar"} duration={300} style={{flex:1}}>
                        <AppointmentCalendar item={this.state.currentItem} navigation={this.props.navigation} onSubmitAppointment={(id) => this.submitAppointment(id)} />
                    </Fade>

                    <Fade remove={this.state.currentStage!="payment"} visible={this.state.currentStage=="payment"} duration={100} style={{ position: "absolute", height:'100%', width:'100%' }}>
                        <PaymentComponent  
                            navigation={this.props.navigation} 
                            isPaymentfrom={"appointment"} 
                            cancelPress={() => this.cancelPress()}
                            ref={"paymentref"} 
                            onPaymentComplete={(param) => this.paymentCompletes(this.props.planData)} 
                            paymentSuccess={(isPayment) => console.log("---------------payment complete------------",isPayment) } />
                    </Fade>

                        
                    </View>
                    
                    <Toast refrence={(refrence) => this.toast = refrence} />
                    {/* { this.props.appointmentData.isLoadingFor || this.props.planData.isLoading ? <Spinner mode="overlay" /> : null} */}
                </AnimatedMove>

            </Modal>
        )
    }
}

  

function mergeProps(stateProps, dispatchProps, ownProps) {
    const { dispatch } = dispatchProps;
    return {
        ...ownProps,
        ...stateProps,
        actions: {
            Appointment: Appointment.bindActionCreators(dispatch, stateProps),
            PaymentAction: bindActionCreators(PaymentAction, dispatch),
            PlanAction: bindActionCreators(PlanAction, dispatch)
        }
    };
}
  
  const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    appointmentData: state.appointmentReducer,
    planData: state.PlanReducer,
    userInfo: state.updateUserReducer,
    getData: languageNameGetter(state),
    error: state.appointmentReducer.error,
    type: state.appointmentReducer.type
  });
  
  export default connect(mapStateToProps, undefined, mergeProps, { forwardRef: true })(AppointmentModal);
