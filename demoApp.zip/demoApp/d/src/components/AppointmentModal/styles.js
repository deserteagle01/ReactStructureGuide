
import { StyleSheet, Platform, Dimensions, I18nManager } from "react-native";
import { Images, Styles, Colors } from "@common";
import { FontScalling } from "../../common/Utility";
const { height, width } = Dimensions.get("window");

export default (styles = StyleSheet.create({
    ModalContainer: {
    height: '95%',
    width: '100%',
    justifyContent: 'center',
    position:'absolute',
    bottom: 0,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow:"hidden"
},
modalStyle:{
    padding:0, 
    margin:0,
  },
  givenHeight: {
    marginVertical: 15
  }
}));

