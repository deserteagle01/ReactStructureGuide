import React, { Component } from "react";
import { View, StyleSheet, Text, TextInput, Dimensions, Image, ActivityIndicator } from "react-native";
import { Colors, Styles } from "@common";
const screen = Dimensions.get("window");

export default function ActivityIndicator(props) {

    const { show } = props;
    return (
        <View>
             <ActivityIndicator size="small" color="darkgray"  animating={show}/>
        </View >
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
});
