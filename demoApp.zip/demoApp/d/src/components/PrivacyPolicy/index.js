import React, { Component } from "react";
import { connect } from "react-redux";
import { Platform, View, ScrollView, StyleSheet, Text, Dimensions, TouchableOpacity, Image,SafeAreaView } from "react-native";
import Modal from "react-native-modal";
import moment from 'moment';
import { translate, setI18nConfig } from "@languages";
import { GradientButton, Spinner, Toast } from "@components";
import { Images, Styles, Colors } from "@common";
import HTML from 'react-native-render-html';
import { bindActionCreators } from "redux";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";

const screen = Dimensions.get("window");
class PrivacyPolicy extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isPolicyVisible: false,
			isSubmitDisabled: true,
		};
		this.togglePrivacyPolicyModal = this.togglePrivacyPolicyModal.bind(this);
	}

	async togglePrivacyPolicyModal(visible){
		await this.setState({ isPolicyVisible: visible });
		if (this.props.Connected) {
			this.props.actions.MasterList.fetchPrivacyPolicy().then(() => {
				if(this.props.error == null){
					this.setState({"isSubmitDisabled": false})
				}else{
					this.toast.show(translate("InternetToast"));
				}
			});
		} else {
			this.toast.show(translate("InternetToast"));
		}
	};

	acceptContinue = visible => {
		this.setState({ isPolicyVisible: visible }, () => {
			this.props.gotoNext()
		});
	};

	render() {		
		const topMargin = Platform.OS === 'ios' ?Styles.height<812?"4.25%":"5%": "3%";
		return (
			<Modal
				hasBackdrop
				isVisible={this.state.isPolicyVisible}
				hideModalContentWhileAnimating={true}
				transparent={true}
				useNativeDriver={true}
				style={{ flex: 1, margin: 0, 
					top: topMargin}}
					onBackdropPress={() => {
					this.togglePrivacyPolicyModal(false);
				}}
				onBackButtonPress={() => {
					this.togglePrivacyPolicyModal(false);
				}}
			>
				    <SafeAreaView style={[Styles.common.safeareViewOnly]}>
				<View style={styles.mainModalContainer}>
					<View style={styles.headerModalContainer}>
						<Text style={styles.headerTitle}>
							{translate("PrivacyPolicy")}
						</Text>
						<View style={styles.headerSubTitleContainer}>
							<Text style={styles.headerSubTitle1}>
								{translate("LastUpdate")}: {" "}  
							</Text>
							<Text style={styles.headerSubTitle1}>
								{this.props.privacyPolicyData.last_updated_date != undefined && this.props.privacyPolicyData.last_updated_date != '' ? moment(new Date(this.props.privacyPolicyData.last_updated_date)).format('DD-MMM-YYYY'): " "}
							</Text>
						</View>
						<TouchableOpacity style={styles.headerCloseBtn}
							onPress={() => {
								this.togglePrivacyPolicyModal(false);
							}}
						>
							<Image source={Images.icons.closeBox} />
						</TouchableOpacity>
					</View>
						{this.props.privacyPolicyData.privacy_policy != undefined && this.props.privacyPolicyData.privacy_policy != '' &&
							<ScrollView style={this.props.notShowBtn?styles.policyTextContainer2:styles.policyTxtContainer}>
							<HTML containerStyle={{flexDirection:"column",paddingHorizontal:10,marginVertical:16,textAlign: 'justify'}} html={this.props.privacyPolicyData.privacy_policy} imagesMaxWidth={Dimensions.get('window').width} />
							</ScrollView>
						}
					{this.props.notShowBtn != true  &&
						<View>
					<GradientButton style={styles.acceptBtnContainer}
								disabled={this.state.isSubmitDisabled}
								onPressAction={() => {
									this.acceptContinue(false);
								}}
								text={translate("AcceptContinue")}
							/>  
						 </View>
					}
				</View>
				</SafeAreaView>
				<Toast refrence={(refrence) => this.toast = refrence} />
				{this.props.isLoading ? <Spinner mode="overlay" /> : null}
			</Modal>
		);
	}
}

const styles = StyleSheet.create({
	mainModalContainer: {
		flex: 1,
		backgroundColor: Colors.white,
		borderTopRightRadius:36,
		borderTopLeftRadius:36,
		paddingBottom:Platform.OS=="ios"?0:5,
	},
	headerModalContainer: {
		width: "100%",
		alignItems: "center",
		justifyContent: "center",
		height: 60,
		marginTop: 8,
		borderBottomColor: 'rgba(233, 233, 233, 1)',
		borderBottomWidth: 1,
	},
	headerTitle: {
		width: "100%",
		fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
		textAlign: 'center',
		fontSize: Styles.FontSize.fnt15,
		color: Colors.black,
		marginTop:8,
	},
	headerSubTitleContainer: {
		flex: 1,
		flexDirection: 'row',
		marginTop: 4,
		marginBottom: 9,
	},
	headerSubTitle1: {
		fontFamily: Styles.FontFamily().ProximaNova,
		textAlign: 'center',
		fontSize: Styles.FontSize.fnt12,
		color: 'rgba(0, 0, 0, 0.6)',
	},
	headerCloseBtn: {
		position: "absolute",
		right: 20
	},
	policyTxtContainer: {
		flex: 1,
		marginBottom: 100,
	},
	policyTextContainer2: {
		flex: 1,
	},
	privacyPolicyTxt: {
		flex: 1,
		alignSelf: "center",
		textAlign: "left",
	},
	textParagraph: {
		fontFamily: Styles.FontFamily().ProximaNova,
		fontSize: Styles.FontSize.fnt14,
		marginVertical: 9,
		color: 'rgba(0, 0, 0, 0.84)',
		lineHeight: 18,
	},
	acceptBtnContainer: {
		position: 'absolute',
		bottom: 34,
		height:56,
		width: screen.width - 32,
		shadowColor: 'rgba(0,0,0,0.4)',
		shadowOffset: { width: 1, height: 3 },
		shadowRadius: 7,
		shadowOpacity: 0.8,
		elevation: Platform.OS == "android" ? 7 : 0,
		backgroundColor:Colors.white,
		borderRadius: 10,

	},
});

const mapStateToProps = (state) => {
	return {
		isLoading: state.fetchMasterListReducer.isLoading,
		Connected: state.updateNetInfoReducer.isConnected,
		privacyPolicyData: state.fetchMasterListReducer.privacyPolicyData,
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			MasterList: bindActionCreators(MasterList, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(PrivacyPolicy);