import React, { Component } from "react";
import { View, Text, StyleSheet, TextInput, I18nManager, Platform } from "react-native";
import { connect } from "react-redux";
import { Styles, Validations, Colors, Images, } from "@common";
import { namePlaceHolders, checkLanguageFlag } from "../../common/Utility";
import InputTextStringProfile from "../InputTextStringProfile"
import InputWithIconProfile from "../InputWithIconProfile"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Spinner, Toast, SimpleMessageModal, InputAccessory } from "@components";
import * as switchLanguage from "../../redux/Actions/SwitchLanguageAction";
import RNRestart from 'react-native-restart';

class EditProfileInput extends Component {
  constructor(props) {
      super(props);
      this.state = {
        firstName: this.props.signupDetail.first_name,
        firstNameError: null,
        lastName: this.props.signupDetail.last_name,
        lastNameError: null,
        secondary_firstname:this.props.signupDetail.secondary_firstname,
        secondary_firstnameError: null,
        secondary_lastname: this.props.signupDetail.secondary_lastname,
        secondary_lastnameError: null,
        gender: this.props.signupDetail.gender,
        genderError: null,
        birthDate: this.props.signupDetail.birth_date,
        birthDateError: null,
        email: this.props.signupDetail.email,
        emailError: null,
        mobile: this.props.signupDetail.mobile,
        mobileError: null,
        language: this.props.signupDetail.lang||"en",
        languageError: null,
        commulanguage:this.props.signupDetail.com_lang || "ar",
        commulanguageError: null,
        old_lang: this.props.signupDetail.lang,
      };
      this.inputRefs = {};
  }

  componentDidMount() {
    if (this.props.Connected) {
      this.props.actions.MasterList.fetchLanguageList();
      this.props.actions.MasterList.fetchGenderList();
    } else {
      this.toast.show(translate("InternetToast"));
    }
  }
  firstNameHandler = (text) => {
    this.setState({ firstName: text })
  }

  lastNameHandler = (text) => {
    this.setState({ lastName: text })
  }
  arfirstNameHandler = (text) => {
    this.setState({ secondary_firstname: text })
  }
  arlastNameHandler = (text) => {
    this.setState({ secondary_lastname: text })
  }
  genderHandler = (text) => {
    if(text){
      this.setState({ gender: text })
    } 
  }
  // onCloseDatePicker=()=>{
  // setTimeout(()=>{
  //   this.inputRefs['language'].togglePicker(true);
  // },500);
  // }
  birthDateHandler = (text) => {
    this.inputRefs['refDatePicker'].hideDateTimePicker();

    this.setState({ birthDate: text });
  }

  emailHandler = (text) => {
    this.setState({ email: text })
  }

  mobileHandler = (text) => {
    this.setState({ mobile: text })
  }

  languageHandler = (text) => {
    if(text){
      this.setState({ language: text })
      // In case of application language is changed to Arabic, changing communication language to Arabic as well 
      // because when Applciation language it Arabic, communciation language can not be English.
      if (text == 'ar'){
        this.commulanguageHandler(text)
      }
    }
   
  }

  commulanguageHandler = (text) => {
      if(text && this.state.commulanguage != text){  
      this.setState({ commulanguage: text, firstName:this.state.secondary_firstname, lastName:this.state.secondary_lastname,
        secondary_firstname: this.state.firstName, secondary_lastname:this.state.lastName, 
        firstNameError:this.state.secondary_firstnameError, lastNameError:this.state.secondary_lastnameError,
        secondary_firstnameError:this.state.firstNameError, secondary_lastnameError:this.state.lastNameError
      });
    }
  }

  validateData = () => {
    let option = { fullMessages: false };
  
    var firstNameError = Validations('reqField', this.state.firstName, option);
    var lastNameError = Validations('reqField', this.state.lastName, option);
    var secondary_firstnameError = Validations('reqField', this.state.secondary_firstname, option);
    var secondary_lastnameError = Validations('reqField', this.state.secondary_lastname, option);
    let genderError = Validations('reqField', this.state.gender, option);
    let birthDateError = Validations('reqField', this.state.birthDate, option);
    let emailError = Validations('email', this.state.email, option);
    // let mobileError = Validations('mobile', this.state.mobile, option);
    let languageError = Validations('reqField', this.state.language, option);
    let commulanguageError = Validations('reqField', this.state.commulanguage, option);
    var firstNameError=null;
    
    if (!checkLanguageFlag(this.state.firstName,this.state.commulanguage)) {
       firstNameError = this.getError(this.state.commulanguage);
    }
    var lastNameError=null;
    if (!checkLanguageFlag(this.state.lastName,this.state.commulanguage)) {
       lastNameError = this.getError(this.state.commulanguage);
    }
    var secondary_firstnameError=null;
    var secondary_language = this.state.commulanguage=='ar'?'en':'ar';
    if (!checkLanguageFlag(this.state.secondary_firstname,secondary_language)) {
       secondary_firstnameError = this.getError(secondary_language);
    }
    var secondary_lastnameError=null;
    if (!checkLanguageFlag(this.state.secondary_lastname,secondary_language)) {
       secondary_lastnameError = this.getError(secondary_language);
    }

    this.setState({
      firstNameError: firstNameError, lastNameError: lastNameError, genderError: genderError, birthDateError: birthDateError, emailError: emailError, languageError: languageError,
      secondary_firstnameError: secondary_firstnameError, secondary_lastnameError: secondary_lastnameError,
      commulanguageError: commulanguageError
    })

    if (!firstNameError && !lastNameError && !genderError && !birthDateError && !emailError && !languageError && !commulanguageError && !secondary_firstnameError && !secondary_lastnameError) {

      if (this.props.Connected) {
        this.props.actions.UpdateUserAction.EditUserAction(this.state.firstName, this.state.lastName, this.state.gender,
          this.state.birthDate, this.state.email, this.state.language,this.state.secondary_firstname, this.state.secondary_lastname,this.state.commulanguage).then(() => {
            setTimeout(() => {
              if (this.props.signupDetail.sucessProfile) {

                let text = this.state.language;
                var set_rtl = false;
                if (text != "en") {
                  set_rtl = true;
                }
                setI18nConfig(text, set_rtl);

                if (text != this.state.old_lang) {
                  this.props.actions.switchLanguage.switchLanguageAction({ lang: text, rtl: set_rtl });
                  setTimeout(() => {
                    RNRestart.Restart()
                  }, 500)
                } else {
                  this.props.showSimpleModal("Success");
                }
              }
              else {
                this.props.showSimpleModal("Error");
              }

            }, 500);

          })
          .catch(e => {
            console.log('update user error--> ' + e);
          });
      } else {
        this.toast.show(translate("InternetToast"));
      }
    }
    return false;
  }
  getError(language) {
    if(language == 'ar')
      return "arabicError"
    else
      return "englishError"
  }
  onUpArrowClicked = (refs) => {
    if (refs == "firstname") {
      // this.props.navigation.goBack();
    }
    else if(refs=="secondary_firstname"){
      this.inputRefs["lastname"].focus();
    }
    else if (refs == "secondary_lastname") {
      this.inputRefs["secondary_firstname"].focus();
    }
    else if (refs == "lastname") {
      this.inputRefs["firstname"].focus();
    }
    else if (refs == "gender") {
      this.inputRefs["secondary_lastname"].focus();
    }
    else if (refs == "language") {
      this.inputRefs["refDatePicker"].showDateTimePicker();
    }
    else if (refs == "commulanguage") {
      this.inputRefs["language"].togglePicker(true);
    }
    else if (refs == "email") {
      if (this.state.language == "en") {
        this.inputRefs["commulanguage"].togglePicker(true);
      } else {
        this.inputRefs["language"].togglePicker(true);
      }
    }
  }

  onDownArrowClicked = (refs) => {
    if (refs == "firstname") {
      this.inputRefs["lastname"].focus();
    }
    else if (refs == "secondary_firstname") {
      this.inputRefs["secondary_lastname"].focus();
    }
    else if (refs == "lastname") {
      this.inputRefs["secondary_firstname"].focus();
    }
    else if (refs == "secondary_lastname") {
      this.inputRefs['gender'].togglePicker(true);
    }
    else if (refs == "gender") {
      this.inputRefs["refDatePicker"].showDateTimePicker();
    }
    else if (refs == "language") {
      if (this.state.language == "en") {
        this.inputRefs["commulanguage"].togglePicker(true);
      } else {
        this.inputRefs["email"].focus();
      }
    }
    else if (refs == "commulanguage") {
      this.inputRefs["email"].focus();
    } else if (refs == "email") {
      this.props.onPress();
    }
  }

  pickerSelectDone(refs) {
    this.inputRefs["language"].togglePicker(false);
  }
  pickerGenderSelectDone(ref) {
    this.inputRefs["gender"].togglePicker(false);
  }
  renderCommulanguage() {
    if (this.props.languageItem && this.state.language == "en") {
      return(
        <View>
          <Text style={[styles.mainTitle, { marginTop: 10, marginBottom: 10 }]}>{translate("CommuLanguage")}</Text>
          <InputTextStringProfile
            arrowHide={false}
            inputAccessoryViewID={"commulanguage"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}
           refName={"commulanguage"} pickerSelectDone={(ref) => this.pickerSelectDone(ref)}
            onRef={(el) => { this.inputRefs["commulanguage"] = el }} onUpArrowFun={this.onUpArrowClicked} onDownArrowFun={this.onDownArrowClicked} textHandler={(value,index)=>this.commulanguageHandler(value,index)} inputText={this.state.commulanguage} errorMsg={this.state.commulanguageError}
            inputType="3" itemObj={this.props.languageItem} placeholderText={translate("SelectLanguage")} />
        </View>
      );
    }
  }
  renderName(key,placeHolder,inputText,handler,errorMsg){
    return( <InputTextStringProfile
      inputType="1"
      appLanguage={this.state.language}
      style={styles.textNameInput}
      inputAccessoryViewID={key} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}
      refName={key} onRef={(el) => { this.inputRefs[key] = el }}
      textHandler={handler} 
      errorMsg={errorMsg}
      inputText={inputText} 
      placeholderText={placeHolder} 
      />)
  }

  render() {
    var secondary_language = this.state.commulanguage=='en'?'ar':'en';
    
       return (
      <View style={styles.profileContainer}>
        <KeyboardAwareScrollView enableOnAndroid={true} keyboardShouldPersistTaps={'always'} showsVerticalScrollIndicator={false}>
          <View>
            <Text style={styles.mainTitle}>{translate("ProfileInformation")}</Text>
            
  
             <View>
            <View style={styles.name}>
              {this.renderName("firstname",namePlaceHolders[this.state.commulanguage].firstName,this.state.firstName,this.firstNameHandler,this.state.firstNameError)}
              {this.renderName("lastname",namePlaceHolders[this.state.commulanguage].lastName,this.state.lastName,this.lastNameHandler,this.state.lastNameError)}
            </View>
            <View style={styles.name}>
              {this.renderName("secondary_firstname",namePlaceHolders[secondary_language].firstName,this.state.secondary_firstname,this.arfirstNameHandler,this.state.secondary_firstnameError)}
              {this.renderName("secondary_lastname",namePlaceHolders[secondary_language].lastName,this.state.secondary_lastname,this.arlastNameHandler,this.state.secondary_lastnameError)}
            </View>
            </View>
          
           

            <View style={[styles.mainContainer]}>
              <Text style={styles.textTitle}>{translate("Gender")}</Text>
              {this.props.genderItem &&
                <InputTextStringProfile
                  pickerSelectDone={(ref) => this.pickerGenderSelectDone(ref)}
                  arrowHide={false}
                  inputAccessoryViewID={"gender"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}
                  refName={"gender"} onRef={(el) => { this.inputRefs["gender"] = el }}
                  onUpArrowFun={this.onUpArrowClicked}
                  onDownArrowFun={this.onDownArrowClicked}
                  textHandler={this.genderHandler} inputText={this.state.gender}
                  errorMsg={this.state.genderError} inputType="5"
                  itemObj={this.props.genderItem} placeholderText={translate("SelectGender")} />
              }
            </View>
            <View style={styles.mainContainer}>
              <Text style={styles.textTitle}>{translate("DateofBirth")}</Text>
              <View style={styles.inputNameContainer}>
                <InputWithIconProfile
                  // onCloseDatePicker={()=>this.onCloseDatePicker()}
                  refName={"refDatePicker"}
                  inputAccessoryViewID={"refDatePicker"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}
                  onRef={(el) => { this.inputRefs["refDatePicker"] = el }}
                  textHandler={this.birthDateHandler} errorMsg={this.state.birthDateError}
                  inputText={this.state.birthDate} iconPath={Images.icons.calendarIcon}
                  placeholderText="" inputType="3" />
              </View>
            </View>
             {/* Disablling  language change feature from profile temporary on TASK 17099 */}
            {/* <Text style={[styles.mainTitle, { marginTop: 24, marginBottom: 10 }]}>{translate("ChangeLanguage")}</Text>
            {this.props.languageItem &&
              <InputTextStringProfile
                arrowHide={false}
                inputAccessoryViewID={"language"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}
                refName={"language"} pickerSelectDone={(ref) => this.pickerSelectDone(ref)}
                onRef={(el) => { this.inputRefs["language"] = el }} onUpArrowFun={this.onUpArrowClicked} onDownArrowFun={this.onDownArrowClicked} textHandler={this.languageHandler} inputText={this.state.language} errorMsg={this.state.languageError}
                inputType="3" itemObj={this.props.languageItem} placeholderText={translate("SelectLanguage")} />
            }
            {this.renderCommulanguage()} */}
            <Text style={[styles.mainTitle, { marginTop: 10 }]}>{translate("ContactInformation")}</Text>
            <View style={styles.mainContainer}>
              <Text style={styles.textTitle}>{translate("EmailAddress")}</Text>
             
            <View style={styles.inputNameContainer}> 
            <InputTextStringProfile 
                inputAccessoryViewID={"email"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}
              refName={"email"} onRef={(el) => {this.inputRefs["email"] = el}} textHandler={this.emailHandler} errorMsg={this.state.emailError} inputText={this.state.email} placeholderText="" inputType="1"/>
            </View> 
            </View>
            <View style={styles.mainContainer}>
              <Text style={[styles.textTitle, { color: Colors.black04 }]}>{translate("PhoneNo")}</Text>
              <View style={styles.inputNameContainer}>
                <InputTextStringProfile textHandler={this.phoneHandler} errorMsg={''} inputText={this.state.mobile} placeholderText="" inputType="4" />
              </View>
            </View>
          </View>
        </KeyboardAwareScrollView>
        {Platform.OS == 'ios' &&
          <View>
            <InputAccessory disableUpArrow={true}
              inputAccessoryViewID={"firstname"} hideDoneBar={true} onUpArrowClick={() => this.onUpArrowClicked('firstname')} onDownArrowClick={() => this.onDownArrowClicked('firstname')} />
            <InputAccessory inputAccessoryViewID={"lastname"} hideDoneBar={true} onUpArrowClick={() => this.onUpArrowClicked('lastname')} onDownArrowClick={() => this.onDownArrowClicked('lastname')} />
            <InputAccessory disableDownArrow={true}
              inputAccessoryViewID={"email"} hideDoneBar={true} onUpArrowClick={() => this.onUpArrowClicked('email')} onDownArrowClick={() => this.onDownArrowClicked('email')} />
            <InputAccessory
              inputAccessoryViewID={"secondary_firstname"} hideDoneBar={true} onUpArrowClick={() => this.onUpArrowClicked('secondary_firstname')} onDownArrowClick={() => this.onDownArrowClicked('secondary_firstname')} />
            <InputAccessory inputAccessoryViewID={"secondary_lastname"} hideDoneBar={true} onUpArrowClick={() => this.onUpArrowClicked('secondary_lastname')} onDownArrowClick={() => this.onDownArrowClicked('secondary_lastname')} />
          </View>
        }
        <Toast refrence={(refrence) => this.toast = refrence} position="bottom" />
      </View>

    );
  }
}

const styles = StyleSheet.create({
  mainContainer: {
    marginLeft: 2,
    marginTop: 20,
    height: 59,
    borderBottomColor: Colors.whiteTwo,
    borderBottomWidth: 2
  },
  profileContainer: {
    marginHorizontal: 16,
    marginVertical: 16,
  },
  name: {
    marginLeft: 2,
    marginTop: 20,
    width: Styles.width - 32,
    borderBottomColor: Colors.whiteTwo,
    borderBottomWidth: 2,
    height: 40,
    flexDirection: "row",
  },
  textNameInput: {
    width: (Styles.width - 32) / 2,
    justifyContent: "flex-start",
    paddingRight: 10,
  },
  mainTitle: {
    fontSize: Styles.FontSize.fnt13,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    color: Colors.reddishGrey,
    textAlign: 'left'
  },
  textTitle: {
    fontSize: Styles.FontSize.fnt12,
    fontFamily: Styles.FontFamily().ProximaNova,
    color: Colors.black08,
    textAlign: 'left'
  },
  inputNameContainer: {
    marginTop: 1,
  },
  subText: {
    color: Colors.greyishBrown,
    fontSize: Styles.FontSize.fnt12,
    fontFamily: Styles.FontFamily().ProximaNova,
    textAlign: 'left'
  },
});

const mapStateToProps = (state) => {
  // console.log("lena", state.fetchMasterListReducer.language);
  return {
    signupDetail: state.updateUserReducer,
    languageItem: state.fetchMasterListReducer.language,
    genderItem: state.fetchMasterListReducer.gender,
    blockItem: state.fetchMasterListReducer.blocks,
    Connected: state.updateNetInfoReducer.isConnected,
    selectedLangFlag: state.switchLanguageReducer,
    error: state.updateUserReducer.error,
  }
};

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      MasterList: bindActionCreators(MasterList, dispatch),
      UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
      switchLanguage: bindActionCreators(switchLanguage, dispatch),
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(EditProfileInput);
