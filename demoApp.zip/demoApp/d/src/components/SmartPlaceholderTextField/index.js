import React, { Component } from "react";
import { View, StyleSheet, Text, TextInput, Dimensions, Image, I18nManager } from "react-native";
import { Colors, Styles } from "@common";
import { translate, setI18nConfig } from "@languages";
const screen = Dimensions.get("window");

export default class SmartPlaceholderTextField extends Component {
    constructor(props) {
		super(props);
        this.state = {
            hasFocus:0,
            valueInternal:""
        };
    }
    componentDidMount(){
	}

	componentDidUpdate(){
	}

	componentWillUnmount() {
    }

    componentWillReceiveProps(nextProps) {
        if(this.props!=nextProps){
            this.setState({valueInternal : nextProps.value});
        }
    }
  
    
    
    onChangeText = (text) =>{
        this.setState({valueInternal:text});
        if(this.props.onChangeText){
            this.props.onChangeText(text);
        }
    } 
    onFocus = (text) =>{
        this.setState({hasFocus:1});
        if(this.props.onFocus){
            this.props.onFocus(text);
        }
    } 
    onBlur = (text) =>{
        this.setState({hasFocus:0});
        if(this.props.onBlur){
            this.props.onBlur(text);
        }
    } 

    render() {
        return (
        <View style={{}}>
            <View style={[styles.container,{}]}>
                {
                    (this.state.hasFocus || this.state.valueInternal.length>0)
                        ?
                        <View style={styles.containerField}>
                        
                            <Text style={[styles.txtSmartPlaceholder,{color:this.props.smartPlaceholderTextColor}]}>{this.props.smartPlaceholder}</Text>
                       
                     {this.props.iconRightVisible?
                        <View style={styles.iconContainer}>
                            <Image style={styles.iconStyle} source={this.props.iconPath} />
                            </View>:null} 
                        </View>
                        :<Text style={[styles.txtSmartPlaceholderNull]}>{}</Text>
                }
                <TextInput
                    {...this.props}
                    ref = {"textInput"}
                    placeholder = {this.state.hasFocus?"":(this.props.placeholder?this.props.placeholder:this.props.smartPlaceholder)}
                    placeholderTextColor = {this.props.placeholderTextColor?this.props.placeholderTextColor:this.props.smartPlaceholderTextColor}
                    style = {[styles.txtInput,{...this.props.style}]}
                    onChangeText = {(text) => this.onChangeText(text)}
                    onSubmitEditing={() => this.props.onSubmitEditing()}
                    onFocus={() => this.onFocus()}
                    onBlur={() => this.onBlur()}
                />
            </View>        
            {
                this.props.errorMsg && this.props.errorMsg.length > 0 ?
                <Text style={styles.errorMsg}>{this.props.errorMsg}</Text>
                :
                null
            }
        </View>
    );
    }

}

const styles = StyleSheet.create({
    container: {
        marginTop: 16,
        width:screen.width-32,
        height: 60,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: Colors.white,
        marginHorizontal: 16,
        paddingHorizontal: 18,
        overflow: 'hidden',
    },
    containerInner:{
        flexDirection:"row",
        width:screen.width,
    },
    containerField:{
        width:screen.width-32,
        flexDirection:"row"
    },
    iconContainer:{
        position:"absolute",
        right:32,
        width:28,
        height:60,
        alignItems:"center",
        justifyContent:"center",
    },
    txtInput: {
        marginTop: 6,
        textAlign: 'left',
        padding: 0,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        width:'100%',
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 17,
    
    },    
    txtSmartPlaceholder: {
      alignSelf: 'flex-start',
      marginTop: 8,
      color:Colors.whiteTransparent,
      fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
      fontSize: 12,
  },  
    txtSmartPlaceholderNull: {
    },  
    errorMsg:{
        alignSelf:'flex-start',
        color: Colors.white,
        fontSize: 14,
        fontFamily: Styles.FontFamily().ProximaNova,
        marginTop: 5,
        marginLeft: 20
      },
      iconStyle: {
		height: 26,
        width: 26,
        borderRadius:13,
        alignItems:"center",
        justifyContent:"center",
        backgroundColor:"white",
        tintColor:Colors.pinkishRed
	},
    
    
});
