import React, { Component } from "react";
import { View, Text, StyleSheet, Image, TouchableHighlight, Dimensions, Platform, Keyboard } from "react-native";
import { connect } from "react-redux";
import { Styles, Colors, Images, Validations } from "@common";
import InputWithIcon from "../InputWithIcon"
import FullButton from "../FullButton"
import { translate } from "@languages";
import { bindActionCreators } from "redux";
import { InputAccessory } from "@components";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const { height, width } = Dimensions.get("window");
import ButtonOk from  "../ButtonOk";
import { TouchableOpacity } from "react-native-gesture-handler";
class WeightContainer extends Component {
	constructor(props) {
		super(props);
		this.state = {
			profileWeight: "",
			profileWeightError: null
		};
		this.inputRefs = {};
	}

	init(){
		this.setState({profileWeight: this.props.signupDetail.weight});
	}

	async validate() {
		return new Promise((resolve, reject) => { 
			let weight = this.state.profileWeight;
			let option = { fullMessages: false };
			let profileWeightError = Validations('numericonly', weight == 0 ? "" : weight, option);
			this.setState({ profileWeightError: profileWeightError })
			if (!profileWeightError) {
				const reqParams = {
					weight: this.state.profileWeight,				// Update this field value only
				};
				this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
				resolve({result :1});
			}
			else{
				resolve({result :0});
			}
		});
	}
	
	textWeightHandler(text) {
		this.setState({ profileWeight: text })
	}

	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView extraScrollHeight={Platform.OS === 'ios' ? 40 : 90} enableOnAndroid={true} keyboardShouldPersistTaps={'always'}>
					<View>
						<Text style={[styles.label(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt : null ]}>{translate("TellAboutYourSelf")}</Text>

						<View style={styles.noteContainer}>
							<Text style={[styles.labelsmall(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt : null]}>{translate("HelpUsToShowDiet")}</Text>
						</View>
						<View style={styles.weightContainer}>
							<InputWithIcon 
								onRef={(el) => {this.inputRefs["weight"] = el} } 
								refName={"weight"} 
								returnKeyEvent={(inputAccessoryViewID) => console.log(inputAccessoryViewID)}
								lang={this.props.signupDetail.com_lang}
								inputAccessoryViewID={"weight"} 
								textHandler={(text) => this.textWeightHandler(text)} 
								errorMsg={this.state.profileWeightError}
								iconPath={translate("KG")} 
								inputText={this.state.profileWeight} 
								placeholderText={translate("YourWeight")} 
								inputType="4" />
						</View>
						{this.state.profileWeight.length > 0 &&
						<TouchableOpacity onPress={this.props.weightSelection}>
							<ButtonOk  lang={this.props.signupDetail.com_lang} />
						</TouchableOpacity>
					}
					</View>

					{Platform.OS == 'ios' &&

                        <InputAccessory inputAccessoryViewID={"weight"} disableUpArrow={true} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} />

                }
				</KeyboardAwareScrollView>
				
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex:1,
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		lineHeight: 36,
		textAlign: 'left',
		marginTop: height * 0.14
	}),
	noteContainer: {
		marginTop: 16,
		marginHorizontal:0
	},
	labelsmall: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		fontSize: 14,
		color: Colors.white,
		lineHeight: 18,
		textAlign: 'left'
	}),
	weightContainer: {
		marginTop: 23
	},
	
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(WeightContainer);