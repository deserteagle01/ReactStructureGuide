import React, { PureComponent } from "react";
import { AnimatedMove, InfoPopup, Shimmer } from "@components";
import { Animated, Dimensions, View, Text, FlatList, Image, StyleSheet, TouchableOpacity } from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const { height, width } = Dimensions.get("window");
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Appointment from "../../redux/Actions/Appointment";
import { languageNameGetter} from "../../common/Utility";
import Modal from "react-native-modal";
import HTML from 'react-native-render-html';
import {CachedImage} from "react-native-img-cache";
class BookDietition extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            currentInfo: {}
        };
    }

    componentDidMount() {   
        
    }
    
    infoClicked(item) {
        this.refs.infoPopup.show(item)
    }

    _renderItem = ({ item, index }) => {
        const { isFetching } = this.props;
        return (
            <TouchableOpacity style={styles.row} onPress={() => this.props.onPressCard(index, item)}>
                <Shimmer style={styles.profileImg} visible={!isFetching}>
                    <CachedImage
                        source={index == 0 ? Images.icons.meeting : {url: item.image_url}}
                        style={index == 0 ? styles.calender: styles.profileImg} />
                </Shimmer>
                <View style={{flex:1}}>
                <Shimmer style={styles.optionalTitle(index)} visible={!isFetching}>
                    <Text style={styles.optionalTitle(index)}>{index == 0 ? translate("txtOptionalTitle") : this.props.getData(item,"name") }</Text>
                </Shimmer>    
                <Shimmer style={styles.optionalSubtitle(index)} visible={!isFetching}>
                    <Text style={styles.optionalSubtitle(index)}>{ index == 0 ? translate("txtOptionalSubtitle") : this.props.getData(item,"job_title") }</Text>
                    {index != 0 && item.status == "Not Available" &&
                        <Text style={styles.availabletxt}>{item.status}</Text>
                    }
                </Shimmer>
                </View>
                {index != 0 && 
                <Shimmer style={styles.btShimmer} visible={!isFetching}>
                    <TouchableOpacity style={styles.infobt} onPress={() => this.infoClicked(item)}>
                        <Image
                            resizeMode="contain"
                            source={Images.icons.info_ic}
                            style={styles.info} />
                    </TouchableOpacity>
                    </Shimmer>
                }
                </TouchableOpacity>


            );
    }
    
    _renderSeparator() {
        return(
            <View style={{height:16}}>
            </View>
        );
    }


    render() {
        return (
            <View style={{ flex: 1 }}>
                <FlatList
                    style={styles.flatliststyle}
                    data={this.props.list}
                    showsVerticalScrollIndicator={false}
                    renderItem={this._renderItem}
                    ItemSeparatorComponent={this._renderSeparator}
                    keyExtractor={(item, index) => index.toString()}
                    extraData={this.props} />

                    <InfoPopup  ref={"infoPopup"} />
            </View>
        )
    }
}

const styles = StyleSheet.create({
	flatliststyle: {
        flex:1,
    },
    row: {
        marginHorizontal: 16, 
        borderRadius: 16, 
        flexDirection: 'row', 
        alignItems:'center',
        paddingVertical: 8,
        borderColor: Colors.cardBorder,
        borderWidth: 1.0,
    },
    optionalTitle: (index) =>  ({
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 17,
        color: Colors.black,
        marginLeft: index == 0 ? 10 : 0,
        alignSelf:'flex-start'
    }),
    availabletxt:{
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 13,
        color: Colors.pinkishRed,
        marginLeft: 0,
        alignSelf:'flex-start'
    },
    optionalSubtitle: (index) =>  ({
        marginVertical: 4,
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 13,
        color: Colors.lightBlack,
        marginLeft: index == 0 ? 10 : 0,
        alignSelf:'flex-start'
    }),
    infobt:{
        marginHorizontal: 16,
        
    },
    calender: {
        width: 80,
        height: 80,
        tintColor:Colors.pinkishRed,
        marginLeft:16
    },
    profileImg: {
        height: 80,
        width: 80,
        borderRadius: 40,
        marginHorizontal: 16
    },
    btShimmer:{
        marginHorizontal: 16,
        width: 25, 
        height: 25
    }
});


function mapDispatchToProps(dispatch) {
    return {
      actions: {
        Appointment: bindActionCreators(Appointment, dispatch),
      }
    };
  }
  
  const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    appointmentData: state.appointmentReducer,
    isFetching: state.appointmentReducer.isLoadingFor,
    getData: languageNameGetter(state)
  });
  
export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(BookDietition);


