import React, { Component } from "react";
import { Animated,View,TouchableOpacity,Text } from 'react-native';
import { connect } from "react-redux";
import { Toast, EditAddressModal ,GradientButton,Fade,AnimatedMove} from "@components";
import { Styles, Colors, Images } from "@common";
import { translate } from "@languages";
class AddressShowMore extends Component {
  constructor(props) {
    super(props);
		this.state = {
      showMore:false,
    }
  }
  toogleShowMore(){
    this.setState({showMore:!this.state.showMore});
  }

  render() {
    const item = this.props.item;
    const style=[styles.addressPartTopTx,{color:item.isDisable?Colors.colorAddressDisable:Colors.black}];
    return (
      <View style={{flex:1,flexDirection:"row",flexWrap:"wrap",overflow:"visible",justifyContent:"flex-start", alignContent:"flex-start"}}>
        <Fade style={{}} remove={!this.state.showMore} visible={this.state.showMore}><Text ref="fullText" style={style}>{item.street}, {item.street2}, {item.block_name}, </Text></Fade>
        <Text style={style}>{item.area_name}</Text>
        <TouchableOpacity onPress={() => {this.toogleShowMore()}}><Text style={[style,{lineHeight: 25,fontSize:12}]}>  {this.state.showMore?translate("AddressHideMore"):translate("AddressShowMore")}</Text></TouchableOpacity>
      </View>
    );
  }
}
const styles = {
  addressPartTopTx: {
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily().ProximaNova,
		color: Colors.black,
		lineHeight: 25,
	},
 
}
const mapStateToProps = (state) => ({
});

function mapDispatchToProps(dispatch) {
	return {
		actions: {
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(AddressShowMore);

