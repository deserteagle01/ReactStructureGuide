import React, { Component } from "react";
import { View, Text, StyleSheet, Keyboard, Dimensions, Image } from "react-native";
import { connect } from "react-redux";
import { Styles, Validations, Colors } from "@common";
import InputTextString from "../InputTextString"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as GetPlanDetailAction from "../../redux/Actions/Plan";
import InputAccessory from "../InputAccessory";
import ButtonOk from "../ButtonOk";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { firebase } from '@react-native-firebase/analytics';
const { height, width } = Dimensions.get("window");
import Images from "../../common/Images";
import { TouchableOpacity } from "react-native-gesture-handler";
class SignupMobile extends Component {
	constructor(props) {
		super(props);
		this.state = {
			singUpMobile: "",
			singUpMobileError: null
		};
	}

	componentDidMount() {
		
	}

	init() {
		firebase.analytics().setCurrentScreen("Signup Mobile Screen");
		this.setState({singUpMobile: this.props.signupDetail.mobile, singUpMobileError: null});
	}

	
	validate() {
		return new Promise((resolve, reject) => {
		let Oldnumber = this.props.signupDetail.mobile;
		let option = { fullMessages: false };
		let singUpMobileError = Validations('mobile', this.state.singUpMobile, option);
		this.setState({ singUpMobileError: singUpMobileError })
		if (!singUpMobileError) {
			if (this.props.connected) {
				this.props.actions.UpdateUserAction.UserExistAction(this.state.singUpMobile).then(() => {
					var reqParams = {
						mobile: this.state.singUpMobile,
						first_name: this.props.signupDetail.first_name,
						last_name: this.props.signupDetail.last_name,
						lang: this.props.signupDetail.lang,
						introComplete: this.props.signupDetail.introComplete
					};
					if (this.props.signupDetail.is_exist) {
						if (this.props.signupDetail.isLogin) {
							if (this.state.singUpMobile == this.props.signupDetail.mobile) {
								//redirect to continue or modify screen
								if(this.state.singUpMobile == Oldnumber) {
									 //redirect to Continue or modify flow
									resolve({
										result: -1,
										nextSlide: "confirmdetail"
									})
								}
								else{
									  //redirect to otp flow
									  resolve ({
										result: -1,
										nextSlide: "accountexist"
									  })
								}
							} else {
								//clear login data and continue with OTP flow
								this.resetLogout(reqParams).then((isLogout) => {
									if (isLogout) {
										this.UpdatePlan().then((isUpdated) => {
											if(isUpdated) {
												if(this.state.singUpMobile == Oldnumber) {
													resolve ({
														result: -1,
														nextSlide: "confirmdetail"
													})
												}
												else{
													resolve ({
														result: -1,
														nextSlide: "accountexist"
													})
												}
											}
										});
									}
								});
							}
						} else {
							//continue with OTP flow
							firebase.analytics().logEvent("checkout_progress", { checkout_step: "Mobile Already Registered" });
							this.props.actions.UpdateUserAction.updateUserDetails({ mobile: this.state.singUpMobile });
							resolve ({
								result: -1,
								nextSlide: "accountexist"
							})
							
						}
					}
					else {
						firebase.analytics().logEvent("checkout_progress", { checkout_step: "New Mobile Number Registered" });
						if (this.props.signupDetail.isLogin) {
							this.resetLogout(reqParams).then((isLogout) => {
								if (isLogout) {
									this.UpdatePlan().then((isUpdated) => {
										if(isUpdated) {
											resolve ({
												result: 1
											})
										}
									});
								}
							});
						} else {
							this.props.actions.UpdateUserAction.updateUserDetails({ mobile: this.state.singUpMobile });
							resolve ({
								result: 1
							})
						}
					}
				})
			} else {
				this.props.singUpToast(translate("InternetToast"))
				resolve ({
					result: 0
				})
			}
		}
		else{
			resolve ({
				result: 0
			})
		}
		});
	}

	resetLogout(reqParams) {
		return new Promise((resolve, reject) => {
			this.props.actions.UpdateUserAction.logoutAction(reqParams, { source: 'clearAction' }).then(() => {
				if (this.props.signupDetail.error) {
					resolve(false);
				}
				else {
					resolve(true);
				}
			});
		});
	}


	UpdatePlan() {
		return new Promise((resolve, reject) => {
			let editParam = {};
			editParam = {
				normal_configuration_lines: this.props.planDetailData.normal_configuration_lines,
				period_type: this.props.planDetailData.period_type,
				product_id: this.props.planDetailData.product_id,
				product_tmpl_id: this.props.planDetailData.product_tmpl_id,
				all_product_ids: this.props.planDetailData.all_product_ids,
				start_date: new Date(),
				qty: this.props.planDetailData.qty,
				extra_amount: this.props.planDetailData.extra_amount,
				amount_total: this.props.planDetailData.amount_total,
				promo_code:  ""
			}

			if (this.props.planDetailData.promo_code.length > 0) {
				editParam.promo_code = this.props.planDetailData.promo_code
			}

			this.props.actions.GetPlanDetailAction.updatePlanDetailAction(editParam, false).then(() => {
				if (this.props.planDetailData.error) {
					this.props.singUpToast(this.props.planDetailData.error);
					resolve(false);
				}
				else {
					resolve(true);
				}
			});
		});
	}


	onDownArrowClicked(refs) {
		this.validate();
	}

	onUpArrowClicked(refs) {
		this.props.gotoPrev();
	}

	onDoneClicked(refs) {
		Keyboard.dismiss();
	}

	render() {
		this.props.singUpLoading(this.props.isLoading);
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView enableOnAndroid={true} keyboardShouldPersistTaps={'always'}>
					<View>
						<Text style={this.props.signupDetail.com_lang == 'ar' ? [styles.label(this.props.signupDetail.com_lang), Styles.common.globalArabictxt]: styles.label(this.props.signupDetail.com_lang)}>{translate("Ok")} {this.props.signupDetail.last_name} {translate("WhatsYourMobileNumber")}</Text>
					</View>
					<View style={styles.noteContainer}>
						<Text style={this.props.signupDetail.com_lang == 'ar' ? [styles.labelsmall(this.props.signupDetail.com_lang), Styles.common.globalArabictxt]: styles.labelsmall(this.props.signupDetail.com_lang)} >{translate("YouWillUseMobileToLogin")}</Text>
					</View>
					<View style={styles.inputNameContainer}>
						<InputTextString returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)} autoFocus={false} textHandler={(text) => this.setState({ singUpMobile: text })} errorMsg={this.state.singUpMobileError} inputText={this.state.singUpMobile} placeholderText="" inputType="2" inputAccessoryViewID={"phone"}
							styless={[styles.inputTextStyle(this.props.signupDetail.com_lang) ,this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt:Styles.common.globalEnglishtxt] } />
					</View>
					{this.state.singUpMobile.length == 8 &&
					<TouchableOpacity onPress={this.props.onOkClick}>
						<ButtonOk  lang={this.props.signupDetail.com_lang} />
					</TouchableOpacity>
					}
				</KeyboardAwareScrollView>
				{Platform.OS == 'ios' &&
					<InputAccessory inputAccessoryViewID={"phone"} onDoneClick={() => this.onDoneClicked('phone')} onUpArrowClick={() => this.onUpArrowClicked('phone')} onDownArrowClick={() => this.onDownArrowClicked('phone')}/>
				}
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		textAlign: 'left',
		marginTop: height*0.14,
	}),
	inputTextStyle: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
	}),
	noteContainer: {
		marginTop: 8
	},
	labelsmall: (lang) =>  ({
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
		fontSize: 14,
		color: Colors.white,
		textAlign: 'left',
		lineHeight: 18,
	}),
	textInputFocus: {
		borderBottomColor: Colors.white,
	},
	inputNameContainer: {
		marginTop: 24,
	},
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer,
	connected: state.updateNetInfoReducer.isConnected,
	isLoading: state.updateUserReducer.isLoading,
	planDetailData: state.PlanReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
			GetPlanDetailAction: bindActionCreators(GetPlanDetailAction, dispatch)
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SignupMobile);