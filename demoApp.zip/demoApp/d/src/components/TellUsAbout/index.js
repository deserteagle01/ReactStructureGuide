import React, { Component } from "react";
import { View, Text, StyleSheet, Image, TouchableHighlight, Dimensions, TouchableOpacity, Animated } from "react-native";
import { connect } from "react-redux";
import { Styles, Colors, Images, Validations } from "@common";
import InputWithIcon from "../InputWithIcon"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import { InputAccessory } from "@components";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const { height, width } = Dimensions.get("window");

class TellUsAbout extends Component {
	constructor(props) {
		super(props);
		this.state = {
			profileGender: "",
			profileGenderError: null,
			fadeMale: new Animated.Value(1),
			fadeFeMale: new Animated.Value(1),
		};
		this.inputRefs = {};
	}

	
	init() {
		setI18nConfig("ar",false);
		this.setState({profileGender: this.props.signupDetail.gender != '' ? this.props.signupDetail.gender : ''})
	}

	async validate() {
		return new Promise((resolve, reject) => {
		let option = { fullMessages: false };
		let profileGenderError = Validations('reqField', this.state.profileGender, option);
		
		this.setState({ profileGenderError: profileGenderError })
		if (!profileGenderError ) {
			const reqParams = {
				gender: this.state.profileGender,				// Update this field value only
			};
			this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
			resolve({result: 1});
		}
		else{
			resolve({result: 0});
		}
	});
	}
	
	async genderChagePress(gender) {
		await this.setState({ profileGender: gender });
		if(gender == "male"){
			this.startAnimation(this.state.fadeMale);	
		}else{
			this.startAnimation(this.state.fadeFeMale);	
		}
		
	}

	startAnimation(animateGender) {
		Animated.timing(animateGender, {
			toValue: 0.2,
			duration: 500
		  }).start();

		  setTimeout(() => {
			Animated.timing(animateGender, {
				toValue: 1.0,
				duration: 500
			  }).start();
			  this.props.genderSelection(null);
		  }, 500);
	}

	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView extraScrollHeight={Platform.OS === 'ios' ? 40 : 90} enableOnAndroid={true} keyboardShouldPersistTaps={'always'}>
					<View>
						<Text style={[styles.label(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt : null ]}>{translate("TellAboutYourSelf")}</Text>

						<View style={styles.noteContainer}>
							<Text style={[styles.labelsmall(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt : null]}>{translate("HelpUsToShowDiet")}</Text>
						</View>
						<View style={styles.genderContainer}>
							<Animated.View style={{opacity: this.state.fadeMale}}>
							<TouchableOpacity style={this.state.profileGender == 'male' ? styles.genderMale : [styles.genderMale, { backgroundColor: 'transparent' }]} onPress={() => this.genderChagePress('male')}>
								<Image source={this.state.profileGender == 'male' ? Images.icons.maleActive : Images.icons.male} style={styles.genderlogo} />
								<Text style={this.state.profileGender == 'male' ? styles.genderTextActive(this.props.signupDetail.com_lang) : styles.genderText(this.props.signupDetail.com_lang)}>{translate("Male")}</Text>
							</TouchableOpacity>
							</Animated.View>

							<Animated.View style={{opacity: this.state.fadeFeMale}}>
							<TouchableOpacity style={this.state.profileGender == 'female' ? styles.genderFemale : [styles.genderFemale, { backgroundColor: 'transparent' }] } onPress={() => this.genderChagePress('female')}>
								<Image source={this.state.profileGender == 'female' ?  Images.icons.femaleActive: Images.icons.female } style={styles.genderlogo} />
								<Text style={this.state.profileGender == 'female' ? styles.genderTextActive(this.props.signupDetail.com_lang) : styles.genderText(this.props.signupDetail.com_lang) }>{translate("Female")}</Text>
							</TouchableOpacity>
							</Animated.View>
						</View>

					</View>
				</KeyboardAwareScrollView>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex:1
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		lineHeight: 36,
		textAlign: 'left',
		marginTop: height * 0.14
	}),
	noteContainer: {
		marginTop: 16,
		marginHorizontal:0
	},
	labelsmall: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		fontSize: 14,
		color: Colors.white,
		lineHeight: 18,
		textAlign: 'left'
	}),
	genderContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		marginVertical: 23,
	},
	genderMale: {
		marginEnd: 12,
		height: 134,
		aspectRatio: 1,
		alignItems: 'center',
		justifyContent: 'center',
		borderRadius: 27,
		borderWidth: 1,
		borderColor: 'rgba(232, 232, 232, 0.8)',
		backgroundColor: 'white',
	},
	genderFemale: {
		height: 134,
		aspectRatio: 1,
		alignItems: 'center',
		justifyContent: 'center',
		borderRadius: 27,
		justifyContent: 'center',
		borderWidth: 1,
		borderColor: 'rgba(232, 232, 232, 0.8)',
		backgroundColor: 'white',
	},
	genderlogo: {
		width: 64,
		height: 64,
		marginBottom: 11
	},
	genderText: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
		fontSize: 19,
		color: Colors.white,
		lineHeight: 20,
		textAlign: 'center',
	}),
	genderTextActive: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
		fontSize: 19,
		color: 'rgba(236, 28, 35, 1)',
		lineHeight: 20,
		textAlign: 'center'
	}),
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(TellUsAbout);