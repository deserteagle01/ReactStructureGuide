import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import { Animated, ViewPropTypes } from 'react-native';
import CircularProgress from './CircularProgress';

const AnimatedProgress = Animated.createAnimatedComponent(CircularProgress);

export default class AnimatedCircularProgress extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chartFillAnimation: new Animated.Value(props.prefill || 0),
    };
  }

  componentDidMount() {
    this.animateFill();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.fill !== this.props.fill) {
      this.animateFill();
    }
  }

  animateFill() {
    const { duration} = this.props;
    Animated.timing(this.state.chartFillAnimation, {
      toValue: this.props.fill,
      duration: duration
    }).start();
  }

  render() {
      const { fill, prefill, ...other } = this.props;
      return <AnimatedProgress {...other} fill={this.state.chartFillAnimation} />;
  }
}

AnimatedCircularProgress.propTypes = {
  style: ViewPropTypes.style,
  size: PropTypes.number.isRequired,
  fill: PropTypes.number,
  prefill: PropTypes.number,
  width: PropTypes.number.isRequired,
  beginColor: PropTypes.string,
  endColor: PropTypes.string,
  backgroundColor: PropTypes.string,
  duration: PropTypes.number
};

AnimatedCircularProgress.defaultProps = {
  duration: 1000
};
