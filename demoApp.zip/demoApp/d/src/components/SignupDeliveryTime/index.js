import React, { Component } from "react";
import { View, FlatList, Text, Image, TouchableOpacity, StyleSheet, I18nManager, Platform, Dimensions, Animated } from "react-native";
import { connect } from "react-redux";
import { Styles, Images, Colors, Validations } from "@common";
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { firebase } from '@react-native-firebase/analytics';
const { height, width } = Dimensions.get("window");
class SignupDeliveryTime extends Component {
	constructor(props) {
		super(props);
		this.state = {
			singUpDeliveryTime: null,
			singUpDeliveryTimeError: null,
			selectedAreaArr: [],
			fadeDelevieryTime:  new Animated.Value(1),
		};
	}

	componentDidMount() {
		
	}

	init() {
		firebase.analytics().setCurrentScreen("Signup DeliveryTime Screen");
		this.setState({ singUpDeliveryTime: this.props.signupDetail.shift_id, singUpDeliveryTimeError: null });
		var areaId = this.props.signupDetail.area_id
		var tempArr = [];
		if (this.props.areaItem.length > 0 && this.props.signupDetail) {
			tempArr = this.props.areaItem.filter(function (item) {
				return item.value == areaId;
			})
			this.setState({ selectedAreaArr: tempArr });
		}

		if (this.props.signupDetail.shift_id == "") {
			this.setState({ singUpDeliveryTime: tempArr&&tempArr.length>0?tempArr[0].default_shift_id:""})
		}
	}

	selecteDeliveryTime = (item) => {
		this.setState({ singUpDeliveryTime: item.value })
		this.startAnimation();
	}

	startAnimation() {
		Animated.timing(this.state.fadeDelevieryTime, {
			toValue: 0.2,
			duration: 400
		  }).start();

		  setTimeout(() => {
			Animated.timing(this.state.fadeDelevieryTime, {
				toValue: 1.0,
				duration: 400
			  }).start();
			  this.props.onShiftSelection();
		  }, 400);
	}

	validate() {
		return new Promise((resolve, reject) => {
		let option = { fullMessages: false };
		let singUpDeliveryTimeError = Validations('reqField', this.state.singUpDeliveryTime, option);
		this.setState({ singUpDeliveryTimeError: singUpDeliveryTimeError })
		if (!singUpDeliveryTimeError) {
			const reqParams = {
				shift_id: this.state.singUpDeliveryTime,					// Update this field value only
			};
			this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
			firebase.analytics().logEvent("checkout_progress", { checkout_step: "Signup Delivery Time" });
			resolve ({result: 1})
		}
		else{
			resolve ({result: 0})
		}
	});
	}

	renderRow(item) {
		return (
			<TouchableOpacity onPress={() => this.selecteDeliveryTime(item)} style={[styles.outlineBtn, this.state.singUpDeliveryTime == item.value ? styles.whiteBg : null]}>
				<Text style={[styles.textStyle(this.props.signupDetail.com_lang), this.state.singUpDeliveryTime == item.value ? styles.redText : null, this.props.signupDetail.com_lang == "ar" ? Styles.common.globalArabictxtFlex : null]}>
					{item.label}
				</Text>
				<Text style={[styles.textSmall(this.props.signupDetail.com_lang), this.state.singUpDeliveryTime == item.value ? styles.redText : null, this.props.signupDetail.com_lang == "ar" ? Styles.common.globalArabictxtFlex : null]}>
					{item.subTitle}
				</Text>
				{this.state.singUpDeliveryTime == item.value &&
					<Image source={Images.icons.leftCheckedOrange} style={[styles.checkLogo, this.props.signupDetail.com_lang == "ar" ? Styles.common.imgTick : null]} />
				}
			</TouchableOpacity>
		);
	}

	_renderItem = ({ item }) => {
		if(this.state.SignupDeliveryTime == item.value) {
			return (
				<Animated.View 
					key={item.index}
					style={{opacity: this.state.fadeDelevieryTime}} >
						{this.renderRow(item)}
					</Animated.View>	
				);
		}else{
			return(
				this.renderRow(item)
			);
		}
	}
		

	render() {
		return (
			<View style={styles.detailContainer}>
				<View>
					<Text style={this.props.signupDetail.com_lang == "ar" ? [styles.label(this.props.signupDetail.com_lang), Styles.common.globalArabictxt] : styles.label(this.props.signupDetail.com_lang)}>{translate("YouHaveChosen")} {this.state.selectedAreaArr.length > 0 ? this.state.selectedAreaArr[0].label : ""}, {translate("SelectDeliveryTime")}</Text>
				</View>
				<View style={styles.delivertyListContainer}>
					<Text style={this.state.singUpDeliveryTimeError ? Styles.common.errorMsg : ''}>{this.state.singUpDeliveryTimeError ? translate(this.state.singUpDeliveryTimeError) : ''}</Text>
					{this.props.deliveryItem &&
						<FlatList
							data={this.props.deliveryItem}
							extraData={this.state}
							keyExtractor={(item, index) => index.toString()}
							renderItem={this._renderItem}
						/>
					}
				</View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		textAlign: 'left',
		marginTop: height*0.14,
	}),
	whiteBg: {
		backgroundColor: Colors.white
	},
	delivertyListContainer: {
		marginTop: 14,
	},
	outlineBtn: {
		height: 56,
		borderRadius: 10,
		alignItems: "flex-start",
		justifyContent: "center",
		borderWidth: 1,
		borderColor: Colors.lightWhite,
		marginBottom: 16,
		paddingLeft: 16,
	},
	textStyle: (lang) =>  ({
		color: Colors.white,
		fontSize: Styles.FontSize.fnt18,
		fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
		alignSelf: 'flex-start',
	}),
	textSmall: (lang) => ({
		color: Colors.white,
		fontSize: Styles.FontSize.fnt14,
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		alignSelf: 'flex-start',
	}),
	redText: {
		color: Colors.pinkishRed,
	},
	checkLogo: {
		width: 28,
		height: 28,
		position: "absolute",
		justifyContent: "center",
		right: 16
	}
});

const mapStateToProps = (state) => {
	return {
		signupDetail: state.updateUserReducer,
		deliveryItem: state.fetchMasterListReducer.delivery_shifts,
		areaItem: state.fetchMasterListReducer.areas,
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SignupDeliveryTime);