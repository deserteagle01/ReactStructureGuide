import React, { Component } from "react";
import { View, StyleSheet, Text, Image, TouchableOpacity } from "react-native";
import { Colors, Styles, Images } from "@common";


class TextWithCounter extends React.Component {
    constructor(props) {
        super(props);
        
    }

   render() {
        const { text, minimumValue, index, isDropdown, protein, carbs, onIncrementPress, onDecrementPress, currentCounter } = this.props;
        return (
            <View style={{ alignItems: 'center' }}>
                {index == 0 ? 
                    <View style={styles.seprator} />
                    : null
                }
                
                <View style={styles.container}>
                    <View>
                    <Text style={styles.title}>{text}</Text>
                    {
                        isDropdown?
                        <TouchableOpacity style={styles.drpViewContainer} onPress={this.props.onChangeProtein}> 
                            <Text>~ </Text>
                            <Text style={styles.txtValue}>{protein}g</Text>
                            <Text style={styles.txtTitle}>Protein</Text>
                            <Text> & </Text>
                            <Text style={styles.txtValue}>{carbs}g</Text>
                            <Text style={styles.txtTitle}>Carbs</Text>
                            <Image source={Images.icons.drpDown} style={styles.drpImage} />
                        </TouchableOpacity>
                        :
                        null
                    }
                    </View>
                    
                    <View style={styles.rightView}>
                        <TouchableOpacity
                            disabled={currentCounter <= minimumValue ? true : false}
                            onPress={onDecrementPress}>
                            <Image source={Images.icons.RoundedLine} style={ currentCounter <= minimumValue ? [styles.cancelLogo, {tintColor:Colors.lighterBlack}] : styles.cancelLogo} />
                        </TouchableOpacity>
                        <Text style={styles.txtCounter}>{currentCounter}</Text>
                        <TouchableOpacity onPress={onIncrementPress}>
                            <Image source={Images.icons.AddRoundedLine} style={styles.cancelLogo} />
                        </TouchableOpacity>
                    </View>

                </View>
                <View style={styles.seprator} />
            </View>
        );
    }


}




const styles = StyleSheet.create({
    container: {
        width: '100%',
        height: 62,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 16
    },
    drpViewContainer:{
        flexDirection:'row',
        marginVertical:4,
        alignItems:'center',
        justifyContent:'center'
    },
    txtValue:{
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 12,
        textAlign: "center",
        letterSpacing:-0.13,
        color: Colors.GrayProteinText,
    },
    txtTitle: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 12,
        textAlign: "center",
        letterSpacing:-0.13,
        color: Colors.GrayProteinText,
        marginLeft:3
    },
    drpImage:{
        marginHorizontal:4,
        height:14,
        width:14
    },
    title: {
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 17,
        alignSelf: 'flex-start',
        color: Colors.royalBlack,
    },
    rightView: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    txtCounter: {
        width: 30,
        marginHorizontal: 6,
        textAlign: 'center',
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 24,
        color: Colors.royalBlack,
    },
    seprator: {
        width: '100%',
        height: 1,
        backgroundColor: Colors.lightGray
    }

});


export default TextWithCounter;
