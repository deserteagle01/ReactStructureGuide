import React, { Component } from "react";
import { View, StyleSheet, Dimensions, I18nManager, Image, Text, TouchableOpacity } from "react-native";
import { connect } from "react-redux";
import { Constants, Styles, Images, Colors } from "@common";
import { GradientButton } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { lang } from "moment";
const { width, height } = Dimensions.get("window");
import { translate, setI18nConfig } from "@languages";
class NotificationOn extends Component {
	constructor(props) {
		super(props);
		this.state = {
			
		};
	}

	init() {
		setI18nConfig(this.props.signupDetail.com_lang,I18nManager.isRTL);
		this.forceUpdate();
	}

	validate(isNotifEnable) {
		return new Promise((resolve, reject) => {
			if(isNotifEnable){
				const reqParams = {
					opt_out_notifications: true,	// Update this field value only
				};
				this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
			}
			this.props.gotoHome();
			resolve({result : 1});
		});
	}

	render() {
		return (
			<View style={styles.detailContainer}>
				<View style={styles.notificationIconCont}>
					<Image source={Images.icons.turnNotifications} style={styles.notificationIcon} />
				</View>	
				<View style={styles.notificationModalCont}>
					<Text style={styles.notificationTitleTxt(this.props.signupDetail.com_lang)}>{translate("TurnOnNotifications")}</Text>
					<View style={styles.notificationTxtCont}>
						<Text style={styles.notificationSmallTxt(this.props.signupDetail.com_lang)}>{translate("NotificationReminder")}</Text>
					</View>
					<View style={styles.notificationBtnCont}>
						<GradientButton style={styles.enableNotification} onPressAction={() => this.props.gotoNext(true)}
							text={translate("EnableNotification")}
						/>
					</View>
					<TouchableOpacity style={styles.doItLaterCon} onPress={() => this.props.gotoNext(false)}>
						<Text style={styles.labelsmall(this.props.signupDetail.com_lang)}>{translate("DoItLater")}</Text>
					</TouchableOpacity>
				</View>	
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
		height: Platform.OS == "ios" ? height-185 : height - 20,
		alignItems: 'center',
		justifyContent: 'center',
	},
	notificationIconCont:{
		top: Platform.OS == "ios" ?((height/2)- 300):((height/2)- 220),
		paddingTop: 20,
		position: 'absolute',
		zIndex: 1,
	},
	notificationIcon: {
		width: 96,
		height: 96,
	},
	notificationModalCont:{
		height: 279,
		width: width - 46,
		backgroundColor: Colors.white,
		alignItems: 'center',
		borderRadius: 16,
		paddingTop: 60,
	},
	notificationTitleTxt: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
		fontSize: Styles.FontSize.fnt17,
		color: Colors.black,
		lineHeight: 21,
		textAlign: 'center'
	}),
	notificationTxtCont:{
		marginTop: 16,
		paddingHorizontal: 41
	},
	notificationSmallTxt: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		fontSize: Styles.FontSize.fnt13,
		color: 'rgba(0, 0, 0, 0.84)',
		lineHeight: 18,
		textAlign: 'center'
	}),
	notificationBtnCont:{
		marginTop: 13,
		shadowColor: Platform.OS === 'ios'?'rgba(0, 0, 0, 0.12)':'#f6f6f6',
        shadowOffset: {
            width: 0,
            height: 12,
        },
        shadowOpacity: Platform.OS === 'ios'?0.1: 0.01,
        shadowRadius: Platform.OS === 'ios'?16:50,
        elevation: Platform.OS === 'ios'?5:10,
	},
	enableNotification:{
		width: width - 94
	},
	doItLaterCon:{
		marginTop: 16,
	},
	labelsmall: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		fontSize: 14,
		color: 'rgba(0, 0, 0, 0.54)',
		lineHeight: 24,
		textAlign: 'center'
	}),
	
	// chooseTextContainer:{
	// 	marginTop: 38,
	// },
	// smallTextContainer:{
	// 	marginTop: 16,
	// },
	// label: {
	// 	fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
	// 	fontSize: 28,
	// 	color: Colors.white,
	// 	lineHeight: 36,
	// 	textAlign: 'center',
	// },
	// labelsmall: {
	// 	fontFamily: Styles.FontFamily().ProximaNovaBold,
	// 	fontSize: 14,
	// 	color: Colors.white,
	// 	lineHeight: 18,
	// 	textAlign: 'center'
	// },
	// continueBtnContainer: {
	// 	marginTop: 40
	// },
	// btnContinue: {
	// 	backgroundColor: Colors.white,
	// 	height: 56,
	// 	borderRadius: 8,
	// 	alignItems: "center",
	// 	justifyContent: "center",
	// 	borderWidth: 1,
	// 	borderColor: Colors.white,
	// },
	// textStyle: {
	// 	color: Colors.pinkishRed,
	// 	fontSize: Styles.FontSize.fnt17,
	// 	fontFamily: Styles.FontFamily().ProximaNovaBold
	// },
	// ChooseLaterCon:{
	// 	marginTop: 24
	// },
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(NotificationOn);