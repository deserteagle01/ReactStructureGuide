import React, { Component } from "react";
import { StyleSheet, InputAccessoryView, View ,Text, TouchableWithoutFeedback, TouchableOpacity,I18nManager } from "react-native";
import { translate } from "@languages";

export default class InputAccessory extends Component {
	constructor(props) {
		super(props);
        this.state = {};
    }
    
    static defaultProps = {
        buttonTitle: "Done",
        onUpArrowClick:null,
        onDownArrowClick:null,
        onDoneClick:null,
        inputAccessoryViewID: 'inputAccessoryViewID'      
    }
	
	render() {	
		const {
            buttonTitle,
            disableUpArrow,
            disableDownArrow,
            hideDoneBar,
            onUpArrowClick,
            onDownArrowClick,
            onDoneClick,
            inputAccessoryViewID
        } = this.props;
		return (
            <InputAccessoryView nativeID={inputAccessoryViewID}>
                <View style={[styles.modalViewMiddle]} testID="input_accessory_view">
                    <View style={[styles.chevronContainer]}>
                        <TouchableOpacity disabled={disableUpArrow?disableUpArrow:false} activeOpacity={disableUpArrow ? 0.5 : 1} onPress={(item) => {onUpArrowClick(item)}}>
                            <View style={[styles.chevron,
                                I18nManager.isRTL? styles.chevronUpArrowRTL:styles.chevronUp,
                                 disableUpArrow ? {}: [styles.chevronActive]]}/>
                        </TouchableOpacity>
                        <TouchableOpacity disabled={disableDownArrow?disableDownArrow: false} activeOpacity={disableDownArrow ? 0.5 : 1} onPress={(item) => {onDownArrowClick(item)}}>
                            <View style={[styles.chevron,
                                I18nManager.isRTL? styles.chevronDownArrowRTL:styles.chevronDown,
                                 disableDownArrow ? {}: [styles.chevronActive]]}/>
                        </TouchableOpacity>
                    </View>
                    {!hideDoneBar &&
                        <TouchableWithoutFeedback onPress={(item) => {onDoneClick(item)}} hitSlop={{ top: 4, right: 4, bottom: 4, left: 4 }} testID="done_button">
                            <View testID="needed_for_touchable">
                                <Text style={[styles.done]}>{translate(buttonTitle)}</Text>
                            </View>
                        </TouchableWithoutFeedback>
                    }
                </View>
            </InputAccessoryView>
		)
	}
}


const styles = StyleSheet.create({
    modalViewMiddle: {
        height: 44,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 10,
        backgroundColor: '#EFF1F2',
        borderTopWidth: 0.5,
        borderTopColor: '#919498',
        zIndex: 2,
    },
    chevronContainer: {
        flexDirection: 'row',
    },
    chevron: {
        width: 15,
        height: 15,
        backgroundColor: 'transparent',
        borderColor: '#D0D4DB',
        borderTopWidth: 1.5,
        borderRightWidth: 1.5,
    },
    chevronUp: {
        marginLeft: 11,
        transform: [{ translateY: 4 }, { rotate: '-45deg' }],
    },
    chevronDown: {
        marginLeft: 22,
        transform: [{ translateY: -5 }, { rotate: '135deg' }],
    },
    chevronUpArrowRTL: {
        marginLeft: 11,
        transform: [{ translateY: 4 }, { rotate: '45deg' }],
    },
   chevronDownArrowRTL: {
       marginLeft: 22,
        transform: [{ translateY: -5 }, { rotate: '-135deg' }],
    },
    chevronActive: {
        borderColor: '#007AFE',
    },
    done: {
        color: '#007AFE',
        fontWeight: 'bold',
        fontSize: 15,
        paddingTop: 1,
        paddingRight: 2,
    },
    modalViewBottom: {
        justifyContent: 'center',
        backgroundColor: '#D0D4DB',
    },
    placeholder: {
        color: '#C7C7CD',
    },
    headlessAndroidPicker: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        color: 'transparent',
        opacity: 0,
    },
});