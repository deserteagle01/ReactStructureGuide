/** @format */

import React, { Component } from "react";
import { connect } from "react-redux";
import {View, Text, filter, FlatList, StyleSheet, Image, TouchableOpacity, I18nManager, TextInput, Dimensions} from "react-native";
import { Images, Colors, Styles, Validations } from "@common";
import { translate } from "@languages";
import { FullButton, DisLikeRow } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import { Spinner, Toast } from "@components";
import { ScrollView } from "react-native-gesture-handler";
const { height, width } = Dimensions.get("window");

class DislikeSelection extends Component {
	constructor(props) {
		super(props);
		this.state={
			filterDislikeList: null,
			selectedDislike: this.props.signupDetail.dislike_category_ids,
			singDislikeCategoriesError: null,
		}
	}

	componentDidMount(){
		if(this.props.connected) {
			this.props.actions.MasterList.fetchDislikeDataList().then(() => {
				// console.log(this.state.selectedDislike)
				for (let i = 0; i < this.props.dislikeMaster.length; i++) {
					this.props.dislikeMaster[i].isChecked = false;
					for( j = 0; j < this.state.selectedDislike.length; j++){ 
						if (parseInt(this.state.selectedDislike[j]) == parseInt(this.props.dislikeMaster[i].value)) {
							this.props.dislikeMaster[i].isChecked = true;  
						}
					} 
				}
				console.log(this.props.dislikeMaster)
				this.setState({ filterDislikeList: this.props.dislikeMaster });
			}).catch(e => {
				this.toast.show(this.props.dislikeMaster.error);	
			});
		}else{
			this.toast.show(translate("InternetToast"));
		}
	}

	searchFilterDislike = (text) => {    
		const newData = this.props.dislikeMaster.filter(item => {
		  	const itemData = `${item.label.toUpperCase()} ${item.label.toUpperCase()} ${item.label.toUpperCase()}`;
		   	const textData = text.toUpperCase();
		   	return itemData.indexOf(textData) > -1;    
		});
		this.setState({ filterDislikeList: newData });
	};

	doneButtonClicked() {
			let option = { fullMessages: false };
			let singDislikeCategoriesError = Validations('reqField', this.state.selectedDislike, option);
			if (!singDislikeCategoriesError) {
					const reqParams = {
						dislike_category_ids: this.state.selectedDislike,	// Update this field value only
					};
					this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
					return true;
			}
			else{
				return true;
			}
	}

	selectDislike = (selectItem) =>{
		if(!selectItem.isChecked){
			this.state.selectedDislike.push(selectItem.value);
		}else{
			var index = this.state.selectedDislike.indexOf(selectItem.value);
			this.state.selectedDislike.splice(index, 1); 
		}
		selectItem.isChecked = !selectItem.isChecked;
		this.setState({ filterDislikeList: this.state.filterDislikeList});
	}

	_renderItem = ({ item }) => {
		return (
			<View>
            <DisLikeRow 
                onPress={(itemReturn) => this.selectDislike(item)}  
                item={item} 
                lang={this.props.signupDetail.com_lang}/>
			</View>
		);
	}

	render() {
		const { onBackViewScreen, onNextViewScreen } = this.props;
		return (
			<View style={styles.dislikeModelContainer}>
					<View style={styles.dislikeModelHeader}>
						<Text style={styles.selectTitleTxt(this.props.signupDetail.com_lang)}>{translate("SelectDislike")}</Text>
						<TouchableOpacity style={styles.dislikeModalCloseBtn} onPress={this.props.closeDislikeScreen}>
              				<Image source={Images.icons.closeBox} />
            			</TouchableOpacity>
					</View>
					<View style={styles.searchContainer}>
						<Image style={[styles.searchIcon]} source={I18nManager.isRTL ? Images.icons.rightSearchIcon : Images.icons.leftSearchIcon} />
						<TextInput style={[styles.searchText(this.props.signupDetail.com_lang)]} selectionColor={Colors.black} placeholder={translate('Search')} onChangeText={text => this.searchFilterDislike(text)} autoCorrect={false} />    
					</View>
					<ScrollView style={styles.scroll}
					    nestedScrollEnabled={true}>
					<FlatList
						style={styles.dislikeListContainer}
						data={this.state.filterDislikeList}
						showsVerticalScrollIndicator={false}
						keyExtractor={(item, index) =>  index.toString()}
						renderItem={this._renderItem}
						extraData={this.state} />
				    </ScrollView>
					{this.props.isLoading ? <Spinner mode="overlay" /> : null}
					<Toast refrence={(refrence) => this.toast = refrence} />
			</View>
		);
	}
}


const styles = StyleSheet.create({
	scroll:
	{
		flex:1,
		marginTop:10
	},
    label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		lineHeight: 36,
		textAlign: 'center',
    }),
   dislikeModelContainer:{
		flex: 1,
		borderTopLeftRadius: 24,
		borderTopRightRadius: 24,
		backgroundColor: 'rgba(255,255,255,1)',
	},
    dislikeModelHeader:{
        flexDirection: "row",
        alignItems: "center",
        height: 44,
        marginTop:16,
        marginBottom:16,
    },
    selectTitleTxt: (lang) => ({
        flex:1,
        fontFamily: Styles.FontFamily(lang).UrbaneRoundedLite,
        fontSize: 14,
        lineHeight: 20,
        alignSelf: "center",
        marginVertical:12,
        textAlign:"center",
        color: 'rgba(0, 0, 0, 0.6)',
    }),
    dislikeModalCloseBtn:{
        position:"absolute", 
        right:20
    },
    searchContainer:{
        flexDirection: 'row',
        height: 44,
        backgroundColor: 'white',
        borderColor: 'rgba(242, 243, 244, 1)',
        borderWidth: 1,
        borderRadius: 24,
        marginHorizontal: 16,
        paddingHorizontal: 15,
        alignItems: 'center',
        shadowColor: Platform.OS === 'ios'?Colors.black:'#f6f6f6',
        shadowOffset: {
            width: 0,
            height: 4,
        },
        shadowOpacity: Platform.OS === 'ios'?0.1: 0.01,
        shadowRadius: Platform.OS === 'ios'?24:50,
        elevation: Platform.OS === 'ios'?5:10,
    },
    searchText: (lang) => ({
        flex: 1,
        height: 42,
        color: Colors.black,
		fontSize: Styles.FontSize.fnt14,
        fontFamily: Styles.FontFamily(lang).ProximaNova,
        marginLeft: 8,
        //paddingLeft: 10,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    }),
    searchIcon:{
        width: 23,
        height: 24
	},
	dislikeListContainer:{
        //flex:1,
		marginHorizontal: 14,
		marginTop: 20,
		flex: 1
	},
});


const mapStateToProps = (state) => {
	return {
		connected: state.updateNetInfoReducer.isConnected,
		isLoading: state.fetchMasterListReducer.isLoading,
		dislikeMaster: state.fetchMasterListReducer.dislikes,
		signupDetail: state.updateUserReducer, 
	}
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(DislikeSelection);