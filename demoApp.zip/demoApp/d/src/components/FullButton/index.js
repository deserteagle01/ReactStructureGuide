import React, { Component } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet, I18nManager } from "react-native";

import { Styles, Images, Colors } from "@common";

export default class FullButton extends Component {
  render() {
    const {
      label,
      btnStyle,
      textStyle,
      iconComponent,
      iconStyle,
      isCheckedVisible,
      onPress
    } = this.props;  
    return (
      <TouchableOpacity style={[btnStyle]} onPress={onPress}>
        {label &&
          <Text style={[textStyle]}>
            {label}
          </Text>}
        {iconComponent &&
          <View>
            {iconComponent}
          </View>}
          { isCheckedVisible && 
            <Image source={I18nManager.isRTL ? Images.icons.leftCheckBlack : Images.icons.rightCheckBlack} style={styles.checkLogo}/>
          }
      </TouchableOpacity>
    );
  }
}


const styles = StyleSheet.create({
    checkLogo:{
        width:28,
        height:28,
        position:"absolute",
        justifyContent:"center",
        right:20
    }
});

