import React, { Component } from "react";
import { StyleSheet, TextInput, Image, Text, I18nManager, TouchableWithoutFeedback } from "react-native";
import { Styles, Colors, Images } from "@common";
import { View } from "react-native-animatable";
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { translate, setI18nConfig } from "@languages";
export default class InputTextString extends Component {
	constructor(props) {
		super(props);
		this.state = {};
		// this.returnRef = this.returnRef.bind(this);
	}

	componentDidMount(){
		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}

	componentDidUpdate(){
		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}

	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

	// returnRef(){
	// 	if (this.props.onRef) {
	// 		this.props.onRef(this.refs['block']);
	// 	}
	// }

	handlerFocus = (input) => {
		this.setState({
			[input]: true
		});
	};

	handlerBlur = (input) => {
		this.setState({
			[input]: false
		});
	};

	textHandler(text)  {
		this.props.textHandler(text);
	}

	InputAccessoryView = () => {
		return (
			<View style={[defaultStyles.modalViewMiddle]} testID="input_accessory_view">
				<View style={[defaultStyles.chevronContainer]}></View>
				<TouchableWithoutFeedback onPress={() => {this.props.onDropDownToggleFun(this.props.refName)}} hitSlop={{ top: 4, right: 4, bottom: 4, left: 4 }} testID="done_button">
					<View testID="needed_for_touchable">
						<Text style={[defaultStyles.done]}>{translate("Done")}</Text>
					</View>
				</TouchableWithoutFeedback>
			</View>
		);
	}

	render() {
		const {
			inputType,
			placeholderText,
			itemObj,
			inputText,
			errorMsg,
			refs,
			onUpArrowFun,
			onDownArrowFun,
			fontFamily,
			fontSize,
			autoFocus,
			styless,
			pickerSelectDone,
			lang,
			isOpenFrom
		} = this.props;

		const placeholderPicker = {
			label: placeholderText?placeholderText: null,
			value: null,
			color: Colors.black,
		};

		const pickerStyle = {
			inputIOSContainer:{
				flex: 1,
				height: 61,
				borderRadius: 12,
				borderWidth: 1,
				borderColor: isOpenFrom ? Colors.pinkishRed :'#d6d7da',	
				overflow: 'hidden',
				justifyContent: 'center'
			},
			inputIOS : {				
				color: isOpenFrom ? Colors.pinkishRed : Colors.white,
				fontSize: fontSize ? fontSize : 24,
				paddingLeft:  16,
				fontFamily: fontFamily,
				maxHeight: 30,
				width: Styles.width - 74,
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			inputAndroidContainer:{
				flex: 1,
				height: 61,
				borderRadius: 12,
				borderWidth: 1,
				borderColor: isOpenFrom ? Colors.pinkishRed :'#d6d7da',	
				overflow: 'hidden',
				justifyContent: 'center',			
			},
			inputAndroid: {				
				color: isOpenFrom ? Colors.pinkishRed : Colors.white,
				fontSize: fontSize ? fontSize : 24,
				paddingLeft: 16,
				width: Styles.width - 74,
				fontFamily: fontFamily,		
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			underline: { borderTopWidth: 0 },
			icon: {
				width: 24,
				height: 24,
			},
			iconContainer: {
				height: 61,
				width: 40,
				flex: 1,
				paddingRight: 16,
				justifyContent: 'center',
				alignItems: 'center',
			},
			chevronUp :I18nManager.isRTL?styles.chevronUpArrowRTL:{},
            chevronDown:I18nManager.isRTL?styles.chevronDownArrowRTL:{},

		};		
		if (inputType == 1) {
			return (
				<View>
					<TextInput autoFocus={autoFocus} ref={this.props.refName ? this.props.refName : 'email'} autoCapitalize='none' selectionColor={Colors.white} returnKeyType='done' keyboardType={'email-address'} onChangeText={(text) => this.textHandler(text)} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} value={this.state.text} style={[{ fontFamily:  Styles.FontFamily().ProximaNova }, Styles.common.textInput, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '']}
						onFocus={() => this.handlerFocus('nameInputOneFocus')} onSubmitEditing={() => this.props.returnKeyEvent(this.props.inputAccessoryViewID)}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} inputAccessoryViewID={this.props.inputAccessoryViewID}/>
					<Text style={errorMsg ? Styles.common.errorMsg : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			);
		} else if (inputType == 2) {
			return (
				<View>
					<TextInput autoFocus={autoFocus} ref={this.props.refName ? this.props.refName : 'phone'} keyboardType={'phone-pad'} selectionColor={Colors.white} returnKeyType='done' onChangeText={(text) => this.textHandler(text)} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[{ fontFamily: Styles.FontFamily().ProximaNova }, Styles.common.textInput,styless, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}
						onFocus={() => this.handlerFocus('nameInputOneFocus')} onSubmitEditing={() => this.props.returnKeyEvent(this.props.inputAccessoryViewID)}
						maxLength={8}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} inputAccessoryViewID={this.props.inputAccessoryViewID}/>
					<Text style={errorMsg ? Styles.common.errorMsg : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			)
		} else if (inputType == 3) {
			// Drop Down
			return (
				<View style={styles.textViewMargin}>
					{!this.props.arrowHide &&
						<RNPickerSelect
							ref={this.props.refName}
							textInputProps={{
								numberOfLines: 1,
								selection:{ start: 0, end: 0 }
							}}
							onValueChange={(text) => this.textHandler(text)} 
							value={inputText} 
							useNativeAndroidPickerStyle={false}
							items={itemObj} 
							key={itemObj.length} style={pickerStyle} 
							placeholder={placeholderPicker.label != null?placeholderPicker: ""}
							Icon={() => { return this.props.refName == 'startPlan' ? <Image source={Images.icons.calendarIcon} /> : <Image source={Images.icons.down} /> }}
							onUpArrow={() => onUpArrowFun(this.props.refName)}
							onDownArrow={() => onDownArrowFun(this.props.refName)}
						/>
					}
					{this.props.arrowHide &&
						<RNPickerSelect
							ref={this.props.refName}
							onValueChange={(text) => this.textHandler(text)} value={inputText} useNativeAndroidPickerStyle={false}
							items={itemObj} key={itemObj.length}  style={pickerStyle} placeholder={placeholderPicker.label != null?placeholderPicker:{}}
							Icon={() => { return this.props.refName == 'startPlan' ? <Image source={isOpenFrom ? Images.icons.calendarIconRed : Images.icons.calendarIcon} /> : <Image source={Images.icons.down} /> }}
							onUpArrow={() => onUpArrowFun(this.props.refName)}
							onDownArrow={() => onDownArrowFun(this.props.refName)}
							InputAccessoryView={() => this.InputAccessoryView()}
						/>
					}
					<Text style={[errorMsg ? Styles.common.errorMsg : '',I18nManager.lang == 'ar' ? Styles.common.globalArabictxt : Styles.common.globalEnglishtxt ]}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			)
		} else {
			return (
				<View>
					<TextInput 
						autoFocus={autoFocus} 
						ref={this.props.refName ? this.props.refName : 'string'} 
						onChangeText={(text) => this.textHandler(text)} 
						selectionColor={Colors.white} 
						value={inputText} 
						placeholder={placeholderText} 
						placeholderTextColor={Colors.placeHoderGrey} 
						style={[{ fontFamily:  Styles.FontFamily(lang).ProximaNova }, Styles.common.textInput, styless,this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}
						onFocus={() => this.handlerFocus('nameInputOneFocus')} onSubmitEditing={() => this.props.returnKeyEvent(this.props.inputAccessoryViewID)}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} 
						inputAccessoryViewID={this.props.inputAccessoryViewID}/>
					<Text style={errorMsg ? [Styles.common.errorMsg, styless] : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			);
		}
	}
}


const styles = StyleSheet.create({
	textInputFocus: {
		borderBottomColor: Colors.white,
	},
	errorMsg: {
		alignSelf: 'flex-start',
		color: 'red',
		fontSize: 14,
		fontFamily:  Styles.FontFamily().ProximaNova,
		marginTop: 5,
		marginLeft: 20
	},
	chevronUpArrowRTL: {
        marginLeft: 11,
        transform: [{ translateY: 4 }, { rotate: '45deg' }],
    },
   chevronDownArrowRTL: {
       marginLeft: 22,
        transform: [{ translateY: -5 }, { rotate: '-135deg' }],
	},
});

