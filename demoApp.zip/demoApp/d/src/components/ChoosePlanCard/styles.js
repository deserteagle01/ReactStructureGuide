import { StyleSheet, Platform, Dimensions, I18nManager } from "react-native";
//import Colors from "../../common/Colors";
import { Images, Styles, Colors } from "@common";
import { FontScalling } from "../../common/Utility";
const { height, width } = Dimensions.get("window");
export default (styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.pinkishRed,
    ...Platform.select({
      android: {
        marginTop: 0, 
      },
    }),
    
  },
  subContainer: {
    flex: 1,
    
  },
  flexView:{ 
    flex: 1 
  },
  selectView:{
    marginVertical:23,
    marginHorizontal:25,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between'
  },
  txtCall:{
    fontFamily: Styles.FontFamily().ProximaNova,
    fontSize: 14,
    letterSpacing: -0.16,
    color: Colors.black08
  },

  callLogo:{
    marginLeft:6,
    width:28,
    height:28,
  },
  topView:{ 
    flexDirection:'row',
    alignSelf:'flex-end',
  },
  txtselect:{
    color: Colors.lightBlack,
    fontSize: 10,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
  },
  switchView: {
    overflow: 'hidden',
    marginTop: 15,
    flexDirection: 'row',
    borderRadius: 8,
    borderColor: Colors.white,
    borderWidth: 1,
    marginHorizontal: 30,
    height: 40,
  },
  switchView2: {
    overflow: 'hidden',
    marginTop: 15,
    flexDirection: 'row',
    marginHorizontal: 30,
    height: 40,
  },
  selected: {
    flex: 0.5,
    backgroundColor: Colors.white,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center'
  },
  unselected: {
    flex: 0.5,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center'
  },
  selected2: {
    flex: 0.5,
    backgroundColor: Colors.white,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: Colors.pinkishRed,
    borderWidth:1,
    borderBottomLeftRadius: 8,
    borderTopLeftRadius: 8
  },
  unselected2: {
    flex: 0.5,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: Colors.grayBorder,
    borderWidth:1,
    borderBottomLeftRadius: 8,
    borderTopLeftRadius: 8
  },
  selected3: {
    flex: 0.5,
    backgroundColor: Colors.white,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: Colors.pinkishRed,
    borderWidth:1,
    borderBottomRightRadius: 8,
    borderTopRightRadius: 8,
  },
  unselected3: {
    flex: 0.5,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: Colors.grayBorder,
    borderWidth:1,
    borderBottomRightRadius: 8,
    borderTopRightRadius: 8,
  },
  txtSelected: {
    color: Colors.pinkishRed,
    fontSize: 12,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    letterSpacing: 0.38,
    textAlign: 'center',
    paddingHorizontal: 10
  },
  txtUnelected: {
    color: Colors.white,
    fontSize: 12,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    letterSpacing: 0.38,
    textAlign: 'center',
    paddingHorizontal: 10
  },
  txtSelected2: {
    color: Colors.pinkishRed,
    fontSize: 12,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    letterSpacing: -0.38,
    textAlign: 'center',
    paddingHorizontal: 10
  },
  txtUnelected2: {
    color: Colors.grayinshText,
    fontSize: 12,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    letterSpacing: -0.38,
    textAlign: 'center',
    paddingHorizontal: 10
  },
  cancelLogo: {
    width: 28,
    height: 28,
  },
  helpView: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  header: {
    width: '100%',
    marginTop: 0,
    flexDirection: 'row',
    padding: 16,
    alignItems: 'center',
    justifyContent: 'space-between',
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  txtor: {
    color: Colors.black,
    fontSize: 10,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
  },
  orView: {
    top: 8,
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    left: ((width - 60) / 2) - 11,
    backgroundColor: Colors.white,
    height: 22,
    width: 22,
    borderRadius: 11,
    borderColor: 'rgb(239,239,239)',
    borderWidth: 0.5
  },
  suggestion: {
    color: Colors.white,
    fontSize: 14,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
    letterSpacing: -0.15,
  },
  suggestion2: {
    color: Colors.black,
    fontSize: 16,
    fontFamily: Styles.FontFamily().ProximaNova,
    letterSpacing: -0.17,
  },
  suggestionView: {
    marginTop: 15,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row'
  },
  suggestionView2: {
    marginVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row'
  },
  infoimg: {
    height: 18,
    width: 18,
    marginHorizontal: 4
  },
  planlistview: {
    flex: 1,
    backgroundColor: Colors.white,
    overflow: "hidden"
  },
  cardView: {
    marginVertical: 8,
    marginHorizontal: 17,
    flex: 1,
    borderRadius: 25,
    overflow: 'hidden'
  },
  cacheStyle:{
    width: '100%', 
    position: 'absolute', 
    height:'100%'
  },
  shimmerLine:{
    marginTop:'6%',
    height:"10%", 
    width: "100%", 
    borderRadius:4
  },
  shimmerView:{
    position:'absolute', 
    height: "100%",
    width: '100%', 
    backgroundColor:'white'
  },
  shimmerContainer:{
    marginHorizontal:'10%', 
    marginVertical:'5%', 
    flex:1
  },
  txtTitle: {
    alignSelf:'flex-start',
    marginHorizontal: 20,
    marginVertical: 20,
    color: Colors.white,
    fontSize: FontScalling(17,4),
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
  },
  txtTitleShimmer:{
    marginHorizontal: 20,
    marginVertical: 20,
    width:'75%'
  },
  boxShimmer:{
    position:"absolute", 
    height:width*0.22,
    width:width*0.22,
    right:10,
    top:20, 
    borderRadius:4
  },
  containerView: {
    flexDirection: 'row',
    flex: 1,
  },
  cardSubView: {
    flex: 0.55
  },
  cardSubView2: {
    flex: 0.45,
  },
  included: {
    color: Colors.white,
    fontSize: 14,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
    marginHorizontal: 20,
    marginTop: 2,
    alignSelf:'flex-start'
  },
  textnumber: {
    color: Colors.white,
    fontSize: 12,
    marginLeft: 5,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
  },
  textprotein: {
    color: Colors.white,
    fontSize: 12,
    marginLeft: 3,
    fontFamily: Styles.FontFamily().ProximaNova,
  },
  proteinView: {
    flexDirection: 'row',
    marginLeft: 15,
    marginVertical: 20,
    alignItems: 'center'
  },
  proteinViewShimmer: {
    marginLeft: 20,
    marginVertical: 20,
  },
  txtOldPrice: {
    textDecorationLine: 'line-through', textDecorationStyle: 'solid',
    marginTop: 23,
    color: Colors.white,
    fontSize: FontScalling(24,6),
    fontFamily: Styles.FontFamily().ProximaNovaBold,
    marginRight:width*0.020
  },
  perView:{
    alignItems:'center',
  },
  coverView:{
    position: 'absolute',
    right: 30,
    flexDirection: 'row'
  },
  txtPer:{
    color: Colors.white,
    fontSize: 12,
    fontFamily: Styles.FontFamily().ProximaNova,
  },
  txtnewPrice: {
    marginTop: 20,
    color: Colors.white,
    fontSize: FontScalling(45, 8),
    fontFamily: Styles.FontFamily().ProximaNovaBold,
  },
  kwd: {
    marginTop: 0,
    color: Colors.white,
    fontSize: 10,
    width: 100,
    fontFamily: Styles.FontFamily().ProximaNova,
    transform: [{ rotate: "-90deg" }],
  },
  customSafearea:{ 
    flex:1, 
    backgroundColor: 'white' 
  },
  offerView: {
    borderRadius: 29,
    backgroundColor: Colors.pinkishRed,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    right: 20,
    bottom: 20,
    paddingHorizontal:10,
    paddingVertical:10
  },
  verticalView: {
    flexDirection: 'row',
  },
  widthView: {
    flexDirection: 'row',
    width: 20,
    position:'absolute',
    right:10,
  },
  centerView: {
    flex: 1,
    alignItems: 'center',
  },
  txtoffer: {
    color: Colors.white,
    fontSize: 10,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,

  },

}));

