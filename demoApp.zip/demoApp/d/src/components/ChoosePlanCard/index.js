import React, { Component, PureComponent } from "react";
import { connect } from "react-redux";
import { View, Animated,ScrollView, StyleSheet, SafeAreaView,Text, StatusBar,ImageBackground, Dimensions, TouchableOpacity, Image, I18nManager, TextInput, FlatList } from "react-native";

import styles from "./styles";
import { translate, setI18nConfig } from "@languages";
import { GradientButton,Fade, OutlineButton, NeedHelp, LanguageSwitcher, Spinner, Toast, WebViewModal, AnimatedMove, Shimmer  } from "@components";
import {CachedImage} from "react-native-img-cache";
import { Images, Styles, Colors, Validations } from "@common";
import { languageNameGetter} from "../../common/Utility";
const screen = Dimensions.get("window");
import { bindActionCreators } from "redux";
import { firebase } from '@react-native-firebase/analytics';
const { height, width } = Dimensions.get("window");
class ChoosePlanCard extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            expand:false,
        };
    }


    componentDidMount() {
    }


    
    renderLeftPart(item) {
        return (
            <View style={styles.cardSubView}>
                <Text numberOfLines={1} allowFontScaling={false} style={styles.txtTitle}>{this.props.getCName(item)}</Text>
                {this.includedList(item.meals)}
                <View style={styles.proteinView}>
                    <Text style={styles.textnumber}>{item.protein}g</Text>
                    <Text style={styles.textprotein}>{translate("Protiens")}</Text>

                    <Text style={styles.textnumber}>{item.carb}g</Text>
                    <Text style={styles.textprotein}>{translate("Carbs")}</Text>
                </View>
            </View>
        );
    }

    renderRightPart(item) {
        return (
            <View style={styles.cardSubView2}>
                
                <View style={styles.verticalView}>
                    <View style={styles.coverView}>
                        {item.offer_price != 0 && 
                            <Text style={styles.txtOldPrice}>{item.list_price}</Text> 
                        }
                        <View style={styles.perView}>
                                <Text style={styles.txtnewPrice}>{item.offer_price == 0 ? item.list_price : (item.list_price - item.offer_price) }</Text>
                                <Text style={styles.txtPer}>{this.props.getCName(item,"plan_period_type")}</Text>
                            
                        </View>
                    </View>
                

                    <View style={styles.widthView}>
                        <View style={styles.centerView}>
                            <Text style={styles.kwd}>{item.currency_code}</Text>
                        </View>
                    </View>
                    
                </View>

                {
                    item.offer_name.length > 0  && !this.props.isLoading ?
                    
                        <View style={styles.offerView}>
                            <Text numberOfLines={1} style={styles.txtoffer}>{this.props.getCName(item,"offer_name")}</Text>
                        </View>
                    
                        :
                        null
                }
                
            </View>
        );
    }
    
    onPlanClicked = (item) => {
        this.props.onPlanClicked(item);
        if(!this.state.expand){
            this.setState({expand:true});
        }
    }

    render() {
        return (
            <TouchableOpacity activeOpacity={1} onPress={() => this.onPlanClicked(this.props.item)}>
                <View style={!this.props.isLoading ? [styles.cardView] : [styles.cardView, {borderWidth:1, borderColor: Colors.cardBorder}]}>
                    <CachedImage
                        source={{uri: this.props.item.plan_image_url.length > 0 ? this.props.item.plan_image_url : 'https://picsum.photos/id/810/340/186' }}
                          style={styles.cacheStyle} />
                     
                        <View style={styles.containerView}>
                            {this.renderLeftPart(this.props.item)}
                            {this.renderRightPart(this.props.item)}
                        </View>
                        {this.props.isLoading && 
                            <View style={styles.shimmerView}>
                                <View style={styles.shimmerContainer}>
                                    {this.shimmerList(["1", "2", "3", "4"])}
                                </View>
                            </View>
                        }
                    </View>
            </TouchableOpacity>
        );
    }

    shimmerList(includes) {
        return includes.map((data, index) => {
            return (
                <Shimmer  style={styles.shimmerLine} visible={!this.props.isLoading} duration={1400}>
                </Shimmer>
            )
        })
    }
    includedList(includes) {
        console.log(includes);
        return includes.map((data, index) => {
            return (
                <Text key={index} style={styles.included}>{data.product_qty + " " + this.props.getCName(data,"product_name")}</Text>
            )
        })
        
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: {
        }
    };
}

const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    userInfo: state.updateUserReducer,
    companyDetails: state.fetchMasterListReducer,    
    getCName: languageNameGetter(state),
    isLoading: state.PlanReducer.isLoading
});

export default connect(mapStateToProps, mapDispatchToProps)(ChoosePlanCard);
