import React, { Component, PureComponent } from "react";
import { View, StyleSheet, Text, FlatList, SectionList, LayoutAnimation, Platform, UIManager } from "react-native";
import {ProductListItem, ProductHeaderItem, ProductListContainer } from "@components";
import { Colors, Styles } from "@common";
import { translate } from "@languages";
import { connect } from "react-redux";
import moment from 'moment';
import 'moment/locale/ar';
import 'moment/locale/en-gb';
import { bindActionCreators } from "redux";
import * as mealsAction from "../../redux/Actions/mealsAction";

class ProductSection extends Component {
	constructor(props) {
		super(props);
	}

	
	render(){
		const { item } = this.props;
		if(item.is_header){
			return (
				<View style={{width:'100%',height:40.5,alignItems:'center',backgroundColor: Colors.paleGreyTwo,}}>
					<ProductHeaderItem userSelectedMeals={this.props.userSelectedMeals} currDate={this.props.date} item={item}/>
					<View style={{height: 0.5}}></View>
				</View>
			)
		}else{
			return (
				<ProductListContainer
					itemsList={this.props.menuData[item.id] || []}
					product_meal_data={item}
					currDate={this.props.date}
					{...this.props}
				/>
			)
		}
	};
}

class ProductMainContentContainer extends Component {
	constructor(props) {
		super(props);
		this.state = {
			data: [],
			menuData: {},
			headerIndexes: [],
			userMeals: {},
			selectMeal: {}
		}
		this.date = null;
	}

	
	componentWillReceiveProps(nextProps) {
		if((this.date != nextProps.date) || 
		(JSON.stringify(this.props.mealDetail.userProduct[this.date]) !== JSON.stringify(nextProps.mealDetail.userProduct[this.date]))){
			this._calData(nextProps.date,nextProps.mealDetail.userProduct);
		}
	}

	_calData = (forDate, userProduct) => {
		this.date = forDate;
		let menuData = {};
		let userMeals = {};
		if(userProduct[this.date] && userProduct[this.date].meals && userProduct[this.date].meals.length > 0){
			let data = [];
			let headerIndexes = [];
			for(let item of userProduct[this.date].meals){
				let obj = {...item};
				menuData[obj.id] = obj.available_items;
				obj.is_header = true;
				headerIndexes.push(data.length);
				for(let selected of obj.selected_items){
					const productIndex = menuData[obj.id].findIndex(obj => obj.recipe_template_id === selected.product_id);
						selected.calorie = menuData[obj.id][productIndex].calorie;
						selected.carb = menuData[obj.id][productIndex].carb;
						selected.fat = menuData[obj.id][productIndex].fat;
						selected.protein = menuData[obj.id][productIndex].protein;
				}
				userMeals[obj.id] = {...obj,mealHeaderIndex: data.length};
				data.push({...obj});
				data.push({
					meal_id: obj.meal_id,
					id: obj.id,
					mealType: obj.type,
					selected_items: obj.selected_items
				});
			}
			this.setState({
				data: [...data],
				menuData: {...menuData},
				headerIndexes: [...headerIndexes],
			},() => {
				this.flatList_Ref.scrollToIndex({animated: true,
					index:0,
				});
			});
			Platform.OS === 'ios' && LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
		} else {
			this.props.onEmptyMenu && this.props.onEmptyMenu();
		}
		let mealSelectionObj = {};
		mealSelectionObj[this.date] = {...userMeals};
		let tempMealData = {...this.state.selectMeal, ...mealSelectionObj};
		this.setState({selectMeal: tempMealData});
		this.props.updateMealSelectionData(tempMealData);
	}
	updateMealSelectionData = (updatedMealData) => {
		let tempMealData = {...this.state.selectMeal, ...updatedMealData};
		this.setState({selectMeal: tempMealData});
		this.props.updateMealSelectionData(tempMealData);
	}

	productMainContentFlatlistScroll = (mealHeaderIndex) => {
		var scrollIndex=mealHeaderIndex+2;
		
		let can_scroll = false;
        for(let Idx = this.state.headerIndexes.indexOf(mealHeaderIndex); Idx < this.state.headerIndexes.length; Idx++){
            let nextMealCategoryId = this.state.data[this.state.headerIndexes[Idx]].id;
            let nextMealCategorySelection = this.state.selectMeal[this.date][nextMealCategoryId];
			if(nextMealCategorySelection.selected_quantity<nextMealCategorySelection.quantity){
						can_scroll=true;
						scrollIndex=this.state.headerIndexes[Idx];
						break;
					}
		}
		if(!this.state.data[scrollIndex]){
			return;
		}
		if(can_scroll){
			setTimeout(()=>{
				this.flatList_Ref.scrollToIndex({animated: true,
					index:(scrollIndex),
				});
			},10)
		}
	}

	_flatlistItem = ({ index, item }) => {
		return <ProductSection 
			item={item}
			userSelectedMeals={this.state.selectMeal}
			updateMealSelectionData={this.updateMealSelectionData}
			menuData={this.state.menuData} 
			date={this.date}
			productMainContentFlatlistScroll={this.productMainContentFlatlistScroll}
			{...this.props}
		/>;
	}
	_keyExtractor = (item, index) => index.toString();

	render() {
		const { menuData, headerIndexes, data } = this.state;
		return (
			<FlatList
				ref={ref => { this.flatList_Ref = ref; }}
				style={{marginTop:8}}
				showsVerticalScrollIndicator={false}
				data={data}
				// extraData={this.props}
				keyExtractor={this._keyExtractor}
				renderItem={this._flatlistItem}
				stickyHeaderIndices={headerIndexes}
				removeClippedSubviews={false}
				initialNumToRender={4}
				maxToRenderPerBatch={8}
				bounces={false}
			/> 
		);
	}
}

const styles = StyleSheet.create({
	listHeaderView: {
    width:'100%',
    backgroundColor: Colors.paleGreyTwo,
    paddingLeft: 12,
    paddingRight: 12,
    paddingTop: 8,
    paddingBottom: 8,
    flexDirection: "row",
  },
  listHeaderTitleView: {
    flex: 0.5,
    alignItems: 'flex-start'
  },
  listHeaderTitleText: {
    fontSize: 19,
    color: Colors.black,
    lineHeight: 20,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
  },
  listHeaderSelectionTextView: {
    flex: 0.5,
    flexDirection: 'row',
    justifyContent: "flex-end"
  },
  listHeaderSelectionText: {
    fontSize: 14,
    alignSelf: "flex-end",
    color: Colors.pinkishRed08,
    lineHeight: 18,
    fontFamily: Styles.FontFamily().ProximaNova,
  },
  listHeaderSelectionDataText: {
    fontSize: 14,
    alignSelf: "flex-end",
    color: Colors.pinkishRed08,
    lineHeight: 18,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
  },
});
const mapStateToProps = (state) => {
    return {
		mealDetail: state.mealsReducer,
	};
};

function mapDispatchToProps(dispatch) {
    return {
        actions: {
			mealsAction: bindActionCreators(mealsAction, dispatch),
		}
    };
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(ProductMainContentContainer);