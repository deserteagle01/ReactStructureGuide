import React, { Component } from "react";
import { View, Text, Dimensions, TouchableOpacity, Image, StyleSheet, I18nManager, Linking, Platform, Clipboard } from "react-native";
import Modal from "react-native-modal";
import { ModalButton, Toast } from "@components";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const screen = Dimensions.get("window");

export default class InviteModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isVisible: false,
			title:null,
			optionalSharetxt: "Download dietStation App. you can use referral code "+ this.props.referralCode
		};
		this.toggleModal = this.toggleModal.bind(this);
	}

	toggleModal = (visible,title) => {
		this.setState({
			isVisible: visible,
			title:title,
		});
	};
	
	async writeToClipboard() {
		let strShare = this.props.shareText.length > 0 ? this.props.shareText : this.state.optionalSharetxt
		await Clipboard.setString(strShare);
		this.toast.show(translate("copied"));
	}

	render() {
		let strShare = this.props.shareText.length > 0 ? this.props.shareText : this.state.optionalSharetxt
		let smsUrl = Platform.OS == 'android' ? "sms:number?body="+strShare : "sms:&addresses=&body="+strShare
		let WhatsappUrl = "whatsapp://send?text="+strShare
		return (
			<Modal
				hasBackdrop
				isVisible={this.state.isVisible}
				hideModalContentWhileAnimating={true}
				useNativeDriver={true}
				style={styles.modal}
				onModalHide={() => {
					this.props.onModalHide();
				}}
				onBackdropPress={() => this.toggleModal(false)}
				onRequestClose={()=>this.toggleModal(false)}
				>
				<View
					style={styles.modalConatiner}>
					<View
						style={styles.topContainer}>
						<Text
							style={styles.txtTitle}>
							{this.state.title}
						</Text>
						<TouchableOpacity
							style={styles.closeConatiner}
							onPress={() => {
								this.setState({
									isVisible: false})
							}}>
							<Image source={Images.icons.closeBox} />
						</TouchableOpacity>
					</View>
					<ModalButton
						btnStyle={{ marginTop: 4 }}
						onPress={()=> Linking.openURL(smsUrl)}
						label={translate("SMS")} />
					<ModalButton
						btnStyle={{ marginTop: 8 }}
						onPress={() => Linking.openURL(WhatsappUrl)}
						label={translate("WhatsApp")} />
					<ModalButton
						btnStyle={{ marginTop: 8 }}
						onPress={() => this.writeToClipboard()}
						label={translate("CopyLink")} />
				</View>
				<Toast refrence={(refrence) => this.toast = refrence} position="top" />
			</Modal>
		);
	}
}
const styles = StyleSheet.create({
	modal: {
		alignItems: "center",
		justifyContent: "center"
	},
	modalConatiner: {
		position: "absolute",
		bottom: 8,
		height: 265,
		width: screen.width - 32,
		borderRadius: 20,
		backgroundColor: Colors.white,
	}, 
	topContainer: {
		flexDirection: "row",
		alignItems: "center",
		height: 44,
		marginTop: 8,
	},
	txtTitle: {
		fontFamily: Styles.FontFamily().UrbaneRoundedLite,
		fontSize: 14,
		alignSelf: "center",
		textAlign: "center",
		flex: 1,
		color: 'rgba(4, 4, 15 ,0.6)',
	},
	bottomText: {
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize: 17,
		marginBottom: 8,
		marginTop: 8,
		justifyContent: 'center',
		textAlign: "center",
		color: Colors.pinkishRed,
	},
	closeConatiner: {
		position: "absolute",
		right: 16
	},

});
