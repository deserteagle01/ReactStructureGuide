import React, { Component } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet, I18nManager } from "react-native";
import { Styles, Images, Colors } from "@common";
import { translate } from "@languages";
export default class SelectDays extends Component {
    renderItem(item, onPress, onDisablePress) {
        if (item.isDisable) {
            return (
                    <TouchableOpacity style={styles.dislikeRow} onPress={onDisablePress}>
                        <Image style={[styles.dislikeCheckbox, { paddingLeft: 16 }]} source={item.isChecked ? I18nManager.isRTL ? Images.icons.rightCheckedOrange : Images.icons.leftCheckedOrange : Images.icons.uncheckedIcon} />
                        <View style={styles.disableText}>
                            <Text style={[styles.dislikeItemTxt, { color: Colors.black39 }]}>{translate(item.value)}</Text>
                            <Text style={styles.descText2} >{translate("OopsMsg")}</Text>
                        </View>
                        <View style={{ width: 28, height: 28 }}>
                            <Image source={Images.icons.info_ic} /></View>
                    </TouchableOpacity>
            );
        } else {
            return (
                <TouchableOpacity style={styles.dislikeRow} onPress={onPress}>
                    <Image style={[styles.dislikeCheckbox]} source={item.isChecked ? I18nManager.isRTL ? Images.icons.rightCheckedOrange : Images.icons.leftCheckedOrange : Images.icons.uncheckedIcon} />
                    <View style={styles.dislikeItemTxtCont}><Text style={styles.dislikeItemTxt}>{translate(item.value)}</Text></View>
                </TouchableOpacity>
            );
        }
    }
    render() {
        const {
            item,
            onDisablePress,
            onPress
        } = this.props;
        return (
            this.renderItem(item, onPress, onDisablePress)
        );
    }
}

const styles = StyleSheet.create({
    descText: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 14,
        alignSelf: "center",
        marginVertical: 12,
        textAlign: "center",
        flex: 1,
        color: Colors.black08
    },
    descText2: {
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: Styles.FontSize.fnt12,
        textAlign: "left",
        marginLeft: 9,
        color: Colors.greyishBrown,
        opacity: 0.5,
        lineHeight: 16,

    },
    disableText: {
        flexDirection: 'column',
        height: 60,
        justifyContent: 'center',
        marginLeft: 9,
        width: Styles.width - 28 - 28 - 32 - 10 - 9
    },
    dislikeRow: {
        paddingHorizontal: 16,
        flexDirection: 'row',
        height: 60,
        alignItems: 'center',
        borderBottomColor: 'rgba(242, 243, 244, 1)',
        borderBottomWidth: 1,
    },
    dislikeRowExtraHeight: {
        flexDirection: 'row',
        height: 100,
        alignItems: 'center'
    },
    dislikeCheckbox: {
        width: 28,
        height: 28
    },
    dislikeItemTxtCont: {
        flex: 1,
        flexDirection: 'row',
        marginLeft: 9,
        paddingVertical: 19,
        flexWrap: 'wrap',
    },
    itemIsDisable: {
        flexDirection: 'row',
        borderBottomColor: 'rgba(242, 243, 244, 1)',
        borderBottomWidth: 1,
        marginLeft: 9,
        paddingVertical: 19,
    },
    dislikeItemTxt: {
        color: Colors.black,
        fontSize: Styles.FontSize.fnt21,
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        marginLeft: 9,
        textAlign: 'left',
    }
});



