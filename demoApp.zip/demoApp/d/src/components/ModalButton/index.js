import React, { Component } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet, I18nManager } from "react-native";

import { Styles, Images, Colors } from "@common";

export default class ModalButton extends Component {
  render() {
    const {
      label,
      btnStyle,
      textStyle,
      iconComponent,
      iconStyle,
      isCheckedVisible,
      onPress,
      isDisable
    } = this.props;  
    return (
      <TouchableOpacity style={[styles.outlineBtn,btnStyle]} onPress={onPress}>
        {label &&
          <Text style={[styles.outlineBtnText, textStyle]}>
            {label}
          </Text>}
        {iconComponent &&
          <View style={[iconStyle]}>
            {iconComponent}
          </View>}
          { isCheckedVisible && 
            <Image source={I18nManager.isRTL ? Images.icons.rightCheckBlack : Images.icons.leftCheckBlack} style={styles.checkLogo}/>
          }
      </TouchableOpacity>
    );
  }
}


const styles = StyleSheet.create({
  outlineBtn: {
    marginHorizontal:16,
    height: 56,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor:"rgba(106 ,109 ,122,0.44)",
    marginHorizontal: 16,
    height: 56
  },
  outlineBtnText: {
    color: Colors.black08,
    fontSize: Styles.FontSize.fnt17,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold
  },
  checkLogo:{
    width:28,
    height:28,
    position:"absolute",
    justifyContent:"center",
    right:20
  }
});

