import React, { Component } from "react";
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';

const Badge = props => {
  const {
    containerStyle,
    textStyle,
    badgeStyle,
    onPress,
    Component = onPress ? TouchableOpacity : View,
    value,
    ...attributes
  } = props;

  return (
    <View style={StyleSheet.flatten([containerStyle && containerStyle])}>
      <Component
        {...attributes}
        style={StyleSheet.flatten([
          styles.badge,
          badgeStyle && badgeStyle,
        ])}
        onPress={onPress}
      >
        <Text style ={StyleSheet.flatten([styles.text, textStyle && textStyle])}>
          {value}
        </Text>
        {
          props.iconImage?
          props.iconImage:null
        }
      </Component>
    </View>
  );
};


const size = 18;
const miniSize = 8;

const styles = {
  badge: {
    alignSelf: 'center',
    minWidth: size,
    height: size,
    borderRadius: size / 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#fff',
  },
  text: {
    fontSize: 12,
    color: 'white',
    paddingHorizontal: 4,
  },
};

export default Badge ;

