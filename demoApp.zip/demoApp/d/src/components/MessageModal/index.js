import React, { Component } from "react";
import { View, Text, Dimensions, TouchableOpacity, Image, StyleSheet, I18nManager } from "react-native";
import Modal from "react-native-modal";
import { GradientButton, ModalButton } from "@components";
import { Images, Styles, Colors } from "@common";
import { translate } from "@languages";

export default class MessageModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isVisible: false,
			headerTitle: "",
			msgFor: "",
			buttons: [],
			currentHandler: null

		};
		this.toggleModal = this.toggleModal.bind(this);
	}
	toggleModal = (visible, headerTitle, msgFor, buttons) => {
		this.setState({
			isVisible: visible,
			headerTitle: headerTitle,
			msgFor: msgFor,
			buttons: buttons,
			currentHandler: null
		});
	};

	render() {
		return (
			<Modal
				hasBackdrop
				isVisible={this.state.isVisible}
				hideModalContentWhileAnimating={true}
				useNativeDriver={true}
				style={styles.modal}
				onModalHide={() => {
					if (this.state.currentHandler) {
						this.state.currentHandler();
					}
				}}
				onBackdropPress={() => {
					for (let item of this.state.buttons) {
						if (item.role == "Ok") {
							this.setState({ isVisible: false, currentHandler: item.handler });
						}
					}
					this.setState({ isVisible: false });
				}}>
				<View style={styles.mainContainer}>
					<View style={styles.titleContainer}>
						<Text style={styles.titleText}> {this.state.headerTitle} </Text>
					</View>
					{this.state.msgFor == "updateAddress" ?
						<View style={styles.descContainer1}>
							<Text style={styles.textStyle2}>
								<Text style={styles.descText}> {translate("RememberAddress1")}</Text>
								<Text style={styles.descTextBold}> {translate("RememberAddress2")}</Text>
								<Text style={styles.descText}> {translate("RememberAddress3")}</Text>
							</Text>
						</View>
						:
						<View style={styles.descContainer1}>
							<Text style={styles.descText}> {this.state.msgFor}</Text>
						</View>
					}

					<View style={styles.btnContainer}>
						{this.state.buttons.map((item, index) => {
							if (item.isGradient) {
								return (
									<GradientButton
										style={styles.gradientBtn}
										isCheckedVisible={false}
										onPressAction={() => { this.setState({ isVisible: false, currentHandler: item.handler }) }}
										text={item.text}
										key={index}
									/>
								)
							} else {
								return (
									<ModalButton isDisable={item.isDisable}
										btnStyle={styles.modalBtn} textStyle={styles.textStyle} isCheckedVisible={false} onPress={() => { this.setState({ isVisible: false, currentHandler: item.handler }) }} label={item.text} />
								)
							}

						})
						}
					</View>

				</View>
			</Modal>
		);
	}
}

const styles = StyleSheet.create({
	modal:
	{
		alignItems: "center",
		justifyContent: "center",
	},
	mainContainer: {
		marginHorizontal: 16,
		width: Styles.width - 32,
		height: 214,
		borderRadius: 20,
		flexDirection: 'column',
		backgroundColor: Colors.white,
	},
	titleContainer: {
		marginLeft: 16,
		marginRight: 16,
		flexDirection: "row",
		alignSelf: "center",
		marginTop: 24,
		paddingHorizontal: 31
	},
	titleText: {
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		fontSize: 17,
		textAlign: "center",
		color: Colors.darkNavyBlue,
		letterSpacing: -0.2,

	},
	descContainer: {
		marginLeft: 16,
		marginRight: 16,
		flexDirection: "row",
		alignSelf: "center",
		marginTop: 8,
		paddingHorizontal: 28
	},
	descContainer1: {
		width: "100%",
		marginTop: 8,
		alignItems: "center",
		justifyContent: "center",
		paddingHorizontal: 28,
		textAlign: "center",
	},
	descText: {
		fontFamily: Styles.FontFamily().ProximaNova,
		fontSize: 14,
		textAlign: "center",
		lineHeight: 18,
		color: Colors.black08,
	},
	descTextBold: {
		fontFamily: Styles.FontFamily().ProximaNovaBold,
		fontSize: 14,
		textAlign: "center",
		lineHeight: 18,
		color: Colors.black08,
	},
	btnContainer: {
		flexDirection: 'row',
		paddingTop: 24,
		marginHorizontal: 12,
	},
	modalBtn: {
		flex: 1,
		marginHorizontal: 4,
	},
	gradientBtn: {
		flex: 1,
		marginHorizontal: 4,
	},
	gradientBtnStyle: {
		flex: 1,
	},
	leftContainer: {
		flex: 1,
	},
	rightContainer: {
		flex: 1,
	},
	textStyle: {
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize: 17,
		textAlign: "center",
		lineHeight: 24,
		color: 'rgba(0, 0, 0, 0.5)',
	},
	textStyle2: {
		textAlign: "center"
	},
})
