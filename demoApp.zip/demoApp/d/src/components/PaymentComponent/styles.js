import { StyleSheet, Platform, Dimensions, I18nManager } from "react-native";
//import Colors from "../../common/Colors";
import { Styles, Colors } from "@common";
import { FontScalling } from "../../common/Utility";
const { height, width } = Dimensions.get("window");
export default  styles = StyleSheet.create({
    mainContainer: {        
        flex:1
    },
    rightIcon: {
        width: 96,
        height: 96,
        alignSelf: 'center',
        marginTop: 165,
    },
    thankyouContainer:{
        alignItems: 'center',
        marginTop: 40,
    },
    thankYouText: (lang) => ({
        alignItems: 'center',
        fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
        fontSize: Styles.FontSize.fnt28,
        color: Colors.white,
        lineHeight: 36,
    }),
    paymentText: (lang) => ({
        alignItems: 'center',
        fontFamily: Styles.FontFamily(lang).ProximaNova,
        fontSize: Styles.FontSize.fnt14,
        color: Colors.white,
        marginTop: 8,
        lineHeight: 18,
    }),
    sepraterBorder:{
        height: 1,
        marginTop: 40,
        backgroundColor: 'rgba(255, 255, 255, 0.3)',
        marginHorizontal: 128,

    },
    continueToContainer:{
        alignItems: 'center',
        marginTop: 36,
    },
    continueToText: (lang) => ({
        alignItems: 'center',
        fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
        fontSize: Styles.FontSize.fnt17,
        color: Colors.white,
        lineHeight: 24,
        textAlign:'center',
        marginHorizontal:20
    }),
    continueBtnContainer:{
        marginHorizontal: 16,
        marginTop: 16,
    },  
    btnContinue: {
        backgroundColor: Colors.white,
        height: 56,
        borderRadius: 8,
        alignItems: "center",
        justifyContent: "center",
        borderWidth: 1,
        borderColor: Colors.white,
    },
    textStyle: {
        color: Colors.pinkishRed,
        fontSize: Styles.FontSize.fnt17,
        fontFamily: Styles.FontFamily().ProximaNovaBold
    },
    loaderImageCont: {
		flex: 1,
		justifyContent: 'center',
		alignItems:"center",
	},
	loaderImage: {
		width: 80,
		height: 62,
		marginBottom: 19
	},
	label: {
		color: Colors.white,
		fontSize: 12,
		fontFamily: Styles.FontFamily().ProximaNova,
		textAlign:'center'
	},
});

