/** @format */

import React, { PureComponent } from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
	View,
	Text,
	StyleSheet,
	ImageBackground,
	StatusBar,
	SafeAreaView,
	Image,
	I18nManager
} from "react-native";
import { Images, Colors, Styles } from "@common";
import { returnRemainingSlider, screens } from "../../common/Utility";
import { translate, setI18nConfig } from "@languages";
import { FullButton, PaymentModal, Toast, GradientButton } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as PaymentAction from "../../redux/Actions/Payment";
import { firebase } from '@react-native-firebase/analytics';

class PaymentComponent extends PureComponent {
	constructor(props) {
		super(props);
		this.state = { isPaymentSuccess: this.props.paymentReducer.isPayment, isPaymentfrom: this.props.isPaymentfrom }
	}
    
    init() {
		this.startInitiatePayment();
    }

	componentDidMount() {
		if(this.state.isPaymentfrom == "appointment"){
			this.startInitiatePayment();
		}
	}

    validate() {
		return new Promise((resolve, reject) => {
		if (this.state.isPaymentSuccess) {
				if (this.props.signupDetail.password.length > 0) {
					let slider = returnRemainingSlider(this.props.signupDetail);
					if (slider.length == 0) {
						if(this.state.isPaymentfrom == "Home"){
							this.props.navigation.navigate("Home");
						}else{
							setI18nConfig("en",false);
							this.props.navigation.navigate("App");
						}
						resolve({result: 0});
					} else {
						resolve({result: -1, nextSlide: slider[0], sliderArray: slider});
					}
				}
				else {
					resolve({result: 1});
				}
		}
		else {
			//Retry option
			this.setState({isPaymentSuccess: null});
			this.startInitiatePayment();
			resolve({result: 0});
		}
	});
    }

    startInitiatePayment() {
        this.props.actions.PaymentAction.InitiatePayment().then(() => {
			if (this.props.paymentReducer.error) {
					this.setState({isPaymentSuccess: false});
					this.toast.show(this.props.paymentReducer.error);
			} else {
				this.setState({isPaymentSuccess: null});
                firebase.analytics().logEvent("checkout_progress", {checkout_step: "Call Payment Gateway"});
                console.log('opening payment URL =',this.props.paymentReducer.payment_url);
                this.refs.refpayment.togglePaymentModal(true,this.props.paymentReducer.payment_url);
			}
		});
    }

    _OnclosePayment(payment_id, id, isSuccess) {
		firebase.analytics().logEvent("checkout_progress", {checkout_step: "Payment Done", checkout_option: payment_id});
		this.props.actions.PaymentAction.CheckPaymentStatus(payment_id,isSuccess).then(() => {
			if (this.props.paymentReducer.error) {
				this.handlePayment(false);
			} else {
				this.handlePayment(true);
			}
		});
	}

	async handlePayment(isPayment) {
		await this.setState({isPaymentSuccess: isPayment});
		this.props.paymentSuccess(isPayment);
	}

	renderStatusPart() {
        return(
            <View>

            {this.state.isPaymentSuccess ?
                <Image source={this.props.isPaymentfrom == "appointment" ? Images.icons.checkWhiteInsie : Images.icons.checkReddish} style={styles.rightIcon} />
                :
                <Image source={this.props.isPaymentfrom == "appointment" ? Images.icons.report_white : Images.icons.report} style={styles.rightIcon} /> 
            }
            
            <View style={styles.thankyouContainer}>
                <Text style={[styles.thankYouText(this.props.signupDetail.com_lang), this.props.isPaymentfrom == "appointment" ? {color:  Colors.pinkishRed} : {}]}>{this.state.isPaymentSuccess ? translate("ThankYou") : translate("Sorry") } </Text>
                <Text style={[styles.paymentText(this.props.signupDetail.com_lang),this.props.isPaymentfrom == "appointment" ? {color:  Colors.pinkishRed} : {}]}>{ this.state.isPaymentSuccess ? translate("YourPaymentReceived") : translate("FailedTitle")  }</Text>
            </View>
            <View style={[styles.sepraterBorder, this.props.isPaymentfrom == "appointment" ? {backgroundColor: "#ff0000" } : {} ]} />
			{!this.props.signupDetail.isLogin &&
            <View style={styles.continueToContainer}>
				<Text style={[styles.continueToText(this.props.signupDetail.com_lang), this.props.isPaymentfrom == "appointment" ? {color:  Colors.pinkishRed} : {}]}>{this.state.isPaymentSuccess ? translate("ContinueToSetProfileAndMeal") : translate("FailedSubtitle1") }</Text>
                <Text style={[styles.continueToText(this.props.signupDetail.com_lang), this.props.isPaymentfrom == "appointment" ? {color:  Colors.pinkishRed} : {}]}>{this.state.isPaymentSuccess ? translate("AndChooseYourMeal") : translate("FailedSubtitle2") }</Text>
			</View>
			}
            <View style={styles.continueBtnContainer}>

				{this.props.isPaymentfrom == "appointment" ?
					<GradientButton
						style={styles.btnContinue}
						text={this.state.isPaymentSuccess ? translate("Continue"): translate("Retrybt")}
						onPressAction={() => this.continueOrRetryButtonClciked()} />
				:
					<FullButton onPress={() => this.continueOrRetryButtonClciked()} btnStyle={styles.btnContinue} textStyle={styles.textStyle} label={this.state.isPaymentSuccess ? translate("Continue"): translate("Retrybt")} />
				}

                
            </View>
            </View>
        );
	}
	
	continueOrRetryButtonClciked() {
		if(this.state.isPaymentSuccess) {
			this.props.onPaymentComplete(null);
		}
		else{
			if(this.props.isPaymentfrom == "appointment"){
				this.setState({isPaymentSuccess: null});
				this.startInitiatePayment();
			}
			else{
				this.props.onPaymentComplete(null);
			}
		}
	}

	render() {
		return (
			<View style={styles.mainContainer}>
                { this.state.isPaymentSuccess != null ?
                    this.renderStatusPart()
                	:
                    <View style={styles.loaderImageCont}>
                        <Image source={Images.smileLogo} style={[styles.loaderImage, this.props.isPaymentfrom == "appointment" ? {tintColor: Colors.pinkishRed} : {}]} />
                        <Text style={[styles.label, this.props.isPaymentfrom == "appointment" ? {color: Colors.pinkishRed} : {} ]}>{translate("paymentLoadingLabel")}</Text>
                    </View>
				}

				<PaymentModal
				ref={"refpayment"}
				navigation={this.props.navigation}
				cancelPress={() => this.props.cancelPress()}
				onClose={(isModalVisible, payment_id, id, isSuccess) => this._OnclosePayment(isModalVisible, payment_id, id, isSuccess)} />
                    
				<Toast refrence={(refrence) => this.toast = refrence} />
            </View>
		);
	}
}

const mapStateToProps = (state) => ({
	Connected: state.updateNetInfoReducer.isConnected,
    signupDetail: state.updateUserReducer,
	paymentReducer: state.PaymentReducer,
	planData: state.PlanReducer
});

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
            UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
            PaymentAction: bindActionCreators(PaymentAction, dispatch)
        }
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(PaymentComponent);
