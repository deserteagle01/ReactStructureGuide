import React, { Component, PureComponent } from "react";
import { View, StyleSheet, Text, I18nManager } from "react-native";
import { Colors, Styles } from "@common";
import { translate } from "@languages";
import { connect } from "react-redux";

class ProductHeaderItem extends Component {
	constructor(props) {
		super(props);
  }
  
  
	render() {
    const { userSelectedMeals,currDate, item } = this.props;
    let tempUserSelectedMeals = userSelectedMeals[currDate][item.id] || {};

    if(Object.keys(tempUserSelectedMeals).length == 0){
      return null;
    }
		return (
			<View style={styles.listHeaderView}>
				<View style={styles.listHeaderTitleView}>
					<Text numberOfLines={1} ellipsizeMode={"tail"} style={styles.listHeaderTitleText}>{I18nManager.isRTL? (tempUserSelectedMeals.name_ar || tempUserSelectedMeals.name) : tempUserSelectedMeals.name}</Text>
				</View>
				<View style={styles.listHeaderSelectionTextView}>
					<Text style={styles.listHeaderSelectionDataText}>{' ' + (tempUserSelectedMeals.selected_quantity || 0) + ' '}</Text>
					<Text style={styles.listHeaderSelectionText}>{translate('of')}</Text>
					<Text style={styles.listHeaderSelectionDataText}>{' ' + (tempUserSelectedMeals.quantity || 0)}</Text>
				</View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	listHeaderView: {
    width:'100%',
    backgroundColor: Colors.paleGreyTwo,
    paddingLeft: 12,
    paddingRight: 12,
    paddingTop: 8,
    paddingBottom: 8,
    flexDirection: "row",
    shadowOpacity: 0.2,
    shadowRadius: 0.7,
		shadowColor: Colors.warmGrey,
    shadowOffset: { height: 1, width: 0 },
    elevation: 1,
  },
  listHeaderTitleView: {
    flex: 0.7,
    alignItems: 'flex-start'
  },
  listHeaderTitleText: {
    fontSize: 19,
    color: Colors.black,
    lineHeight: 20,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
  },
  listHeaderSelectionTextView: {
    flex: 0.3,
    flexDirection: 'row',
    justifyContent: "flex-end"
  },
  listHeaderSelectionText: {
    fontSize: 14,
    alignSelf: "flex-end",
    color: Colors.pinkishRed08,
    lineHeight: 18,
    fontFamily: Styles.FontFamily().ProximaNova,
  },
  listHeaderSelectionDataText: {
    fontSize: 14,
    alignSelf: "flex-end",
    color: Colors.pinkishRed08,
    lineHeight: 18,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
  },
});

export default ProductHeaderItem;