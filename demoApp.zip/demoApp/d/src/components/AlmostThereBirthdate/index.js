import React, { Component } from "react";
import { View, Text, StyleSheet, I18nManager ,Platform, Dimensions} from "react-native";
import { connect } from "react-redux";
import { Styles, Images, Colors, Validations } from "@common";
import InputWithIcon from "../InputWithIcon"
import FullButton from "../FullButton"
import { translate } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import moment from 'moment';
import { InputAccessory } from "@components";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import ButtonOk from  "../ButtonOk";
import { TouchableOpacity } from "react-native-gesture-handler";
const { height, width } = Dimensions.get("window");
class AlmostThereBirthdate extends Component {
	constructor(props) {
		super(props);
		this.state = {
			profileDob: this.props.signupDetail.birth_date ? this.props.signupDetail.birth_date : '',
            profileDobError: null,
            isValidDob: false
		};
		this.inputRefs = {};
	}
	
	init() {
		//this.inputRefs["email"].focus();
		this.setState({profileDob: this.props.signupDetail.birth_date, isValidDob: false })
	}

	textDobHandler = (date) => {
        this.setState({isValidDob: true,  profileDob: date});
    }

	validate() {
		return new Promise((resolve, reject) => {
			let option = {fullMessages: false};
			let profileDobError = Validations('reqField', this.state.profileDob, option);
			this.setState({profileDobError: profileDobError});
			if (!profileDobError) {
				var profileDob=moment(this.state.profileDob).locale('en');
				const reqParams = {
					birth_date:profileDob.format('YYYY-MM-DD'),		// Update this field value only
				};
                this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
                resolve({result: 1});
			}else{
                resolve({result: 0});
            }
		});
	}

	render() {
		return (
			<View style={styles.detailContainer}>
				 <KeyboardAwareScrollView enableOnAndroid={true} keyboardShouldPersistTaps={'always'} >
				    <Text style={[styles.label(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? {textAlign:'right'} : null]}>{translate("AlmotThere")}</Text>
                    <View style={styles.inputNameContainer}>
                        <InputWithIcon 
						    onRef={(el) => {this.inputRefs["refDatePicker"] = el} } 
						    refName={"refDatePicker"} 
						    textHandler={this.textDobHandler} errorMsg={this.state.profileDobError}
						    iconPath={Images.icons.calendarIcon} inputText={this.state.profileDob} 
						    lang={this.props.signupDetail.com_lang}
						    placeholderText={translate("EnterDob")} inputType="3" />
					</View>
				
				{this.state.isValidDob  &&
				<TouchableOpacity onPress={this.props.onOkClick}>
					<ButtonOk  lang={this.props.signupDetail.com_lang} />
				</TouchableOpacity>
				}
				</KeyboardAwareScrollView>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		lineHeight: 36,
        textAlign: 'left',
        marginTop: height*0.14,
    }),
	inputNameContainer: {
		marginTop: 34
	},
	inputNameInternalContainer: {
		marginBottom: 7
	},
	continueBtnContainer: {
		marginTop: 24
	},
	btnContinue: {
		backgroundColor: Colors.white,
		height: 56,
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
		borderWidth: 1,
		borderColor: Colors.white,
	},
	textStyle: (lang) => ({
		color: Colors.pinkishRed,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold
	}),
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(AlmostThereBirthdate);