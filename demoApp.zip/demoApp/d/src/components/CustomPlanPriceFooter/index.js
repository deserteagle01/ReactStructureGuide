import React, { Component } from "react";
import { Button, View,Platform, Text, StyleSheet } from "react-native";
import { Styles, Images, Colors } from "@common";
import { translate } from "@languages";
export default class CustomPlanPriceFooter extends Component {
        render() {
            const {
                index,
                title,
                type,
                amount
            } = this.props;
            return (
                <View style={styles.headerFooter}  key={index}>
                    <Text style={[styles.txttotaltxt, { marginLeft: 8 }]}>{translate(title)}</Text>
                    <View style={styles.subview}>
                        <Text style={styles.kwd}>{translate("KWD")}</Text>
                        <Text style={type == "big" ? styles.totalNum : styles.totalNumSmall}>{amount.toFixed(2)}</Text>
                    </View>
                </View>
            );
        }
    }
    
const styles = StyleSheet.create({
	headerFooter:{
        marginTop: 8,
        height: 50,
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'space-between',
        marginHorizontal: 24,
        overflow:'hidden'
       },
       txttotaltxt:{
        fontSize: 13,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        color: Colors.black,
        marginHorizontal: 5
      },
      subview:{
        flexDirection:'row',
        alignItems:'center'
      },
      kwd:{
        fontSize: 12,
        fontFamily: Styles.FontFamily().ProximaNova,
        color: Colors.blacktextPrice,
      },
      totalNum:{
        fontSize: 32,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        color: Colors.pinkishRed,
        marginLeft:6
      },
      totalNumSmall:{
        fontSize: 18,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        color: Colors.pinkishRed,
        marginLeft:6
      },
});
