import React, { Component } from "react";
import { connect } from "react-redux";
import { View, StyleSheet, Text, TextInput, TouchableOpacity, Image, Platform, LayoutAnimation, Keyboard, I18nManager, TouchableWithoutFeedback } from "react-native";  
import Modal from "react-native-modal";
import moment from 'moment';
import { translate } from "@languages";
import { GradientButton,  RateThanksModel, Toast, SimpleMessageModal} from "@components";
import { Images, Styles, Colors, Constants } from "@common";
import { bindActionCreators } from "redux";
import * as mealsAction from "../../redux/Actions/mealsAction";
import ReactNativeHapticFeedback from "react-native-haptic-feedback";

const marginTopModal =  Styles.height - 405;

const defaultAnimation = {
	duration: 500,
	create: {
	  duration: 300,
	  type: LayoutAnimation.Types.easeInEaseOut,
	  property: LayoutAnimation.Properties.opacity
	},
	update: {
	  type: LayoutAnimation.Types.spring,
	  springDamping: 200
	}
};
class ProductRateModel extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isProductRateVisible: false,
			item: null,
			fillStarCount: 0,
			commentText: '',
			selectedDate:'',
			isSubmitDisabled: true,
			rateTag: ['NotRated', 'HatedIt', 'DislikedIt', 'ItWasOk', 'LikedIt', 'LovedIt'],
			keyboardSpace: 0,
		};
		this.toggleProductRateModal = this.toggleProductRateModal.bind(this);
		this._listeners = [];
		this.updateKeyboardSpace = this.updateKeyboardSpace.bind(this);
		this.resetKeyboardSpace = this.resetKeyboardSpace.bind(this);
	}

	componentDidMount() {
		if(Platform.OS === 'ios'){
			this._listeners = [
				Keyboard.addListener('keyboardWillShow', this.updateKeyboardSpace),
				Keyboard.addListener('keyboardWillHide', this.resetKeyboardSpace)
			];
		}
	}
	
	componentWillUnmount() {
		Keyboard.dismiss();
		this._listeners.forEach(listener => listener.remove());
	}

	updateKeyboardSpace(event) {
		if (!event.endCoordinates) {
		  return;
		}
		let animationConfig = defaultAnimation;
		animationConfig = LayoutAnimation.create(
		event.duration,
		LayoutAnimation.Types[event.easing],
		LayoutAnimation.Properties.opacity,
		);
		LayoutAnimation.configureNext(animationConfig);
		this.setState({
		  keyboardSpace: (event.endCoordinates.height + 24),
		});
	}
	
	resetKeyboardSpace(event) {
		let animationConfig = defaultAnimation;
		animationConfig = LayoutAnimation.create(
		event.duration,
		LayoutAnimation.Types[event.easing],
		LayoutAnimation.Properties.opacity,
		);
		LayoutAnimation.configureNext(animationConfig);
		this.setState({
			keyboardSpace: 0,
		});
	}

	toggleProductRateModal = (visible, itemData, currDate) => {
		Keyboard.dismiss();
		this.setState({"fillStarCount": 0, commentText: '', isSubmitDisabled: true});
		if(itemData != undefined){
			this.setState({ isProductRateVisible: visible, item: itemData, selectedDate: currDate });
		}else{
			this.setState({ isProductRateVisible: visible});
		}
	};

	_rateOnFoodCount(count){
		if(count > 0){
			this.setState({"fillStarCount": count, isSubmitDisabled: false});
		}else{
			this.setState({"fillStarCount": count, isSubmitDisabled: true});
		}
		
	}

	triggerHapticEffect = (type) => {
		const options = {
		  enableVibrateFallback: true,
		  ignoreAndroidSystemSettings: true
		};
		ReactNativeHapticFeedback.trigger(type, options);
	}

	_renderKeyboardSpacer = () => {
		return (
			<View style={[{ height: this.state.keyboardSpace }]} />
		);
	}

	renderStart() {
		const tempXml = [];
		for (let i = 0; i < 5; i++) {
			if(i < this.state.fillStarCount){
				tempXml.push(<TouchableOpacity key={i} onPress={()=>{this._rateOnFoodCount(i+1);this.triggerHapticEffect("impactHeavy")}}><Image style={styles.starImage} source={Images.icons.Rate} /></TouchableOpacity>);
			}else{
				tempXml.push(<TouchableOpacity key={i} onPress={()=>{this._rateOnFoodCount(i+1);this.triggerHapticEffect("impactHeavy")}}><Image style={styles.starImage} source={Images.icons.RatingGrey} /></TouchableOpacity>);
			}
		}
		return tempXml;
	}

	_submitRating(item){
		if (this.props.Connected) {
			if(this.state.fillStarCount > 0){
				this.toggleProductRateModal(false);	
				let params = {
					'date': moment(this.state.selectedDate).format(Constants.dateFormate),
					'product_id': item.product_id,
					'rating': this.state.fillStarCount,
					'review': this.state.commentText
				}
				this.props.actions.mealsAction.submitRating(params).then(() => {
					if(this.props.mealDetail.error != null){
						setTimeout(() => {
							this.refs.simpleMessageModal.toggleModal(true, translate('errorInRating'));
						}, 300);
					}else{
						setTimeout(() => {
							const product_name = (this.state.item ? (I18nManager.isRTL? (this.state.item.name_ar || this.state.item.name) : this.state.item.name) : '');
							this.refs.refRateThanksModel.toggleRateThanksModal(true, item.image, product_name);
						}, 300);
					}
				});
			}
		} else {
			this.toast.show(translate("InternetToast"));
		}
	}

	refreshMainProductData = () => {
		this.props.gotoNext(moment(this.state.selectedDate).format(Constants.dateFormate));
	}
	
	onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
	};

	render() {
		return (
			<View style={this.state.isProductRateVisible && styles.modalViewContainer}>
				<RateThanksModel ref={"refRateThanksModel"} gotoNext={this.refreshMainProductData}></RateThanksModel>
				<SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} />
				<Modal
					hasBackdrop
					hideModalContentWhileAnimating={true}
					transparent={true}
					backdropOpacity={0.5}
					useNativeDriver={true}
					isVisible={this.state.isProductRateVisible}
					style={styles.modal}
					onBackdropPress={() => {
						this.toggleProductRateModal(false);
					}}>
						<View style={styles.modelMainContainer}>
						<TouchableWithoutFeedback onPress={()=>{Keyboard && Keyboard.dismiss()}}>
					<View style={styles.modalViewContainer}>
						<View style={styles.modelHeader}>
							<View style={styles.headerFirst}>
								<Image style={styles.mealImage} source={this.state.item != null && this.state.item.image != ''?{uri: this.state.item.image}: Images.ProductListDefault} />
							</View>
							<TouchableOpacity style={styles.headerSecond} onPress={() => {this.toggleProductRateModal(false);}}>
								<Image source={Images.icons.closeBox} />
							</TouchableOpacity> 
						</View>
						<View style={styles.modalContainer}>
							{this.state.item && <Text numberOfLines={1} ellipsizeMode={"tail"} style={styles.greekRateTx}>{I18nManager.isRTL? (this.state.item.name_ar || this.state.item.name) : this.state.item.name}</Text>}
							<Text style={styles.RateYourFoodTx}>{translate("RateYourFood")}</Text>
							<View style={styles.starContainer}>
								{this.renderStart()}
							</View>
							<View style={styles.commentContainer}>
								<View style={[styles.rateTagMark, styles[this.state.rateTag[this.state.fillStarCount]]]}>	
									<Text style={styles.rateTagTx}>{translate(this.state.rateTag[this.state.fillStarCount])}</Text>
								</View>
								<TextInput style={styles.commentTextArea} multiline={true} underlineColorAndroid="transparent" placeholder={translate("TypeSomething")} placeholderTextColor={Colors.black} numberOfLines={4} selectionColor={Colors.black}  onChangeText={(text) => this.setState({commentText: text})} value={this.state.commentText}/>
							</View>
							<View style={styles.submitBtnContainer}>
								<GradientButton disabled={this.state.isSubmitDisabled} style={styles.submitBtn}
									onPressAction={() => { this._submitRating(this.state.item)}}
									text={translate("submitReview")}
								/>								
							</View>
						</View>
					</View>
					</TouchableWithoutFeedback>
					{Platform.OS === 'ios' && this._renderKeyboardSpacer()}
					</View>
					<Toast refrence={(refrence) => this.toast = refrence} />
				</Modal>
			</View>
		);
	}
}

const styles = StyleSheet.create ({
	modal: {
		flex: 1,
	   	margin: 0,
		position: 'absolute',
		bottom: 0,
		backgroundColor: Colors.white,
		borderRadius: 36,
	},
	modelMainContainer: {
		flex: 1,
		flexDirection: 'column'
	},
	modalViewContainer: {
		flex:1,
		width: Styles.width,
		height: 405,
	},
	modelHeader: {
		width: Styles.width,
	},
	headerFirst:{
		position: 'absolute',
		width: 120,
		height: 120,
		alignSelf: 'center',
		top: -60,
		shadowColor: "rgba(0, 0, 0, 0.16)",
		shadowOffset: {
			width: 0,
			height: 4,
		},
		shadowOpacity: 0.30,
		shadowRadius: 4.65,
		elevation: 8,
	},
	mealImage: {
		width: 120,
		height: 120,
		borderRadius: 36
	},
	headerSecond:{
		position: 'absolute',
		width: 44,
		height: 28,
		alignSelf: 'flex-end',
		marginTop: 24,
		paddingRight: 16,
	},
	modalContainer:{
		alignItems: 'center',
		top: 60,
		marginTop: 16,
		//backgroundColor: 'yellow'
	},
	greekRateTx:{
		fontFamily: Styles.FontFamily().ProximaNova,
		color: Colors.black06,
        fontSize: Styles.FontSize.fnt12,
		lineHeight: 14,
		letterSpacing: -0.14,
        textAlign: 'center',
	},
	RateYourFoodTx:{
		fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
		color: Colors.black,
        fontSize: Styles.FontSize.fnt28,
		lineHeight: 36,
		letterSpacing: -0.1,
        textAlign: 'center',
	},
	doneBtnContainer:{
		marginTop: 24,
		marginHorizontal: 16,
		width: Styles.width - 80,
		alignItems: 'center'
	},
	starContainer:{
		flexDirection: 'row',
		marginTop: 16,
		height: 46,
		padding: 6
	},
	starImage:{
		width: 36,
		height: 34.5
	},
	commentContainer:{
		marginTop: 29,
		marginHorizontal: 24,
		backgroundColor: Colors.paleGreyTwo,
		borderColor: "rgba(241, 242, 246, 1)",
		borderWidth: 1,
		borderRadius: 8,
		minHeight: 74,
		width: Styles.width - 48,
		padding: 16,
	},
	commentTextArea:{	
		height: 74 - 32,
		fontFamily: Styles.FontFamily().ProximaNova,
		color: Colors.black,
        fontSize: Styles.FontSize.fnt15,
		lineHeight: 21,
	},
	rateTagMark:{
		position: 'absolute',
		width: 68,
		height: 27,
		borderRadius: 15,
		alignSelf: 'center',
		justifyContent: "center",
		top: -13,
		color: Colors.white,
	},
	NotRated:{
		backgroundColor: Colors.reddishGrey
	},
	HatedIt:{		
		backgroundColor: Colors.pinkishRed
	},
	DislikedIt:{		
		backgroundColor: Colors.marigoldTwo
	},
	ItWasOk:{		
		backgroundColor: Colors.robinSEgg
	},
	LikedIt:{		
		backgroundColor: Colors.deepSkyBlue
	},
	LovedIt:{
		backgroundColor: Colors.shamrockGreen
	},
	rateTagTx:{
		fontFamily: Styles.FontFamily().ProximaNova,
		color: Colors.white,
        fontSize: Styles.FontSize.fnt12,
		letterSpacing: -0.13,
        textAlign: 'center',
	},
	submitBtnContainer:{
		marginTop: 24,
		width: Styles.width - 32,
		alignItems: 'center'
	},
	submitBtn:{
		width: "100%"
	}
 })

const mapStateToProps = (state) => {
	return {
		Connected: state.updateNetInfoReducer.isConnected,
		isLoading: state.mealsReducer.isLoading,
		mealDetail: state.mealsReducer,		
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			mealsAction: bindActionCreators(mealsAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(ProductRateModel);