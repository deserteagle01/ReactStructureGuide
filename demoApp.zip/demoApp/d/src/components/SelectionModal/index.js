import React, { PureComponent } from "react";
import { AnimatedMove } from "@components";
//import ChoosePlanModal from ".";
import Modal from "react-native-modal";
import { View, Text, StyleSheet, Platform, StatusBar, SafeAreaView, Image, TouchableOpacity, Animated, Dimensions, FlatList } from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import SelectionList from '../SelectionList';

import * as GetPlanAction from "../../redux/Actions/Plan";
const { height, width } = Dimensions.get("window");

class SelectionModal extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            isVisible:this.props.isVisible,
        };
    }
    show() {
        this.setState({isVisible:true});
    }
    hide() {
        this.setState({isVisible:false});
        if(this.props.onModalClose) {
            this.props.onModalClose()
        }
        if(this.props.onModalHide) {
            this.props.onModalHide();
        }
    }

    componentDidMount() {
        
    }
	onApply = () => {
		if(this.props.onApply){
			if(this.props.multiSelect) {
                let selectedValueIds = this.refs.refSelectionList.state.selectedValues.map((item)=>{ return item.value; });
                this.props.onApply(selectedValueIds);
			} else {
                let singleSelect = this.refs.refSelectionList.state.selectedValues;
				this.props.onApply(singleSelect?singleSelect[0]:null);
            }
            this.hide();
		}	
		if(this.props.onCancel) {
			this.props.onCancel();
		}
    }
    
    onSelectItem = (item) => {
        if(this.props.onSelectItem) {
            this.props.onSelectItem(item);
        }
        if(item.isChecked && !this.props.multiSelect) {
            this.hide();
        }
    }
    
    render() {
        return (
            <Modal
                hasBackdrop
                isVisible={this.state.isVisible}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={0.5}
                useNativeDriver={true}
                style={styles.modalStyle}
                onBackdropPress={() =>
                    this.hide()
                }
                onBackButtonPress={() =>
                    this.hide()
                }
                onModalHide = {() => this.hide()}>
                <View style={[styles.choosePlanModalContainer, this.props.containerStyle && this.props.containerStyle]}>
                    <View style={styles.selectionModalContainer}>
                        <View style={[styles.selectionModalHeader]}>
                            <Text style={styles.selectTitleTxt(this.props.lang)}>{this.props.title || translate("Select")}</Text>
                            <TouchableOpacity style={styles.backButton} onPress={()=>{this.hide()}}>
                                <Image source={Images.icons.LeftGrey} style={{width: 23,height: 24}}/>
                            </TouchableOpacity>
                            {this.props.multiSelect?
                                <TouchableOpacity style={styles.doneButton} onPress={this.onApply}>
                                    <Text style={styles.applyButtonText}>{translate("Apply")}</Text>
                                </TouchableOpacity>
                                :null
                            }
                        </View>
                        <SelectionList ref="refSelectionList"
                            {...this.props}
                            onSelectItem = {(item) => this.onSelectItem(item)}
                        />
                    </View>
                </View>
            </Modal>
        )
    }
}
const styles = StyleSheet.create({
    choosePlanModalContainer: {
        height: '80%',
        width: '100%',
        justifyContent: 'center',
        // backgroundColor: "red",
        position:'absolute',
        bottom: 0,
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        overflow:"hidden"
    },
    modalStyle:{
      padding:0, 
      margin:0,
    },
    selectionModalContainer:{
		flex: 1,
		borderTopLeftRadius: 24,
		borderTopRightRadius: 24,
		backgroundColor: 'rgba(255,255,255,1)',
	},
    selectionModalHeader:{
        flexDirection: "row",
        alignItems: "center",
        height: 44,
        marginTop:16,
    },
    selectTitleTxt: (lang) => ({
        flex:1,
        fontFamily: Styles.FontFamily(lang).UrbaneRoundedLite,
        fontSize: 16,
        lineHeight: 20,
        alignSelf: "center",
        marginVertical:12,
        textAlign:"center",
		color:"black",
		fontWeight:"bold"
    }),
    backButton:{
        position:"absolute", 
		left:20,
    },
    doneButton:{
        position:"absolute", 
		right:20,
	},
	applyButtonText: {
		color:Colors.pinkishRed,
		fontSize: 14,
		fontWeight: 'bold',
	},    
});


  
  

export default SelectionModal;