import React, { Component } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet ,ScrollView,Dimensions,StatusBar,Platform} from "react-native";
import { translate } from "@languages";
import Modal from "react-native-modal";
import { Images, Styles, Colors } from "@common";
import HTML from 'react-native-render-html';
import { GradientButton, WhiteButton } from "@components";

var deviceHeight = Dimensions.get('window').height;

export default class SimpleModalWithButton extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isVisible: false,
      title: translate('ErrorTitle'),
      message: '',
      options:{},
    };
    this.toggleModal = this.toggleModal.bind(this);
    this.onConfirm = false;
  }

  toggleModal = (visible,title, message, options, btLeft, btRight) => {
      this.setState({ message: message, title: title, isVisible: visible, options: options});
  };

  onModalHide() {
    if(this.onConfirm){
        this.props.onConfirm()
    }
  }

  render() {  
    const { modalStyle } = this.props;  
    return (  
      <Modal
        hasBackdrop
        isVisible={this.state.isVisible}
        hideModalContentWhileAnimating={true}
        useNativeDriver={true}
        style={styles.modalContainer}
        onModalHide={() => this.onModalHide()}
        onBackdropPress={() => {
          this.onConfirm = false;
          this.toggleModal(false);
        }}>
        <View style={[styles.mainContainer,modalStyle]}>
          <View style={styles.titleContainer}>
            <Text style={styles.titleText} > {this.state.title} </Text>
          </View>
          <View style={styles.descContainer}>
            <Text style={styles.descText} > {this.state.message} </Text>
          </View>
          <View style={styles.btnContainer}>
            <TouchableOpacity onPress={() => {
              this.onConfirm = false;
              this.props.onClose()
            }}>
              <Image
                source={Images.icons.close}
                style={styles.closeIcon} />
            </TouchableOpacity>
          </View>
          <View style={styles.buttonContainer}>
              <View style={styles.btView}>
              <WhiteButton
                    onPress={() => {
                      this.onConfirm = false;
                      this.props.onClose()
                    }}
                    text={translate(this.props.btLeftText)}
                    style={styles.leftBT} />
              </View>
              <View style={styles.btView}>
                  <GradientButton 
                      style={styles.rightBT} 
                      isCheckedVisible={false} 
                      onPressAction={() => {
                        this.onConfirm = true;
                        this.props.onClose()
                      }} 
                      text={translate(this.props.btRightText)} />  
              </View>
          </View>
        </View>
      </Modal>  
    );
  }
}

const styles = StyleSheet.create({
  modalContainer:{
    margin:0,
    alignItems: "center",
    justifyContent: "center",
    flex:1,
  },
  leftBT:{
    backgroundColor: 'lightgray', 
    height: 45,
    width: "90%"
  },
  rightBT:{
    height: 45, 
    width: "90%"
  },
  btView:{
    flex:0.5
  },
  buttonContainer:{
    flexDirection: 'row', 
    width: "100%",
    marginTop: 15
  },
  gradientBtn: {
    backgroundColor: Colors.white,
    height: 56,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: Colors.white,
},
  mainContainer:{
    flexDirection: 'column',
    position: "absolute",
    minHeight: 140,
    width: Styles.width-32,
    borderRadius: 20,
    marginLeft:16,
    marginRight:16,
    paddingLeft: 41,
    paddingRight: 41,
    paddingBottom: 24,
    paddingTop: 24,
    justifyContent: "center",
    backgroundColor: Colors.white,
  },
  titleContainer: {
    flexDirection: "row",
    paddingBottom: 8,
    paddingLeft:16,
    paddingRight:16,
    alignItems: "center",
    justifyContent: "center",
  },
  titleText: {
    fontFamily: Styles.FontFamily().ProximaNovaBold,
    fontSize: 18,
    textAlign: "center",
    color: Colors.darkNavyBlue
  },
  descContainer: {
    flexDirection: "row",
  },
  descText: {
    fontFamily: Styles.FontFamily().ProximaNova,
    fontSize: 15,
    alignSelf: "center",
    textAlign: "center",
    flex: 1,
    color: Colors.black08
  },
  btnContainer: {
    right: 16,
    top: 24,
    position: 'absolute',
  },
  closeIcon: {
    width: 28,
    height: 28,
  },
})

