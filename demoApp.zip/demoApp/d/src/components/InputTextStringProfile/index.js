import React, { Component } from "react";
import {
	StyleSheet, TextInput, Image, Text, I18nManager, TouchableWithoutFeedback, Platform,
	TouchableOpacity,InputAccessoryView
} from "react-native";
import { Styles, Colors, Images } from "@common";
import { View } from "react-native-animatable";
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { translate, setI18nConfig } from "@languages";
import { InputAccessory } from "@components";
export default class InputTextStringProfile extends Component {
	constructor(props) {
		super(props);
		this.state = {};
		// this.returnRef = this.returnRef.bind(this);
	}

	componentDidMount() {
		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}
	componentDidUpdate() {
		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}
	componentWillUnmount() {
		if (this.props.onRef) {
			this.props.onRef(null);
		}
	}

	handlerFocus = (input) => {
		this.setState({
			[input]: true
		});
	};

	handlerBlur = (input) => {
		this.setState({
			[input]: false
		});
	};

	textHandler = (text) => {
		this.props.textHandler(text);
	}

	updateRef(name, refs) {
		this[name] = refs;
	}
	InputAccessoryView = () => {
		return (
			<View style={[defaultStyles.modalViewMiddle]} testID="input_accessory_view">
				<View style={[defaultStyles.chevronContainer]}></View>
				<TouchableWithoutFeedback
					onPress={() => {
                        this.props.pickerSelectDone(this.props.refName)
                    }}
					hitSlop={{ top: 4, right: 4, bottom: 4, left: 4 }}
					testID="done_button"
				>
					<View testID="needed_for_touchable">
						<Text style={[defaultStyles.done]}>{"Done"}</Text>
					</View>
				</TouchableWithoutFeedback>
			</View>);
	}
 
	render() {
		const {
			inputType,
			placeholderText,
			itemObj,
			inputText,
			errorMsg,
			refs,
			onUpArrowFun,
			onDownArrowFun,
			fontFamily,
			fontSize,
			inputAccessoryViewID,
			style,
			appLanguage,
		} = this.props;
		const placeholderPicker = {
			label: placeholderText ? placeholderText : null,
			value: null,
			color: Colors.black,
		};
		const pickerStyle = {
			inputIOS: {
				color: Colors.black,
				fontSize: 17,
				height: 60,
				paddingLeft: 16,
				borderRadius: 12,
				borderWidth: 1,
				fontFamily: Styles.FontFamily().ProximaNova,
				borderColor: Colors.whiteTwo,
				textAlign: I18nManager.isRTL ? 'right' : 'left',

			
			},
			inputAndroid: {
				color: Colors.black,
				fontSize: 17,
				height: 60,
				paddingLeft: 16,
				borderRadius: 12,
				borderWidth: 1,
				fontFamily: Styles.FontFamily().ProximaNova,
				borderColor: Colors.whiteTwo,
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			underline: { borderTopWidth: 0 },
			icon: {
				width: 20,
				height: 20,
			},
			iconContainer: {
				height: 61,
				width: 40,
				flex: 1,
				paddingRight: 16,
				justifyContent: 'center',
				alignItems: 'center',
			},
			chevronUp :I18nManager.isRTL?styles.chevronUpArrowRTL:{},
            chevronDown:I18nManager.isRTL?styles.chevronDownArrowRTL:{},

		};
		const pickerStyleWithoutBorder = {
			
			inputIOS: {
				color: Colors.black,
				fontSize: 17,
				height: 30,
				paddingLeft: 0,
				borderRadius: 12,
				borderWidth: 0,
				fontFamily: Styles.FontFamily().ProximaNova,
				borderColor: Colors.whiteTwo,
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			inputAndroid: {
				color: Colors.black,
				marginTop: 0,
				fontSize: 12,
				height: 40,
				paddingLeft: 0,
				borderRadius: 0,
				borderWidth: 0,
				fontFamily: Styles.FontFamily().ProximaNova,
				borderColor: Colors.whiteTwo,
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			underline: { borderTopWidth: 0 },
			icon: {
				width: 20,
				height: 20,
			},
			iconContainer: {
				height: 30,
				width: 40,
				flex: 1,
				paddingRight: 16,
				justifyContent: 'center',
				alignItems: 'center',
				marginBottom: 10
			},
			chevronUp :I18nManager.isRTL?styles.chevronUpArrowRTL:{},
            chevronDown:I18nManager.isRTL?styles.chevronDownArrowRTL:{},
		};		
		if (inputType == 1) {
			return (
				<View>
					<TextInput
						onSubmitEditing={() => this.props.returnKeyEvent(inputAccessoryViewID)}
						inputAccessoryViewID={inputAccessoryViewID}
						ref={this.props.refName ? this.props.refName : 'email'} keyboardType={'email-address'} autoCapitalize='none' selectionColor={Colors.black08} returnKeyType='done' onChangeText={this.textHandler} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.coolGrey} 
						style={[{ fontFamily:  Styles.FontFamily().ProximaNovaSemiBold }, styles.textInput, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '',style]}
						onFocus={() => this.handlerFocus('nameInputOneFocus')}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} />
					<Text style={errorMsg ?styles.errorMsg(appLanguage) : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			);
		} else if (inputType == 2) {
			return (
				<View>
					<TextInput ref={this.props.refName ? this.props.refName : 'phone'} keyboardType={'phone-pad'} selectionColor={Colors.black08} returnKeyType='done' onChangeText={this.textHandler} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[ Styles.FontFamily().ProximaNovaSemiBold , styles.textInput, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}
						onFocus={() => this.handlerFocus('nameInputOneFocus')}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} />
					<Text style={errorMsg ? styles.errorMsg : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			)
		} else if (inputType == 3) {
			// Drop Down
			return (
				<View style={styles.textViewMargin}>
					{this.props.arrowHide ?
						

					<RNPickerSelect
						ref={this.props.refName}
						onValueChange={this.textHandler} value={inputText} useNativeAndroidPickerStyle={false}
						items={itemObj} key={itemObj.length}  style={pickerStyle} placeholder={placeholderPicker.label != null?placeholderPicker:{}}
						Icon={() => <Image source={Images.icons.down} style={{ tintColor: Colors.battleshipGrey }} />}
						onUpArrow={() => onUpArrowFun(this.props.refName)}
						onDownArrow={() => onDownArrowFun(this.props.refName)}
						InputAccessoryView={this.InputAccessoryView}
					/>

					:
						<RNPickerSelect
							inputAccessoryViewID={inputAccessoryViewID}
							ref={this.props.refName}
							onValueChange={this.textHandler} value={inputText} useNativeAndroidPickerStyle={false}
							items={itemObj} key={itemObj.length} style={pickerStyle} placeholder={placeholderPicker.label != null?placeholderPicker:{}}
							Icon={() => <Image source={Images.icons.down} style={{ tintColor: Colors.battleshipGrey }} />}
							onUpArrow={() => onUpArrowFun(this.props.refName)}
							onDownArrow={() => onDownArrowFun(this.props.refName)}
						/>
					}	
					<Text style={errorMsg ? styles.errorMsg : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			)
		} else if (inputType == 4) {
			// not editable
			return (
				<View>
					<TextInput ref={this.props.refName ? this.props.refName : 'noteditable'} autoCapitalize='none' selectionColor={Colors.black08} returnKeyType='done' value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[{ fontFamily: Styles.FontFamily().ProximaNovaSemiBold }, styles.textInput, { color: Colors.black04 }]} editable={false}
						onFocus={() => this.handlerFocus('nameInputOneFocus')}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} />
					<Text style={errorMsg ? styles.errorMsg : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			);
		} else if (inputType == 5) {
			// Drop Down without border
			return (
				<View style={{paddingTop: 25, height: 30, backgroundColor: 'translate' ,justifyContent:"center"}}>
					{!this.props.arrowHide &&
						<RNPickerSelect
							
							onSubmitEditing={() => this.props.returnKeyEvent(inputAccessoryViewID)}
							inputAccessoryViewID={inputAccessoryViewID}
							ref={this.props.refName}
							onValueChange={this.textHandler} value={inputText} useNativeAndroidPickerStyle={false}
							items={itemObj} key={itemObj.length} style={pickerStyleWithoutBorder} placeholder={placeholderPicker.label != null?placeholderPicker:{}}
							Icon={() => <Image source={Images.icons.down} style={{ tintColor: Colors.battleshipGrey, marginBottom: 8 }} />}
							onUpArrow={() => onUpArrowFun(this.props.refName)}
							onDownArrow={() => onDownArrowFun(this.props.refName)}
						/>
					}
					{this.props.arrowHide &&
						<RNPickerSelect
							onSubmitEditing={() => this.props.returnKeyEvent(inputAccessoryViewID)}
							inputAccessoryViewID={inputAccessoryViewID}
							ref={this.props.refName}
							onValueChange={this.textHandler} value={inputText} useNativeAndroidPickerStyle={false}
							items={itemObj} key={itemObj.length} style={pickerStyleWithoutBorder} placeholder={placeholderPicker.label != null?placeholderPicker:{}}
							Icon={() => <Image source={Images.icons.down} style={{ tintColor: Colors.battleshipGrey, marginBottom: 8 }} />}
							onUpArrow={() => onUpArrowFun(this.props.refName)}
							onDownArrow={() => onDownArrowFun(this.props.refName)}
							InputAccessoryView={this.InputAccessoryView}
						/>
					}
				 <Text style={errorMsg ? Styles.common.errorMsg : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			)
		} else if (inputType == 6) {
			// password
			return (
				<View>
					<TextInput 
											inputAccessoryViewID={this.props.inputAccessoryViewID}
											onSubmitEditing={() => this.props.returnKeyEvent(this.props.inputAccessoryViewID)}
											ref={this.props.refName ? this.props.refName : 'password'} secureTextEntry={true}
						onChangeText={this.textHandler} returnKeyType='done' selectionColor={Colors.black08} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey}
						style={[{ fontFamily: Styles.FontFamily().ProximaNova, fontSize: 17, lineHeight: 25 }, styles.textInput, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}
						onFocus={() => this.handlerFocus('nameInputOneFocus')}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} />
					<Text style={errorMsg ? styles.errorMsg : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			)
		} else {
			return (
				<View>
					<TextInput
						inputAccessoryViewID={this.props.inputAccessoryViewID}
						onSubmitEditing={() => this.props.returnKeyEvent(this.props.inputAccessoryViewID)}
						ref={this.props.refName ? this.props.refName : 'string'} onChangeText={this.textHandler} selectionColor={Colors.black08} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.coolGrey}
						style={[{ fontFamily: Styles.FontFamily(appLanguage).ProximaNova }, styles.textInput, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '',style]}
						onFocus={() => this.handlerFocus('nameInputOneFocus')}
						onBlur={() => this.handlerBlur('nameInputOneFocus')} />
					<Text style={errorMsg ?styles.errorMsg : ''}>{errorMsg ? translate(errorMsg) : ''}</Text>
				</View>
			);
		}
	}
}

const styles = StyleSheet.create({
	textInputFocus: {
		borderBottomColor: 'transparent',
	},
	textInput: {
		borderColor: Colors.whiteTwo,
		borderBottomWidth: 0,
		height: 40,
		width: '100%',
		color: Colors.black08,
		fontFamily: Styles.FontFamily().ProximaNova,
		fontSize: 17,
		alignSelf: 'flex-start',
		textAlign: I18nManager.isRTL ? 'right' : 'left',
	},
	errorMsg:(lang)=> ({
		alignSelf: 'flex-start',
		color: 'red',
		fontSize: 12,
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		marginTop: 4,
		marginLeft: 0
	}),
	chevronUpArrowRTL: {
		marginLeft: 11,
		transform: [{ translateY: 4 }, { rotate: '45deg' }],
	},
	chevronDownArrowRTL: {
		marginLeft: 22,
		transform: [{ translateY: -5 }, { rotate: '-135deg' }],
	},
});
