import React, { PureComponent,Component, useRef } from "react";
import { View, StyleSheet, I18nManager, Image, Text, TouchableOpacity, Animated, Easing, Dimensions, SafeAreaView } from "react-native";
import { connect } from "react-redux";
import { Styles, Images, Colors } from "@common";
import FullButton from "../FullButton"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const { height, width } = Dimensions.get("window");
import { DislikeSelection  } from "@components";
import DeviceInfo from 'react-native-device-info';
class DislikeOption extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isDislikeOpen: false,
			animatedValue: new Animated.Value(0),
		};

		this.dislikeSelection = React.createRef();
	}

	init() {
		setI18nConfig(this.props.signupDetail.com_lang,I18nManager.isRTL);
		this.forceUpdate();
	}

	//Cannot read property 'doneButtonClicked' of null
	validate(param) {
		return new Promise((resolve, reject) => { 
			if(param) {
				let results = this.dislikeSelection.current.doneButtonClicked();
				if(results) {
					resolve({result: 1});
				}else{
					resolve({result: 0});
				}
			}else{
				resolve({result: 1});
			}
		});
	}

	selectDislikes() {
		if(!this.state.isDislikeOpen) {
			this.setState({isDislikeOpen: true});
			Animated.timing(this.state.animatedValue, {
				toValue: 1,
				duration: 350,
				easing: Easing.linear
			}).start()
		}
		else{
			this.props.continueClick(true);
			
		}
	}

	closeDislikes() {
		Animated.timing(this.state.animatedValue, {
			toValue: 0,
			duration: 350,
			easing: Easing.linear
		}).start()
		setTimeout(() => {
			this.setState({isDislikeOpen: false});	
		}, 350);
	}

	render() {
		return (
			<View style={styles.detailContainer}>
				<View style={styles.dislikeImageContainer}>

					<Animated.Image
                    	source={Images.icons.dislikeWhiteBig}
                    	resizeMode='contain'
                    	style={[styles.dislikeMainIcon, {
							transform: [
								{
									translateY: this.state.animatedValue.interpolate({
										inputRange: [0, 1],
										outputRange: [0, -height*0.12]
									})
								},
								{
									scaleX: this.state.animatedValue.interpolate({
										inputRange: [0, 1],
										outputRange: [1, 0.5]
									})
								},
								{
									scaleY: this.state.animatedValue.interpolate({
										inputRange: [0, 1],
										outputRange: [1, 0.5]
									})
								}
							]
						}]}
                	/>

				</View> 

				<View style={styles.chooseTextContainer}>
					<Animated.Text style={[styles.label(this.props.signupDetail.com_lang),
					{
						transform: [
							{
								translateY: this.state.animatedValue.interpolate({
									inputRange: [0, 1],
									outputRange: [0, -height*0.20]
								})
							},
							{
								scaleX: this.state.animatedValue.interpolate({
									inputRange: [0, 1],
									outputRange: [1, 0.8]
								})
							},
							{
								scaleY: this.state.animatedValue.interpolate({
									inputRange: [0, 1],
									outputRange: [1, 0.8]
								})
							}
						]
					}
				]}>{translate("ChooseDislike")}</Animated.Text>
				</View>
				{!this.state.isDislikeOpen &&
					<View style={styles.smallTextContainer}>
						<Text style={styles.labelsmall(this.props.signupDetail.com_lang)}>{translate("AvoidDislikeAndLert")}</Text>
						<Text style={styles.labelsmall(this.props.signupDetail.com_lang)}>{translate("TryToChoseDislikeItem")}</Text>
					</View>
				}
				
				<Animated.View style={[styles.continueBtnContainer,
				{
					transform: [
						{
							translateY: this.state.animatedValue.interpolate({
								inputRange: [0, 1],
								outputRange: [0, -height*0.23]
							})
						},
						{
							scaleX: this.state.animatedValue.interpolate({
								inputRange: [0, 1],
								outputRange: [1, 1]
							})
						},
						{
							scaleY: this.state.animatedValue.interpolate({
								inputRange: [0, 1],
								outputRange: [1, 1]
							})
						}
					]
				}
				]}>
					<FullButton onPress={() => this.selectDislikes()} btnStyle={styles.btnContinue} textStyle={styles.textStyle} label={this.state.isDislikeOpen ?  translate("Done") : translate("SelectDislike")} />
				</Animated.View>


				<Animated.View style={[styles.subView,{
					opacity: this.state.isDislikeOpen ? 1 :  0,
					transform: [
						{
							translateY: this.state.animatedValue.interpolate({
							inputRange: [0, 1],
							outputRange: [0, DeviceInfo.hasNotch() ? -height*1.69 : -height*1.60 ]
						})
					},
					]}]}>

					<DislikeSelection  ref={this.dislikeSelection} closeDislikeScreen={() => this.closeDislikes()}/>
						
            	</Animated.View>


				{!this.state.isDislikeOpen &&
					<TouchableOpacity style={styles.ChooseLaterCon} onPress={() => this.props.continueClick(false)}>
					<Text style={styles.labelsmall(this.props.signupDetail.com_lang)}>{translate("ChooseLater")}</Text>
				</TouchableOpacity>
				}

				
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
	},
	container: {
		flex:1
	},
	dislikeImageContainer:{
		marginTop: height*0.15,
		width: "100%",
		alignItems: 'center',
	},
	dislikeMainIcon: {
		width: 136,
		height: 110,
	},
	chooseTextContainer:{
		marginTop: height*0.05,
	},
	smallTextContainer:{
		marginTop: height*0.02,
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		lineHeight: 36,
		textAlign: 'center',
	}),
	labelsmall: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
		fontSize: 14,
		color: Colors.white,
		lineHeight: 18,
		textAlign: 'center'
	}),
	continueBtnContainer: {
		marginTop: height*0.05
	},
	btnContinue: {
		backgroundColor: Colors.white,
		height: 56,
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
		borderWidth: 1,
		borderColor: Colors.white,
	},
	textStyle: {
		color: Colors.pinkishRed,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily().ProximaNovaBold
	},
	ChooseLaterCon:{
		marginTop: height* 0.03
	},
	subView: {
		position: "absolute",
		bottom: 0,
		left: 0,
		right: 0,
		top: height*2,
		backgroundColor: "#FFFFFF",
		height: DeviceInfo.hasNotch() ? height*0.69 : height*0.60,
		borderRadius: 24
	  }
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(DislikeOption);

