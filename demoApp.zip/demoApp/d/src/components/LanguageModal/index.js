import React, { Component } from "react";
import { View, Text, Dimensions, TouchableOpacity, Image } from "react-native";
import Modal from "react-native-modal";
import { GradientButton, ModalButton,SimpleMessageModal } from "@components";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const screen = Dimensions.get("window");

export default class LanguageModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isVisible: false
		};
		this.toggleModal = this.toggleModal.bind(this);

	}

	toggleModal = visible => {
		this.setState({ isVisible: visible });
	};

	_changeLanguage = (lang, isRTL) => {
		if((lang == "ar" && this.props.selectedLangFlag == "en") || (lang == "en" && this.props.selectedLangFlag == "ar")){
			this.refs.simpleMessageModal.toggleModal(true, translate('txtLanguageRelease'));
		}

		{/* Disablling  language change feature  temporary on TASK 17099 */}
		// this.toggleModal(false);
		// this.props.changeLanguage(lang, isRTL);
	}

	onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
	};
	render() {
		const selectedLang = this.props.selectedLangFlag;
		
		return (
			<Modal
				hasBackdrop
				isVisible={this.state.isVisible}
				hideModalContentWhileAnimating={true}
				useNativeDriver={true}
				style={{ alignItems: "center", justifyContent: "center" }}
				onBackdropPress={() => {
					this.toggleModal(false);
				}}
			>
				<View
					style={{
						position: "absolute",
						bottom: 34,
						height: 226,
						width: screen.width-24,
						marginHorizontal:12,
						borderRadius: 20,
						backgroundColor: Colors.white,
					}}
				>
					<View
						style={{
							flexDirection: "row",
							alignItems: "center",
							height: 44,
							marginTop: 8,
							marginBottom: 16,
						}}
					>
						<Text
							style={{
								fontFamily: Styles.FontFamily().UrbaneRoundedLite,
								fontSize: 14,
								alignSelf: "center",
								marginVertical: 12,
								textAlign: "center",
								flex: 1
							}}
						>{translate("ChangeLanguage")}</Text>
						<TouchableOpacity
							style={{ position: "absolute", right: 20 }}
							onPress={() => {
								this.toggleModal(false);
							}}
						>
							<Image source={Images.icons.closeBox} />
						</TouchableOpacity>
					</View>

					{selectedLang == 'en' ?
						<View>
						<GradientButton
							isCheckedVisible={true}
							onPressAction={() => {
								this._changeLanguage("en", false);
							}}
							text={"English"}
						/>
						<View style={{marginTop:16}} />
						<ModalButton
							isCheckedVisible={false}
							onPress={() => {
								this._changeLanguage("ar", true);
							}}
							label={"عربى"}
						/>
						</View>
					:
						<View>
						<ModalButton
							isCheckedVisible={false}
							onPress={() => {
								this._changeLanguage("en", false);
							}}
							label={"English"}
						/>
						<View style={{marginTop:16}} />

						<GradientButton
							isCheckedVisible={true}
							onPressAction={() => {
								this._changeLanguage("ar", true);
							}}
							text={"عربى"}
						/>
						</View>

					}




				</View>
				<SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} />
			</Modal>
		);
	}
}
