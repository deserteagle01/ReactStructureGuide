import React, { Component } from "react";
import { View, Text, StyleSheet, Platform, Dimensions, Image, TouchableOpacity } from "react-native";
import { connect } from "react-redux";
import { Styles, Validations, Colors } from "@common";
import InputTextString from "../InputTextString"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { firebase } from '@react-native-firebase/analytics';
import InputAccessory from "../InputAccessory";
import FullButton from "../FullButton";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const { height, width } = Dimensions.get("window");
import Images from "../../common/Images";
class SignupAddressDetail extends Component {
	constructor(props) {
		super(props);
		this.state = {
			singUpStreet: "",
			singUpStreetError: null,
			singUpHouseNo: "",
			singUpHouseNoError: null,
			singUpAvenue: "",
			singUpAvenueError: null,
		};
		this.inputRefs = {};
	}

	componentWillMount() {
		
	}

	init() {
		firebase.analytics().setCurrentScreen("SignupDeliveryAddress Detail");
		this.setState({
            singUpStreet: this.props.signupDetail.street,
			singUpStreetError: null,
			singUpHouseNo: this.props.signupDetail.street2,
			singUpHouseNoError: null,
			singUpAvenue: this.props.signupDetail.avenue,
			singUpAvenueError: null,
		});
	}

	streetTextHandler = (text) => {
		this.setState({ singUpStreet: text })
	}

	houseNoTextHandler = (text) => {
		this.setState({ singUpHouseNo: text })
	}

	avenueTextHandler = (text) => {
		this.setState({ singUpAvenue: text })
	}

	validate() {
		return new Promise((resolve, reject) => {
		let option = { fullMessages: false };
		let singUpStreetError = Validations('reqField', this.state.singUpStreet, option);
        let singUpHouseNoError = Validations('reqField', this.state.singUpHouseNo, option);
        
        this.setState({ singUpStreetError: singUpStreetError, singUpHouseNoError: singUpHouseNoError })

		if (!singUpStreetError && !singUpHouseNoError) {
			const reqParams = {
				street: this.state.singUpStreet,				
				street2: this.state.singUpHouseNo,				
				avenue: this.state.singUpAvenue,				
			};
			this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
			firebase.analytics().logEvent("checkout_progress", {checkout_step: "Signup Address"});
			resolve ({result: 1});
		}
		else{
			resolve ({result: 0});
		}
	});
	}

	onUpArrowClicked = (refs) => {
		if(refs == "street"){
            this.props.gotoPrev();
        } else if(refs == "houseNo"){
            this.inputRefs["street"].focus();
        } else if(refs == "avenue"){
            this.inputRefs["houseNo"].focus();
        }
    }

    onDownArrowClicked = (refs) => {
        if(refs == "street"){
            this.inputRefs["houseNo"].focus();
        } else if(refs == "houseNo"){
            this.inputRefs["avenue"].focus();
        } else if(refs == "avenue"){
            this.validate();
        }
    }

	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView enableOnAndroid={true} extraScrollHeight={Platform.OS === 'ios' ? 50 : 100} keyboardShouldPersistTaps={'always'}>
					<View>
						<Text style={this.props.signupDetail.com_lang  == "ar" ?  [styles.label(this.props.signupDetail.com_lang), Styles.common.globalArabictxt]: styles.label(this.props.signupDetail.com_lang)}>{translate("YourDeliveryAddress")}</Text>
					</View>

					<View style={[styles.lineInputNameContainer,styles.topInputSpace]}>
						<InputTextString textHandler={this.streetTextHandler} onRef={(el) => {this.inputRefs["street"] = el} } refName={"street"} errorMsg={this.state.singUpStreetError} inputText={this.state.singUpStreet} placeholderText={translate("Street")} inputAccessoryViewID={"street"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}
							styless={[styles.commonFont(this.props.signupDetail.com_lang) ,this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt:Styles.common.globalEnglishtxt] } />
					</View>
					<View style={styles.lineInputNameContainer}>
						<InputTextString textHandler={this.houseNoTextHandler} onRef={(el) => {this.inputRefs["houseNo"] = el} } refName={"houseNo"} errorMsg={this.state.singUpHouseNoError}  inputText={this.state.singUpHouseNo} placeholderText={translate("HouseNo")} inputAccessoryViewID={"houseNo"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)}
							styless={[styles.commonFont(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt:Styles.common.globalEnglishtxt] } />
					</View>
					<View style={styles.lineInputNameContainer}>
						<InputTextString textHandler={this.avenueTextHandler} onRef={(el) => {this.inputRefs["avenue"] = el} } refName={"avenue"} errorMsg={this.state.singUpAvenueError} inputText={this.state.singUpAvenue} placeholderText={translate("Avenue")} inputAccessoryViewID={"avenue"} returnKeyEvent={(refIndex) => this.onDownArrowClicked(refIndex)} 
							styless={[styles.commonFont(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? Styles.common.globalArabictxt:Styles.common.globalEnglishtxt ]} />
					</View>
					{this.state.singUpStreet.length > 0 && this.state.singUpHouseNo.length > 0 &&
						<View style={styles.btContainer}>
							<FullButton 
								onPress={this.props.onOkClick} 
								btnStyle={styles.btnContinue} 
								textStyle={styles.textStyle(this.props.signupDetail.com_lang)} 
								label={translate("Continue")} />
						</View>
					}
				</KeyboardAwareScrollView>
				{Platform.OS == 'ios' &&
					<View>
						<InputAccessory inputAccessoryViewID={"street"} hideDoneBar={false} onUpArrowClick={() => this.onUpArrowClicked('street')} onDownArrowClick={() => this.onDownArrowClicked('street')}/>
						<InputAccessory inputAccessoryViewID={"houseNo"} hideDoneBar={false} onUpArrowClick={() => this.onUpArrowClicked('houseNo')} onDownArrowClick={() => this.onDownArrowClicked('houseNo')}/>
						<InputAccessory inputAccessoryViewID={"avenue"} hideDoneBar={false} onUpArrowClick={() => this.onUpArrowClicked('avenue')} onDownArrowClick={() => this.onDownArrowClicked('avenue')}/>
					</View>
				}
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
	},
	commonFont: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
	}),
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		textAlign: 'left',
		marginTop: height*0.14,
	}),
	textInputFocus: {
		borderBottomColor: Colors.white,
	},
	inputNameContainer: {
		marginTop: 44,
	},
	lineInputNameContainer: {
		//marginTop: 16,
    },
    topInputSpace: {
        marginTop: 10
	},
	btnContinue: {
		backgroundColor: Colors.white,
		height: 56,
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
		borderWidth: 1,
		borderColor: Colors.white,
	},
	btContainer:{
		marginTop: height*0.05
	},
	textStyle: (lang) => ({
		color: Colors.pinkishRed,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold
	}),
});

const mapStateToProps = (state) => {
	return {
		isLoading: state.fetchMasterListReducer.isLoading,
		signupDetail: state.updateUserReducer,
		areaItem: state.fetchMasterListReducer.areas,
		blockItem: state.fetchMasterListReducer.blocks,
		connected: state.updateNetInfoReducer.isConnected,
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(SignupAddressDetail);
