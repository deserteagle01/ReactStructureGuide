import React, { Component } from "react";
import { View, ScrollView, StyleSheet, Text, Dimensions, TouchableOpacity, Image, I18nManager, TextInput, SafeAreaView } from "react-native";
import Modal from "react-native-modal";
import { translate, setI18nConfig } from "@languages";
import { GradientButton } from "@components";
import { Images, Styles, Colors, Validations, AppConfig } from "@common";
const screen = Dimensions.get("window");
import { WebView } from 'react-native-webview';
import { firebase } from '@react-native-firebase/analytics';

export default class WebViewModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isModalVisible: false,
        };
    }

    show() {
        this.setState({ isModalVisible: true});
    };
    hide() {
        this.setState({ isModalVisible: false});
    };

    onNavigationStateChange(status) {

    };

    onBackdropPress(){
        this.hide();
        if(this.props.onBackdropPress){
            this.props.onBackdropPress(this);
        }
    }
    onCancelClick() {
        this.hide();
        if(this.props.onCancelClick){
            this.props.onCancelClick(this);
        }
    }
    render() {
        return (
            <Modal
                hasBackdrop
                isVisible={this.state.isModalVisible}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={0.5}
                useNativeDriver={true}
                style={[{ margin: 0 },this.props.modalStyle]}
                onBackdropPress={() => {
                    this.onBackdropPress();
                }}>
                <View style={styles.mainModalContainer}>
                    <View style={styles.subModalContainer}>
                        <WebView 
                            source = {{ uri: this.props.sourceUri }}
                            startInLoadingState
                            sharedCookiesEnabled={true}
                            onNavigationStateChange={(status) => this.onNavigationStateChange(status) }
                            scalesPageToFit
                            {...this.props}
                            style={[{ flex: 1, marginTop:70 },this.props.modalStyle]}
                        />
                        <TouchableOpacity style={styles.cancelButton} onPress={() => this.onCancelClick()}>
                            <Image source={Images.icons.closeBox} style={styles.infoimg} />
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        );
    }
}

const styles = StyleSheet.create({
    mainModalContainer: {
        height: '100%',
        width: '100%',
        justifyContent: 'center'
    },
    cancelButton: {
        position:'absolute',
        right:15,
        top:35,
    },
    infoimg: {
        height:28,
        width: 28
    },
    subModalContainer: {
        backgroundColor: 'white',
        borderRadius: 16,
        flex: 1
    }
});