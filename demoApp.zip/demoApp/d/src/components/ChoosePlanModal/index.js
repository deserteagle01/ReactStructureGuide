import React, { PureComponent } from "react";
import { AnimatedMove, ChoosePlanView, PaymentComponent, Fade, SignupStartTime,Toast, FullButton, PrivacyPolicy, GradientButton, NeedHelp   } from "@components";
//import ChoosePlanModal from ".";
import Modal from "react-native-modal";
import { View, Text, StyleSheet, Platform, StatusBar, SafeAreaView, Image, TouchableOpacity, Animated, Dimensions, FlatList, ImageBackground } from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as PaymentAction from "../../redux/Actions/Payment";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import styles from "./styles";

import * as GetPlanAction from "../../redux/Actions/Plan";
import * as PlanAction from "../../redux/Actions/Plan";

const { height, width } = Dimensions.get("window");

class ChoosePlanModal extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            isVisible:this.props.isVisible,
            fullWidth: false,
            stage: null,
            isPaymentVisible: false,
            paymentStage: "",
            isPlanDetailFrom: null,
            height: "80%"
        };
    }

    show(isplanDetail) {
        let currentStage = null;
        let fullView = false;
        
        if(isplanDetail){
            currentStage = "plan-detail";
            fullView = true;
        }
        this.setState({stage: currentStage,isVisible:true, fullWidth: fullView, isPlanDetailFrom: isplanDetail});    
    }

    hide() {
        this.setState({isVisible:false, fullWidth:false});
        if(this.props.onModalClose) {
            this.props.onModalClose()
        }
        if(this.props.onModalHide) {
            this.props.onModalHide();
        }
    }

    hidePay() {
        this.setState({isPaymentVisible: false});
    }
    
    componentDidMount() {
        
    }
    
    onPrev(){
        this.setState({fullWidth:false})
        this.props.actions.PlanAction.clearPlanDetails();
    }
    
    onNext(currentStage, isStartdate, isPayment) {
        if(currentStage=="list-cards"){
            this.setState({fullWidth:false})
        }
        else if(currentStage=="plan-detail" && this.state.isPlanDetailFrom == "referralUserExists") {
            this.props.onContinue();
            this.hide();
        }
        else if(currentStage=="plan-detail") {
            if(this.props.signupDetail.isLogin){
                if(isStartdate && isPayment){
                    this.startWithPayment("startDate");
                }
                if(!isPayment && !isStartdate){
                    this.hide();
                }
                if(!isStartdate && isPayment){
                    this.startWithPayment("startPayment");
                }
            }else{
                this.gotoSignup();
            }
        }        
    }

    startWithPayment(stageFrom) {
        let reqParam = {
            isPayment: null
        }
        this.props.actions.PaymentAction.updatePaymentStatus(reqParam);
        this.setState({isPaymentVisible: true, paymentStage: stageFrom });
    }

    gotoSignup() {
        this.props.onContinue()
        this.hide();
    }

    renderChoosePlanModal() {
        return(
            <Modal
                hasBackdrop
                isVisible={this.state.isVisible}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={0.5}
                useNativeDriver={true}
                style={styles.modalStyle}
                onBackdropPress={() =>
                    this.hide()
                }
                onModalHide = {() => this.hide()}>
                <AnimatedMove duration={300} style={[styles.choosePlanModalContainer, {height: this.state.height, maxHeight: 0.95*height} ]} animate={this.state.fullWidth} toHeight={height-40} fromHeight={height*0.80} >
                    <ChoosePlanView
                            {...this.props}
                            stageTo = {(stage, planData, modalHeight) =>  {
                                if(stage == "book-appointment" && modalHeight){
                                    this.setState({height: (modalHeight + 1) * 120})
                                    if(planData == undefined){
                                        this.props.resetmodalReOpenPlanData()
                                    }
                                }else if(stage == "appointment-calendar"){
                                    this.setState({height: "95%" })
                                }else if(stage == "plan-detail"){
                                    this.setState({height: "95%" })
                                }else if(stage == "list-cards") {
                                    this.setState({height: "80%" })
                                    if(this.props.modalReOpenPlanData && !this.props.modalReOpenPlanData.is_book_appointment){
                                        this.props.resetmodalReOpenPlanData()
                                    }
                                }
                                else{
                                    this.setState({height: "95%" })
                                }
                            }}
                            planDetailFrom = {this.state.isPlanDetailFrom}
                            modalReOpenPlanData = {this.props.modalReOpenPlanData}
                            forwardStage={this.state.stage}
                            onBookingDone={() => this.gotoSignup()}
                            onDone={() => this.hide()}
                            onPrev={() => this.onPrev()}
                            onNext={(currentStage, isStartdate, isPayment) => this.onNext(currentStage, isStartdate, isPayment)}/>
                </AnimatedMove>
                {this.renderPAymentModal()}
            </Modal>
        );
    }

    render() {
        return(
            <View>
                {this.renderChoosePlanModal()}
                <Toast refrence={(refrence) => this.toast = refrence} />
            </View>
        );
    }

    signUpToastShow(toastMsg) {
		this.toast.show(toastMsg);
    }
    
    gotoPayContinue = () => {
		var reqParams = {
			expected_plan_start_date : this.props.signupDetail.expected_plan_start_date
        };
        if (this.props.connected) {
			this.props.actions.UpdateUserAction.registerUpdateUser(reqParams).then(() => {
				if (this.props.signupDetail.error) {
					this.toast.show(this.props.signupDetail.error);
				} else {
					this.startWithPayment("startPayment");
				}
			});
        } 
        else {
			this.toast.show(translate("InternetToast"));
		}	
    }
    
    openPrivacyPolicyModal = () => {
		this.refs.refPrivacyPolicy.togglePrivacyPolicyModal(true);
    }
    
    renderTopbar(){
        return(
            <View style={styles.header}>
                <TouchableOpacity onPress={() => this.cancelPress()}>
                    <Image source={Images.icons.cancel_redBackground} style={styles.cancelLogo} />
                </TouchableOpacity>

                <View style={styles.helpView}>
                    <NeedHelp textStyle={styles.txtCall} iConPath={Images.icons.callGrey} />
                </View>
            </View>
        )
    }

    renderPAymentModal(){
        return(
            <Modal
              hasBackdrop
              isVisible={this.state.isPaymentVisible}
              hideModalContentWhileAnimating={true}
              transparent={true}
              backdropOpacity={0.5}
              useNativeDriver={true}
              style={styles.modalStyle}
              onBackdropPress={() => this.hidePay()}
              onModalHide = {() => this.hidePay()}>

                <View style={styles.choosePlanModalContainer2}>
                    <View style={{flex:1}}>

                        <Fade remove={this.state.paymentStage!="startDate"} visible={this.state.paymentStage=="startDate"} duration={300} style={{flex:1,backgroundColor: Colors.white}}>
                            <SignupStartTime  
                                    ref={this.startdate} 
                                    onOkClick={() => this._SlideDown(null)} 
                                    singUpToast={(toastMsg) => this.signUpToastShow(toastMsg)} 
                                    isCheckedVisible={false} 
                                    isOpenFrom={"afterlogin"}
                                    gotoNext={() => { this.gotoNext() }} 
                                    gotoPrev={() => { this._SlideUp() }} />

                                <View style={styles.termContainer}>
							        <GradientButton
                                        style={{width:"100%",bottom:10}}
                                        text={translate("ContinuePay")}
                                        onPressAction={this.gotoPayContinue} />
							        <Text style={[styles.termTextSmall, { fontFamily: Styles.FontFamily(this.props.signupDetail.com_lang).ProximaNova }]}>{translate("ByClickingContinue")}</Text>
							        <Text onPress={this.openPrivacyPolicyModal} style={[styles.termTextSmall, { fontFamily: Styles.FontFamily(this.props.signupDetail.com_lang).ProximaNovaBold }]}>{translate("TermConditions")}</Text>
						        </View>
                                {this.renderTopbar()}
                                <PrivacyPolicy ref={"refPrivacyPolicy"} gotoNext={this.gotoPayContinue}></PrivacyPolicy>
                        </Fade>

                        <Fade remove={this.state.paymentStage!="startPayment"} visible={this.state.paymentStage=="startPayment"} duration={300} style={{flex:1}}>
                            <View style={{flex:1, backgroundColor:'white'}}>
                            <PaymentComponent  
                                navigation={this.props.navigation} 
                                isPaymentfrom={"appointment"} 
                                cancelPress={() => this.cancelPress()}
                                ref={"paymentref"} 
                                onPaymentComplete={(param) => 
                                    this.setState({isPaymentVisible: false}, () => 
                                        {
                                            this.hide()
                                            if (this.props.signupDetail.isLogin && this.props.onPaymentComplete) {
                                                this.props.onPaymentComplete()
                                            }
                                        }
                                    )} 
                                paymentSuccess={(isPayment) => console.log("---------------payment complete------------",isPayment) } />
                            {this.renderTopbar()}
                            </View>
                        </Fade>
                    </View>
                </View>
            </Modal>
        );
    }

    cancelPress() {
        this.setState({isPaymentVisible: false})
    }
}

  
function mapDispatchToProps(dispatch) {
    return {
      actions: {
        PaymentAction: bindActionCreators(PaymentAction, dispatch),
        UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
        PlanAction: bindActionCreators(PlanAction, dispatch),
    }
    };
  }
  
  const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    signupDetail: state.updateUserReducer
  });
  
  export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(ChoosePlanModal);