import { StyleSheet, Platform, Dimensions, I18nManager } from "react-native";
//import Colors from "../../common/Colors";
import { Images, Styles, Colors } from "@common";
import { FontScalling } from "../../common/Utility";
const { height, width } = Dimensions.get("window");
export default (styles = StyleSheet.create({
  choosePlanModalContainer: {
    height: '80%',
    width: '100%',
    justifyContent: 'center',
    // backgroundColor: "red",
    position:'absolute',
    bottom: 0,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow:"hidden"
},
choosePlanModalContainer2: {
  height: height-40,
  width: '100%',
  justifyContent: 'center',
  position:'absolute',
  bottom: 0,
  borderTopLeftRadius: 24,
  borderTopRightRadius: 24,
  overflow:"hidden",
  
},
txtCall:{
  fontFamily: Styles.FontFamily().ProximaNova,
  fontSize: 14,
  letterSpacing: -0.16,
  color: Colors.black08
},
helpView: {
  flexDirection: 'row',
  alignItems: 'center'
},
cancelLogo: {
  width: 28,
  height: 28,
},
header: {
  width: '100%',
  position:'absolute',
  top:0,
  flexDirection: 'row',
  padding: 16,
  alignItems: 'center',
  justifyContent: 'space-between',
  ...Platform.select({
    android: {
      marginTop: 20,
    },
  }),
},  
termTextSmall: {
  textAlign: 'center',
  fontSize: Styles.FontSize.fnt10,
  color: Colors.pinkishRed,
},
termContainer: {
  width: "90%",
  bottom: 32,
  alignItems: "center",
  justifyContent: "center",
  alignSelf:'center',
},
textStyle:(lang) => ({
  color: Colors.pinkishRed,
  fontSize: Styles.FontSize.fnt17,
  fontFamily: Styles.FontFamily(lang).ProximaNovaBold
}),
btnContinue: {
  backgroundColor: Colors.white,
  height: 56,
  borderRadius: 8,
  alignItems: "center",
  justifyContent: "center",
  borderWidth: 1,
  borderColor: Colors.white,
  marginBottom: 12,
  width:'100%'
},
modalStyle:{
  padding:0, 
  margin:0,
},
}));

