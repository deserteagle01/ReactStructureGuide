import React, { Component } from "react";
import { View, StyleSheet,TouchableOpacity, Text, TextInput, Dimensions, Image, I18nManager } from "react-native";
import { Colors, Styles , Images} from "@common";
import { translate, setI18nConfig } from "@languages";
import SelectionModal from '../SelectionModal'
const screen = Dimensions.get("window");

export default class InputSelectionPicker extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value:"",
            itemKey:this.props.value,
            item:{},
        }
        this.keyExtractor = this.props.keyExtractor?this.props.keyExtractor:()=>{return "value"};
    }
    componentWillReceiveProps(nextProps) {
        if(this.props!=nextProps) {
            if(this.props.data && (this.state.value!=nextProps.value)) {
                let initial = this.props.data.filter((item)=> {
                    return this.getKey(item)==nextProps.value;
                });
                if(this.state.value!=initial && initial) {
                    this.setState({itemKey:nextProps.value, value: initial && this.getValue(initial[0]) || ""});
                }
            }
        }
    }
    getValue = (item) => {
        let value;
        if(this.props.valueExtractor) {
            value = item && this.props.valueExtractor(item);
        } else {
            value =  item && item["label"];
        }
        return value;
    }
    getKey = (item) => {
        return item && item[this.keyExtractor()];
    }
    onClick = () => {
        this.refs.refSelectionModal.show();
    }
    
    setVals(props, item) {
    }
    onSelectItem = (item) => {
        item = item || {}
        this.setState({value:this.getValue(item), itemKey:this.getKey(item)})
        console.log("Item selected received ",item, this.getValue(item));
        if(this.props.onSelectItem) {
            this.props.onSelectItem(item);
        }
    }

    render() {
        return (
        <View style={{flex:1, width:"100%"}}>
            <View style={[styles.container,this.props.containerStyle]}>
            <TouchableOpacity style={{flex:1}} activeOpacity={.7} onPress={this.onClick}>
                <View style={{flex:1, flexDirection:"row", justifyContent:"flex-end", alignContent:"center", alignItems:"center"}}>
                    <Text
                        {...this.props}
                        ref = {"textInput"}
                        style = {[styles.txtInput(this.props.lang),this.state.value?{...this.props.style}:{...this.props.placehoderStyle}]}
                    >{this.state.value?this.state.value:this.props.placeholder}</Text>
                    <Image style={{height:22, width:22}} source={this.props.icon || Images.icons.down} />
                </View>
                </TouchableOpacity>
            </View>        
            {
                this.props.errorMsg && this.props.errorMsg.length > 0 ?
                <Text style={[styles.errorMsg(this.props.lang),this.props.errorMsgStyle]}>{this.props.errorMsg}</Text>
                :
                null
            }
            <SelectionModal 
                ref="refSelectionModal" 
                data = {this.props.data}
                selectedValues = {this.state.itemKey?[this.state.itemKey]:[]}
                lang = {this.props.lang}
                isLoading = {this.props.isLoading}
                onApply = {this.onSelectItem}
                onSelectItem = {this.onSelectItem}
                title={this.props.title}
                search={true}
                multiSelect={false}
                showSelection={false}
                containerStyle={{"height":"95%"}}
                isGroupView={this.props.isGroupView}
			/>
        </View>
    );
    }

}

const styles = StyleSheet.create({
    container: {
        height: 60,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: Colors.white,
        paddingHorizontal: 18,
        overflow: 'hidden',
    },
    txtInput: (lang) => ({
        textAlign: 'left',
        padding: 0,
        paddingLeft:24,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        width:'100%',
        fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
        fontSize: 24,
        color:Colors.placeHoderGrey,
        fontWeight:"normal",
    }),
    errorMsg: (lang) => ({
        alignSelf:'flex-start',
        color: Colors.white,
        fontSize: 14,
        fontFamily: Styles.FontFamily(lang).ProximaNova,
        marginTop: 5,
        marginLeft: 20,
    }),
    
});
