import React, { Component } from "react";
import { Dimensions, View, Text, TouchableOpacity, Image, StyleSheet, I18nManager } from "react-native";
import { Styles, Images, Colors, Constants } from "@common";
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import moment from 'moment';
import * as Appointment from "../../redux/Actions/Appointment";
import 'moment/locale/ar'
import 'moment/locale/en-gb'
import LinearGradient from 'react-native-linear-gradient';
if (I18nManager.isRTL) {
    moment.locale('ar');
} else {
    moment.locale('en-gb');
}
import { connect } from "react-redux";

class AppointmentBox extends Component {
    constructor(props) {
        super(props);
        this.todayDate = moment(new Date()).lang("en-gb").format('YYYYMMDD');
    }

    _renderDateBox =  () => {
        const { gotoNext, boxDate } = this.props;
        if(moment(boxDate).lang("en-gb").format('YYYYMMDD') == this.props.selectedDate) {
            return (
                <View style={styles.linearGradient}>
                    <LinearGradient colors={['rgb(238,29,36)', 'rgb(255,110,0)']} style={styles.linearGradient}>
                        {this._renderappointmentDateView(true)}
                    </LinearGradient>
                </View>
            ); 
        }
        else{
            return this._renderappointmentDateView(false);
        }
    }

    selectDate(boxDate) {
        let param = {
            selectedDate: moment(boxDate).lang("en-gb").format('YYYYMMDD'),
            slotList:  this.props.slots,
            selectedTimeSlot: null
        }
        this.props.actions.Appointment.updateSelecteDate(param);
    }

    _renderappointmentDateView = (isGradient) => {
        const { gotoNext, boxDate, isFrom} = this.props;
        return (
            <View>
                <TouchableOpacity disabled={ this.props.status == "not_available" ? true: false } 
                    onPress={() => this.selectDate(boxDate)} 
                    style={[styles.mainDayBoxContainer]}>
                    <Text style={isGradient ? styles.boxDateWhite : styles.boxDate}>{moment(new Date(boxDate)).format('D')}</Text>
                    <View>
                        <View style={styles.statusIconContainer}>
                            {this.renderImage(this.props.status, isGradient)}
                        </View>

                        { this.props.status && this.props.status != "not_available" && 
                            <View style={styles.statusContainer}>
                                <Text style={isGradient ? styles.boxStatusWhiteTx : styles.boxStatusTx}>{ isGradient ? translate("MealAssign") : translate("schedule")} </Text>
                            </View>
                        }
                        
                    </View>
                </TouchableOpacity>
            </View>
        );
    }

    renderImage(status, isGradient) {
        if(status){
            return(
                <Image source={this.props.status == "not_available" ?  Images.icons.close_gray : isGradient ? Images.icons.round_selected_white : Images.icons.meeting_Red} style={styles.dayBoxIcon} />
            );
        }else{
            return(
                null
            );
        }
    }
    
    
  render() {
        return (
            <View style={{height: 68,width: (dimensionsWidth / 7) - 5,alignItems: 'center'}}>
                {this._renderDateBox()}
            </View>
        );
    }
}

const dimensionsWidth = Dimensions.get('window').width;
const dimensionsHeightBox = (dimensionsWidth / 7) * 1.1;
const styles = StyleSheet.create({
	mainDayBoxContainer:{
        width: (dimensionsWidth / 7) - 5,
        height: 60,
        // paddingHorizontal: 3,
        // paddingVertical: 4,
        borderColor: 'rgba(234, 234, 234, 1)',
        borderWidth: 1,
        borderRadius: 8,
    },
    boxDate:{
        color: 'rgba(0, 0, 0, 0.5)',
        fontSize: 12,
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        lineHeight: 14,
        textAlign: 'right',
        paddingRight: 4,
        paddingTop: 3,
    },
    dateTxContainer:{
        height: dimensionsHeightBox / 4,
    },
    boxDateWhite:{
        color: Colors.white,
        fontSize: 12,
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        lineHeight: 14,
        textAlign: 'right',
        paddingRight: 4,
        paddingTop: 3,
    },
    statusIconContainer:{
        alignItems: 'center',
        justifyContent: 'center',
        height: 28,
    },
    dayBoxIcon:{
        width: 28,
				height:28,
        aspectRatio: 1,
        alignSelf: 'center'
    },
    dayBoxIconRed:{
        width: 28,
        height:28,
        aspectRatio: 1,
        alignSelf: 'center',
        tintColor: 'red'
    },
    statusContainer:{
        alignItems: 'center',
        paddingBottom: 2,
        // height: dimensionsHeightBox / 4,
    },
    boxStatusTx:{
        color: 'rgba(0, 0, 0, 0.5)',
        fontSize: 8,
        fontFamily: Styles.FontFamily().ProximaNova,
        lineHeight: 14,
        textAlign: 'center',
    },
    boxStatusWhiteTx:{
        color: Colors.white,
        fontSize: 8,
        fontFamily: Styles.FontFamily().ProximaNova,
        lineHeight: 14,
        textAlign: 'center',
    },
    linearGradient:{
        width: (dimensionsWidth / 7) - 5,
        height: 60,
        borderRadius: 8,    
        // marginRight: 4,
        shadowColor: 'rgba(0, 0, 0, 0.6)',
        shadowOffset: { width: 0, height: 8 },
        shadowRadius: Platform.OS === 'ios'?16:32,
        shadowOpacity: 0.24,
        elevation: Platform.OS === 'ios'?5:10,
    },
});

const mapStateToProps = (state,ownProps) => {
    let userSlots = {};
    if(ownProps && ownProps.boxDate){
        var key = moment(new Date(ownProps.boxDate)).lang("en-gb").format(Constants.dateFormate);
        var dietitionId = ownProps.dietitionId;
        if(state.appointmentReducer.calendarList && state.appointmentReducer.calendarList[dietitionId][key]) {
              userSlots = state.appointmentReducer.calendarList[dietitionId][key];
              userSlots.selectedDate = state.appointmentReducer.selectedDate;
        }
    }
    return {
        ...userSlots
    };
};

function mapDispatchToProps(dispatch) {
    return {
        actions: {
          Appointment: bindActionCreators(Appointment, dispatch),
        }
      };
}

export default connect(mapStateToProps, mapDispatchToProps)(AppointmentBox);