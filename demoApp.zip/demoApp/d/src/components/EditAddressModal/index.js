import React, { Component } from "react";
import { View, Text, Dimensions, TouchableOpacity, Image, StyleSheet, I18nManager } from "react-native";
import Modal from "react-native-modal";
import { ModalButton } from "@components";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const screen = Dimensions.get("window");

export default class EditAddressModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isVisible: false,
			item: null,
			numberAddresses: null,
			modalTextPressed:"",
			numberOfAddressTitle:"",
		};
		this.toggleModal = this.toggleModal.bind(this);
	}

	toggleModal = (visible, item, numberAddresses,numberOfAddressTitle) => {
		this.setState({
			isVisible: visible,
			item: item,
			numberAddresses: numberAddresses,
			numberOfAddressTitle:numberOfAddressTitle
		});
	};
	render() {
		return (
			<Modal
				hasBackdrop
				isVisible={this.state.isVisible}
				hideModalContentWhileAnimating={true}
				useNativeDriver={true}
				style={styles.modal}
				onModalHide={() => {
					this.props.editProfile(this.state.modalTextPressed,this.state.item,this.state.numberOfAddressTitle);
				}}>
				<View
					style={styles.modalConatiner}>
					<View
						style={styles.topContainer}>
						<Text
							style={styles.txtTitle}>
							{this.state.numberAddresses}
						</Text>
						<TouchableOpacity
							style={styles.closeConatiner}
							onPress={() => {
								this.setState({
									isVisible: false,modalTextPressed:"close"})
							}}>
							<Image source={Images.icons.closeBox} />
						</TouchableOpacity>
					</View>
					<ModalButton
						btnStyle={{ marginTop: 4 }}
						onPress={()=>{
							this.setState({
								isVisible: false,modalTextPressed:"edit"})
						}}
						label={translate("Edit")}
					/>
					<ModalButton
						btnStyle={{ marginTop: 8 }}
						onPress={() => {
							this.setState({
								isVisible: false,modalTextPressed:"disable"})
						}}
						label={this.state.item!==null?this.state.item.isDisable?translate("Enable"):translate("Disable"):""}
					/>
					<ModalButton
						btnStyle={{ marginTop: 8, borderColor: "transparent" }}
						textStyle={styles.bottomText}
						onPress={() => {
							this.setState({
								isVisible: false,modalTextPressed:"delete"})
						}}
						label={translate("DeleteAddress")}
					/>
				</View>
			</Modal>
		);
	}
}
const styles = StyleSheet.create({
	modal: {
		alignItems: "center",
		justifyContent: "center"
	},
	modalConatiner: {
		position: "absolute",
		bottom: 8,
		height: 250,
		width: screen.width - 32,
		borderRadius: 20,
		backgroundColor: Colors.white,
	}, topContainer: {
		flexDirection: "row",
		alignItems: "center",
		height: 44,
		marginTop: 8,
	},
	txtTitle: {
		fontFamily: Styles.FontFamily().UrbaneRoundedLite,
		fontSize: 14,
		alignSelf: "center",
		textAlign: "center",
		flex: 1,
		color: 'rgba(4, 4, 15 ,0.6)',
	},
	bottomText: {
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize: 17,
		marginBottom: 8,
		marginTop: 8,
		justifyContent: 'center',
		textAlign: "center",
		color: Colors.pinkishRed,
	},
	closeConatiner: {
		position: "absolute",
		right: 16
	},

});
