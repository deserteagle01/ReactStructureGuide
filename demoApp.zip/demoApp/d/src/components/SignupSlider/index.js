import React, { Component } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

import { Styles, Colors } from "@common";

export default class SignupSlider extends Component {
  render() {
    const {
      label,
      btnStyle,
      textStyle,
      iconComponent,
      iconStyle,
      onPress
    } = this.props;
    return (
        <TouchableOpacity style={[styles.outlineBtn, btnStyle]} onPress={onPress}>
        {label &&
          <Text style={[styles.outlineBtnText, textStyle]}>
            {label}
          </Text>}
        {iconComponent &&
          <View style={[iconStyle]}>
            {iconComponent}
          </View>}
      </TouchableOpacity>
    );
  }
}

const styles = StyleSheet.create({
  outlineBtn: {
    height: 56,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: Colors.white,
    marginTop: 16,
    marginHorizontal: 16
  },
  outlineBtnText: {
    color: Colors.white,
    fontSize: Styles.FontSize.fnt17,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold
  }
});
