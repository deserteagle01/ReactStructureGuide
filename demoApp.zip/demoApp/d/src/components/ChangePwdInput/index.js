import React, { Component } from "react";
import { View, Text, StyleSheet, TextInput, I18nManager,Platform } from "react-native";
import { connect } from "react-redux";
import { Styles, Validations, Colors, Images, Constants } from "@common";
import InputTextStringProfile from "../InputTextStringProfile"
import InputWithIconProfile from "../InputWithIconProfile"
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Spinner, Toast ,SimpleMessageModal,InputAccessory} from "@components";
import HTTP from "../../webservice/http";
class ChangePwdInput extends Component {
  constructor(props) {
      super(props);
      this.state = {
  			currentPwd: '',
  			currentPwdError: null,
  			newPwd: '',
        newPwdError: null,
        newPwdErrorColor:Colors.whiteTwo,
  			confirmPwd: '',
  			confirmPwdError: null,
        confirmPwdErrorColor:Colors.whiteTwo
      };
      this.inputRefs = {};
  }

  componentDidMount() {
    this.inputRefs["password"].focus();
  }

	currentPwdHandler = (text) => {
		this.setState({ currentPwd: text })
	}

	newPwdHandler = (text) => {
		this.setState({ newPwd: text })
    if(this.state.confirmPwd !== text){
      // this.props.onCanShowSave(false);
      this.setState({newPwdErrorColor:Colors.pinkishRed});
    }else {
      // this.props.onCanShowSave(true);
      this.setState({newPwdErrorColor:Colors.whiteTwo});
    }
	}

	confirmPwdHandler = (text) => {
		this.setState({ confirmPwd: text })
    if(this.state.newPwd !== text){
      // this.props.onCanShowSave(false);
      this.setState({confirmPwdErrorColor:Colors.pinkishRed});
    }else {
      // this.props.onCanShowSave(true);
      this.setState({confirmPwdErrorColor:Colors.whiteTwo});
    }
	}
  onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
  };
  validateData = () => {
    let option = { fullMessages: false };
    let currentPwdError = Validations('reqField', this.state.currentPwd, option);
    let newPwdError = Validations('password', this.state.newPwd, option);
    let confirmPwdError = Validations('reqField', this.state.confirmPwd, option);

    this.setState({ currentPwdError: currentPwdError, newPwdError: newPwdError, confirmPwdError: confirmPwdError})

    if (!currentPwdError && !newPwdError && !confirmPwdError) {
      if(this.state.newPwd == this.state.confirmPwd){
        if (this.props.Connected) {
          this.props.actions.UpdateUserAction.ChangePwdAction(this.state.currentPwd, this.state.newPwd).then(() => {
                setTimeout(()=>{
                  console.log("------>>>> " + this.props.pwdDetail.sucessChangePwd);
                  if(this.props.pwdDetail.sucessChangePwd){
                    HTTP.setNumberandPassword(this.props.pwdDetail.mobile, this.state.newPwd);
                    this.props.actions.UpdateUserAction.updateUserDetails({ password: this.state.newPwd });
                    this.refs.simpleMessageModal.toggleModal(true,translate("ChangePwdSucessMessage"),translate("Success"));
                    this.setState({
                      currentPwd:'',
                      newPwd:'',
                      confirmPwd:''
                    })
                  }else{
                    this.refs.simpleMessageModal.toggleModal(true,this.props.error,translate("Error"));
                  }

                },500);
            })
            .catch(e => {
                console.log('update user error--> ' + e);
            });
        } else {
          console.log('toast here');
        }
      }else{
        this.refs.simpleMessageModal.toggleModal(true,translate("PwdDoesnotMatchError"),translate("Error"));
      }
    }
    return false;
  }
  onUpArrowClicked(refs){
	  if(refs=="newPassword"){
			this.inputRefs["password"].focus();
		}else if(refs=="pwd"){
      this.inputRefs["newPassword"].focus();
    }
	}
	onDownArrowClicked(refs){
    // console.log("refs",refs,this.inputRefs);
		if(refs == "password"){
			this.inputRefs["newPassword"].focus();
		}else if(refs=="newPassword"){
      this.inputRefs["pwd"].focus();
		}else if(refs=="pwd"){
      // this.props.onPress();
    }
	}
  render() {
    return (
    
      <View>
       <View style={{
        marginHorizontal:16,marginVertical:6
        }}>
          <View style={styles.mainContainer}>
          
            <Text style={styles.textTitle}>{translate("CurrentPassword")}</Text>
            <View style={styles.inputNameContainer}>
                <InputWithIconProfile 
                inputAccessoryViewID={"password"}
                refName={"password"}
                returnKeyEvent={(refIndex) =>this.onDownArrowClicked(refIndex)}
                onRef={(el) => {this.inputRefs["password"] = el} }

                textHandler={this.currentPwdHandler} errorMsg={this.state.currentPwdError} inputText={this.state.currentPwd} placeholderText="" inputType="1" />
            </View>
          </View>
          <View style={styles.mainContainer}>
            <Text style={styles.textTitle}>{translate("NewPassword")}</Text>
            <View style={styles.inputNameContainer}>
                <InputWithIconProfile 
                inputAccessoryViewID={"newPassword"}
                refName={"newPassword"}
                returnKeyEvent={(refIndex) =>this.onDownArrowClicked(refIndex)}
                onRef={(el) => {this.inputRefs["newPassword"] = el} }
                textHandler={this.newPwdHandler} errorMsg={this.state.newPwdError} inputText={this.state.newPwd} placeholderText="" inputType="1" />
            </View>
          </View>
          <View style={[styles.mainContainer,{borderBottomColor:this.state.confirmPwdErrorColor}]}>
            <Text style={styles.textTitle}>{translate("ConfirmPassword")}</Text>
            <View style={styles.inputNameContainer}>
                <InputWithIconProfile 
                 inputAccessoryViewID={"pwd"}
                 refName={"pwd"}
                 returnKeyEvent={(refIndex) =>this.onDownArrowClicked(refIndex)}
                 onRef={(el) => {this.inputRefs["pwd"] = el}}
                textHandler={this.confirmPwdHandler} errorMsg={this.state.confirmPwdError} inputText={this.state.confirmPwd} placeholderText="" inputType="1"/>
            </View>

          </View>
          <View style={[styles.mainContainer,{borderBottomWidth : 0}]}/>
          <SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose}/>
          </View>
          {Platform.OS == 'ios' &&
				<View>
          
          <InputAccessory inputAccessoryViewID={"password"} 
                disableUpArrow={true} hideDoneBar={true}
				        onUpArrowClick={() =>this.onUpArrowClicked('password')}
                onDownArrowClick={() =>this.onDownArrowClicked('password')}
               />
			    <InputAccessory inputAccessoryViewID={"newPassword"} 
                disableUpArrow={false} hideDoneBar={true}
				        onUpArrowClick={() =>this.onUpArrowClicked('newPassword')}
                onDownArrowClick={() =>this.onDownArrowClicked('newPassword')}
               />
                <InputAccessory inputAccessoryViewID={"pwd"} 
                disableDownArrow={true} hideDoneBar={true}
				        onUpArrowClick={() =>this.onUpArrowClicked('pwd')}
                onDownArrowClick={() =>this.onDownArrowClicked('pwd')}
               />
			  </View>
          }
           
      </View>
      );
    }
}

const styles = StyleSheet.create({
  mainContainer:{
    marginLeft:2,
    marginTop:22,
    height:59,
    borderBottomColor:Colors.whiteTwo,
    borderBottomWidth: 2
  },
  mainTitle: {
    fontSize:Styles.FontSize.fnt13,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    color:Colors.reddishGrey,
    textAlign: 'left'
  },
  textTitle: {
    fontSize:Styles.FontSize.fnt12,
    fontFamily: Styles.FontFamily().ProximaNova,
    color:Colors.black08,
    textAlign: 'left'
  },
  inputNameContainer: {
    marginTop:0,
  },
  subText:{
    color: Colors.greyishBrown,
    fontSize: Styles.FontSize.fnt12,
    fontFamily: Styles.FontFamily().ProximaNova,
  },
});

const mapStateToProps = (state) => {
  // console.log("-------> " + JSON.stringify(state));
	return {
		pwdDetail: state.updateUserReducer,
		Connected: state.updateNetInfoReducer.isConnected,
		isLoading: state.updateUserReducer.isLoadingChangePwd,
    error:state.updateUserReducer.errorChangePwd,
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(ChangePwdInput);
