import React, { Component } from "react";
import { View, Text, StyleSheet,Platform, I18nManager,Dimensions, Image, TouchableOpacity, Keyboard, Linking } from "react-native";
import { connect } from "react-redux";
import { Styles, Colors, Images, Validations } from "@common";
import InputWithIcon from "../InputWithIcon"
import { Toast,InputAccessory, SmartPlaceholderTextField, ChoosePlanModal   } from "@components";
import FullButton from "../FullButton"
import { translate } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { firebase } from '@react-native-firebase/analytics';
import HTTP from "../../webservice/http";
const { height, width } = Dimensions.get("window");
import OtpInputs from "react-native-otp-inputs";
import DeviceInfo from 'react-native-device-info';
import Modal from "react-native-modal";

const IOSVersion = parseInt(Platform.Version, 10);

class OTPContainer extends Component {
	otpRef = React.createRef();
	constructor(props) {
		super(props);
		this.state = {
			mobile: this.props.mobile ? this.props.mobile : "",
			isOTPEnable: true,
			isMenuOptions: false,
			password: "",
			confirmPassword: "",
			txtOtp: "",
			choosePasswordError: null,
			confirmPassError: null,
			seconds: 30
		};
		this.inputRefs = {};
		this.interval = null;
	}

	componentDidMount() {
		if(this.props.isFrom == "login"){
			this.init();
		}
	}

	init() {
		firebase.analytics().setCurrentScreen("Send OTP Screen");
		this.sendOTP(this.state.mobile, "generate");
	}

	startTimer() {
		this.interval = setInterval( () => 
			this.setState(()=> ({ seconds: this.state.seconds - 1 }))
			,1000
		  );
	}
	
	componentDidUpdate(){
		if(this.state.seconds == 1){
			clearInterval(this.interval);
		}
	}

	sendOTP(mobile, action) {
        if (this.props.Connected) {
            this.props.actions.UpdateUserAction.sendOTPAction(action, mobile).then(() => {
                if (this.props.userDetail.error) {
                    this.toast.show(this.props.userDetail.error);
                }
                else {
					//Success of send OTP
					this.otpRef.current.focus();
					if(this.interval){
						clearInterval(this.interval);
					}
					this.setState({seconds: 30});
					this.startTimer();
				}
            })
        } else {
            this.toast.show(translate("InternetToast"));
        }
	}

	verifyOTP(otp) {
		if (this.props.Connected) {
			this.props.actions.UpdateUserAction.verifyOTPAction(otp, this.state.mobile).then(() => {
                if (this.props.userDetail.error) {
                    this.toast.show(this.props.userDetail.error);
                }
                else {
					//Success of verify OTP
					this.setState({isOTPEnable: false});
				}
            })
        } else {
            this.toast.show(translate("InternetToast"));
        }
	}

	continueButtonPress() {
		let option = { fullMessages: false };
		let PasswordError = Validations('password', this.state.password, option);
		let otpErr = Validations('reqField', this.state.otp, option);
	}
	
	resendPress(action) {
		this.setState({isMenuOptions: false});
		this.sendOTP(this.state.mobile, action);
	}

	handleOtpchange(code) {
		if(code.length == 4) {
			this.setState({txtOtp: code});
			this.verifyOTP(code);
		}
	}

	choosePasswordHandler(password) {
		this.setState({password: password});
	}

	confirmPasswordHandler(confirmpass) {
		this.setState({confirmPassword: confirmpass});
	}

	validate(isFrom) {
        return new Promise((resolve, reject) => {
		let option = { fullMessages: false };
		
		let passErr = Validations('password', this.state.password, option);
		let confirmPassErr = Validations('password', this.state.confirmPassword, option);
		this.setState({ choosePasswordError: passErr, confirmPassError: confirmPassErr });
		if (!passErr && !confirmPassErr) {

			if(this.state.password == this.state.confirmPassword) {
				if (this.props.Connected) {
					this.props.actions.UpdateUserAction.ChoosePasswordAction(this.state.txtOtp, this.state.password, this.state.mobile).then(() => {
						if (this.props.userDetail.error) {
							this.toast.show(this.props.userDetail.error);
							resolve({result: 0});
						}
						else {
							HTTP.setNumberandPassword(this.props.userDetail.mobile, this.state.password);
							var reqParam = {
								password: this.state.password, 
								isLogin: true
							}
							this.props.actions.UpdateUserAction.updateUserDetails(reqParam);
							if(this.props.planData.is_book_appointment) {
								resolve ({result : 0})
								this.props.navigation.navigate('Appointment1', {isDirectlyOpenPayment:  true});
							}
							else{
								if(isFrom == "forget") {
									if(this.props.userDetail.plan_data.warning_list.length > 0){
										resolveReferralUserCase = () => {
											resolve ({result : -1, nextSlide: "confirmdetail"})
										} 
										this.refs.refChoosePlanModal.show("referralUserExists");
									}
									else{
										resolve({result: -1, nextSlide: "confirmdetail"})
									}
								}									
								else if(isFrom == "setpass") {
									resolve({result: 1});
								}
								else {
									this.props.navigation.navigate('App');
									resolve({result: 0});
								}	
							}
						}
					})
				} else {
					this.toast.show(translate("InternetToast"));
					resolve({result: 0});
				}
			}else{
				this.toast.show(translate("passdoesnotmatch"));
				resolve({result: 0});
			}
		}
    });
	}

	onCancel() {
		this.props.navigation.goBack();
	}

	_onPressHelp()  {
		let number = this.props.fetchData.phone;
		Linking.openURL('tel://' + number).catch(err => {
		  console.log(err);
	   });
	};

	renderMenuOptions() {
		let btTitle = styles.txtResend(this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang)
		let btDetail = styles.txtResendMsg(this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang)
        return (
            <Modal
                hasBackdrop
                isVisible={this.state.isMenuOptions}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={0}
                useNativeDriver={true}
                style={styles.menumodalStyle}
                onBackdropPress={() =>
                    this.setState({ isMenuOptions: false })
                }
                onModalHide={() => console.log('')}>
                <View style={styles.menuContainer}>

					<TouchableOpacity style={styles.menuInnerView} onPress={() => this.resendPress("generate")}>
						<View style={styles.resendBt}>
							<Text style={btTitle}>{translate("resendTitle")}</Text>
						</View>
						<Text style={btDetail}>{translate("txtresendDetail")}</Text>
					</TouchableOpacity>

					<View style={styles.seprator}></View>

					<TouchableOpacity style={styles.menuInnerView} onPress={() => this.resendPress("send")}>
						<View style={styles.resendBt}>
							<Text style={btTitle}>{translate("textmeTitle")}</Text>
						</View>
						<Text style={btDetail}>{translate("textmeDetail")}</Text>
					</TouchableOpacity>

					<View style={styles.seprator}></View>

					<TouchableOpacity style={[styles.menuInnerView, {flex: 0.4}]} onPress={() => this._onPressHelp()}>
						<View style={styles.resendBt}>
							<Text style={btTitle}>{translate("moreOptionTitle")}</Text>
						</View>
						<Text style={btDetail}>{translate("moreOptionDetail")}</Text>
					</TouchableOpacity>
                    
                </View>
            </Modal>
        )
	}
	
	renderPasswordView() {
		return(
			<View style={{width:'100%'}}>
				{this.props.isFrom != 'login' &&
					<Text style={styles.title(this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang, this.props.isFrom)}>{translate("chooseyourpassword")} </Text>
				}
				<View style={[styles.inputNameContainer, {marginTop: height*0.05}]}>

					{this.props.isFrom == 'login' ?
						<View style={{width: '100%',marginTop: height*0.22}}>
							<SmartPlaceholderTextField
								ref={"choosePassword"}
								inputAccessoryViewID={"choosePassword"}
								returnKeyType='done'
								onSubmitEditing={() => {}}
								smartPlaceholder={translate("ChoosePassword")}
								smartPlaceholderTextColor = {Colors.whiteTransparent}
								value={this.state.password}
								keyboardAppearance = "dark"
								errorMsg={this.state.choosePasswordError ? translate(this.state.choosePasswordError): ""}
								underlineColorAndroid='transparent'
								style={styles.txtPass}
								autoCapitalize="none"
								selectionColor={Colors.white}
								onChangeText = {(text) => this.choosePasswordHandler(text)} /> 
						</View>
				  		:
						  <InputWithIcon 
							inputAccessoryViewID={"choosePassword"}
							refName={"choosePassword"}
							onRef={(el) => {this.inputRefs["choosePassword"] = el}}
							textHandler={(text) => this.choosePasswordHandler(text)} 
							returnKeyEvent={(inputAccessoryViewID) => console.log(inputAccessoryViewID)}
							errorMsg={this.state.choosePasswordError} 
							inputText={this.state.password} 
							styless={this.props.isFrom == "login" ? styles.txtStyle(this.props.switchLanguageReducer.lang) : styles.txtStyle(this.props.userDetail.com_lang)}
							lang={this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang}
							placeholderText={translate("ChoosePassword")} 
							inputType="1" /> 
					}


					{this.props.isFrom == 'login' ?
						<View style={{width: '100%'}}>
							<SmartPlaceholderTextField
								ref={"choosePassword"}
								inputAccessoryViewID={"choosePassword"}
								returnKeyType='done'
								onSubmitEditing={() => {}}
								smartPlaceholder={translate("ConfirmPassword")}
								smartPlaceholderTextColor = {Colors.whiteTransparent}
								value={this.state.confirmPassword}
								keyboardAppearance = "dark"
								errorMsg={this.state.confirmPassError ? translate(this.state.confirmPassError) : ""}
								underlineColorAndroid='transparent'
								style={styles.txtPass}
								autoCapitalize="none"
								selectionColor={Colors.white}
								onChangeText = {(text) => this.confirmPasswordHandler(text)} /> 
						</View>
				  		:
				  		<InputWithIcon 
							inputAccessoryViewID={"confirmPassword"}
							refName={"confirmPassword"}
							returnKeyEvent={(inputAccessoryViewID) => console.log(inputAccessoryViewID)}
							onRef={(el) => {this.inputRefs["confirmPassword"] = el}}
							textHandler={(text) => this.confirmPasswordHandler(text)} 
							errorMsg={this.state.confirmPassError} 
							inputText={this.state.confirmPassword} 
							styless={this.props.isFrom == "login" ? styles.txtStyle(this.props.switchLanguageReducer.lang) : styles.txtStyle(this.props.userDetail.com_lang)}
							lang={this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang}
							placeholderText={translate("ConfirmPassword")} 
							inputType="1" /> 
					}
							
				</View>

						
				<View style={this.props.isFrom == "login" ? styles.buttonContainer : styles.inputNameContainer}>
					<FullButton 
						onPress={() => this.props.setPassword(this.props.isFrom)} 
						btnStyle={styles.btnContinue} 
						textStyle={styles.textStyle} 
						label={translate("Continue")} />
				</View>

				{/* {Platform.OS == 'ios' &&
					<View>
						<InputAccessory inputAccessoryViewID={"choosePassword"} disableUpArrow={true} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} />
						<InputAccessory inputAccessoryViewID={"confirmPassword"} disableUpArrow={true} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} />
					</View>
				} */}

		</View>
		);
	}

	render() {
		return (
			<View style={styles.detailContainer}>
				{this.props.isFrom == "login" &&
					<TouchableOpacity style={styles.cancelBt} onPress={() => this.onCancel()} >
                		<Image source={Images.icons.cancel_red} style={styles.cancelLogo} />
              		</TouchableOpacity>
				}

				{this.props.isFrom == "login" &&
					<Image source={Images.DietLogo} resizeMode='contain' style={[styles.dislikeMainIcon,{}]}/>
				}
				
				{this.state.isOTPEnable ?
					<View style={{width:'100%'}}>
							<Text style={styles.otpTitle(this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang,this.props.isFrom)}>{translate("OTPTitle")}</Text>
							<View style={styles.otpContainer}>
								<OtpInputs
									ref={this.otpRef}
									handleChange={code => this.handleOtpchange(code)}
									isRTL={I18nManager.isRTL}
									style={styles.otpOutView}
									inputContainerStyles={styles.otpInnerView}
									inputStyles={styles.inputStyle}
									numberOfInputs={4} 
									autofillFromClipboard={(Platform.OS === 'ios' && (IOSVersion >= 14)) ? false : true}
									keyboardAppearance = {this.props.isFrom == 'login' ? "dark":"light"}/>
							</View>
							<Text style={styles.otpMessage(this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang)}>{translate("OTPMessage")}</Text>
							{this.state.seconds <= 1 ?
								<TouchableOpacity style={styles.didntgetstyle} onPress={() => this.setState({isMenuOptions: true})}>
									<Text style={styles.otpButton(this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang)}>{translate("OTPButtonTitle")}</Text>
								</TouchableOpacity>
							:
								<View style={styles.didntgetstyle}>
									<Text style={styles.otpButton(this.props.isFrom == "login" ? this.props.switchLanguageReducer.lang : this.props.userDetail.com_lang)}>{translate("txtResendTimer")} {this.state.seconds} {translate("seconds")}</Text>
								</View>
							}
							
							
						</View>
					:

					this.renderPasswordView()
				}
				
				{this.renderMenuOptions()}
				{this.renderChoosePlanModal()}
				<Toast refrence={(refrence) => this.toast = refrence} />
			</View>
		);
	}

	renderChoosePlanModal() {
        return (
            <ChoosePlanModal {...this.props}
                ref="refChoosePlanModal" navigation ={this.props.navigation}
                onContinue = {() => resolveReferralUserCase()}
                onModalClose = {() => console.log("close call")} />
        )
    }
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
		alignItems: 'center',
		width: '100%',
	},
	dislikeMainIcon: {
		width: width*0.27,
		height: height*0.17,
		position: 'absolute',
		marginTop: DeviceInfo.hasNotch() ? height*0.12 : height*0.15
	},
	buttonContainer:{
		marginVertical: 15,
		marginHorizontal: width*0.05
	},
	inputNameContainer:{
		alignItems: 'center',
		justifyContent: 'center',
		marginVertical: 15,
	},
	txtPass: {
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize: 17,
		color: Colors.white,
	},   
	title: (lang, isFRom) => ({
        marginTop: isFRom == "login" ? height*0.33 : height*0.14,
        fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
        fontSize: 22,
				textAlign: lang == 'ar'?'right':'left',
		color: Colors.white,
		marginHorizontal: isFRom == "login" ? width*0.05 : 0
	}),
	cancelBt:{
		position:'absolute',
		top:60, 
		left:10,
		zIndex:8
	},
	btnContinue: {
		backgroundColor: Colors.white,
		height: 56,
		width: '100%',
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
		borderWidth: 1,
		borderColor: Colors.white,
	},
	txtStyle: (lang) => ({
		textAlign: lang == "ar" ? "right" : "left"
	}),
	textStyle: {
		color: Colors.pinkishRed,
		fontSize: Styles.FontSize.fnt17,
		fontFamily:  Styles.FontFamily().ProximaNovaBold,
	},
	seprator: {
		height:1,
		width:'80%',
		backgroundColor: Colors.sepratorColor,
		alignSelf: 'center'
	},
	otpTitle: (lang, isFrom) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
		fontSize: 18,
		color: Colors.white,
		textAlign: 'center',
		marginTop: isFrom == "login" ? height*0.35 : height* 0.14,
	}),
	otpMessage: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		fontSize: 18,
		color: Colors.white,
		textAlign: 'center',
		marginTop: DeviceInfo.hasNotch() ? height*0.02 : height*0.04
	}),
	otpButton: (lang) => ({
		fontFamily: Styles.FontFamily(lang).ProximaNova,
		fontSize: 18,
		color: Colors.white,
		textAlign: 'center',
	}),
	otpOutView:{ 
		width:width*0.75, 
		height: 60, 
		flexDirection:'row', 
		justifyContent:'center' 
	},
	otpInnerView:{
		backgroundColor: Colors.white,
		alignItems:"center",
		justifyContent:'center',
		marginHorizontal:width*0.03 ,
		height: '100%' ,
		width:'18%',
		borderColor: Colors.otpGray, 
		borderWidth:1, 
		borderRadius:5,
		alignItems:'center',
		justifyContent:'center'
	},
	inputStyle:{
		textAlign:'center',
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		fontSize: 25,
		width:'100%',
		height:'100%',
	//	caretColor: '#BA85FC'
	},
	didntgetstyle:{
		marginTop:height*0.05
	},
	otpContainer: {
		alignItems:'center',
		width:'100%',
		marginTop: height*0.03,
		height: height*0.10,
	},
	menumodalStyle: {
		flex: 1,
		alignItems:'center',
		justifyContent:'center',
		margin: 0
	},
	menuContainer: {
		height: height*0.37,
		width: '85%',
		borderRadius:10,
		backgroundColor: Colors.white
	},
	menuInnerView: {
		flex: 0.3,
		justifyContent: 'center'
	},
	resendBt: {
		marginLeft: '15%'
	},
	txtResend: (lang) => ({
		textAlign: lang == "ar" ? "right" : "left",
		fontFamily: Styles.FontFamily(lang).ProximaNovaSemiBold,
		fontSize: 16,
	}),
	txtResendMsg: (lang) => ({
		marginLeft: '15%',
		marginVertical: 5
	}),
	
});

const mapStateToProps = (state) => ({
	Connected: state.updateNetInfoReducer.isConnected,
	userDetail: state.updateUserReducer,
	switchLanguageReducer: state.switchLanguageReducer,
	fetchData: state.fetchMasterListReducer,
	planData: state.PlanReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(OTPContainer);

