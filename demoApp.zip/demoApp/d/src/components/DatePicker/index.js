import React, { Component } from "react";
import { Button, View,Platform } from "react-native";
import DateTimePicker from "react-native-modal-datetime-picker";

export default class DatePicker extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isDateTimePickerVisible: false,
		};
	}

	 showDateTimePicker = () => {
		 this.setState({ isDateTimePickerVisible: true });
		 
	};

	hideDateTimePicker = () => {
		this.setState({ isDateTimePickerVisible: false });
	};

	handleDatePicked = date => {
		this.hideDateTimePicker();
		this.props.selectedReturn(date);
	};
	render() {
		const {
			minimumDate,
			maximumDate,
			mode,
			selecteddate,
		} = this.props;
		return (
			<View>
				 {minimumDate &&
					<DateTimePicker
						minimumDate={minimumDate}
						date={selecteddate ? new Date(selecteddate) : new Date()}
						mode={mode ? mode : 'date'}
						isVisible={this.state.isDateTimePickerVisible}
						onConfirm={this.handleDatePicked}
						onCancel={this.hideDateTimePicker}
					/>
				}
				{maximumDate &&
					<DateTimePicker
						maximumDate={maximumDate}
						date={selecteddate ? new Date(selecteddate) : new Date()}
						mode={mode ? mode : 'date'}
						isVisible={this.state.isDateTimePickerVisible}
						onConfirm={this.handleDatePicked}
						onCancel={this.hideDateTimePicker}
					/>
				}
				{maximumDate && minimumDate &&
					<DateTimePicker
						minimumDate={minimumDate}
						maximumDate={maximumDate}
						date={selecteddate ? new Date(selecteddate) : new Date()}
						mode={mode ? mode : 'date'}
						isVisible={this.state.isDateTimePickerVisible}
						onConfirm={this.handleDatePicked}
						onCancel={this.hideDateTimePicker}
					/>
				}
			</View>
		);
	}
}