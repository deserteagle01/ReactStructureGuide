import React, { Component } from "react";
import { View, Text, StyleSheet, Image, Dimensions, I18nManager, Keyboard, Platform} from "react-native";
import { connect } from "react-redux";
import { Styles, Colors, Images, Validations } from "@common";
import InputWithIcon from "../InputWithIcon"
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const { height, width } = Dimensions.get("window");
import { checkLanguageFlag } from "../../common/Utility";
import FullButton from "../FullButton"
import { translate, setI18nConfig } from "@languages";
import * as SwitchLanguage from "../../redux/Actions/SwitchLanguageAction";
import { InputAccessory } from "@components";
class Communicationname extends Component {
	constructor(props) {
		super(props);
		this.state = {
			txtFirstname: "",
            txtFirstnameError: null,
            txtLastname: "",
			txtLastnameError: null,
			inverseCom_lang: this.props.signupDetail.com_lang ? this.props.signupDetail.com_lang : ""
		};
		this.inputRefs = {};
	}

	componentDidMount() {
		this.init();
	}

	init() {
		var inLang;
		if(this.props.signupDetail.com_lang == "ar"){
			inLang = "en"
		}else{
			inLang = "ar"
		}

		setI18nConfig(inLang,I18nManager.isRTL);
		this.forceUpdate();

		this.setState({txtFirstname: this.props.signupDetail.secondary_firstname, txtLastname: this.props.signupDetail.secondary_lastname, inverseCom_lang: inLang});
	}

	textFirstnameHandler(text){
		this.setState({ txtFirstname: text })
	}
    
    textLastnameHandler(text){
		this.setState({ txtLastname: text })
	}

	async validate() {
		return new Promise((resolve, reject) => {
			Keyboard.dismiss();
            let com_lang = this.state.inverseCom_lang;
            var diffLang = com_lang == "ar" ?  "arabicError" : "englishError"
			let option = { fullMessages: false };
			if(com_lang == "en"){
				const reqParams = {
					secondary_firstname: this.state.txtFirstname,				
					secondary_lastname: this.state.txtLastname,				
				};
				this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
				resolve({result: 1});
			}else{
				let firstNameError = Validations('reqField', this.state.txtFirstname, option);
				let lastNameError = Validations('reqField', this.state.txtLastname, option);
				this.setState({  txtFirstnameError: firstNameError, txtLastnameError: lastNameError });
				if (!firstNameError && !lastNameError) {
						let isValidfirstname = checkLanguageFlag(this.state.txtFirstname, com_lang);
						let isValidlastname = checkLanguageFlag(this.state.txtLastname, com_lang);
						if(isValidfirstname && isValidlastname) {
							const reqParams = {
								secondary_firstname: this.state.txtFirstname,				
								secondary_lastname: this.state.txtLastname,				
							};
							this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
							resolve({result: 1});
						}
						else{
							if(!isValidfirstname) {
								this.setState({txtFirstnameError: diffLang})
								resolve({result: 0});
							}
							else{
								this.setState({txtLastnameError: diffLang})
								resolve({result: 0});
							}
						}
				}
				else{
					resolve({result: 0});
				}	
			}
		});
	}

	
	render() {
		return (
			<View style={styles.detailContainer}>
				<KeyboardAwareScrollView extraScrollHeight={Platform.OS === 'ios' ? 40 : 90} enableOnAndroid={true} keyboardShouldPersistTaps={'always'}>
					<View style={styles.heightContainer}>
						<InputWithIcon 
							onRef={(el) => {this.inputRefs["firssst"] = el} } 
							refName={"firssst"} 
							inputAccessoryViewID={"firssst"} 
							returnKeyEvent={(inputAccessoryViewID) => console.log(inputAccessoryViewID)}
							lang={this.state.inverseCom_lang}
							textHandler={(text) => this.textFirstnameHandler(text)} 
							errorMsg={this.state.txtFirstnameError} 
							inputText={this.state.txtFirstname} 
							placeholderText={translate("FirstName")} />
					</View>
                    <View style={styles.lastnameContainer}>
						<InputWithIcon 
							onRef={(el) => {this.inputRefs["lassst"] = el} } 
							refName={"lassst"} 
							inputAccessoryViewID={"lassst"} 
							returnKeyEvent={(inputAccessoryViewID) => console.log(inputAccessoryViewID)}
							lang={this.state.inverseCom_lang}
							textHandler={(text) => this.textLastnameHandler(text)} 
							errorMsg={this.state.txtLastnameError} 
							inputText={this.state.txtLastname} 
							placeholderText={translate("LastName")} />
					</View>
                    <View style={styles.continueBtnContainer}>
						<FullButton 
							onPress={() => this.props.continueClick()}
							btnStyle={styles.btnContinue} 
							textStyle={styles.textStyle(this.state.inverseCom_lang)} 
							label={translate("Continue")} />
					</View>

					{Platform.OS == 'ios' &&
                        <InputAccessory inputAccessoryViewID={"lassst"} disableUpArrow={true} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} />
					}
					{Platform.OS == 'ios' &&
                        <InputAccessory inputAccessoryViewID={"firssst"} disableUpArrow={true} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} />
					}


				</KeyboardAwareScrollView>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1
	},
	heightContainer: {
		marginTop: height*0.20
    },
    lastnameContainer: {
        marginTop: 15
    },
    continueBtnContainer: {
		marginTop: height*0.08
	},
	btnContinue: {
		backgroundColor: Colors.white,
		height: 56,
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
		borderWidth: 1,
		borderColor: Colors.white,
	},
	textStyle: (lang) => ({
		color: Colors.pinkishRed,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold
	}),
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
			SwitchLanguage: bindActionCreators(SwitchLanguage, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(Communicationname);