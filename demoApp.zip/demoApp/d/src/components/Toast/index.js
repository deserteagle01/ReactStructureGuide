import Toast, { DURATION } from 'react-native-easy-toast'
/** @format */

import React from "react";
import { Dimensions, StyleSheet, Text } from "react-native";
import { Colors, Styles } from "@common";

class Toaster extends React.Component {
  constructor(props) {
    super(props);
    this.state = {opacity: 0.8, position: 'top', positionValue: 50 }
  }

  componentDidMount() {
    this.props.refrence(this.toast);
  }
  componentWillUnmount() {
    this.props.refrence(null);
  }

  render() {
    const { refrence, message, position, positionValue, opacity, Styles, textStyle } = this.props;
    return (
      <Toast ref={(el) => this.toast = el}
        style={[styles.containerStyle, Styles]}
        position={position ? position : this.state.position}
        positionValue={positionValue ? positionValue : this.state.positionValue}
        opacity={opacity ? opacity : this.state.opacity}
        textStyle={[styles.fontStyle, textStyle]} />
    );
  }
}

const styles = StyleSheet.create({
  containerStyle: {
    backgroundColor: Colors.toastBackground, 
    padding:15
  },
  fontStyle:{ 
    color: Colors.white,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    fontSize: 15, 
  },
  
});

export default Toaster;
