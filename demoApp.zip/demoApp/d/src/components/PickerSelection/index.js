import React, { Component } from "react";
import { Image, Text, I18nManager, TouchableWithoutFeedback, Platform } from "react-native";
import { Styles, Colors, Images } from "@common";
import { View } from "react-native-animatable";
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { translate, setI18nConfig } from "@languages";

const pickerStyle1 = {
    inputIOS: {
        color: Colors.white,
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        width: 125,
        fontSize: 15,
        paddingLeft: 16,
        paddingRight: 25,
        paddingVertical: 7,
        borderRadius: 20,
        height: 36,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        backgroundColor: Colors.pinkishRed
    },
    inputAndroid: {

        color: Colors.white,
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        width: 125,
        fontSize: 15,
        paddingLeft: 16,
        paddingRight: 25,
        paddingVertical: 7,
        borderRadius: 20,
        height: 36,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        backgroundColor: Colors.pinkishRed
    },
    underline: { borderTopWidth: 0 },
    icon: {
        width: '100%',
        height: '100%',
    },
    iconContainer: {
        height: '100%',
        width: 24,
        flex: 1,
        paddingRight: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
};

export default class PickerSelection extends Component {
    constructor(props) {
        super(props);
        this.state = {txtValue: this.props.inputText};
    }

    componentDidMount() {
        if (this.props.onRef) {
            this.props.onRef(this.refs[this.props.refName]);
        }
    }

    componentWillUnmount() {
        if (this.props.onRef) {
            this.props.onRef(null);
        }
    }

    handlerFocus = (input) => {
        this.setState({
            [input]: true
        });
    };

    handlerBlur = (input) => {
        this.setState({
            [input]: false
        });
    };

    updateRef(name, refs) {
        this[name] = refs;
    }

    InputAccessoryView = () => {
        return (
			<View style={[defaultStyles.modalViewMiddle]} testID="input_accessory_view">
				<View style={[defaultStyles.chevronContainer]}></View>
				<TouchableWithoutFeedback
					onPress={() => {
                        this.props.pickerSelectDone(this.props.refName, this.state.txtValue, true)
                        this.refName.togglePicker(false);
                    }}
					hitSlop={{ top: 4, right: 4, bottom: 4, left: 4 }}
					testID="done_button"
				>
					<View testID="needed_for_touchable">
						<Text style={[defaultStyles.done]}>{"Done"}</Text>
					</View>
				</TouchableWithoutFeedback>
			</View>);
    }
    
    valueChange(text) {
        if(text){
            this.setState({txtValue: text })
            this.props.pickerSelectDone(this.props.refName, text, Platform.OS == 'android');
        }
    }

    render() {
        const { itemsArray, inputText, refs, pickerSelectDone, placeholderTxt } = this.props;
        return (
            <View style={styles.textViewMargin}>
                <RNPickerSelect
                    ref={el => {this.refName = el }}
                    placeholder={placeholderTxt ? {label: placeholderTxt, value: null} :  {label: translate("pickerPlaceholder"), value: null }}
                    onValueChange={(text) => this.valueChange(text)}
                    value={this.state.txtValue}
                    useNativeAndroidPickerStyle={false}
                    items={itemsArray}
                    style={pickerStyle1}
                    Icon={() => { return <Image source={Images.icons.drpDownIC} /> }}
                    InputAccessoryView={() => this.InputAccessoryView()} />
             </View>
        )
    }
}



