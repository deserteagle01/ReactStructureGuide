import React, { Component } from "react";
import { View, Text, Dimensions, TouchableOpacity, Image, StyleSheet } from "react-native";
import Modal from "react-native-modal";
import {  ModalButton } from "@components";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
const screen = Dimensions.get("window");

export default class ImagePickerModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isVisible: false
		};
		this.toggleModal = this.toggleModal.bind(this);
	}

	toggleModal = visible => {
		this.setState({ isVisible: visible });
	};

	render() {
		return (
			<Modal
				hasBackdrop
				isVisible={this.state.isVisible}
				hideModalContentWhileAnimating={true}
				useNativeDriver={true}
				style={styles.modal}
				onBackdropPress={() => {
					this.toggleModal(false);
				}}
			>
				<View
					style={styles.modalConatiner}>
					<View
						style={styles.topContainer}>
						<Text
							style={styles.txtTitle}>
							{translate("UploadPhoto")}
            			</Text>
						<TouchableOpacity
							style={styles.closeConatiner}
							onPress={() => {
								this.toggleModal(false);
							}}
						>
							<Image source={Images.icons.closeBox} />
						</TouchableOpacity>
					</View>
					<ModalButton
					btnStyle={{marginTop:4}}
						onPress={() => {
							this.props.editProfile("camera");
						}}
						label={translate("TakePhoto")}
					/>
					<ModalButton
					btnStyle={{marginTop:8}}
						onPress={() => {
							this.props.editProfile("gallery");
						}}
						label={translate("UploadGallery")}
					/>
				</View>
			</Modal>
		);
	}
}
const styles = StyleSheet.create({
	modal: {
		alignItems: "center",
		justifyContent: "center"
	},
	modalConatiner: {
		position: "absolute",
		bottom: 8,
		height: 200,
		width: screen.width - 32,
		borderRadius: 20,
		backgroundColor: Colors.white,
	}, topContainer: {
		flexDirection: "row",
		alignItems: "center",
		height: 44,
		marginTop: 8,
	},
	txtTitle: {
		fontFamily: Styles.FontFamily().UrbaneRoundedLite,
		fontSize: 14,
		alignSelf: "center",
		textAlign: "center",
		flex: 1,
		color:'rgba(4, 4, 15 ,0.6)',
	},
	closeConatiner: { 
		position: "absolute", 
		right: 16 },

});
