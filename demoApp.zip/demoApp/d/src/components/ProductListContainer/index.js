import React, { Component, PureComponent } from "react";
import { View, Text, FlatList } from "react-native";
import {ProductListItem, ProductHeaderItem } from "@components";
import { Colors } from "@common";
import { translate } from "@languages";
import { connect } from "react-redux";

export default class ProductListContainer extends Component {
	constructor(props) {
		super(props);
		this.state = {
			product_list: {}
		};
		this.date = null;
		this.currSelectedStatus = '';
		this.selected_filters = {};
		this.product_meal_data = {};
		this.itemsList = [];
	}

	componentDidMount(){
		this.setData(this.props);
	}
	
	setData = (newProps) => {
		this.date = newProps.currDate;
		this.currSelectedStatus = newProps.currSelectedStatus;
		this.product_meal_data = newProps.product_meal_data;
		this.selected_filters = newProps.product_filters;
		this.itemsList = newProps.itemsList;
		this._calProductList();
	}

	componentWillReceiveProps(nextProps) {
		if((this.date != nextProps.currDate) || (this.selected_filters != nextProps.product_filters) || (this.product_meal_data != nextProps.product_meal_data)){
			this.setData(nextProps);
		}
	}

	_getSelectedItems = () => {
		let selected_items_dict = {};
		for(let selected_product of this.product_meal_data.selected_items){
			selected_items_dict[selected_product.recipe_template_id] = {
				recipe_template_id: selected_product.recipe_template_id,
				quantity: selected_product.quantity,
				is_rated: selected_product.is_rated,
			}
		}
		return selected_items_dict;
	}

	_calProductList = () => {
		let newProductList = {};
		let newItemList = this.itemsList.filter(this._filter);
		let selected_products = this._getSelectedItems();
		for(let product of newItemList){
			
			let obj = {};
			obj.is_rated = selected_products[product.product_id] ? selected_products[product.product_id].is_rated : (product.is_rated || false);
			obj.meal_id = this.product_meal_data.meal_id || '';
			obj.mealType = this.product_meal_data.mealType || '';
			obj.selected = selected_products[product.product_id] ? true : false;
			obj.quantity = selected_products[product.product_id] ? selected_products[product.product_id].quantity : 0;
		
			if((this.currSelectedStatus == 'prepare' || this.currSelectedStatus == 'rate' || this.currSelectedStatus == 'delivered') && selected_products[product.product_id]){
				newProductList[product.product_id] = Object.assign(product, obj);
			}else if(this.currSelectedStatus == 'choose-meal' || this.currSelectedStatus == 'meal-assign' || this.currSelectedStatus == 'pause'){
				newProductList[product.product_id] = Object.assign(product, obj);
			}
		}
	this.setState({
		product_list: {...newProductList}
	});
	}

	_filter = (product) => {
		if(
			this.selected_filters && 
			((this.selected_filters.tags && Object.keys(this.selected_filters.tags).length > 0) ||
			(this.selected_filters.dislike_attr && Object.keys(this.selected_filters.dislike_attr).length > 0))
		){
			if(product.tag_id && product.tag_id in this.selected_filters.tags){
				return true;
			} else {
				let is_found = false;
				for(let product_tag of product.tag2_ids){
					if(product_tag in this.selected_filters.tags){
						is_found = true;
						break;
					}
				}
				if(!is_found){
					for(let dislike_attr of product.dislike_attributes){
						if(dislike_attr.id in this.selected_filters.dislike_attr){
							is_found = true;
							break;
						}
					}
				}
				return is_found;
			}
		} else {
			return true;
		}
	}

	_renderItem = ({ index, item }) => {
		
		return (
			<ProductListItem key={index}
						userSelectedMeals={this.props.userSelectedMeals}
						updateMealSelectionData={this.props.updateMealSelectionData}
						index={index}
						item={this.state.product_list[item]}
						categoryId={this.product_meal_data.id}
						currDate={this.date} currSelectedStatus={this.currSelectedStatus}
						onModelClose={this.props.onModelClose}
						toggleRateModel={this.props.toggleRateModel}
						toggleMessageModal={this.props.toggleMessageModal}
						toggleDiscardChangeModal={this.props.toggleDiscardChangeModal}
						productMainContentFlatlistScroll={this.props.productMainContentFlatlistScroll}
				/>
		)
	}
	
	render() {
		const { product_list } = this.state;
		return (
			<FlatList
				numColumns={2}
				initialNumToRender={3}
				showsVerticalScrollIndicator={false}
				data={Object.keys(product_list)}
				extraData={this.state}
				keyExtractor={this._keyExtractor}
				renderItem={this._renderItem}
				maxToRenderPerBatch={20}
				removeClippedSubviews={true}
			/>
		);
	}
_keyExtractor = (item, index) => index.toString();
}