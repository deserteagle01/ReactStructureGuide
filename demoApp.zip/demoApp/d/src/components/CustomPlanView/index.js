/** @format */

import React, { PureComponent } from "react";
import { connect } from "react-redux";
import { AppConfig } from "@common";
import styles from "./styles";
import {
    View,
    Text,
    StyleSheet,
    ImageBackground,
    StatusBar,
    SafeAreaView,
    Image,
    TouchableOpacity,
    I18nManager,
    Linking,
    FlatList,
    ScrollView,
    TextInput,
    Dimensions,
    Alert,
    PixelRatio
} from "react-native";
import moment from 'moment';
import { Images, Colors, Styles } from "@common";
import { translate, setI18nConfig } from "@languages";
import { GradientButton, TextWithCounter, PromoCode, ProteinSelection, 
        Spinner, Toast, PickerSelection,MessageModal, SimpleMessageModal,CustomPlanPriceFooter, WalletModal } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as GetPlanDetailAction from "../../redux/Actions/Plan";
import * as PaymentAction from "../../redux/Actions/Payment";
import { languageNameGetter} from "../../common/Utility";
import { firebase } from '@react-native-firebase/analytics';
const { height, width } = Dimensions.get("window");
var protVal = 0;
var carbVal = 0;
var selectedRow = 0;
let defaultRule = {
    has_protein_carb: false,
    default_qty: 1,
    min_qty_for_extra_price : 0,
    min_qty: 0,
    extra_price: 0,
    extra_gram_price: 0,
    protein: 0,
    carb: 0
}
class CustomPlanView extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            attribArray: [],
            mealsList: [],
            selectedPlanData: [],
            normal_configuration_lines: [],
            selectedAttribute: this.props.planDetailData.product_id,
            duration: this.props.planDetailData.period_type,
            isPromocodeApplied: false,
            isWalletIncluded: false,
            txtPromocode: '',
            WalletAmount: 0,
            defaultProteinArray: this.props.planDetailData.all_protein_carg,
            planPrice: 0,
            FinalTotal_carbModal: 0,
            selectedProtein: 1,
            selectedCarb: 1,
            extraProtCarbPrice: 0,
            tempExtraProtCarbPrice: 0,
            promotion_amount: 0,
            amount_total_expected: 0,
            amount_total: 0,
            extraQuantityPrice: 0,
            price_subtotal: 0,
            amount_confirmed_plan: 0,
            product_uom_qty: 1,
            rules_configuration: {},
            maximumwalletAllowed: 0,
            isWalletEnablePlan: false,
            display_amount_total: 0,
        };

        this.inputRefs = {};
    }

    componentDidMount() {
        let plan_id = this.props.initialPlanDetailData.id;
        this.props.actions.GetPlanDetailAction.setPlanDetailAction(this.props.initialPlanDetailData).then(()=>{
                this.setState({
                    defaultProteinArray: this.props.planDetailData.all_protein_carg
                });
                //Auto Apply promocode
                if(this.props.planDetailData.offer_code != "") {
                    this.setState({txtPromocode: this.props.planDetailData.offer_code});
                }
                this.setAttributeData(this.props.planDetailData.period_type, this.props.planDetailData.product_id);
                //console.log("Detail", this.props.planDetailData)
                let params = {
                    item_id: plan_id,
                    item_name: this.props.planDetailData.plan_name,
                    start_date: this.props.planDetailData.period_type
                }
                firebase.analytics().logEvent("view_item", params);
            });    

            if(this.props.initialPlanDetailData.hasOwnProperty("warning_list")  && this.props.initialPlanDetailData.warning_list.length > 0) {
                setTimeout(() => {
                    alert(this.props.initialPlanDetailData.warning_list[0]);
                }, 1500);
            }
    }

    async setAttributeData(period_type, defaultAttribute) {
        /**
            * set Attribute data based on duration selection
        */
        let attributeArray = this.props.getCName(this.props.planDetailData,"all_product_ids");
        let filteredAttribs = attributeArray.filter((e) => e.period === period_type);
        filteredAttribs = filteredAttribs.filter((e) => e.title != false);
        let normal_configuration_lines = [];
        let compareArr = [];
        let selectedPlanData = [];
        let ruleConfiguration = [];
        if (filteredAttribs.length > 0) {
            if (defaultAttribute == null) {
                defaultAttribute = filteredAttribs[0].id;
            }
            this.setState({ attribArray: filteredAttribs });
            let currentMeals = filteredAttribs.filter((e) => e.id === defaultAttribute);
            if (currentMeals.length > 0) {
                selectedPlanData = currentMeals[0];
                let tempResult = await this.getnormalConfiguration(selectedPlanData.meal_ids);
                normal_configuration_lines = tempResult[0];
                ruleConfiguration = tempResult[1];

            }
        }
        this._compute_total("duration", period_type, defaultAttribute, normal_configuration_lines, selectedPlanData, ruleConfiguration);
    }

    getnormalConfiguration(temp_all_product_Data) {
        //getting normalConfigurations
        let temp_normal_configuration = [];
        if(this.props.planDetailData.normal_configuration_lines.length > 0) {
            temp_normal_configuration = this.props.planDetailData.normal_configuration_lines;
        }
        else{
            let tempCreateNormal = [];
            temp_all_product_Data.forEach(normalConfItem => {
                let tempItem = {
                    qty:  normalConfItem.default_qty,
                    name: normalConfItem.name,
                    carb: normalConfItem.carb,
                    protein: normalConfItem.protein,
                    meal_id: normalConfItem.product_id
                };
                tempCreateNormal.push(tempItem);
            });
            temp_normal_configuration = tempCreateNormal;
        }
        
        
        var normal_configuration_lines = [];
        var rules_configuration = {};
        protVal = 0;
        carbVal = 0;

        temp_normal_configuration.forEach(normalConfItem => {

            //For head to head rules comparison with normal_configuration
            let all_product_configuration = temp_all_product_Data.filter((e) => e.product_id === normalConfItem.meal_id);
            if(all_product_configuration.length > 0) {
                rules_configuration[all_product_configuration[0].product_id] = all_product_configuration[0];
            }
            else{
                rules_configuration[normalConfItem.meal_id] = defaultRule;
            }

            //For displaying normal configuration
            normal_configuration_lines.push(normalConfItem);   

            //For total protein carb value 
            let protcarbArr = temp_all_product_Data.filter((e) => e.product_id === normalConfItem.meal_id);
            if (protcarbArr[0].has_protein_carb) {
                if (this.props.initialPlanDetailData.isFromSignUpScreen) {
                    protVal = protVal + (normalConfItem.protein / AppConfig.DietStation.perUnitGram);
                    carbVal = carbVal + (normalConfItem.carb / AppConfig.DietStation.perUnitGram);
                }
                else {
                    protVal = protVal + (protcarbArr[0].protein / AppConfig.DietStation.perUnitGram);
                    carbVal = carbVal + (protcarbArr[0].carb / AppConfig.DietStation.perUnitGram);
                }
            }
        });

        this.setState({ selectedProtein: protVal, selectedCarb: carbVal });
        return [normal_configuration_lines, rules_configuration];
    }

    _helpPress() {
        let number = this.props.fetchData.phone;
        Linking.openURL('tel://' + number).catch(err => {

        });
    }

    _onPressProtein(index) {
        selectedRow = index;
        this.refs.refproteinselection.toggleProteinModal(true);
        this.setState({tempExtraProtCarbPrice:this.state.extraProtCarbPrice, FinalTotal_carbModal: this.state.amount_total_expected});

    }

    getExtraCalculation(configuration_lines, ruleConfiguration) {
        var extraQuantityPrice = 0;
        var extraGram = 0;
        var temp_comparison_compact = [];

        configuration_lines.forEach(conf_line => {
            let tempRule = this.gettingRule(ruleConfiguration, conf_line);

            //extra gram
            if (tempRule.hasOwnProperty("has_protein_carb") && tempRule.has_protein_carb) {
                if(conf_line.protein > tempRule.protein || conf_line.carb > tempRule.carb) {
                    extraGram = extraGram + (conf_line.qty * tempRule.extra_gram_price);
                }
            }

            //For generating compactConfiguration
            let filterArr = temp_comparison_compact.filter((e) => e.meal_id === conf_line.meal_id);
            if(filterArr.length > 0) {
                let tempItem = {
                    qty: filterArr[0].qty + conf_line.qty,
                    name: filterArr[0].name,
                    meal_id: filterArr[0].meal_id
                };
                const index = temp_comparison_compact.indexOf(filterArr[0]);               
                temp_comparison_compact.splice(index, 1);
                temp_comparison_compact.push(tempItem);
            }
            else{
                temp_comparison_compact.push(conf_line);
            }
        });

        //extra quantity
        temp_comparison_compact.forEach(conf_line => {
            let tempRule = this.gettingRule(ruleConfiguration, conf_line);
            var maxFreeAllowed = tempRule.default_qty + tempRule.min_qty_for_extra_price;
            if (conf_line.qty > maxFreeAllowed) {
                  extraQuantityPrice = extraQuantityPrice + ((conf_line.qty - maxFreeAllowed) * tempRule.extra_price);
             }
        });

        return [extraQuantityPrice, extraGram];
    }

    gettingRule(ruleConfiguration, conf_line) {
        let tempRule = ruleConfiguration[conf_line.meal_id];
        return tempRule;
    }

    
    _computeWallet(walletUsed, arr_promoCode, currentPlanID, total_amount) {
        var dictState = {
            maximumwalletAllowed: 0,
            isWalletEnablePlan: false,
            WalletAmount: 0,
            isWalletIncluded: false
        };
        
        
        if(this.props.planDetailFrom == "renew") {
            let walletArr = arr_promoCode.filter((e) => e.type === "wallet");
            let tempValidRulescontainer = [];
            
                // find all validation rules 
                walletArr.forEach(obj => {
                    let walletData = obj;
                    var discountedPrice = 0;
                    let matches = this.validateRules(walletData, currentPlanID, total_amount);

                    if (matches.isValid) {
                        discountedPrice = matches.promotion_amount;
                        tempValidRulescontainer.push(discountedPrice);
                    }
                });
                
                let max = null;
                if(tempValidRulescontainer.length > 0){
                    max = Math.max.apply(Math, tempValidRulescontainer);
                }
                
                if(max != null) {
                    let  min = Math.min(max, this.props.signupDetail.total_wallet_amount);
                    if(min > 0){
                        dictState.WalletAmount = Math.min(min, walletUsed);
                        dictState.isWalletEnablePlan = true
                        dictState.maximumwalletAllowed = max;
                        delete dictState.isWalletIncluded
                    }
                }
        }

        return dictState;
    }
    
    
    async _compute_total(updated_field, duration, selectedAttribute, configuration_lines, selectedPlanData, ruleConfiguration) {
        var selectedPlanData = selectedPlanData == undefined ? this.state.selectedPlanData : selectedPlanData;
        let mealsList = selectedPlanData.meal_ids;
        var extraQuantityPrice = 0;
        var extraGram = 0;

        let extraPrice = await this.getExtraCalculation(configuration_lines, ruleConfiguration);
        extraQuantityPrice = extraPrice[0];
        extraGram = extraPrice[1];

        /*grand total
        */
        let product_uom_qty = this.props.planDetailData.product_uom_qty ? this.props.planDetailData.product_uom_qty : 1;
        let plan_price_unit = selectedPlanData.plan_price
        let amount_extra = extraQuantityPrice + extraGram;
        let amount_confirmed_plan = this.props.planDetailData.amount_confirmed_plan ? this.props.planDetailData.amount_confirmed_plan : 0;
        let discount_amount = this.props.planDetailData.discount_amount ? this.props.planDetailData.discount_amount : 0;
        
        let amount_total_expected = product_uom_qty * (plan_price_unit + amount_extra);

        new_price_unit = (amount_total_expected - amount_confirmed_plan) / product_uom_qty
        price_subtotal = (new_price_unit * product_uom_qty) - discount_amount;
        
        let promotion_state = this._ComputePromotion(this.state.txtPromocode, price_subtotal);
        let promotion_amount = promotion_state.promotion_amount;
        let total_amount = price_subtotal - promotion_amount;

        let wallet_state = this._computeWallet(this.state.WalletAmount, this.props.planDetailData.promo_codes, selectedAttribute, price_subtotal);
        let wallet_included_amount = wallet_state.WalletAmount;
        let display_total = total_amount - wallet_included_amount;
        
        if(total_amount < 0){
            total_amount = 0;
        }

        let final_state = {
            ...promotion_state,
            ...wallet_state,
            planPrice: selectedPlanData.plan_price,
            extraQuantityPrice: extraQuantityPrice,
            extraProtCarbPrice: extraGram,
            amount_total_expected: amount_total_expected,
            amount_total: total_amount,
            display_amount_total: display_total,
            price_subtotal: price_subtotal,
            amount_confirmed_plan: amount_confirmed_plan,
            product_uom_qty: product_uom_qty,
            rules_configuration: ruleConfiguration
        };

        if (updated_field == "duration") {
            final_state.duration = duration;
            final_state.selectedAttribute = selectedAttribute;
            final_state.selectedPlanData = selectedPlanData;
            final_state.mealsList = mealsList;
            final_state.normal_configuration_lines = configuration_lines;
        }
        else if (updated_field == 'selectedAttribute') {
            final_state.selectedAttribute = selectedAttribute;
            final_state.selectedPlanData = selectedPlanData;
            final_state.mealsList = mealsList;
        }
        else if (updated_field == 'normal_configuration_lines') {
            final_state.normal_configuration_lines = configuration_lines;
        }
        
        this.setState(final_state);

    }

    _incrementPress(item, index) {
        let newCounter = item.qty + 1;
        let config_array = [...this.state.normal_configuration_lines];
        config_array[index] = { ...config_array[index], qty: newCounter };
        this._compute_total("normal_configuration_lines", this.state.duration, this.state.selectedAttribute, config_array, undefined, this.state.rules_configuration);
    }

    _decrementPress(item, index) {
        let counter = item.qty
        let config_array = [...this.state.normal_configuration_lines];
        config_array[index] = { ...config_array[index], qty: counter - 1 };
        this._compute_total("normal_configuration_lines", this.state.duration, this.state.selectedAttribute, config_array, undefined, this.state.rules_configuration);
    }

    async changeProteinCarbData(protein, carb) {
        this.setState({ selectedProtein: protein / AppConfig.DietStation.perUnitGram, selectedCarb: carb / AppConfig.DietStation.perUnitGram });
        let defaultProtein = this.state.mealsList[selectedRow].protein;
        let defaultCarb = this.state.mealsList[selectedRow].carb;
        let tempExtraProtCarbPrice = 0;
        if (protein > defaultProtein || carb > defaultCarb) {
            tempExtraProtCarbPrice = this.state.mealsList[selectedRow].extra_gram_price * this.state.normal_configuration_lines[selectedRow].qty;
        }
        let FinalTotal_carbModal = this.state.amount_total_expected  - this.state.extraProtCarbPrice  + tempExtraProtCarbPrice ;
        this.setState({tempExtraProtCarbPrice:tempExtraProtCarbPrice, FinalTotal_carbModal: FinalTotal_carbModal});
    }

    _extraSelectionDone() {
        const config_array = [...this.state.normal_configuration_lines];
        config_array[selectedRow] = { ...config_array[selectedRow], protein: (AppConfig.DietStation.perUnitGram * this.state.selectedProtein), carb: (AppConfig.DietStation.perUnitGram * this.state.selectedCarb) };
        this._compute_total("normal_configuration_lines", this.state.duration, this.state.selectedAttribute, config_array, undefined, this.state.rules_configuration);
    }

    _cancelProteinSelection() {
        this.setState({
            selectedProtein: (this.state.normal_configuration_lines[selectedRow].protein / AppConfig.DietStation.perUnitGram),
            selectedCarb: (this.state.normal_configuration_lines[selectedRow].carb / AppConfig.DietStation.perUnitGram),
        });
    }

    _OnPressAttributeSelection(data, index) {
        let selectedAttribute = this.state.attribArray[index].id;
        if (this.state.selectedAttribute != selectedAttribute) {
            let ruleConfiguration = {};
            let currentMeals = this.state.attribArray.filter((e) => e.id === selectedAttribute);
            if (currentMeals.length > 0) {
                selectedPlanData = currentMeals[0];
                let tempMeal_id = selectedPlanData.meal_ids

                this.state.normal_configuration_lines.forEach(normalConfItem => {


                    let tempFilterComparison = tempMeal_id.filter((e) => e.product_id === normalConfItem.meal_id);
                    if(tempFilterComparison.length > 0){
                        ruleConfiguration[tempFilterComparison[0].product_id] = tempFilterComparison[0];
                    }
                    else{
                        ruleConfiguration[normalConfItem.meal_id] = defaultRule;
                    }

                });
            }

            this._compute_total("selectedAttribute", this.state.duration, selectedAttribute, this.state.normal_configuration_lines, selectedPlanData, ruleConfiguration);
        }
    }

    okAlertPressed(planFor) {
        let tempDict = {};
        let temp_state = {};
        if(planFor == "changePlan"){
            tempDict = this.props.planDetailData.changePlanDataDic;
        }else{
            tempDict = this.props.planDetailData.savePlanDataDic;
        }

        temp_state = {
            product_id: tempDict.product_id,
            promotion_amount: tempDict.amount_promotion,
            amount_total: planFor == "changePlan" ?  tempDict.price_subtotal : tempDict.amount_total,
            display_amount_total: tempDict.amount_total,
            amount_total_expected: tempDict.amount_total_expected,
            price_subtotal: tempDict.price_subtotal,
        }

        if(planFor == "renew") {
            temp_state.amount_total = tempDict.amount_total;
            temp_state.display_amount_total = tempDict.amount_total - tempDict.wallet_amount;
            temp_state.wallet_amount = tempDict.wallet_amount;
        }
        this.setState(temp_state);

        if(tempDict.promo_code != false && tempDict.promo_code != "") {
            this.setState({txtPromocode: tempDict.promo_code, isPromocodeApplied: true });
        }else{
            this.setState({txtPromocode: "", isPromocodeApplied: false });
        }
    }

    changePlanSubmitRequest() {
        let editParam = {};
        editParam = {
            id: this.props.planDetailData.id,
            product_tmpl_id: this.props.planDetailData.product_tmpl_id,
            product_id: this.state.selectedAttribute,
            product_uom_qty: this.state.product_uom_qty,
            normal_configuration_lines: this.state.normal_configuration_lines,
            price_subtotal: this.state.amount_total
        }
        
        
        if (this.props.Connected) {
            this.props.actions.GetPlanDetailAction.changePlanSubmit(editParam).then(() => {
                if (this.props.planDetailData.error) {
                        this.toast.show(this.props.planDetailData.error);
                } else {
                    if (this.props.planDetailData.changePlanDataDic.warning_list.length > 0) {
                        let buttons  = [{
                                text:translate("Ok"),
                                role: 'Ok',
                                isGradient:true,
                                handler: () => {
                                    this.okAlertPressed(this.props.planDetailFrom);
                                }
                            }];
                        this.refs.messageModal.toggleModal(true, translate("WARNINGTXT"), this.props.planDetailData.changePlanDataDic.warning_list[0],buttons);
                        } 
                        else {
                            if(this.props.planDetailData.changePlanDataDic.price_subtotal == 0) {
                                Alert.alert(
                                    translate("txtPlanConfirm"),
                                    translate('txtPlanConfDesc'),
                                    [
                                      {text: translate("Continue"), onPress: () => this.callConfirmChangePlanfatoorah()},
                                      {text: translate("cancel"), onPress: () => console.log("cancel Press") },
                                    ],
                                     { cancelable: false }
                                 )
                            }
                            else{
                                this.props.ContinuePress(false, true);
                            }
                        }
                    }
                });
        } else {
            this.toast.show(translate("InternetToast"));
        }
    }

    callConfirmChangePlanfatoorah() {
        if (this.props.Connected) {
               this.props.actions.PaymentAction.InitiatePayment().then(() => {
			        if (this.props.paymentReducer.error) {
				        this.toast.show(this.props.paymentReducer.error);
                    }
                    else {
                        this.props.ContinuePress(false, false);
			        }
                });
        }
        else {
            this.toast.show(translate("InternetToast"));
        }
    }

    _ContinuePress() {
        if(this.props.planDetailFrom  && this.props.planDetailFrom == "changePlan") { 
            this.changePlanSubmitRequest();
        }
        else{
            let editParam = {};
            editParam = {
                normal_configuration_lines: this.state.normal_configuration_lines,
                id: this.props.planDetailData.id,
                product_id: this.state.selectedAttribute,
                product_tmpl_id: this.props.planDetailData.product_tmpl_id,
                promo_code: this.state.txtPromocode,
                product_uom_qty: this.state.product_uom_qty,
                amount_total: this.state.amount_total,
                wallet_amount: this.state.WalletAmount
            }

            if(this.state.isPromocodeApplied){
                editParam.promo_code = this.state.txtPromocode
            }else{
                editParam.promo_code = ""
            }
            
            console.log('continue Press parameter JSON =' + JSON.stringify(editParam));
            let params = {
                transaction_id: editParam.product_id,
                value: editParam.amount_total,
                currency: "KWD",
            }
            firebase.analytics().logEvent("begin_checkout", params);
            if (this.props.Connected) {
                console.log('action -------', this.props.actions);
                this.props.actions.GetPlanDetailAction.updatePlanDetailAction(editParam, this.props.signupDetail.isLogin).then(() => {
                    if (this.props.planDetailData.error) {
                            this.toast.show(this.props.planDetailData.error);
                    } else {
                        if (this.props.planDetailData.savePlanDataDic.warning_list.length > 0) {
                            let buttons  =
                            [
                                {
                                    text:translate("Ok"),
                                    role: 'Ok',
                                    isGradient:true,
                                    handler: () => {
                                        this.okAlertPressed(this.props.planDetailFrom);
                                    }
                                }
                            ];
                            this.refs.messageModal.toggleModal(true, translate("WARNINGTXT"), this.props.planDetailData.savePlanDataDic.warning_list[0],buttons);
                            } 
                            else {
                                if(this.props.planDetailFrom == "renew") {
                                    if(this.props.signupDetail.days_remaining != 0) {
                                        this.props.ContinuePress(false, true);    
                                    }else{
                                        this.props.ContinuePress(true, true);
                                    }
                                }
                                else{
                                    this.props.ContinuePress(true, true);
                                }
                            }
                        }
                    });
            } else {
                this.toast.show(translate("InternetToast"));
            }
        }
    }

    _openPromoCodeModal() {
        this.refs.refpromocode.togglePromocodeModal(true);
    }

    _openWalletModal() {
        //modal visible, initial display counter, totalWallet, maxUsing
        this.refs.refwallet.toggleModal(true, this.state.maximumwalletAllowed, this.props.signupDetail.total_wallet_amount, this.state.maximumwalletAllowed );
    }

    async walletAmountSelected(usedAmount) {
        if(usedAmount){
            await this.setState({isWalletIncluded: true, WalletAmount: usedAmount});
            this._compute_total("duration", this.state.duration, this.state.selectedAttribute, this.state.normal_configuration_lines, undefined, this.state.rules_configuration);
        }
    }


    /**
       * Promocode rules validation on applied
    */
    _OnclosePromocode(flagPromocode, promocode) {
        let promotion_state = this._ComputePromotion(promocode, this.state.amount_total_expected);
        let total_amount = this.state.amount_total_expected - promotion_state.promotion_amount;
        promotion_state.amount_total_expected = this.state.amount_total_expected;
        promotion_state.amount_total = total_amount;
        promotion_state.display_amount_total = (this.state.amount_total_expected - promotion_state.promotion_amount) - this.state.WalletAmount;
        this.setState(promotion_state);
        if(!promotion_state.isPromocodeApplied && promocode.length > 0) {
            this.setState({txtPromocode: ""});
            this.refs.simpleMessageModal.toggleModal(true, translate("INVALIDPROMO"), translate("OOPSTITLE"));
        }
    }
    
    onClose = () => {
        this.refs.simpleMessageModal.toggleModal(false);
    };

    validateRules(obj, currentPlanID, FinalTotal) {
        var promoData = obj;
        var matches = true;
        var discountedPrice = 0;
        let currentDate = new Date();
        
        // For startDate and endDate 
        if (currentDate < promoData.start_date || (promoData.end_date.length > 0 && promoData.end_date < currentDate)) {
            console.log('-------> Date Condition Proved');
            matches = false;
        }
        // only if only product is set then validate
        if (promoData.only_product_ids.length > 0 && promoData.only_product_ids.filter((e) => e === currentPlanID).length == 0) {
            console.log('-------> productid Condition Proved');
            matches = false;
        }
        //only validate min amount if value is greate then 0
        if (FinalTotal < promoData.order_amount_min) {
            console.log('-------> min account accoCondition Proved');
            matches = false;
        }
        //only validate max amount if value is greate then 0
        if (promoData.order_amount_max <= 0 || FinalTotal >= promoData.order_amount_max) {
            console.log('-------> order_amount_max -1 or 0');
            matches = false;
        }

        //only valid when FinalTotal >= promoData.order_amount_min
        if (FinalTotal < promoData.order_amount_min) {
            matches = false;
        }
        
        if (matches) {
            if (promoData.promotion_type == "fixed") {
                    discountedPrice = promoData.promotion_amount;
            }
            else if (promoData.promotion_type == "percentage") {
                    discountedPrice = (promoData.promotion_amount / 100) * FinalTotal;
            }
        }
        if (discountedPrice > promoData.maximum_promotion_amount) {
            discountedPrice = promoData.maximum_promotion_amount;
        }

        return {
            isValid: matches,
            promotion_amount: discountedPrice
        }
    }

    returnInvalidate(promocode) {
        this.refs.refpromocode.displayValidateAlert(false);
        return { isPromocodeApplied: false, txtPromocode: promocode, promotion_amount: 0 };
    }

    returnPromoApllied(promocode, discountedPrice) {
        this.refs.refpromocode.togglePromocodeModal(false);
        return { isPromocodeApplied: true, txtPromocode: promocode, promotion_amount: discountedPrice };
    }

    _ComputePromotion(promocode, FinalTotal) {
        let promocodeArr = this.props.planDetailData.promo_codes;
        let filterPromocode = promocodeArr.filter((e) => e.code === promocode);

        var regex = /^\d{3}[a-zA-Z]{3}\d{3}$/
        
        if(regex.test(promocode) == true &&  !this.props.signupDetail.isLogin) {
            let filterReferralCode = promocodeArr.filter((e) => e.type === "referral_code");
            if (filterReferralCode.length > 0) {
                let tempDiscountedArr = [];

                filterReferralCode.forEach(referralItem => {
                    let matches = this.validateRules(referralItem, this.state.selectedAttribute, FinalTotal);
                    if (matches.isValid) {
                        tempDiscountedArr.push(matches.promotion_amount);    
                    }
                });

                if(tempDiscountedArr.length > 0) {
                    let discountedPrice = Math.max.apply(Math, tempDiscountedArr);  
                    return this.returnPromoApllied(promocode.toLowerCase(), discountedPrice);
                }
            }
            return this.returnPromoApllied(promocode.toLowerCase(), 0);
        }

        
        else if (filterPromocode.length > 0) {
            var promoData = filterPromocode[0];
            var discountedPrice = 0;

            let matches = this.validateRules(promoData, this.state.selectedAttribute, FinalTotal);
            if (matches.isValid) {
                discountedPrice = matches.promotion_amount;
                return this.returnPromoApllied(promocode, discountedPrice);
            }
            else {
                return this.returnInvalidate(promocode);
            }
        }
        else {
            return this.returnInvalidate("");
        }
    }

    async _OncloseWallet() {
         await this.setState({isWalletIncluded: false, WalletAmount: 0});
         this._compute_total("duration", this.state.duration, this.state.selectedAttribute, this.state.normal_configuration_lines, undefined, this.state.rules_configuration);
    }

    _closeModal() {
        this._OnclosePromocode(true, '');
    }

    pickerSelectiondone = (refs, text, toggleModal) => {
        if(text){
            if(text != this.state.duration) {
                this.setState({ duration: text, extraProtCarbPrice: 0 });
                this.setAttributeData(text, null);
            }
        }
    }

    renderRowWithProteinData(item, index, ruleData) {
        console.log("Item with protein data ", item);
        return (
            <View>
                <TextWithCounter
                    onIncrementPress={() => this._incrementPress(item, index)}
                    onDecrementPress={() => this._decrementPress(item, index)}
                    isDropdown={true}
                    protein={this.state.selectedProtein * AppConfig.DietStation.perUnitGram}
                    carbs={this.state.selectedCarb * AppConfig.DietStation.perUnitGram}
                    text={this.props.getCName(item,"name")}
                    onChangeProtein={() => this._onPressProtein(index)}
                    minimumValue={ruleData.min_qty}
                    index={index}
                    currentCounter={item.qty}
                />
            </View>
        );
    }

    renderRowWithoutProteinData(item, index, ruleData) {
        return (
            <View>
                <TextWithCounter
                    onIncrementPress={() => this._incrementPress(item, index)}
                    onDecrementPress={() => this._decrementPress(item, index)}
                    text={this.props.getCName(item,"name")}
                    isDropdown={false}
                    minimumValue={ruleData.min_qty}
                    index={index}
                    currentCounter={item.qty}
                />
            </View>
        );
    }

    _renderItem = ({ item, index }) => {
        let ruleObj = this.state.rules_configuration[item.meal_id];
        if (ruleObj.hasOwnProperty("has_protein_carb") && ruleObj.has_protein_carb) {
            return (
                this.renderRowWithProteinData(item, index, ruleObj)
            );
        }
        else {
            return (
                this.renderRowWithoutProteinData(item, index, ruleObj)
            );
        }
    }

    renderAttributes() {
        return this.state.attribArray.map((data, index) => {
            console.log('data ------' + JSON.stringify(this.state.selectedPlanData));
            let diffrence = data.plan_price - this.state.selectedPlanData.plan_price;
            return (
                <TouchableOpacity key={index} style={this.state.selectedAttribute === data.id ? styles.selectedOption : styles.unselectedOption}
                    onPress={() => this._OnPressAttributeSelection(data, index)}>
                    <Text style={styles.txtNumDays}>{this.props.getCName(data,"title")}</Text>
                    {
                        this.state.selectedAttribute === data.id ?
                            <Image source={Images.icons.successGreen} style={styles.selectedic} />
                            :
                            <Text style={styles.txtPrice}>{diffrence} {translate("KWD")}</Text>
                    }
                </TouchableOpacity>
            );
        })
    }
    
    //CustomPlanPriceFooter
    renderFooter() {
        let isPay = false;
        if(this.props.planDetailFrom == "renew") {
            isPay = true;
        }
        else if(this.props.planDetailFrom == "changePlan") { 
            isPay = this.state.amount_total > 0 ? true : false
        }
            
        return (
            <View style={this.state.isPromocodeApplied || this.state.isWalletIncluded ? [styles.footerView, { marginTop: 0 }] : styles.footerView}>
                {this.state.isPromocodeApplied || this.state.isWalletIncluded ?
                    <View style={styles.includedeView}>
                        <View style={styles.planView}>
                            <Text style={styles.txtPlan}>{translate("Plan")}</Text>
                            <Text style={styles.txtoriginalPrice}>{this.state.amount_total_expected.toFixed(2)}</Text>
                        </View>

                        {
                            this.state.isPromocodeApplied &&
                        <View style={styles.contentView}>
                            <View style={styles.priceconfigView}>
                                <TouchableOpacity style={styles.cancelView} onPress={() => this._closeModal()}>
                                    <Image source={Images.icons.cancel_redBackground} style={styles.cancelLogo} />
                                </TouchableOpacity>
                                <Text style={styles.txtpromo}>{this.state.txtPromocode}</Text>
                            </View>
                            <Text style={styles.txtDiscountedPrice}>- {this.state.promotion_amount.toFixed(2)}</Text>

                        </View>
                        }

                        {
                            this.state.isWalletIncluded &&
                            <View style={[styles.contentView, {marginTop: 15}]}>
                            <View style={styles.priceconfigView}>
                                <TouchableOpacity style={styles.cancelView} onPress={() => this._OncloseWallet()}>
                                    <Image source={Images.icons.cancel_redBackground} style={styles.cancelLogo} />
                                </TouchableOpacity>
                                <Text style={styles.txtWallet}>{translate("txtWallet")}</Text>
                                <Text style={styles.txtTotalWallet}>{this.props.signupDetail.total_wallet_amount.toFixed(2) + " " +translate("KWD")}</Text>
                            </View>
                            <Text style={styles.txtDiscountedPrice}>- {this.state.WalletAmount.toFixed(2)}</Text>

                            </View>
                        }


                    </View>
                    :
                    null
                }

                <View style={styles.seprator}></View>

                {
                    this.props.planDetailFrom != "changePlan" &&

                    <View style={styles.codewalletView}>
                        <Text style={styles.txtadd}>{translate("Add")}</Text>
                        <TouchableOpacity onPress={() => this._openPromoCodeModal()}>
                            <Text style={styles.txttotaltxt}>{translate("Promocode")}</Text>
                        </TouchableOpacity>

                        {this.state.isWalletEnablePlan && 
                        <View style={{flexDirection:'row'}}>
                            <Text style={styles.txtadd}>{translate("OR")}</Text>
                            <TouchableOpacity onPress={() => this._openWalletModal()}>
                                <Text style={styles.txttotaltxt}>{translate("txtWallet")}</Text>
                            </TouchableOpacity>
                        </View>
                        }
                    </View>
                }
                    
                    
                    { this.props.planDetailFrom == "changePlan" ? 
                        <View>
                            <CustomPlanPriceFooter index={"0"} title={"txtTotal"} type={"small"} amount= {this.state.amount_total_expected} />
                            <CustomPlanPriceFooter index={"1"} title={"txtPaid"} type={"small"} amount= {this.state.amount_confirmed_plan} />
                            <CustomPlanPriceFooter index={"2"} title={"txtBalance"} type={"big"} amount= {this.state.amount_total} />
                        </View>
                    :
                        <CustomPlanPriceFooter index={"0"} title={"GrandTotal"} type={"big"} amount= {this.state.display_amount_total} />
                    }
                    
                
                <GradientButton
                    style={styles.gradientbt}
                    text={isPay ? translate("ContinuePay") : translate("Continue")}
                    onPressAction={() => this._ContinuePress()} />
            </View>
        )
    }

    render() {
        return (
            <View style={[styles.flexView,{flex:1,backgroundColor:"red"}]}>        
                <View style={[styles.customSafearea,{flex:1,backgroundColor:"red"}]}>
                    <View style={[styles.container, {marginTop: 0 }]}>
                        <View style={[styles.CardView, {marginTop: 0 }]}>

                            <View style={styles.titleView}>
                                <View style={styles.innerView}>
                                    <Text style={styles.title}>{this.props.getCName(this.props.planDetailData,"plan_name")}</Text>
                                    <Text style={styles.txtPlanSelected}>{translate('PlanSelected')}</Text>
                                </View>
                                {
                                    this.props.getCName(this.props.planDetailData,"all_periods").length > 0 && this.state.duration.length > 0 &&
                                    
                                    <PickerSelection
                                        pickerSelectDone={this.pickerSelectiondone}
                                        inputText={this.state.duration}
                                        placeholderTxt={translate("pickerPlaceholder")}
                                        itemsArray={this.props.getCName(this.props.planDetailData,"all_periods")}
                                        refName={"durationSelector"}
                                        onRef={(el) => { this.inputRefs["durationSelector"] = el }} />
                                }

                            </View>

                            <ScrollView alwaysBounceVertical={false} bounces={false}  contentContainerStyle={this.props.planDetailFrom == "changePlan" ? styles.contentContainer : null}>
                                <FlatList   
                                    style={styles.customSafearea}
                                    data={this.state.normal_configuration_lines}
                                    extraData={this.state}
                                    keyExtractor={(item, index) => index.toString()}
                                    renderItem={(item, index) => this._renderItem(item, index)} />

                                <View style={styles.dayView}>
                                    {this.renderAttributes()}
                                </View>
                                <View style={this.state.isPromocodeApplied ? styles.sepratorView2 : styles.sepratorView} />
                            </ScrollView>
                        </View>

                        {this.renderFooter()}
                        <Toast refrence={(refrence) => this.toast = refrence} />
                    </View>
                </View>
                <PromoCode
                            isApplied={this.state.isPromocodeApplied}
                            promocodesArr={this.props.planDetailData.promo_codes}
                            promocodetext={this.state.isPromocodeApplied ? this.state.txtPromocode : ''}
                            ref={"refpromocode"}
                            onClose={(flagPromocode, promocode) => this._OnclosePromocode(flagPromocode, promocode)} />

                <WalletModal 
                    ref={"refwallet"}
                    onModalHide={(usedAmount) => this.walletAmountSelected(usedAmount)}
                    fetchData={this.props.fetchData} />

                <SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} />
                
                {this.state.defaultProteinArray &&
                    <ProteinSelection
                        ref={"refproteinselection"}
                        proteinData={this.state.defaultProteinArray.protein}
                        carbData={this.state.defaultProteinArray.carb}
                        selectedProtein={this.state.selectedProtein}
                        selectedCarb={this.state.selectedCarb}
                        onChangeProteinIndex={(index) => this.changeProteinCarbData(AppConfig.DietStation.perUnitGram * (index + 1), AppConfig.DietStation.perUnitGram * this.state.selectedCarb)}
                        extraProtCarbPrice={this.state.tempExtraProtCarbPrice}
                        FinalTotal={this.state.FinalTotal_carbModal}
                        extraSelectionDone={() => this._extraSelectionDone()}
                        cancelProteinSelection={() => this._cancelProteinSelection()}
                        onChangeCarbIndex={(index) => this.changeProteinCarbData(AppConfig.DietStation.perUnitGram * this.state.selectedProtein, AppConfig.DietStation.perUnitGram * (index + 1))} 
                        best_protein_carb_url = {this.props.fetchData.best_protein_carb_url}
                        />
                }
			        <MessageModal ref={"messageModal"}
						modelMessage={false}
						// okPress={() =>{this.okAlertPressed()}}
						/>
                          <Toast refrence={(refrence) => this.toast = refrence} />
            </View>
        );
    }
}


function mapDispatchToProps(dispatch) {
    return {
        actions: {
            UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
            GetPlanDetailAction: bindActionCreators(GetPlanDetailAction, dispatch),
            PaymentAction: bindActionCreators(PaymentAction, dispatch)
        }
    };
}

const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    fetchData: state.fetchMasterListReducer,
    planDetailData: state.PlanReducer,
    signupDetail: state.updateUserReducer,
    paymentReducer: state.PaymentReducer,
    getCName: languageNameGetter(state)
});

export default connect(mapStateToProps, mapDispatchToProps)(CustomPlanView);