import { StyleSheet, Platform, Dimensions,  PixelRatio, I18nManager } from "react-native";
//import Colors from "../../common/Colors";
import { Images, Styles, Colors } from "@common";
import { FontScalling } from "../../common/Utility";
const { height, width } = Dimensions.get("window");
export default (styles = StyleSheet.create({
flexView:{
  flex:1
},
  container: {
    flex: 1,
    backgroundColor: Colors.pinkishRed,
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  CardView: {
    marginTop: 23,
    flex: 1,
    backgroundColor: Colors.white,
    overflow: "hidden"
  },
  header: {
    width: '100%',
    marginTop: 0,
    flexDirection: 'row',
    padding: 16,
    alignItems: 'center',
    justifyContent: 'space-between',
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  cancelLogo: {
    width: 14,
    height: 14,
  },
  helpView: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  txtCall: {
    fontFamily: Styles.FontFamily().ProximaNova,
    fontSize: 14,
    letterSpacing: -0.16,
    color: Colors.black08
  },
  callLogo: {
    marginLeft: 6,
    width: 28,
    height: 28,
  },
  titleView: {
    flexDirection: 'row',
    marginHorizontal: 14,
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  txtPlanSelected: {
    fontFamily: Styles.FontFamily().ProximaNova,
    fontSize: 12,
    color: Colors.lightBlack,
    letterSpacing: -0.14,
    marginTop: 4
  },
  title: {
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    fontSize: 24,
    textAlign: "center",
    color: Colors.black,
    letterSpacing: -0.86
  },
  duration: {
    borderRadius: 20,
    backgroundColor: Colors.pinkishRed,
    flexDirection: 'row',
    paddingHorizontal: 14,
    paddingVertical: 7,
    alignItems: 'center'
  },
  txtDuration: {
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    fontSize: 15,
    color: Colors.white,
  },
  downic: {
    marginLeft: 5,
    height: 15,
    width: 15
  },
  gradientbt:{ 
    marginTop: 0
  },
  priceconfigView:{ 
    flexDirection: 'row', 
    alignItems: 'center' 
  },
  dayView: {
    margin: 16,
    height: 54,
    flexDirection: 'row',
    justifyContent: 'space-evenly'
  },
  selectedOption: {
    flex: 0.30,
    borderColor: Colors.weirdGreen,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',

    backgroundColor:Colors.white,
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 5 },
    shadowRadius: 10,
    shadowOpacity: 0.12,
    elevation: 5,
  },
  unselectedOption: {
    flex: 0.30,
    borderColor: Colors.lightGray,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  codewalletView:{
    flexDirection: 'row',
    alignItems:'center',
    justifyContent:'center',
    marginVertical:12,
  },
  selectedic: {
    position: 'absolute',
    height: 22,
    width: 22,
    right: 1,
    top: 1,
  },
  txtadd:{
    fontSize: 13,
    fontFamily: Styles.FontFamily().ProximaNova,
    color: Colors.black
  },
  txtOff: {
    fontSize: 14,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
    color: Colors.darkGray
  },
  txtPrice:{
    fontSize: 10,
    
    fontFamily: Styles.FontFamily().ProximaNova,
    color: Colors.black,
    letterSpacing:-0.12,
  },
  txtNumDays:{
    fontSize: 14,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
    color: Colors.darkGray,
  },
  footerView:{
    //marginTop: height*0.135,
    position:'absolute',
    bottom: 0,
    paddingBottom:height/width > 1.7 ? 20 :0 ,
    width:'100%',
    borderTopLeftRadius:24,
    borderTopRightRadius:24,
    backgroundColor:Colors.white,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -15 },
    shadowRadius: Platform.OS === 'ios'?24:30,
    shadowOpacity: 0.12,
    elevation: 5,
  },
  sepratorView:{
    //height:height > 650 ? 0 : height*0.35
    height: PixelRatio.get() <= 2 ? height*0.30 : height*0.25
  },
  sepratorView2:{
    height: PixelRatio.get() <= 2 ? height*0.50 : height*0.40
  },
  innerView:{ 
    marginVertical: 16 
  },
  customSafearea:{ 
    flex:1, 
    backgroundColor: 'white' 
  },
  seprator:{
    width:'100%',
    height: 1,
    backgroundColor:Colors.lightGray
  },
  txttotaltxt:{
    fontSize: 13,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
    color: Colors.black,
    marginHorizontal: 5
  },
  includedeView:{
    
  },
  planView:{
    flexDirection:'row',
    marginHorizontal: 24,
    alignItems:'center',
    justifyContent:'space-between',
    marginVertical:20
  },
  txtPlan:{
    fontSize: 13,
    fontFamily: Styles.FontFamily().ProximaNova,
    color: Colors.black,
    marginLeft: 8
  },
  txtoriginalPrice: {
    fontSize: 16,
    fontFamily: Styles.FontFamily().ProximaNova,
    color: Colors.pinkishRed
  },
  contentView:{
      flexDirection:'row',
      justifyContent:'space-between',
      marginHorizontal: 24,
      borderStyle: 'dotted',
      borderColor: Colors.pinkishRed,
      alignItems:'center',
      borderWidth: 1,
      borderRadius: 8,
  },
  cancelView:{
    margin: 10
  },
  txtpromo:{
    fontSize: 13,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
    color: Colors.pinkishRed
  },
  txtWallet:{
    fontSize: 17,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    color: Colors.black
  },
  txtTotalWallet:{
    marginLeft: 8,
    fontSize: 15,
    fontFamily: Styles.FontFamily().ProximaNova,
    color: Colors.black06
  },
  txtDiscountedPrice: {
    fontSize: 15,
    fontFamily: Styles.FontFamily().ProximaNova,
    color: Colors.pinkishRed,
    marginHorizontal:15
  },
  contentContainer: {
    paddingBottom: 70
  }
  





}));

