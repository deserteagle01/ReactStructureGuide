
import { StyleSheet, Platform, Dimensions, I18nManager } from "react-native";
import { Images, Styles, Colors } from "@common";
import { FontScalling } from "../../common/Utility";
const { height, width } = Dimensions.get("window");

export default (styles = StyleSheet.create({
    ModalContainer: {
    
},
modalStyle:{
  
},
backArrow: {
    height: 28,
    width: 28
},
subtitle: {
    textAlign:'center',
	fontFamily: Styles.FontFamily().ProximaNova,
    fontSize: 12,
    color: Colors.lightBlack,
    marginTop:4
},
title: {
    textAlign:'center',
	fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    fontSize: 15,
    color: Colors.black,
},
containerView:{
    flexDirection: 'row', 
    justifyContent:'space-between', 
    alignItems:'center', 
    width:'100%', 
    marginVertical:28, 
    paddingHorizontal:16
}
}));

