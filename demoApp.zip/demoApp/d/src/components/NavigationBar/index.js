import React, { PureComponent } from "react";
import { AnimatedMove, ChoosePlanView } from "@components";
import { Animated, Dimensions, View, Text, Image, TouchableOpacity } from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate, setI18nConfig } from "@languages";
import styles from "./styles";
const { height, width } = Dimensions.get("window");

class NavigationBar extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            
        };
    }

    componentDidMount() {
        
    }
    
    
    render() {
        const {title, subtitle, onPressBack, onPressCancel} = this.props;
        return (
           <View style={[styles.containerView, this.props.style]}> 
                <TouchableOpacity onPress={onPressBack}>  
                    <Image
                       resizeMode="contain"
                        source={Images.icons.LeftGrey}
                        style={styles.backArrow} />
                </TouchableOpacity>

                <View>  
                    <Text style={styles.title}>{title}</Text>
                    {subtitle &&
                         <Text style={styles.subtitle}>{subtitle}</Text>
                    }
                </View>

                <TouchableOpacity onPress={onPressCancel}>  
                    <Image
                       resizeMode="contain"
                        source={Images.icons.closeBox}
                        style={styles.backArrow} />
                </TouchableOpacity>

            </View>
        )
    }
}

  
export default NavigationBar;