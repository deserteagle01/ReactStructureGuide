import React, { Component } from "react";
import { StyleSheet, TextInput, Image, Text, TouchableHighlight, TouchableOpacity, I18nManager } from "react-native";
import { Styles, Colors } from "@common";
import { View } from "react-native-animatable";
import DatePicker from "../DatePicker";
import moment from 'moment';
import RNPickerSelect, { defaultStyles } from 'react-native-picker-select';
import { translate } from "@languages";
export default class InputWithIconProfile extends Component {
	constructor(props) {
		super(props);
		this.toggleSwitch = this.toggleSwitch.bind(this);
		this.state = {
            showPassword: true // boolean to show/hide the password
		};
		// this.returnRef = this.returnRef.bind(this);
	}

	componentDidMount(){
		if(this.props.onRef){
			this.props.onRef(this.refs[this.props.refName]);
		}
	}
	componentDidUpdate(){
		if (this.props.onRef) {
			this.props.onRef(this.refs[this.props.refName]);
		}
	}
	// returnRef(){
	// 	if (this.props.onRef) {
	// 		this.props.onRef(this.refs['language']);
	// 	}
	// }
	componentWillUnmount(){
			if(this.props.onRef){
				this.props.onRef(null);
			}
	}

	handlerFocus = (input) => {
		this.setState({
			[input]: true
		});
	};

	handlerBlur = (input) => {
		this.setState({
			[input]: false
		});
	};

	textHandler = (text) => {
		this.props.textHandler(text);
	}

	updateRef(name, refs) {
		this[name] = refs;
	}

	InputAccessoryView = () => {
		return (
			<View style={[defaultStyles.modalViewMiddle]} testID="input_accessory_view">
				<View style={[defaultStyles.chevronContainer]}></View>
				<TouchableWithoutFeedback
						onPress={() => {
							this.props.onDropDownToggleFun(this.props.refName)
						}}
						hitSlop={{ top: 4, right: 4, bottom: 4, left: 4 }}
						testID="done_button"
						>
						<View testID="needed_for_touchable">
							<Text style={[defaultStyles.done]}>{"Done"}</Text>
						</View>
				</TouchableWithoutFeedback>
			</View>);
	}

	toggleSwitch() {
		this.setState({ showPassword: !this.state.showPassword });
	}

	openDatepicker = () => {
        this.refs.refDatePicker.showDateTimePicker();
    }

	render() {
		const {
			inputType,
			refs,
			placeholderText,
			itemObj,
			inputText,
			errorMsg,
			iconPath,
			selecteddate,
			inputAccessoryViewID,
			refName
		} = this.props;

		const placeholderPicker = {
			label: placeholderText,
			value: null,
			color: Colors.white,
		};
		const pickerStyle = {
			inputIOS: {
				color: Colors.black,
				fontSize: 17,
				height: 60,
				paddingLeft: 16,
				borderRadius: 12,
				borderWidth: 1,
				fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
				borderColor: Colors.whiteTwo,
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			inputAndroid: {
				color: Colors.black,
				fontSize: 17,
				height: 60,
				paddingLeft: 16,
				borderRadius: 12,
				borderWidth: 1,
				fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
				borderColor: Colors.whiteTwo,
				textAlign: I18nManager.isRTL ? 'right' : 'left',
			},
			underline: { borderTopWidth: 0 },
			icon: {
				width: 24,
				height: 24,
			},
			iconContainer: {
				height: 61,
				width: 40,
				flex: 1,
				paddingRight: 16,
				justifyContent: 'center',
				alignItems: 'center',
			},
		};
		if (inputType == 1) {
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput ref={refName?refName: 'password'}
						onSubmitEditing={() => this.props.returnKeyEvent(this.props.inputAccessoryViewID)}
						inputAccessoryViewID={inputAccessoryViewID} secureTextEntry={this.state.showPassword} selectionColor={Colors.black08} returnKeyType='done' onChangeText={this.textHandler} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[styles.leftContainer, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '',{height:40}]}/>
						<View style={[styles.rightContainerIcon]}><Image style={[styles.iconStyle,{tintColor:Colors.pinkishRed,marginBottom:5}]} source={iconPath} /></View>
					</View>
					<Text style={errorMsg?[styles.errorMsg,{paddingTop:4}]: ''}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		} else if (inputType == 2) {
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput ref={refName?refName: 'email'} autoCapitalize = 'none' returnKeyType='done' selectionColor={Colors.black08} keyboardType={'email-address'} onChangeText={this.textHandler} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[{ fontFamily:  Styles.FontFamily().ProximaNovaSemiBold }, styles.leftContainer, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}/>
						<TouchableOpacity style={[styles.rightContainerIcon]}><Image style={[styles.iconStyle]} source={iconPath} /></TouchableOpacity>
					</View>
					<Text style={errorMsg?styles.errorMsg: ''}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		} else if (inputType == 3) {
			return (
				<View>
					<TouchableOpacity onPress={() => this.openDatepicker()} style={[styles.inputContainer]}>
						<View style={[styles.leftContainer, inputText != ''?styles.textInputFocus:'']}><Text style={[styles.textStyle]}>{inputText?moment(inputText).format('DD-MMM-YYYY'): ''}</Text></View>
						<View style={[styles.rightContainerIcon]}><Image style={[styles.iconStyle]} source={iconPath} /></View>
					</TouchableOpacity>
					<Text style={errorMsg?styles.errorMsg: ''}>{errorMsg?translate(errorMsg): ''}</Text>
					<DatePicker 
					onSubmitEditing={() => this.props.returnKeyEvent(inputAccessoryViewID)}
					inputAccessoryViewID={inputAccessoryViewID}
					ref={refName?refName: 'refDatePicker'} 
					selecteddate={inputText} 
					maximumDate={new Date()} 
					selectedReturn={this.textHandler}></DatePicker>
				</View>
			);
		} else if(inputType == 4) {
			// Full border with right text
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput ref={refName?refName: 'phone'} keyboardType={'decimal-pad'} returnKeyType='done' selectionColor={Colors.black08} onChangeText={this.textHandler} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[{ fontFamily: Styles.FontFamily().ProximaNova }, styles.leftContainerBorder, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocusFullBorder : '', this.state.nameInputOneFocus ? styles.textInputFocusFullBorder : '']}/>
						<Text style={[styles.inputRightText]}>{iconPath}</Text>
					</View>
					<Text style={errorMsg?styles.errorMsg: ''}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		} else if (inputType == 5) {
			//change pwd field
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput ref={refName?refName: 'password'} secureTextEntry={this.state.showPassword} selectionColor={Colors.black08} returnKeyType='done' onChangeText={this.textHandler} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[{ fontFamily: Styles.FontFamily().ProximaNovaSemiBold }, styles.leftContainer, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}/>
						<TouchableOpacity onPress={this.toggleSwitch} style={[styles.rightContainerIcon]}><Image style={[styles.iconStyle]} source={iconPath} /></TouchableOpacity>
					</View>
					<Text style={errorMsg?styles.errorMsg: ''}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		} else {
			return (
				<View>
					<View style={styles.inputContainer}>
						<TextInput ref={refName?refName: 'string'}
						onSubmitEditing={() => this.props.returnKeyEvent(this.props.inputAccessoryViewID)}
						inputAccessoryViewID={inputAccessoryViewID}
						onChangeText={this.textHandler} selectionColor={Colors.black08} value={inputText} placeholder={placeholderText} placeholderTextColor={Colors.placeHoderGrey} style={[{ fontFamily: Styles.FontFamily().ProximaNovaSemiBold }, styles.leftContainer, this.state.nameInputOneFocus || inputText != '' ? styles.textInputFocus : '', this.state.nameInputOneFocus ? styles.textInputFocus : '']}/>
						<TouchableOpacity style={[styles.rightContainerIcon]}><Image style={[styles.iconStyle]} source={iconPath} /></TouchableOpacity>
					</View>
					<Text style={errorMsg?styles.errorMsg: ''}>{errorMsg?translate(errorMsg): ''}</Text>
				</View>
			);
		}
	}
}


const styles = StyleSheet.create({
	inputContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		// backgroundColor: 'blue'
	},
	leftContainer:{
		borderColor: Colors.white,
		borderBottomWidth: 0,
		height: 45,
		width: '100%',
		color: Colors.black08,
		fontFamily: Styles.FontFamily().ProximaNova,
		fontSize: 17,
		paddingEnd: 29,
		justifyContent: 'center',
		textAlign: I18nManager.isRTL ? 'right' : 'left',
		lineHeight:25
	},
	leftContainerText:{
		fontSize: 17,
		justifyContent: 'flex-start',
		textAlign: 'left'
	},
	leftContainerBorder:{
		borderColor: '#9D9D9D',
		borderWidth: 0,
		height: 45,
		width: '100%',
		color: Colors.black08,
		fontSize: 17,
		paddingEnd: 55,
		paddingStart: 10,
		justifyContent: 'flex-start',
		alignItems: 'center',
		borderRadius: 12,
		textAlign: I18nManager.isRTL ? 'right' : 'left',
	},
	textInputFocusFullBorder: {
		borderColor: Colors.white,
		borderWidth: 0,
	},
	rightContainerIcon: {
		right: 10,
		position: 'absolute',
		justifyContent: "center",
		height: 24,
		width: 24,
	},
	iconStyle: {
		height: 24,
		width: 24,
		tintColor:Colors.battleshipGrey
	},
	textStyle: {
    color: Colors.black08,
    fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily().ProximaNova,
		textAlign: 'left'
	},
	inputRightText:{
		right: 10,
		paddingTop: 5,
		position: 'absolute',
		height: 28,
		width: 42,
		color: Colors.black08,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily().ProximaNova,
		lineHeight: 20,
		backgroundColor: 'rgba(248,68,66, 1)',
		borderRadius: 14,
		textAlign: 'center',
	},
	textInputFocus: {
		borderBottomColor: Colors.white,
	},
	errorMsg:{
		alignSelf:'flex-start',
		color: 'red',
		fontSize: 12,
		fontFamily:  Styles.FontFamily().ProximaNova,
		marginTop: 4,
		marginLeft: 0
	}
});
