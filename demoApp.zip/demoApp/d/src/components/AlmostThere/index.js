import React, { Component } from "react";
import { View, Text, StyleSheet, I18nManager , Dimensions, Platform, Keyboard} from "react-native";
import { connect } from "react-redux";
import { Styles, Images, Colors, Validations } from "@common";
import InputWithIcon from "../InputWithIcon"
import ButtonOk from  "../ButtonOk";
import { translate } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import moment from 'moment';
import { InputAccessory } from "@components";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { TouchableOpacity } from "react-native-gesture-handler";
const { height, width } = Dimensions.get("window");
class AlmostThere extends Component {
	constructor(props) {
		super(props);
		this.state = {
			profileEmail: this.props.signupDetail.email,
			profileEmailError: null,
			isValidEmail: null
		};
		this.inputRefs = {};
	}
	
	init() {
		//this.inputRefs["email"].focus();
		this.setState({profileEmail: this.props.signupDetail.email, isValidEmail: false })
		if(this.props.signupDetail.email.length > 0) {
			this.emailValidate(this.props.signupDetail.email);
		}
	}

	textEmailHandler = (text) => {
		this.setState({profileEmail: text.trim()})
		this.emailValidate(text);
	}

	emailValidate(text) {
		//let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
		let reg = /.+@.+\..+$/;
		if(reg.test(text) === false){
			this.setState({isValidEmail: false});
		}else{
			this.setState({isValidEmail: true});
		}
	}

	validate() {
		return new Promise((resolve, reject) => {
			let option = {fullMessages: false};
			let profileEmailError = Validations('email', this.state.profileEmail, option);
			this.setState({ profileEmailError: profileEmailError });
			if (!profileEmailError) {
				const reqParams = {
					email: this.state.profileEmail,	// Update this field value only
				};
				this.props.actions.UpdateUserAction.updateUserDetails(reqParams);
				resolve({result: 1});
			}
			else{
				resolve({result: 0});
			}
		});
	}

	render() {
		return (
			<View style={styles.detailContainer}>
				 <KeyboardAwareScrollView  enableOnAndroid={true} keyboardShouldPersistTaps={'always'} >
				<View>	
					<Text style={[styles.label(this.props.signupDetail.com_lang), this.props.signupDetail.com_lang == 'ar' ? {textAlign:'right'} : null]}>{translate("AlmotThere")}</Text>
					<View style={styles.inputNameContainer}>
						<View style={styles.inputNameInternalContainer}>
							<InputWithIcon 
								onRef={(el) => {this.inputRefs["email"] = el} } 
								refName={"email"} 
								 inputAccessoryViewID={"email"} 
								 returnKeyEvent={(inputAccessoryViewID) => console.log(inputAccessoryViewID)}
						 		textHandler={this.textEmailHandler}
						 		errorMsg={this.state.profileEmailError}
						 		lang = {this.props.signupDetail.com_lang}
						 		iconPath={this.state.isValidEmail ?  I18nManager.isRTL ? Images.icons.rightCheckRedishPink : Images.icons.leftCheckRedishPink : null }  
						 		lang={this.props.signupDetail.com_lang}
						 		inputText={this.state.profileEmail} placeholderText={translate("EnterEmail")} inputType="2" />
						</View>
					</View>
				{this.state.isValidEmail  &&
				<TouchableOpacity onPress={this.props.onOkClick}>
					<ButtonOk  lang={this.props.signupDetail.com_lang} />
				</TouchableOpacity>
				}
				</View>

				{Platform.OS == 'ios' &&
                        <InputAccessory inputAccessoryViewID={"email"} disableUpArrow={true} hideDoneBar={false} onDoneClick={() => Keyboard.dismiss()} />
                }
				</KeyboardAwareScrollView>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		flex: 1,
	},
	label: (lang) => ({
		fontFamily: Styles.FontFamily(lang).UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.white,
		lineHeight: 36,
		textAlign: 'left',
		marginTop: height*0.14,
	}),
	inputNameContainer: {
		marginTop: 34
	},
	inputNameInternalContainer: {
		marginBottom: 7
	},
	textStyle: (lang) => ({
		color: Colors.pinkishRed,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold
	}),
});


const mapStateToProps = (state) => ({
	signupDetail: state.updateUserReducer
});


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(AlmostThere);