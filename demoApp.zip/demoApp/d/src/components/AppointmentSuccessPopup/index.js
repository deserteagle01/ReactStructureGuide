import React, { PureComponent } from "react";
import { Animated, Dimensions, View, Text, Image, StyleSheet, Platform, Linking, TouchableOpacity } from "react-native";
import { Images, Styles, Colors } from "@common";
import { GradientButton, ModalButton } from "@components";
import { translate, setI18nConfig } from "@languages";
const { height, width } = Dimensions.get("window");
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as Appointment from "../../redux/Actions/Appointment";
import { languageNameGetter, convertToLocalDatetime} from "../../common/Utility";
import Modal from "react-native-modal";
import HTML from 'react-native-render-html';
import * as AddCalendarEvent from 'react-native-add-calendar-event';

class AppointmentSuccessPopup extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            isVisible: false,
        };
    }

    componentDidMount() {   
        
    }

    show(item) {
        this.setState({isVisible: true});
    }

    async hide() {
        await this.setState({isVisible:false});
        this.props.onClosePopup()
    }

    addCalendar() {
        
        const eventConfig = {
            title: translate("txtCalendarTitle"),
            startDate: convertToLocalDatetime(this.props.planData.start_datetime,"YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
            endDate: convertToLocalDatetime(this.props.planData.end_datetime,"YYYY-MM-DDTHH:mm:ss.SSS[Z]"),
            location: this.props.planData.dietitian_address.city+ ", "+this.props.planData.dietitian_address.street,
            notes: translate("txtBookedWith")+this.props.getData(this.props.planData,"dietitian_name"),
                navigationBarIOS: {
                  tintColor: Colors.black,
                  backgroundColor: Colors.shamrockGreen,
                  titleColor: Colors.black,
                },
        };
        

       AddCalendarEvent.presentEventCreatingDialog(eventConfig).then((eventInfo) => {
          console.log('eventInfo -> ' + JSON.stringify(eventInfo));
          if(eventInfo.action == "SAVED"){
                this.hide();
          }
        }
      )
      .catch((error) => {
          console.log('Error -> ' + error);
      });
    }

    openMap() {
        let lat =  this.props.planData.dietitian_address.latitude;
        let lng = this.props.planData.dietitian_address.longitude;
        const scheme = Platform.select({ ios: 'maps:0,0?q=', android: 'geo:0,0?q=' });
        const latLng = `${lat},${lng}`;
        const label = 'Dietition Address';
        const url = Platform.select({
          ios: `${scheme}${label}@${latLng}`,
          android: `${scheme}${latLng}(${label})`
        });
        
        Linking.openURL(url); 
    }

   
     render() {
        return (
            <Modal
                hasBackdrop
                isVisible={this.state.isVisible}
                hideModalContentWhileAnimating={true}
                transparent={true}
                backdropOpacity={0.6}
                useNativeDriver={true}
                style={styles.modalStyle}
                onBackdropPress={() => this.hide()}
                onModalHide = {() => this.hide()}>

                <View style={styles.ModalContainer} >
                    <Text style={styles.txtTitle}>{translate("txtBookingSuccessTitle")}</Text>

                    <View style={styles.subContainer}>
                        <Text style={styles.datetimeTitle}>{translate("txtdatetime")}</Text>
                        
                        <Text style={styles.txtdateTime}>{convertToLocalDatetime(this.props.planData.start_datetime,'DD MMMM YYYY hh:mm A')}</Text>
                        <View  style={styles.seprator}/>
                    </View>
                    <View style={styles.subContainer}>
                        <Text style={styles.datetimeTitle}>{translate("txtDietitionPlaceholder")}</Text>
                        <Text style={styles.txtdateTime}>{this.props.getData(this.props.planData,"dietitian_name")}</Text>
                        <View  style={styles.seprator}/>
                    </View>
                    <View style={[styles.subContainer, {flexDirection: "row"}]}>
                        <View style={{width: "70%"}}>
                            <Text style={styles.datetimeTitle}>{translate("txtLocation")}</Text>
                            <Text style={styles.txtdateTime}>{this.props.planData.dietitian_address.city+ ", "+this.props.planData.dietitian_address.street}</Text>
                        </View>
                        <TouchableOpacity style={styles.btnMap} onPress={() => this.openMap()}>
                            <Text style={styles.txtopne}>{translate("txtBtnMap")}</Text>
                        </TouchableOpacity>
                        <View  style={styles.seprator}/>
                    </View>

                    <View style={styles.buttonContainer}>
                        <ModalButton
                            isCheckedVisible={false}
                            onPress={() => this.addCalendar()}
                            label={translate("txtCalenderTitle")} />
                        <View style={{height: 12}}></View>
                        <GradientButton
                            isCheckedVisible={false}
                            onPressAction={() => this.hide()}
                            text={translate("Done")} />
                    </View>
                </View>
            </Modal>
        )
    }
}

const styles = StyleSheet.create({
	btnMap: {
        marginHorizontal: 16,
        alignSelf: "flex-end",
    },
    buttonContainer: {
        paddingTop: 16,
        paddingBottom: 24
    },
    subContainer: {
        marginTop: 0,
        width: "100%",
        alignItems: 'center',
        paddingVertical: 8,
    },
    seprator:{
        position:'absolute',
        bottom: 0,
        height: 1,
        width: '100%',
        backgroundColor: "rgb(234, 234, 234)",
    },
    txtopne: {
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        color: Colors.pinkishRed,
        fontSize: 14,
    },
    datetimeTitle: {
        fontFamily: Styles.FontFamily().ProximaNova,
        color: Colors.lightBlack,
        marginHorizontal: 24,
        fontSize: 14,
        alignSelf:'flex-start',
    },
    txtdateTime: {
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        color: Colors.black,
        marginHorizontal: 24,
        fontSize: 14,
        alignSelf:'flex-start',
    },
    txtTitle :{
        marginVertical: 24,
        marginHorizontal:'10%',
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        color: Colors.darkNavyBlue,
        fontSize: 17,
        textAlign: 'center',
        alignSelf:'center',
    },
    ModalContainer: {
        backgroundColor: Colors.white,
        width:'90%',
        borderRadius: 24,
        marginHorizontal: '5%'
    },
    modalStyle:{
        padding:0, 
        margin:0,
      },
    
});


function mapDispatchToProps(dispatch) {
    return {
      actions: {
        Appointment: bindActionCreators(Appointment, dispatch),
      }
    };
  }
  
  const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    planData: state.PlanReducer,
    getData: languageNameGetter(state)
  });

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(AppointmentSuccessPopup);


