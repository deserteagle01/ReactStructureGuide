import React, { Component } from "react";
import { View, Text, StyleSheet, FlatList, Dimensions, Platform } from "react-native";
import { connect } from "react-redux";
import { Styles, Colors } from "@common";
import { GradientButton, SelectDays, SimpleMessageModal } from "@components";
import { translate } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import { ScrollView } from "react-native-gesture-handler";
import FastImage from "react-native-fast-image";
const screen = Dimensions.get("window");
// import {getDaysFromOtherAddress } from "../../common/Utility";

class AddDaysAddress extends Component {
	constructor(props) {
		super(props);
		this.state = {
			daysArray: [...this.props.daysList],
			addressArray: [...this.props.userInfo.addresses],
		};
	}
	componentDidMount() {
		var localWeek = [];
		var showPopup=false;
		// FOR BACKPRESS GET DATA FROM REDUX that is this.props.userInfo.changeAddress.daysArray
		var arrayOfDays=this.props.userInfo.changeAddress.daysArray.length>0?this.props.userInfo.changeAddress.daysArray:(this.props.addressVal !== null?this.props.addressVal['daysArray']:[]);
		// for checked 
		for (let item of this.state.daysArray) {
			if (arrayOfDays.indexOf(item.key) > -1) {
				localWeek.push({ ...item, isChecked: true });
			}
			else {
				localWeek.push({ ...item });
			}
		}
		// for together all days of addresses for disable
		let weekdays = [];
		for (j = 0; j < this.state.addressArray.length; j++) {
			var addressItem = this.state.addressArray[j];
			if (!addressItem.isDisable && !addressItem.isPrimary && (this.props.addressVal == null || (this.props.addressVal !== null && this.props.addressVal.id !== addressItem.id))) {
				weekdays=weekdays.concat(addressItem.daysArray);
			}
		}
		weekdays = [...new Set(weekdays)];
		for (let item of localWeek) {
			if(weekdays.indexOf(item.key)>-1){
				//  when editing disabled address i will do checked false
				item.isChecked=false;
				item.isDisable = true;
			}
		}
		this.setState({ daysArray: localWeek });
	}
	validateAddress = () => {
		var newArr = [];
		for (i = 0; i < this.state.daysArray.length; i++) {
			if (this.state.daysArray[i].isChecked) {
				newArr.push(this.state.daysArray[i].key)
			}
		}
		const reqParams = {
			daysArray: newArr,					// Update this field value only	
		};
		if (newArr.length>0) {
			this.props.actions.UpdateUserAction.updateUserAddress(reqParams);
			this.props.gotoNext();
		}else{
			this.refs.simpleMessageModal.toggleModal(true, translate("SelectOneDay"), translate("NotSelectedDeliveryDays"));
		}
	}
	selectDays = (item) => {
		var daysArray = [];
		if (!item['isChecked']) {
			item['isChecked'] = true;
		} else {
			item['isChecked'] = false;
		}
		if (this.state.daysArray !== [] || this.state.daysArray !== null) {
			for (i = 0; i < this.state.daysArray.length; i++) {
				if (this.state.daysArray[i].value == item.value) {
					this.state.daysArray[i].isChecked = item['isChecked'];
				}
				daysArray.push(this.state.daysArray[i]);
				this.setState({ daysArray: daysArray });
			}
		}
	}
	onDisablePress = () => {
		this.refs.simpleMessageModal.toggleModal(true, translate("OopsDesc"), translate("OopsTitle"));
	}
	onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
	};
	_renderItem = ({ item }) => {
		return (
			<SelectDays onPress={(itemReturn) => this.selectDays(item)} item={item} onDisablePress={this.onDisablePress} />
		);
	}
	render() {
		return (
			<View style={styles.detailContainer}>
				<View style={styles.containerHeight}>

					<Text style={styles.label}>{translate("SelectDaysFoodDeliver")}</Text>
					<FlatList
						showsVerticalScrollIndicator={false}
						data={this.state.daysArray}
						keyExtractor={(item, index) => index.toString()}
						renderItem={this._renderItem}
						extraData={this.state}
					/>
				</View>
				<View style={styles.addressBtnConti}>
					<GradientButton
						onPressAction={() => { this.validateAddress() }}
						text={translate("Continue")}
					/>
					</View>
				<SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} modalStyle={styles.modal}/>
			</View>

		);
	}
}

const styles = StyleSheet.create({
	detailContainer: {
		width:screen.width,
		flexDirection:"column",
		height: screen.height-94-(Dimensions.get("window").height >= 812?41:21),
	},
	containerHeight:{
		width:screen.width,
		height: screen.height - 200,
	},
	label: {
		paddingHorizontal: 16,
		fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
		fontSize: 28,
		color: Colors.black,
		textAlign: 'left',
		lineHeight: 36,
		letterSpacing: -0.1,
	},
	addressBtnConti:{
		bottom: Dimensions.get("window").height >= 812?41:21,
		position:"absolute",
		width: "100%",
		shadowColor: "#000",
		shadowOffset: {
			width: 0,
			height: 6,
		},
		shadowOpacity: 0.15,
		shadowRadius: 7.49,
		elevation: 12,
	},
	modal:{
		height:160,
	}
});

const mapStateToProps = (state) => {
	return {
		userInfo: state.updateUserReducer,
		daysList: state.fetchMasterListReducer.daysList,
	};
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(AddDaysAddress);
