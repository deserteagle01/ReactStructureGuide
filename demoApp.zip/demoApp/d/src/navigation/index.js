/** @format */

import React from "react";
import { View, Image, Dimensions, I18nManager, StyleSheet, Animated, Easing } from "react-native";
import {
	createAppContainer,
	createSwitchNavigator,
	createStackNavigator,
	createBottomTabNavigator,
	NavigationActions
} from "react-navigation";
import { Colors, Images } from "@common";

import SignupScreen from "../screens/SignupScreen";
import AuthLoadingScreen from "./AuthLoadingScreen";
import HomeScreen from "../screens/HomeScreen";
import MealScreen from "../screens/MealScreen";
import AppointmentScreen from "../screens/AppointmentScreen";
import ProfileScreen from "../screens/ProfileScreen";
import OnboardingScreen from "../screens/OnboardingScreen";
import LoginScreen from "../screens/LoginScreen";
import ForgetPasswordScreen from "../screens/ForgetPassword";
import LoadingScreen from "../screens/LoadingScreen";
import ChoosePlanScreen from "../screens/ChoosePlanScreen";
import CustomPlanScreen from "../screens/CustomPlanScreen";
import AboutScreen from "../screens/AboutScreen";
import ChangePwdScreen from "../screens/ChangePwdScreen";
import EditProfileScreen from "../screens/EditProfileScreen";
import EditAddressScreen from "../screens/EditAddressScreen";
import ProfileDislikeScreen from "../screens/ProfileDislikeScreen";
import ProductCalendarScreen from "../screens/ProductCalendarScreen";
import NotificationList from "../screens/NotificationList";
import WalletScreen from '../screens/WalletScreen';
// import TransitionConfig from "./TransitionConfig";
const { width } = Dimensions.get("window");
const transitionConfig= () =>{
	return {
	transitionSpec: {
		duration: 300,
		easing: Easing.out(Easing.poly(4)),
		timing: Animated.timing,
	},
	screenInterpolator: sceneProps => {
		const {layout, position, scene} = sceneProps;
		const {index} = scene;

		const width = layout.initWidth;
		const height = layout.initHeight;
		const translateX = position.interpolate({
			inputRange: [index - 1, index, index + 1],
			outputRange: [width, 0, 0],
		});

		const translateY = position.interpolate({
		 inputRange: [index - 1, index, index + 1],
		 outputRange: [height, 0, 0],
		 });
		 
		const opacity = position.interpolate({
			inputRange: [index - 1, index - 0.99, index],
			outputRange: [0, 1, 1],
		});
		if(scene.route.routeName == "ChoosePlanScreen" ||  scene.route.routeName == "CustomPlan" || scene.route.routeName == "SignupScreen" || scene.route.routeName == "LoadingScreen"|| scene.route.routeName == "NotificationList" || scene.route.routeName =="ProductList" || scene.route.routeName == "ForgetPasswordScreen") {
			return {opacity, transform: [{translateY: translateY}]};
		}else{
			return {opacity, transform: [{translateX: translateX}]};
		}

	},
}
}

const HomeStack = createStackNavigator(
	{
		Home: { screen: HomeScreen },
		ChoosePlanScreen: { screen: ChoosePlanScreen },
		CustomPlan: { screen: CustomPlanScreen },
		SignupScreen: { screen: SignupScreen, navigationOptions: {
			gesturesEnabled: false 
		}},
		NotificationList: { screen: NotificationList },
		Wallet: { screen: WalletScreen },
	},
	{
		transitionConfig: transitionConfig,
		navigationOptions: {
			gestureResponseDistance: { horizontal: width / 2 },
			gesturesEnabled: true,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default"
		},
		defaultNavigationOptions: {
			header: null,
		
		},
	}
);

HomeStack.navigationOptions = ({ navigation }) => {
	let tabBarVisible;
	if (navigation.state.routes.length > 1) {
		navigation.state.routes.map(route => {
			if (route.routeName === "Home") {
				tabBarVisible = true;
			} else {
				tabBarVisible = false;
			}
		});
	}
	return {
		tabBarVisible,
		animationEnabled: false
	};
};


const MealStack = createStackNavigator(
	{
		ProductCalendar: { screen: ProductCalendarScreen },
		NotificationList: { screen: NotificationList },
	},
	{
		transitionConfig: transitionConfig,
		navigationOptions: {
			gestureResponseDistance: { horizontal: width / 2 },
			gesturesEnabled: true,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default"
		},
		defaultNavigationOptions: {
			header: null,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default",
		}
	}
);

MealStack.navigationOptions = ({ navigation }) => {
	let tabBarVisible;
	if (navigation.state.routes.length > 1) {
		navigation.state.routes.map(route => {
			if (route.routeName === "Meal") {
				tabBarVisible = true;
			} else {
				tabBarVisible = false;
			}
		});
	}
	return {
		tabBarVisible,
		animationEnabled: false
	};
};

const AppointmentStack = createStackNavigator(
	{
		Appointment1: { screen: AppointmentScreen },
		NotificationList: { screen: NotificationList },
	},
	{
		transitionConfig: transitionConfig,
		navigationOptions: {
			gestureResponseDistance: { horizontal: width / 2 },
			gesturesEnabled: true,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default"
		},
		defaultNavigationOptions: {
			header: null,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default",
		}
	}
);

const ProfileStack = createStackNavigator(
	{
		Profile: { screen: ProfileScreen },
		About: { screen: AboutScreen },
		ChangePwd: { screen: ChangePwdScreen },
		EditProfile: { screen: EditProfileScreen },
		EditAddress: { screen: EditAddressScreen },
		ProfileDislike: { screen: ProfileDislikeScreen },
		NotificationList: { screen: NotificationList },
		Wallet: { screen: WalletScreen },
	},
	{
		transitionConfig:  transitionConfig,
		navigationOptions: {
			gestureResponseDistance: { horizontal: width / 2 },
			gesturesEnabled: true,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default"
		},
		defaultNavigationOptions: {
			header: null,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default",
		}
	}
);
ProfileStack.navigationOptions = ({ navigation }) => {
	let tabBarVisible;
	if (navigation.state.routes.length > 1) {
		navigation.state.routes.map(route => {
			if (route.routeName === "Profile") {
				tabBarVisible = true;
			} else {
				tabBarVisible = false;
			}
		});
	}
	return {
		tabBarVisible,
		animationEnabled: false
	};
};
const getScreenRegisteredFunctions = navState => {
	const { routes, index, params } = navState;
	if (navState.hasOwnProperty('index')) {
	  return getScreenRegisteredFunctions(routes[index]);
	}
	// When we have the final screen params
	else {
	  return params;
	}
  }

const AppNavigator = createBottomTabNavigator(
	{
		Home: HomeStack,
		Meal: MealStack,
		Appointment: AppointmentStack,
		Profile: ProfileStack,
	},
	{
		transitionConfig: transitionConfig,
		defaultNavigationOptions: ({ navigation }) => ({
			tabBarOnPress: ({ defaultHandler }) => {

				if (navigation && navigation.isFocused()) {
				  const screenFunctions = getScreenRegisteredFunctions(navigation.state);
		
				  if (screenFunctions && typeof screenFunctions.tapOnTabNavigator === 'function') {
					screenFunctions.tapOnTabNavigator()
				  }
				}
				// Always call defaultHandler()
				defaultHandler();
			  },
			tabBarIcon: ({ focused, horizontal, tintColor }) => {
				const { routeName } = navigation.state;
				if (routeName === 'Home') {
					return (
						<Image
							source={focused ? Images.icons.homeActive : Images.icons.home}
							style={{ width: 36, height: 36 }} />
					);
				} else if (routeName === 'Meal') {
					return (
						<Image
							source={focused ? Images.icons.mealActive : Images.icons.meal}
							style={{ width: 36, height: 36 }} />
					);
				} else if (routeName === 'Appointment') {
					return (
						<Image
							source={focused ? Images.icons.appointmentActive : Images.icons.appointment}
							style={{ width: 36, height: 36 }} />
					);
				} else if (routeName === 'Profile') {
					return (
						<Image
							source={focused ? Images.icons.profileActive : Images.icons.profile}
							style={{ width: 36, height: 36 }} />
					);
				}
			},
		}),
		tabBarPosition: "bottom",
		swipeEnabled: false,
		animationEnabled: false,
		tabBarOptions: {
			showIcon: true,
			showLabel: false,
			activeTintColor: Colors.tabbarActiveTint,
			style: {
				shadowColor: Colors.black16,
				shadowOffset: { width: 0, height: 1 },
				shadowOpacity: 0.1,
				shadowRadius: 8,
				elevation: 2,
				borderTopWidth: 0,
				borderColor: Colors.white
			}
		},
		lazy: true,
		navigationOptions: {
			gestureDirection: I18nManager.isRTL ? "inverted" : "default"
		}
	}
);

const AuthNavigator = createStackNavigator({
	LoginScreen: { screen: LoginScreen },
	SignupScreen: { screen: SignupScreen, navigationOptions: {
		gesturesEnabled: false 
	}},
	ForgetPasswordScreen: { screen: ForgetPasswordScreen },
	LoadingScreen: { screen: LoadingScreen },
	ChoosePlanScreen: { screen: ChoosePlanScreen },
	CustomPlan: { screen: CustomPlanScreen },
},
	{
		transitionConfig: transitionConfig,
		defaultNavigationOptions: {
			header: null,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default",
		},
		transitionConfig: () => ({
            transitionSpec: {
                duration: 300,
				easing: Easing.out(Easing.poly(4)),
				timing: Animated.timing,
			},
            screenInterpolator: sceneProps => {
                const {layout, position, scene} = sceneProps;
                const {index} = scene;

				const width = layout.initWidth;
				const height = layout.initHeight;
                const translateX = position.interpolate({
                    inputRange: [index - 1, index, index + 1],
                    outputRange: [width, 0, 0],
                });

                const translateY = position.interpolate({
                 inputRange: [index - 1, index, index + 1],
                 outputRange: [height, 0, 0],
                 });
                 
				const opacity = position.interpolate({
                    inputRange: [index - 1, index - 0.99, index],
                    outputRange: [0, 1, 1],
				});

				if(scene.route.routeName == "ChoosePlanScreen" ||  scene.route.routeName == "CustomPlan" || scene.route.routeName == "SignupScreen" || scene.route.routeName == "LoadingScreen" || scene.route.routeName == "ForgetPasswordScreen") {
					return {opacity, transform: [{translateY: translateY}]};
				}else{
					return {opacity, transform: [{translateX: translateX}]};
				}
                
            },
        }),
	}
);

const SignupNavigator = createStackNavigator({
	SignupScreen: { screen: SignupScreen, navigationOptions: {
		gesturesEnabled: false 
	} },
},
	{
		transitionConfig: transitionConfig,
		defaultNavigationOptions: {
			header: null,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default",
		}
	}
);


const OnboardNavigator = createStackNavigator({
	OnboardingScreen: { screen: OnboardingScreen },
},
	{
		transitionConfig: transitionConfig,
		defaultNavigationOptions: {
			header: null,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default",
		}
	}
);

const PlanNavigator = createStackNavigator({
	ChoosePlanScreen: { screen: ChoosePlanScreen },
	CustomPlan: { screen: CustomPlanScreen }
},
	{
		transitionConfig: transitionConfig,
		defaultNavigationOptions: {
			header: null,
			gestureDirection: I18nManager.isRTL ? "inverted" : "default",
		}
	}
);

export default createAppContainer(
	createSwitchNavigator(
		{
			AuthLoading: AuthLoadingScreen,
			ChoosePlan: PlanNavigator,
			Onboard: OnboardNavigator,
			Auth: AuthNavigator,
			SignupFlow: SignupNavigator,
			App: AppNavigator,
		}
	)
);
