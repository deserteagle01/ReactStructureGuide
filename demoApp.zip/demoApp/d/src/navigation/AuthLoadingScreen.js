import React from "react";
import {
  ActivityIndicator,
  StatusBar,
  StyleSheet,
  View,
  Text,
  DeviceEventEmitter,
  AppState,NativeModules
} from "react-native";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../redux/Actions/getNetInfoAction";
import * as FetchMasterAction from "../redux/Actions/fetchMasterListAction";
import * as UpdateUserAction from "../redux/Actions/updateUserAction";
import store from "@store";
import { setI18nConfig, translate } from "@languages";
import NetInfo from "@react-native-community/netinfo";
import { Images, Colors, Styles, AppConfig } from "@common";
import { returnRemainingSlider, screens } from "../common/Utility";
import { Spinner, Toast } from "@components";
import OneSignal from 'react-native-onesignal';
import  NotificationManager  from '../common/NotificationManager';
import SplashScreen from "react-native-splash-screen";
import HTTP from "../webservice/http";
import moment from 'moment';
import LanguageManager  from "../common/LanguageManager";

class AuthLoadingScreen extends React.Component {
  constructor(props) {
    super(props);
    console.log("AuthLodingScreen")
    this.onReceived = this.onReceived.bind(this);
    this.onOpened = this.onOpened.bind(this);
  }

  
  componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange);
    NetInfo.isConnected.addEventListener(
      'connectionChange',
      this._handleConnectivityChange
    );

    const language = this.props.languagess;
    if (language.rtl) {
      setI18nConfig("ar", true);
    } else {
      setI18nConfig(language.lang, language.rtl);
    }

    LanguageManager.setLanguages(this.props.languagess.lang);
    this.setMasterData();
    this.listener = DeviceEventEmitter.addListener('logoutAction', () => this.logoutAction());
  }

  _handleAppStateChange = (nextAppState) => {
    this.setState({appState: nextAppState});
    if(nextAppState == "active"){
        this.handleForegroundState();
    }
  };

  async handleForegroundState() {
    let currentDate = moment().format('MM-DD-YYYY');
    if(this.props.userInfo.currentDate != currentDate) {
        this.props.actions.FetchMasterAction.getCompanyDetails().then(() => {
          if (this.props.companyDetails.error == null) {
               this.props.actions.UpdateUserAction.updateUserDetails({ currentDate: currentDate });    
          }
        });
    }
  }

  componentWillUnmount() {
     
  }

  async logoutAction() {
    var reqParams = {
			lang: this.props.userInfo.lang,
			introComplete: this.props.userInfo.introComplete
		};
    await this.props.actions.UpdateUserAction.clearDataAction(reqParams, {});
    this.props.navigation.navigate("Auth");
  }

  async setMasterData() {
    await this.props.actions.FetchMasterAction.getCompanyDetails().then(() => {
      if (this.props.companyDetails.error) {
        console.log('Error in API ='+this.props.companyDetails.error);
      }
    });

    await this.props.actions.FetchMasterAction.PreloadedDataAction().then(() => {
      if (this.props.companyDetails.error) {
        console.log('Error ='+this.props.companyDetails.error);
      }
    });

    OneSignal.init(this.props.companyDetails.onesignal_app_id, {kOSSettingsKeyAutoPrompt : true });
    OneSignal.inFocusDisplaying(0);
    OneSignal.addEventListener('received', this.onReceived);
    OneSignal.addEventListener('opened', this.onOpened);
    OneSignal.sendTag(AppConfig.DietStation.public, "1");

    HTTP.setNumberandPassword(this.props.userInfo.mobile, this.props.userInfo.password.length > 0 ?  this.props.userInfo.password : this.props.userInfo.auto_password);
    this._bootstrapAsync();
  }

  onReceived(notification) {
    console.log("Notification received: ", notification);
    let tempDict = notification.payload;
    NotificationManager.show({data: tempDict, type: "notification" });
  }

  onOpened(openResult) {
    console.log('Message: ', openResult.notification.payload.body);
    console.log('Data: ', openResult.notification.payload.additionalData);
    console.log('isActive: ', openResult.notification.isAppInFocus);
    let notificationData = openResult.notification.payload.additionalData;
    if(notificationData && notificationData.type && notificationData.type == 'Meal Selection' && notificationData.customer_date){
      this.props.navigation.navigate("ProductCalendar",{'mealDate': notificationData.customer_date});
    }
    else {
      this.props.navigation.navigate("App");
    }
  }

  _handleConnectivityChange = (isConnected) => {
    console.log('---------=' + isConnected);
    this.props.actions.UpdateConnection.getNetInfoAction(isConnected);
  };

  // Fetch the token from storage then navigate to our appropriate place
  _bootstrapAsync = async () => {
    const { userInfo } = this.props;
    // This will switch to the App screen or Auth screen and this loading 
    // screen will be unmounted and thrown away.
    if (userInfo.introComplete) {
       if (userInfo.isLogin) {
          let slider = returnRemainingSlider(userInfo);
          if (slider.length == 0) {
            this.props.navigation.navigate("App");
          } else {
            this.props.navigation.navigate('SignupScreen', { slide: slider });
          }
        } else {
          this.props.navigation.navigate("Auth");
        }
    } else {
      this.props.navigation.navigate("Onboard");
    }
    SplashScreen.hide();  
    NativeModules.AppDelegate && NativeModules.AppDelegate.stopGifAnimation();
  };

  // Render any loading content that you like here
  render() {
    return (
      <View style={styles.container}>
        {/* <StatusBar barStyle={Device.isIphoneX ?  "dark-content" : "light-content"} backgroundColor="black"/> */}
        {/* {this.props.companyDetails.isLoading ? <Spinner mode="overlay" /> : null} */}
        <Toast refrence={(refrence) => this.toast = refrence} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
      FetchMasterAction: bindActionCreators(FetchMasterAction, dispatch),
      UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
    }
  };
}

const mapStateToProps = (state) => ({
  Connected: state.updateNetInfoReducer.isConnected,
  languagess: state.switchLanguageReducer,
  userInfo: state.updateUserReducer,
  companyDetails: state.fetchMasterListReducer,
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AuthLoadingScreen);
