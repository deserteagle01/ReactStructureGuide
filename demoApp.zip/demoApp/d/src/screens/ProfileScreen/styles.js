import { StyleSheet, Dimensions, Platform } from "react-native";
import { Colors, Styles } from "@common";

export default  styles = StyleSheet.create({
    mainContainer:{
      flex:1,
      ...Platform.select({
        android: {
          marginTop: 20,
        },
      }),
    },
    customSafearea:{
      flex:1,
    },
    headerContainer:{
      height:112,
      backgroundColor:Colors.pinkishRed
    },
    headerIcon:{
      height:52,
      flexDirection:'row',
      alignItems:"flex-start",
      justifyContent:'flex-end',
      marginHorizontal:16
    },
    headerTitleContainer:{
      height:52,
      justifyContent:"flex-end",
    },
    headerTitle:{
      marginLeft: 16,
      color: Colors.white,
      fontSize: Styles.FontSize.fnt28,
      fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
      textAlign: 'left'
    },
    contentContainer:{
      flex:0.81,
      backgroundColor:'white'
    },
});
