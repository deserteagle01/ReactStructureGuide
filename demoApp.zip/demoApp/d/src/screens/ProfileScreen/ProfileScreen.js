import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  StatusBar,
  SafeAreaView,
  Image,
  TouchableOpacity,
  TextInput,
  I18nManager, ScrollView
} from "react-native";
import { Images, Colors, Styles, AppConfig } from "@common";
import { translate, setI18nConfig } from "@languages";
import { OutlineButton, NeedHelp, GradientButton, ProfileComponent, LogoutModal, Toast } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { NavigationActions, StackActions } from 'react-navigation';
import OneSignal from 'react-native-onesignal';

class ProfileScreen extends React.Component {
  constructor(props) {
    super(props);
  }

  canEdit() {
    if(this.props.signupDetail.test_user){
      this.toast.show(translate("NoPermission4TestUser"));
      return false;
    }else{
      return true;
    }
  }
  _onPressEditProfile = () => {
    if(this.canEdit()){
      this.props.navigation.navigate('EditProfile');
    }
  }
  _onPressDeliveryAddress = () => {
    if(this.canEdit()){
      this.props.navigation.navigate('EditAddress');
    }
  }
  _onPressProfileDislike = () => {
    if(this.canEdit()){
      this.props.navigation.navigate('ProfileDislike');
    }
  }
  _onPressRemindMe = () => {
    if(this.canEdit()){
    }
  }
  _onPressInviteFriends = () => {
    if(this.canEdit()){
      this.props.navigation.navigate("Wallet");
    }
  }
  _onPressAbout = () => {
    this.props.navigation.navigate('About');
  }
  _onPressChangePwd = () => {
    if(this.canEdit()){
      this.props.navigation.navigate('ChangePwd');
    }
  }
  _onPressLogout = () => {
    this.refs.logoutModal.toggleModal(true);
  }

  async onLogout() {
    this.refs.logoutModal.toggleModal(false);
    var reqParams = {
        lang: this.props.signupDetail.lang,
        introComplete: this.props.signupDetail.introComplete
    };
    await this.props.actions.UpdateUserAction.logoutAction(reqParams, {});
    await OneSignal.deleteTag(AppConfig.DietStation.private);
    await OneSignal.deleteTag(AppConfig.DietStation.user_id);
    await OneSignal.deleteTag(AppConfig.DietStation.gender);
    this.props.navigation.navigate("Auth");
 }

  onCancelLogout = () => {
    this.refs.logoutModal.toggleModal(false);
  }

  componentDidMount() {
    this._getHomeDetail();
  }
  componentWillReceiveProps(nextProps){
		if(this.props !== nextProps){
            if(this.props.homeData !== nextProps.homeData && nextProps.homeData.error != null){
                this.toast.show(nextProps.homeData.error);
            }
		} 
	}

  _getHomeDetail = () => {
    if (this.props.Connected) {
        this.props.actions.HomeAction.getHomeDataAction(true);
    } else {
        this.toast.show(translate("InternetToast"));
    }
}
  // Render any loading content that you like here
  render() {
    return (
      <View style={styles.mainContainer}>
      <SafeAreaView style={[Styles.common.safeareView0]}/>
      <StatusBar
          barStyle="light-content"
          backgroundColor={Colors.pinkishRed}
          translucent={true} /> 
          <View style={styles.headerContainer}>
            <View style={styles.headerIcon}>
              <NeedHelp showIcon={true} notificationPress={() => this.props.navigation.navigate("NotificationList")} />
            </View>
            <View style={styles.headerTitleContainer}>
              <Text style={styles.headerTitle}>{translate("Profile")}</Text>
            </View>
          </View>
          <ScrollView style={styles.contentContainer}>
            <TouchableOpacity onPress={() => this._onPressEditProfile()}>
              <ProfileComponent
                icon={Images.icons.profile}
                mainText={translate("ProfileEdit")}
                subText={translate("ProfileEditSubText")} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { this._onPressDeliveryAddress() }}>
              <ProfileComponent
                icon={Images.icons.location}
                mainText={translate("DeliveryAddress")}
                subText={translate("DeliveryAddressSubText")+" "+this.props.signupDetail.addresses.length+" "+translate("AddressActive")}/>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this._onPressProfileDislike()}>
              <ProfileComponent
                icon={Images.icons.dislike}
                mainText={translate("Dislikes")}
                subText={this.props.signupDetail.dislike_category_ids.length + " " + translate("Dislikes")} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { this._onPressRemindMe() }}>
              <ProfileComponent
                icon={Images.icons.remind}
                mainText={translate("RemindMe")}
                subText={translate("RemindMeSubText")} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { this._onPressInviteFriends() }}>
              <ProfileComponent
                icon={Images.icons.invite}
                mainText={translate("InviteFriends")}
                subText={translate("InviteFriendsSubText")} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { this._onPressAbout() }}>
              <ProfileComponent
                icon={Images.icons.phone}
                mainText={translate("About")}
                subText={translate("AboutSubText")} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { this._onPressChangePwd() }}>
              <ProfileComponent
                icon={Images.icons.password}
                mainText={translate("ChangePassword")}
                subText={""} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { this._onPressLogout() }}>
              <ProfileComponent
                isLast={true}
                icon={I18nManager.isRTL ? Images.icons.logout_right : Images.icons.logout}
                mainText={translate("Logout")}
                subText={""} />
            </TouchableOpacity>
          </ScrollView>      
          <Toast refrence={(refrence) => this.toast = refrence} />
        <LogoutModal ref={"logoutModal"} onLogout={() => this.onLogout()} onCancel={this.onCancelLogout} />
      </View>
    );
  }
}


function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  return {
      ...ownProps,
      ...stateProps,
      actions: {
          UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
          HomeAction: UpdateUserAction.bindActionCreators(dispatch, stateProps)
      }
  };
}

const mapStateToProps = (state) => {
  return {
    signupDetail: state.updateUserReducer,
    homeData: state.updateUserReducer,
    Connected: state.updateNetInfoReducer.isConnected,
  };
};


export default connect(mapStateToProps, undefined, mergeProps)(ProfileScreen);
