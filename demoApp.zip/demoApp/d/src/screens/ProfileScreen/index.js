import Profile from "./ProfileScreen";
export default Profile;
