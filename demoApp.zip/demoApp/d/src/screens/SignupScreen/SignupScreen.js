/** @format */

import React, { PureComponent, useRef } from "react";
import _ from 'lodash';
import { connect } from "react-redux";
import styles from "./styles";
import { View, Text, ImageBackground, Image, TouchableOpacity, I18nManager, Dimensions, BackHandler } from "react-native";
import { Images, Styles } from "@common";
import { translate, setI18nConfig } from "@languages";
import { Spinner, Toast, NeedHelp, LanguageSwitcher, PrivacyPolicy, FullButton, 
		SignupName, SignupFamilyName, SignupMobile, SignupAddress,SignupAddressDetail, 
		SignupDeliveryTime, SignupStartTime, AccountExist, ConfirmDetail, ForgetPassword, 
		ChoosePassword, AlmostThere, AlmostThereBirthdate, TellUsAbout, HeightContainer, 
		WeightContainer, Communicationname,DislikeOption, NotificationOn, OTPContainer, AppointmentSuccessPopup, SimpleModalWithButton } from "@components";
import { bindActionCreators } from "redux";
import * as SwitchLanguage from "../../redux/Actions/SwitchLanguageAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as PaymentAction from "../../redux/Actions/Payment";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { firebase } from '@react-native-firebase/analytics';
import HTTP from "../../webservice/http";
import Carousel, { getInputRangeFromIndexes } from 'react-native-snap-carousel';
import { screens } from "../../common/Utility";
import PaymentComponent from "../../components/PaymentComponent";
const { height, width } = Dimensions.get("window");
import { NavigationActions, StackActions } from 'react-navigation';

class SignupScreen extends PureComponent {
	constructor(props) {
		super(props);
		this.state = {
			text: '',
			visibleView: 0,
			currentView: this.props.navigation.state.params.slide ? this.props.navigation.state.params.slide[0] : screens.firstname,
			allView: this.props.navigation.state.params.slide ? [this.props.navigation.state.params.slide[0]] : [screens.firstname],
			only_slide: this.props.navigation.state.params.slide ? this.props.navigation.state.params.slide : [],
			isFrom: this.props.navigation.state.params.isFrom ? this.props.navigation.state.params.isFrom : "",
			scrollEnabled: true,
			mobile: ''
		};
		this.gotoNext = this.gotoNext.bind(this)

		this.firstname = React.createRef();
		this.lastname = React.createRef();
		this.mobilenumber = React.createRef();
		this.address1 = React.createRef();
		this.address2 = React.createRef();
		this.shift = React.createRef();
		this.startdate = React.createRef();
		this.accountexist = React.createRef();
		this.forgetpass = React.createRef();
		this.confirmdetail = React.createRef();
		this.paymentScreen = React.createRef();
		this.passwordScreen = React.createRef();
		this.emailScreen = React.createRef();
		this.birthScreen = React.createRef();
		this.genderScreen = React.createRef();
		this.heightScreen = React.createRef();
		this.weightScreen = React.createRef();
		this.comnameScreen = React.createRef();
		this.dislikeScreen = React.createRef();
		this.notificationScreen = React.createRef();
		BackHandler.addEventListener('hardwareBackPress', this.onBackPress);
	}

	componentDidMount() {
		setI18nConfig("ar",false);
	}

	componentWillUnmount() {
		BackHandler.removeEventListener('hardwareBackPress', this.onBackPress);
	}

	componentWillMount() {
		setI18nConfig("ar",false);
	}

	onBackPress = () => {
		this.onBackArrowPress();
		return true;
	}
	
	_changeLanguage = (lang, isRTL) => {
		const { switchLanguage, switchRtl } = this.props;
		let isRTLS = false;
		if(this.props.switcher.lang == 'ar') {
			isRTLS  =true;
		}
		setI18nConfig(lang, isRTLS);
		this.props.switchLanguage({ lang: lang, rtl: isRTLS });
		this.forceUpdate();
	};

	_updateScreen = (lang, isRTL) => {
		I18nManager.forceRTL(isRTL);
		this.forceUpdate();
		this.props.actions.UpdateUserAction.updateUserDetails({com_lang: lang});
	}

	_SlideUp = () => {
		this._carousel.snapToPrev()
	}

	findCurrentRef(switchCause) {
		var currentRef = null;
		switch (switchCause) {
			case screens.firstname :
				currentRef = this.firstname.current;
				break;
			case screens.lastname :
				currentRef = this.lastname.current;
				break;
			case screens.mobile :
				currentRef = this.mobilenumber.current;
				break;
			case screens.address1 :
				currentRef = this.address1.current;
				break;
			case screens.address2 :
				currentRef = this.address2.current;
				break;
			case screens.shift :
				currentRef = this.shift.current;
				break;
			case screens.startdate :
				currentRef = this.startdate.current;
				break;
			case screens.accountexist :
				currentRef = this.accountexist.current;
				break;
			case screens.forgetpass :
				currentRef = this.forgetpass.current;
				break;
			case screens.confirmdetail :
				currentRef = this.confirmdetail.current;
				break;
			case screens.paymentScreen :
				currentRef = this.paymentScreen.current;
				break;
			case screens.password :
				currentRef = this.passwordScreen.current;
				break;
			case screens.email :
				currentRef = this.emailScreen.current;
				break;
			case screens.birthdate :
				currentRef = this.birthScreen.current;
				break;
			case screens.gender :
				currentRef = this.genderScreen.current;
				break;
			case screens.height :
				currentRef = this.heightScreen.current;
				break;
			case screens.weight :
				currentRef = this.weightScreen.current;
				break;
			case screens.comname :
				currentRef = this.comnameScreen.current;
				break;
			case screens.dislike :
				currentRef = this.dislikeScreen.current;
				break;
			case screens.enablenotification :
				currentRef = this.notificationScreen.current;
				break;
			default:
				break;
		}
		return currentRef;
	}
	
	async _SlideDown(param) {
		let currentRef = this.findCurrentRef(this.state.currentView);
		var slide = null;
		currentRef.validate(param).then((validation) => {
			//----------- (case  0 = validation fail ,  1 = validated and decide by parent,  -1 = validated and decide by child )
			switch (validation.result) {
				case 0 :
					break;
					
				case 1 :
					slide = this.findNextSlide(this.state.currentView);
					break;
				
				case -1 :
					slide = validation.nextSlide;
					if (validation && validation['sliderArray']){
						this.setState({ only_slide: validation['sliderArray'] });
					}
					break;
			}

			while(slide != null) {
				if(this.state.only_slide.length <= 0 || this.state.only_slide.includes(slide)) {
						this.gotoNext(slide);
						break;
				}else{
					slide = this.findNextSlide(slide);
				}
			}

			if(this.state.isFrom == "Home") {
				if(validation.result == 1 && (slide == undefined || slide == null)) {
					this.props.navigation.navigate('Home')
				}
			}
			else{
				if(validation.result == 1 && (slide == undefined || slide == null)){
					this.props.navigation.navigate('LoadingScreen')
				}
			}

			//TODO: we should remove this in future
			if(this.state.only_slide.includes(screens.forgetpass) && (slide == undefined || slide == null)) {
				this.props.navigation.navigate('App')
			}

		})
	}

	findNextSlide(currentView) {
		var slide;
			switch (currentView) {
				case screens.firstname:
					slide = screens.lastname;
					break;

				case screens.lastname:
					slide = screens.mobile;
					break;

				case screens.mobile:
					slide = screens.address1;
					break;

				case screens.address1:
					slide = screens.address2;
					break;

				case screens.address2:
					slide = screens.shift;
					break;

				case screens.shift:
					if(this.props.planData.is_book_appointment == true){
						slide = screens.paymentScreen;
					}else{
						slide = screens.startdate;
					}
					break;

				case screens.forgetpass:
					slide = screens.confirmdetail;
					break;

				case screens.startdate:
					slide = screens.paymentScreen;
					break;

				case screens.paymentScreen:
					slide = screens.password;
					break;

				case screens.password:
					slide = screens.email;
					break;

				case screens.email:
					slide = screens.birthdate;
					break;

				case screens.birthdate:
					slide = screens.gender;
					break;

				case screens.gender:
					if(this.props.planData.is_book_appointment) {
						if(this.props.signupDetail.allow_change_plan){
							slide = screens.dislike;	
						}else{
							slide = screens.comname;
						}
					}else{
						slide = screens.height;
					}
					break;

				case screens.height:
					slide = screens.weight;
					break;
				
				case screens.weight:
					slide = screens.dislike;
					break;
				
				case screens.dislike:
					slide = screens.comname
					break;

				case screens.comname:
					slide = screens.enablenotification
					break;

				default:
					break;
			}

		return slide;
	}

	//first add the slide and then goto that slide
	async gotoNext(slide) {
		if(!this.state.allView.includes(slide)){
			await this.setState({ allView: [...this.state.allView, slide] });
			var nextRef = this.findCurrentRef(slide);
			setTimeout(() => {
				this._carousel.snapToNext()
				nextRef.init();
			}, 100);
		}
	}

	gotoPayContinue = () => {
		var reqParams = {
			first_name: this.props.signupDetail.first_name,
			last_name: this.props.signupDetail.last_name,
			mobile: this.props.signupDetail.mobile,
			area_id: this.props.signupDetail.area_id,
			block_id: this.props.signupDetail.block_id,
			street: this.props.signupDetail.street,
			street2: this.props.signupDetail.street2,
			avenue: this.props.signupDetail.avenue,
			lang: this.props.switchLanguageReducer.lang,
			secondary_firstname: this.props.signupDetail.secondary_firstname,
			secondary_lastname: this.props.signupDetail.secondary_lastname,
			com_lang: this.props.signupDetail.com_lang,
		};

		if(this.state.currentView == screens.shift){
			let currentRef = this.findCurrentRef(this.state.currentView);
			currentRef.validate(null).then((validation) => {
				if(validation.result == 1){
					reqParams.shift_id = this.props.signupDetail.shift_id;
					reqParams.is_book_appointment = this.props.planData.is_book_appointment;
					this.callRegisterUpdateUser(reqParams);
				}
			});
		}
		else{
			reqParams.shift_id = this.props.signupDetail.shift_id;
			reqParams.expected_plan_start_date = this.props.signupDetail.expected_plan_start_date;
			this.callRegisterUpdateUser(reqParams);
		}
	}

	callRegisterUpdateUser(reqParams){
		if (this.props.connected) {
			if (this.props.signupDetail.isLogin) {
				this.props.actions.UpdateUserAction.registerUpdateUser(reqParams).then(() => {
					if (this.props.signupDetail.error) {
						this.toast.show(this.props.signupDetail.error);
					} else {
						this.finishRegister();
					}
				});
			} else {
				this.props.actions.UpdateUserAction.registerUser(reqParams).then(() => {
					if (this.props.signupDetail.error) {
						this.toast.show(this.props.signupDetail.error);
					} else {
						this.finishRegister();
					}
				});
			}

		} else {
			this.toast.show(translate("InternetToast"));
		}
	}

	finishRegister() {
		HTTP.setNumberandPassword(this.props.signupDetail.mobile,this.props.signupDetail.password.length > 0 ? this.props.signupDetail.password : this.props.signupDetail.auto_password);
		let reqParam = {
			isPayment: null
		}
		this.props.actions.PaymentAction.updatePaymentStatus(reqParam);
		this._SlideDown(null);
	}

	gettingPaymentresult(payment) {
		if(payment){
			this.setState({allView: [this.state.currentView], visibleView: 0});
		}
	}

	openPrivacyPolicyModal = () => {
		this.refs.refPrivacyPolicy.togglePrivacyPolicyModal(true);
	}

	flagChange(flag) {
		
	}

	signUpToastShow(toastMsg) {
		this.toast.show(toastMsg);
	}

	beforepaymentComplete(param) {
		if(this.props.planData.is_book_appointment && this.props.planData.payment_method == "online") {
			this.refs.appointmentSuccess.show(this.props.planData);
		}
		else{
			this._SlideDown(param);
		}
	}

	_renderCaroselItem(item, index) {
		switch (item.item) {
			case screens.firstname:
				return (
					<SignupName ref={this.firstname} onOkClick={() => this._SlideDown(null)} />
				);
			case screens.lastname:
				return (
					<SignupFamilyName ref={this.lastname}  gotoPrev={() => { this._SlideUp() }} onOkClick={() => this._SlideDown(null)}/>
				);
			case screens.mobile:
				return (
					<SignupMobile ref={this.mobilenumber} singUpToast={(toastMsg) => this.signUpToastShow(toastMsg)} singUpLoading={(flag) => this.flagChange(flag)} gotoNext={() => { this.gotoNext() }} gotoPrev={() => { this._SlideUp() }}   onOkClick={() => this._SlideDown(null)}/>
				);
			case screens.address1:
				return (
					<SignupAddress ref={this.address1} singUpToast={(toastMsg) => this.signUpToastShow(toastMsg)} singUpLoading={(flag) => this.flagChange(flag)} gotoNext={() => { this._SlideDown(null) }} gotoPrev={() => { this._SlideUp() }} />
				);
			case screens.address2:
				return (
					<SignupAddressDetail ref={this.address2} singUpToast={(toastMsg) => this.signUpToastShow(toastMsg)} singUpLoading={(flag) => this.flagChange(flag)} gotoNext={() => { this._SlideDown(null) }} gotoPrev={() => { this._SlideUp() }} onOkClick={() => this._SlideDown(null)}/>
				);
			case screens.shift:
				return (
					<SignupDeliveryTime ref={this.shift} singUpToast={(toastMsg) => this.signUpToastShow(toastMsg)} isCheckedVisible={false} onShiftSelection={() => this._SlideDown(null)}  />
				);
			case screens.startdate:
				return (
					<SignupStartTime  ref={this.startdate} onOkClick={() => this._SlideDown(null)} singUpToast={(toastMsg) => this.signUpToastShow(toastMsg)} isCheckedVisible={false} gotoNext={() => { this.gotoNext() }} gotoPrev={() => { this._SlideUp() }} />
				);
			case screens.accountexist:
				return (
 					<AccountExist ref={this.accountexist} navigation={this.props.navigation} onContinueClick={(param) => this._SlideDown(param)}  />
				);
			case screens.forgetpass:
				return (
					<OTPContainer ref={this.forgetpass} mobile={this.props.signupDetail.mobile} isFrom={"forget"} setPassword={(param) => this._SlideDown(param)} />
				);
			case screens.confirmdetail:
				return (
					<ConfirmDetail  ref={this.confirmdetail} ContinueOrModifyPress={(param) => this._SlideDown(param)} />
				);
			case screens.paymentScreen:
				return (
					<PaymentComponent  navigation={this.props.navigation} isPaymentfrom={this.state.isFrom} ref={this.paymentScreen} onPaymentComplete={(param) => this.beforepaymentComplete(param)} paymentSuccess={(isPayment) => this.gettingPaymentresult(isPayment)} cancelPress={()=> {}}/>
				);
			case screens.password:
				return (
					<OTPContainer ref={this.passwordScreen} navigation={this.props.navigation} mobile={this.props.signupDetail.mobile} isFrom={"setpass"} setPassword={(param) => this._SlideDown(param)} />
				);
			case screens.email:
				return (
					<AlmostThere ref={this.emailScreen} navigation={this.props.navigation} onOkClick={() => this._SlideDown(null)}  />
				);
			case screens.birthdate:
				return (
					<AlmostThereBirthdate ref={this.birthScreen} navigation={this.props.navigation} onOkClick={() => this._SlideDown(null)} />
				);
			case screens.gender:	
				return (
					<TellUsAbout ref={this.genderScreen} navigation={this.props.navigation} genderSelection={() => this._SlideDown(null)} />
				);
			case screens.height:	
				return (
					<HeightContainer ref={this.heightScreen} navigation={this.props.navigation} heightSelection={() => this._SlideDown(null)} />
				);
			case screens.weight:	
				return (
					<WeightContainer ref={this.weightScreen} navigation={this.props.navigation} weightSelection={() => this._SlideDown(null)} />
				);
			case screens.comname:	
				return (
					<Communicationname ref={this.comnameScreen} navigation={this.props.navigation} continueClick={() => this._SlideDown(null)} />
				);
			case screens.dislike:	
				return (
					<DislikeOption ref={this.dislikeScreen} navigation={this.props.navigation} continueClick={(param) => this._SlideDown(param)} />
				);
			case screens.enablenotification:	
				return (
					<NotificationOn ref={this.notificationScreen} gotoNext={(param) => this._SlideDown(param)} gotoHome={() => this._SlideDown(null) } />
				);
			default:
				return (
					null
				);
		}
	}

	afterSlideChange(slideIndex) {
		var dictState = {
			visibleView: slideIndex,
			currentView: this.state.allView[slideIndex] 
		};
		if(slideIndex < this.state.visibleView) {
			/* TODO: remove the page only when we make the current page dirty, but not at the time of going to the previous page */
			let tempArr = this.state.allView.slice(0, -1);
			this.setState({allView:  tempArr});
			var currentRef = this.findCurrentRef(this.state.allView[slideIndex]);
			currentRef.init();
		}
		else{
			if(this.state.allView[slideIndex] == screens.password){
				dictState.visibleView = 0;
				dictState.allView = [screens.password]; 
				dictState.currentView = screens.password;
			}
			else if(this.state.allView[slideIndex] == screens.email && (slideIndex == this.state.allView.length-1)){
				dictState.visibleView = 0;
				dictState.allView = [screens.email]; 
				dictState.currentView = screens.email;
			}
		}
		this.setState(dictState);
	}

	onBackArrowPress() {
		if(this.state.currentView == screens.firstname){
			if(this.props.planData.is_book_appointment){
					this.refs.SimpleModalWithButton.toggleModal(true, translate("txtConfirmAreyouSure"), translate("txtAppointmentGobackWarning"));
				}else{
					this.gotoPreviousScreen();
				}
			}else{
				this._carousel.snapToPrev();
			}
		}

	gotoPreviousScreen() {
		setI18nConfig("en",false);
		this.forceUpdate();  
		var tempPlanData = _.cloneDeep(this.props.planData)
		for (var property in tempPlanData) {
			if (property in tempPlanData.savePlanDataDic && property != 'is_book_appointment') {
				tempPlanData[property] = tempPlanData.savePlanDataDic[property]
			}
		}   
		tempPlanData.isFromSignUpScreen = true 
		const resetAction = StackActions.reset({
			index: 0,
			actions: [NavigationActions.navigate({ routeName: 'LoginScreen', params: { modalReOpenPlanData: tempPlanData } })],
		});
		this.props.navigation.dispatch(resetAction);
	}
	
	render() {
		isForgetPass = this.state.only_slide.includes(screens.forgetpass)
		return (
			<ImageBackground
				source={isForgetPass ? Images.LoginBackground2 : Images.SignupBackground}
				style={[Styles.common.imgContainer]}
				resizeMode="cover">
				<View style={styles.mainContainer}>
					<View style={{ flex: 1 }}>
						<Carousel
							ref={(c) => { this._carousel = c; }}
							data={this.state.allView}
							renderItem={(item, index) => this._renderCaroselItem(item, index)}
							sliderHeight={height}
							itemHeight={height}
							containerCustomStyle={{ backgroundColor: 'transparent', flexGrow: 0, }}
							vertical={true}
							useScrollView={true}
							inactiveSlideOpacity={0.1}
							inactiveSlideScale={0.5}
							onSnapToItem={(slideIndex) => this.afterSlideChange(slideIndex)} />
					</View>

					{ this.state.currentView != screens.paymentScreen && this.state.currentView != screens.dislike && this.state.currentView != screens.enablenotification && this.state.currentView != screens.email && this.state.currentView != screens.password &&
						<View style={styles.helpContainer}>
							<View>
							<TouchableOpacity onPress={() => this.onBackArrowPress()}>
								<Image style={styles.backIcon} source={Images.icons.left} />
							</TouchableOpacity>
							</View>
							<NeedHelp lang={this.props.signupDetail.com_lang} />
						</View>
					}
					
					{this.state.currentView != screens.accountexist && this.state.currentView != screens.forgetpass && this.state.currentView != screens.confirmdetail && this.state.currentView != screens.paymentScreen && this.state.currentView != screens.gender && this.state.currentView != screens.dislike && this.state.currentView != screens.enablenotification && this.state.isFrom != "Home" && (this.props.planData.is_book_appointment == true && this.state.currentView != screens.shift) &&
						this.renderButtonContainer()
					}

					{this.state.currentView == screens.firstname  && !I18nManager.isRTL ?
						<View style={styles.langPopupContainer}>
							<LanguageSwitcher updateScreen={this._updateScreen} isfor={'comminication_language'}></LanguageSwitcher>
						</View>
						:
						null
					}
					{this.state.currentView == screens.startdate || (this.state.currentView == screens.shift && this.props.planData.is_book_appointment == true)?
						<View style={styles.termContainer}>
							<FullButton onPress={this.gotoPayContinue} btnStyle={styles.btnContinue} textStyle={styles.textStyle(this.props.signupDetail.com_lang)} label={(this.props.planData.is_book_appointment == true && this.props.planData.payment_method == "cash") ? translate("Continue") : translate("ContinuePay")} />
							<Text style={[styles.termTextSmall, { fontFamily: Styles.FontFamily(this.props.signupDetail.com_lang).ProximaNova }]}>{translate("ByClickingContinue")}</Text>
							<Text onPress={this.openPrivacyPolicyModal} style={[styles.termTextSmall, { fontFamily: Styles.FontFamily(this.props.signupDetail.com_lang).ProximaNovaBold }]}>{translate("TermConditions")}</Text>
						</View>
						:
						null
					}
					<PrivacyPolicy ref={"refPrivacyPolicy"} gotoNext={this.gotoPayContinue}></PrivacyPolicy>
				</View>
				<SimpleModalWithButton 
					ref={"SimpleModalWithButton"} 
					onClose={() => this.refs.SimpleModalWithButton.toggleModal(false)}  
					onConfirm={() => this.gotoPreviousScreen()}
					btLeftText={"cancel"}
					btRightText={"txtGoback"} />
				<AppointmentSuccessPopup  ref={"appointmentSuccess"} onClosePopup={() => this._SlideDown(null)} />
				{(this.props.masterData.isLoading) || this.props.signupDetail.isLoading ? <Spinner mode="overlay" /> : null}
				<Toast refrence={(refrence) => this.toast = refrence} />
			</ImageBackground>
		);
	}

	renderButtonContainer() {
			return (
				<View style={[styles.buttonContainer,this.state.currentView == screens.startdate ? styles.btContianer : null ]}>
					<View style={styles.whiteIconContainer}>
							<TouchableOpacity style={styles.btTouchable} disabled={this.state.currentView == screens.firstname  ? true : false }
								onPress={() => {
									this._SlideUp();
								}}>
								<Image style={[styles.updownIcon, this.state.currentView == screens.firstname ? styles.disableOpcity : ""]} source={Images.icons.upcircle} />
							</TouchableOpacity>
					</View>
	
					<View style={[styles.whiteIconContainer]}>
						<TouchableOpacity style={styles.btTouchable} onPress={() => this._SlideDown(null)} disabled={this.state.currentView == screens.startdate  ? true : false} >
								<Image style={[styles.updownIcon,this.state.currentView == screens.startdate ? styles.disableOpcity : ""]} source={Images.icons.downcircle} />
							</TouchableOpacity>
					</View>
	
				</View>
			);
	}
}


const mapStateToProps = (state) => {
	return {
		connected: state.updateNetInfoReducer.isConnected,
		signupDetail: state.updateUserReducer,
		success: state.updateUserReducer.successRegister,
		paymentReducer: state.PaymentReducer,
		switchLanguageReducer: state.switchLanguageReducer,
		masterData: state.fetchMasterListReducer,
		switcher: state.switchLanguageReducer,
		planData: state.PlanReducer
	}
}


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			SwitchLanguage: bindActionCreators(SwitchLanguage, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
			PaymentAction: bindActionCreators(PaymentAction, dispatch)
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(SignupScreen);