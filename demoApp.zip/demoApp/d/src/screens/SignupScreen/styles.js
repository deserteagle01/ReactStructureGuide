import { StyleSheet, Dimensions, Platform } from "react-native";
import { Colors, Styles } from "@common";
import DeviceInfo from 'react-native-device-info';
const { height, width } = Dimensions.get("window");

export default styles = StyleSheet.create({
	mainContainer: {
		flex:1,
		...Platform.select({
			android: {
			  marginTop: 20,
			},
		}),
		paddingHorizontal:15,
	},
	helpContainer: {
		height: 44,	
		position:'absolute',
		top: DeviceInfo.hasNotch() ? (Dimensions.get('window').height)*0.06 : (Dimensions.get('window').height)*0.04,
		width:'100%',
		alignItems:'center',
		alignSelf:'center',
		flexDirection:'row',
		justifyContent:'space-between',
	},
	backIcon:{
		height:35,
		width:35
	  },
	whiteIconContainer: {
		flex: 0.495,
		height:'100%',
		backgroundColor: Colors.white,
		justifyContent:'center',
		alignItems: 'center'
	},
	buttonContainer: {
		position: "absolute",
		bottom: 23,
		right:15,
		flexDirection: 'row',
		justifyContent:'space-between',
		width: width*0.30,
		aspectRatio: 2.5,
		borderRadius: 8,
		overflow:'hidden',
	},
	btContianer:{
		bottom: DeviceInfo.hasNotch() ?  height*0.18 : height*0.22
	},
	enabled:{
		opacity: 1.0
	},
	disabled:{
		opacity: 0.5
	},
	downArrow:{
		 alignItems:'flex-end'
	},
	updownIcon: {
		height: '45%',
		aspectRatio: 1.0
	},
	btTouchable: {
		height:'100%',
		width:'100%',
		alignItems:'center',
		justifyContent:'center'
	},
	disableOpcity: {
		opacity: 0.4,
	},
	langPopupContainer: {
		width: "35%",
		alignSelf:'center',
		position: "absolute",
		bottom: 34,
		alignItems: "center",
	},
	fulWidthBtn: {
		width: "100%",
		marginTop: 10,
	},
	textStyle:(lang) => ({
		color: Colors.pinkishRed,
		fontSize: Styles.FontSize.fnt17,
		fontFamily: Styles.FontFamily(lang).ProximaNovaBold
	}),
	btnContinue: {
		backgroundColor: Colors.white,
		height: 56,
		borderRadius: 8,
		alignItems: "center",
		justifyContent: "center",
		borderWidth: 1,
		borderColor: Colors.white,
		marginBottom: 12,
		width:'100%'
	},
	termContainer: {
		width: "100%",
		bottom: 32,
		alignItems: "center",
		justifyContent: "center",
	},
	termTextSmall: {
		textAlign: 'center',
		fontSize: Styles.FontSize.fnt10,
		color: Colors.white,
	},
});