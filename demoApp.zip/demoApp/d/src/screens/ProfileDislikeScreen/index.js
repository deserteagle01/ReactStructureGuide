import ProfileDislike from "./ProfileDislikeScreen";
export default ProfileDislike;
