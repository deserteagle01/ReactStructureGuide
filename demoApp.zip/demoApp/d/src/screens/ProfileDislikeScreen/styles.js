import { StyleSheet, Dimensions, Platform, I18nManager } from "react-native";
import { Images, Styles, Colors } from "@common";
const screen = Dimensions.get("window");

export default  styles = StyleSheet.create({
  mainContainer:{
    flex:1,
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  customSafearea:{
    flex:1,
    backgroundColor: 'white'
  },
  headerContainer:{
    flex:0.20,
    flexDirection:'column',
    justifyContent:"center",
    backgroundColor: Colors.pinkishRed,
    paddingTop:14,
    paddingBottom:16,
  },
  headerNavigationContainer:{
    flex:0.5,
    flexDirection:'row',
    justifyContent:"center",
    backgroundColor:'transparent'
  },
  searchBarContainer:{
    flex:0.5,
    backgroundColor:'transparent',
    justifyContent:"center",
    marginTop:8
  },
  searchContainer:{
      marginTop:4,
      height:44,
      flexDirection: 'row',
      backgroundColor: 'white',
      borderColor: 'rgba(242, 243, 244, 1)',
      borderWidth: 1,
      borderRadius: 22,
      marginHorizontal: 16,
      paddingHorizontal: 15,
      alignItems: 'center',
  },
  searchText:{
      flex: 1,
      height: 42,
      color: Colors.darkNavyBlue,
      fontSize: Styles.FontSize.fnt14,
      fontFamily: Styles.FontFamily().ProximaNova,
      marginLeft: 8,
      //paddingLeft: 10,
      textAlign: I18nManager.isRTL ? 'right' : 'left',
  },
  searchIcon:{
      width: 23,
      height: 24
  },
  headerIconContainer:{
    flex:1,
    flexDirection:'row',
    marginTop:23,
    marginHorizontal:16,
    backgroundColor:'grey',
    justifyContent:'center'
  },
  headerIcon:{
    flex:0.15,
    alignItems:'flex-start',
    alignSelf:'center',
    padding:8
  },
  backIcon:{
    width:28,
    height:28
  },
  headerTitleContainer:{
    flex:0.8,
    justifyContent:'center',
    alignSelf:'center',
    alignItems:'center',
  },
  headerTitle:{
    color: Colors.white,
    alignSelf:'center',
    fontSize: Styles.FontSize.fnt17,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    lineHeight:36,
  },
  contentContainer:{
    flex:0.80,
    backgroundColor:Colors.white
  },
  headerRightView:{
    flex:0.15,
    alignSelf:'center',
    marginRight:16,
    alignItems:'flex-end',
  },
  saveBtn:{
    color: Colors.white,
    alignSelf:'center',
    fontSize: Styles.FontSize.fnt15,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
  },
  dislikeListContainer:{
      marginTop: 8,
      marginStart: 16,
      marginBottom: 10,
      backgroundColor:Colors.white
  },
  dislikeCountText:{
    marginTop: 16,
    marginStart: 17,
    color: Colors.reddishGrey,
    fontSize: Styles.FontSize.fnt13,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    textAlign:'left'
  },
});
