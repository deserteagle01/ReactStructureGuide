/** @format */

import React, { Component } from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {View, Text, filter, FlatList, StatusBar, SafeAreaView, Image, TouchableOpacity, I18nManager, TextInput} from "react-native";
import { Images, Colors, Styles } from "@common";
import { translate } from "@languages";
import { DisLikeRow,SimpleMessageModal } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import { Spinner } from "@components";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

var tempArr = [];

class ProfileDislikeScreen extends Component {
	constructor(props) {
		super(props);
		this.state={
			filterDislikeList:null,
			selectedDislike: (this.props.signupDetail.dislike_category_ids).slice(0),
			singDislikeCategoriesError: null,
		}
	}

	componentDidMount(){
		if(this.props.connected){
			this.props.actions.MasterList.fetchDislikeDataList().then(() => {
				for (let i = 0; i < this.props.dislikeMaster.length; i++) {
					this.props.dislikeMaster[i].isChecked = false;
					for( j = 0; j < this.state.selectedDislike.length; j++){
						if (parseInt(this.state.selectedDislike[j]) == parseInt(this.props.dislikeMaster[i].value)) {
							this.props.dislikeMaster[i].isChecked = true;
						}
					}
				}
				this.setState({ filterDislikeList: this.props.dislikeMaster });
			}).catch(e => {

			});
		}else{
      for (let i = 0; i < this.props.dislikeMaster.length; i++) {
        this.props.dislikeMaster[i].isChecked = false;
        for( j = 0; j < this.state.selectedDislike.length; j++){
          if (parseInt(this.state.selectedDislike[j]) == parseInt(this.props.dislikeMaster[i].value)) {
            this.props.dislikeMaster[i].isChecked = true;
          }
        }
      }
      this.setState({ filterDislikeList: this.props.dislikeMaster });
		}
	}

	searchFilterDislike = (text) => {
		const newData = this.props.dislikeMaster.filter(item => {
		  	const itemData = `${item.label.toUpperCase()} ${item.label.toUpperCase()} ${item.label.toUpperCase()}`;
		   	const textData = text.toUpperCase();
		   	return itemData.indexOf(textData) > -1;
		});
		this.setState({ filterDislikeList: newData });
	};

	selectDislike = (selectItem) =>{
		if(!selectItem.isChecked){
      var index = this.state.selectedDislike.indexOf(selectItem.value);
			this.state.selectedDislike.push(selectItem.value);
		}else{
			var index = this.state.selectedDislike.indexOf(selectItem.value);
			this.state.selectedDislike.splice(index, 1);
		}
		selectItem.isChecked = !selectItem.isChecked;
		this.setState({ filterDislikeList: this.state.filterDislikeList});
	}
  onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
	};
  _onPressSave = ()=> {
    // var ids = this.state.filterDislikeList.filter(item=>item.isChecked==true).map(item=>item.value)
    var ids = this.state.selectedDislike;
    this.props.actions.UpdateUserAction.DislikeCategoryAction(ids).then(() => {
            setTimeout(()=>{
              if(this.props.signupDetail.sucessDislikeCategory){
								this.props.navigation.pop();
              }else{
                this.refs.simpleMessageModal.toggleModal(true,this.props.signupDetail.errorDislikeCategory,translate("Error"));
              }

            },500);
      })
      .catch(e => {
            console.log('dislike category error--> ' + e);
      });
  }

	_renderItem = ({ item }) => {
		return (
			<DisLikeRow onPress={(itemReturn) => this.selectDislike(item)}  item={item} isFrom={"Profile"} app_Lang={this.props.signupDetail.lang}/>
		);
	}

	render() {
		return (
      <View style={{flex:1}}>
      <SafeAreaView style={[Styles.common.safeareView0]} />
      <SafeAreaView style={styles.customSafearea}>
          <StatusBar
              barStyle="light-content"
              backgroundColor={Colors.pinkishRed}
              translucent={true} />
          <View style={styles.mainContainer}>
              <View style={styles.headerContainer}>
                  <View style={styles.headerNavigationContainer}>
                      <TouchableOpacity style={styles.headerIcon} onPress={() => this.props.navigation.pop()}>
                          <Image
                            source={this.props.languageReducer.lang == "ar" ? Images.icons.right : Images.icons.left}
                            defaultSource={Images.icons.left}
                            style={styles.backIcon}
                          />
                      </TouchableOpacity>
                      <View style={styles.headerTitleContainer}>
                        <Text style={styles.headerTitle}>{translate("Dislikes")}</Text>
                      </View>
                      <View style={styles.headerRightView}>
                          <TouchableOpacity style={{}} disabled={this.state.disableSave} onPress={() => this._onPressSave()}>
                              <Text style={styles.saveBtn}>{translate("Save")}</Text>
                          </TouchableOpacity>
                      </View>
                  </View>
                  <View style={styles.searchBarContainer}>
                      <View style={styles.searchContainer}>
            							<Image style={[styles.searchIcon]} source={I18nManager.isRTL ? Images.icons.rightSearchIcon : Images.icons.leftSearchIcon} />
            							<TextInput style={[styles.searchText]} selectionColor={Colors.darkNavyBlue} placeholderTextColor={Colors.black04} placeholder={translate('Search')} onChangeText={text => this.searchFilterDislike(text)} autoCorrect={false} />
            					</View>
                  </View>
              </View>
              <KeyboardAwareScrollView style={styles.contentContainer} keyboardShouldPersistTaps={'always'}>
                  <Text style={styles.dislikeCountText}>{this.state.selectedDislike.length + " " + translate("Dislikes")}</Text>
                  <View style={styles.dislikeListContainer}>
                    <FlatList
                      data={this.state.filterDislikeList}
                      keyExtractor={(item, index) =>  index.toString()}
                      renderItem={this._renderItem}
                      extraData={this.state}
                    />
                  </View>
              </KeyboardAwareScrollView>

          </View>
        </SafeAreaView>
        {this.props.isLoadingDislikeCategory ? <Spinner mode="overlay" /> : null}
        <SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose}
        />
        </View>
		);
	}
}

const mapStateToProps = (state) => {
	return {
		connected: state.updateNetInfoReducer.isConnected,
		isLoadingDislikeCategory: state.updateUserReducer.isLoadingDislikeCategory,
    isLoading: state.fetchMasterListReducer.isLoading,
		dislikeMaster: state.fetchMasterListReducer.dislikes,
    signupDetail: state.updateUserReducer,
    languageReducer: state.switchLanguageReducer
	}
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(ProfileDislikeScreen);
