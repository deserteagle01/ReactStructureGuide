import Meal from "./MealScreen";
export default Meal;
