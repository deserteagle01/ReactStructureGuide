import { StyleSheet, Dimensions } from "react-native";
import { Images, Styles, Colors } from "@common";
const screen = Dimensions.get("window");

export default  styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
    },
  });
  