import React from "react";
import { connect } from "react-redux";
import styles from "./styles";

import { View, Text, StyleSheet } from "react-native";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";


class MealScreen extends React.Component {
  constructor(props) {
    super(props);
  }

  // Render any loading content that you like here
  render() {
    return (
      <View style={styles.container}>
        <Text>Meal Screen</Text>
      </View>
    );
  }
}


function mapDispatchToProps(dispatch) {
  return {
    actions: {
      UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
    }
  };
}

const mapStateToProps = (state) => ({
  Connected: state.updateNetInfoReducer.isConnected
});

export default connect(mapStateToProps, mapDispatchToProps)(MealScreen);
