import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
	View,
	Text,
	StatusBar,
	SafeAreaView,
	Image,
	TouchableOpacity, I18nManager, Animated,Easing,PanResponder,TouchableWithoutFeedback,DeviceEventEmitter
} from "react-native";
import ReactNativeHapticFeedback from "react-native-haptic-feedback";
import { Images, Styles, Colors } from "@common";
import { translate } from "@languages";
import { SimpleMessageModal, Spinner, Toast,
	ProductDiscardChangeModal, CalendarStrip, ProductMainContentContainer, ProductRateModel, SelectionModal } from "@components";
import LinearGradient from 'react-native-linear-gradient';
import { bindActionCreators } from "redux";
import * as mealsAction from "../../redux/Actions/mealsAction";
import * as mealsErrorAction from "../../redux/Actions/mealsErrorAction";
var Sound = require('react-native-sound');
import FastImage from 'react-native-fast-image'

import moment from 'moment';
import 'moment/locale/ar';
import 'moment/locale/en-gb';
import { ACTION_TYPE_MEALS, ACTION_TYPE_MEALS_ERROR } from '../../redux/Actions/ActionType';
class ProductListScreen extends React.Component {

	constructor(props) {
		super(props);
		this.attributeCalArr = [{'name':translate('CALORIES').toUpperCase(),count:0},{'name':translate('Protein').toUpperCase(),count:0},
										{'name':translate('Carbs').toUpperCase(),count:0},{'name':translate('Fat').toUpperCase(),count:0}];
		this.state = {
			isLoading: false,
			caloriesCount:this.attributeCalArr,
			nextAttributeIndex:0,
			scale: new Animated.Value(1),
			selectedDislike: (this.props.signupDetail.dislike_category_ids).slice(0),
			showCalorieBtn:false,
			selectedValues: [],
			product_filters: {},
			userSelectedMeals: {}
		}
		this.isParentClose = false;
	}
	componentDidMount() {
		this.setDataForMeals(this.props.selectedDate);
	}

	
	componentWillReceiveProps(nextProps){
		if(this.state.date !== nextProps.selectedDate){
		this.setDataForMeals(nextProps.selectedDate);
		}
		else{
			if(this.props !== nextProps){
				const lastActionType = nextProps.mealDetail.action_type;
				const lastActionTypeErrorRedux = nextProps.mealErrorDetail.action_type;
			    if(lastActionType == ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_ERROR && nextProps.mealDetail.error){
			        this.setState({isLoading: false});
			        this.refs.simpleMessageModal && this.refs.simpleMessageModal.toggleModal(true, nextProps.mealDetail.error);
			    }
			    else if(lastActionTypeErrorRedux == ACTION_TYPE_MEALS_ERROR.UPDATE_USER_MEAL_PLAN_ERROR_NEW && nextProps.mealErrorDetail.error){
			         this.setState({isLoading: false});
			         this.onMealUpdateError(nextProps);
				}
			    else if(lastActionType == ACTION_TYPE_MEALS.UPDATE_MEAL_PAUSEUNPAUSE_PLAN_SUCCESS){
			         this.setState({isLoading: false,currSelectedStatus: nextProps.mealDetail.userProduct[this.state.date].status});
				}
			    else if(lastActionType == ACTION_TYPE_MEALS.UPDATE_USER_MEAL_PLAN_SUCCESS){
				    this.setState({isLoading: false});
			         this.onMealUpdate(nextProps.mealDetail.nextMealDate);
			    }
			}
		 }
	}

	onMealUpdate = (nextMealDate) => {
		if(nextMealDate){
			this.fetchNextDateProductList(nextMealDate);
		}
		else{
			this.clearFilterandDateCloseModel();
		}
	}

	onMealUpdateError = (nextProps) => {
		this.refs.productDiscardChangeModal.toggleModal(true, '', nextProps.mealErrorDetail.error, translate("cancel"), translate("Discard"), () => {
			this.refs.productDiscardChangeModal.toggleModal(false);
			this.props.actions.mealsErrorAction.clearError();
		}, () => {
			this.refs.productDiscardChangeModal.toggleModal(false);
			this.onMealUpdate(nextProps.mealErrorDetail.nextMealDate);
			this.props.actions.mealsErrorAction.clearError();
		});
	}

	setDataForMeals(selectedDate) {
			this.setState({ date:selectedDate, currSelectedStatus: this.props.mealDetail.userProduct[selectedDate].status,
				todayEnDate: moment(selectedDate).lang("en-gb").format('DD MMMM YYYY').toUpperCase(),
				todayArDate: moment(selectedDate).lang("ar").format('DD MMMM YYYY').toUpperCase(),isLoading:false
			},() => {
				this.setAnimation(940,1000);
				this.doCaloriesCalculation();
			});
	}

	doCaloriesCalculation = () => {
		let calCount = [];
		for(let item of this.attributeCalArr){
			calCount.push({...item});
		}
		var showCalorieBtn=false;
		var selected_items_count = 0;
		let selected_meals = this.state.userSelectedMeals[this.state.date];
		for (let key in selected_meals) {
			if(selected_meals[key].selected_items!==undefined && selected_meals[key].selected_items!==[]){
				selected_items_count += selected_meals[key].selected_items.length
			}
		  if (selected_meals[key].is_header && selected_meals[key].selected_items.length > 0){	
				showCalorieBtn=true;
				for(let i=0; i < selected_meals[key].selected_items.length ; i++){
					let item = selected_meals[key].selected_items[i];
					let qty = item.quantity || 0;
					calCount[0].count = calCount[0].count + ((item.calorie || 0)* qty);
					calCount[1].count = calCount[1].count + ((item.protein || 0) * qty)
					calCount[2].count = calCount[2].count + ((item.carb || 0) * qty)
					calCount[3].count = calCount[3].count + ((item.fat || 0) * qty)
				}
		  }
		}
		this.setState({caloriesCount : calCount,
			showCalorieBtn:showCalorieBtn
		},()=>{
			if(selected_items_count == 1 ){
			this.setAnimation(200,200);
		}
	});
	}

	showNextAttributeCalculation = () =>{
		if(this.state.nextAttributeIndex < (this.state.caloriesCount.length -1)){
			this.setState({nextAttributeIndex:this.state.nextAttributeIndex+1})
		}else {
			this.setState({nextAttributeIndex:0})
		}
	}

	playSound = () => {
		// Enable playback in silence mode
		Sound.setCategory('Playback');

		// Load the sound file 'whoosh.mp3' from the app bundle
		// See notes below about preloading sounds within initialization code below.
		var whoosh = new Sound('sms.mp3', Sound.MAIN_BUNDLE, (error) => {
		  if (error) {
		    console.log('failed to load the sound', error);
		    return;
		  }
		  // loaded successfully
		  console.log('duration in seconds: ' + whoosh.getDuration() + 'number of channels: ' + whoosh.getNumberOfChannels());

		  // Play the sound with an onEnd callback
		  whoosh.play((success) => {
		    if (success) {
		      console.log('successfully finished playing');
		    } else {
		      console.log('playback failed due to audio decoding errors');
		    }
		  });
		});
	}

	checkAllSelectionDone() {
		let userMeals = this.state.userSelectedMeals[this.state.date];
		for (var key of Object.keys(userMeals)) {
			if(userMeals[key].quantity != userMeals[key].selected_quantity){
				return false;
			}
		}
		return true;
	}
	isApiCallRequire(){
		let userPropsData = this.props.mealDetail.userProduct[this.state.date];
		if(userPropsData.hasOwnProperty('meals')){
			let mainUserMealArr = userPropsData.meals;
			let userMeals = this.state.userSelectedMeals[this.state.date];
			for(let i = 0; i < mainUserMealArr.length ; i++){
				let key = mainUserMealArr[i].id;
				let userChangedMealObj = userMeals[key];
				let mainSelectionArray = mainUserMealArr[i].selected_items;

				if(userChangedMealObj != undefined){
					if(mainSelectionArray.length != userChangedMealObj.selected_items.length)
						return true;
					else{
						for(let j = 0; j < mainSelectionArray.length ; j++){
							let checkItemExist = userChangedMealObj.selected_items.filter(obj => obj.recipe_template_id === mainSelectionArray[j].recipe_template_id);
							if(checkItemExist.length == 0){
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
	getUserSelectedData(){
		var userObj = {};
		userObj.date = this.state.date;
		userObj.meals = [];
		let userMeals = this.state.userSelectedMeals[this.state.date];
		for (var key in userMeals) {
		  	userObj.meals.push(userMeals[key]);
		}
		return userObj;
	}

	onDateClick = (date) => {
		if(this.isApiCallRequire()){
			if(this.checkAllSelectionDone()){
				if (this.props.Connected) {
					this.setState({isLoading:true}, () => {
						let params = this.getUserSelectedData();
						this.props.actions.mealsAction.updateUserMealPlan(params,date);
					});
				} else {
					this.toast.show(translate('InternetToast'));
				}
			}else{
				this.refs.productDiscardChangeModal.toggleModal(true, translate("discardProductChangeTitle"), translate("discardProductChangeMessage"), translate("Continue"), translate("Discard"), () => {
					this.refs.productDiscardChangeModal.toggleModal(false);
				}, () => {
					this.fetchNextDateProductList(date);
					this.refs.productDiscardChangeModal.toggleModal(false);
				});
			}
		}else{
			this.fetchNextDateProductList(date);
		}
	}

  fetchNextDateProductList(date) {
	  this.props.onDateChange && this.props.onDateChange(date);
	}

	onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
	};

	onDone = () => {
		if(this.isApiCallRequire()){
			if(this.checkAllSelectionDone()){

				if (this.props.Connected) {
					this.setState({isLoading:true}, () => {
						let params = this.getUserSelectedData();
						this.props.actions.mealsAction.updateUserMealPlan(params);
					});
				} else {
					this.toast.show(translate('InternetToast'));
				}

			}else{
				this.refs.productDiscardChangeModal.toggleModal(true, translate("discardProductChangeTitle"), translate("discardProductChangeMessage"), translate("Continue"), translate("Discard"), () => {
					this.refs.productDiscardChangeModal.toggleModal(false);
				}, () => {
					this.isParentClose = true
					this.refs.productDiscardChangeModal.toggleModal(false);
					});
			}
		}else{
			this.clearFilterandDateCloseModel();
		}
	}

	clearFilterandDateCloseModel() {
		this.props.closeModel && this.props.closeModel();
	}

	_pauseUnpauseEvent = () => {
		let confirmationMsg = translate('unpauseConfirmMessage');
		if(this.state.currSelectedStatus != 'pause'){
			confirmationMsg = translate('pauseConfirmMessage');
		}
		this.refs.productDiscardChangeModal.toggleModal(true, "", confirmationMsg, translate("Cancel"), translate("yes"), () => {
			this.refs.productDiscardChangeModal.toggleModal(false);
		}, () => {
			this.refs.productDiscardChangeModal.toggleModal(false);
			this.pauseUnpauseApi();
		});
	}
	pauseUnpauseApi(){
		if (this.props.Connected) {
			let params = {
				'date': this.state.date,
				'status': "pause",
			}
			this.props.actions.mealsAction.userMealPauseUnpause(params);
		} else {
			this.toast.show(translate("InternetToast"));
		}
	}
	
	triggerHapticEffect = (type) => {
		const options = {
		  enableVibrateFallback: true,
		  ignoreAndroidSystemSettings: true
		};
		ReactNativeHapticFeedback.trigger(type, options);
	}
	setAnimation(outDuration,InDuration){
		setTimeout(() => {
			this.animateIn();
			setTimeout(() => {
			this.animateOut();
			}, outDuration);	  
		}, InDuration);	
	}	
	animateIn(){
		Animated.timing(this.state.scale, {
			toValue: 1.2,
			duration:30,
			useNativeDriver:true,
		}).start()
	}
	animateOut(){
		Animated.timing(this.state.scale, {
			toValue: 1,
			useNativeDriver:true,
			duration:30,
		}).start()
	}
	_rateMeModelOpen(item) {
		this.refs.refProductRateModel.toggleProductRateModal(true, item, this.state.date);
	}
	updateMealSelectionData = (mealData) => {
		let tempMealData = {...this.state.userSelectedMeals, ...mealData};
		this.setState({userSelectedMeals: tempMealData}, () => this.doCaloriesCalculation());
	}

	render() {
		let productDate = (I18nManager.isRTL) ? this.state.todayArDate : this.state.todayEnDate;
		let today = moment(new Date()).lang("en-gb").format('YYYY-MM-DD');
		let selectedDate = moment(this.state.date).lang("en-gb").format('YYYY-MM-DD');
		let currDateStatus = "";
		if (Object.keys(this.props.mealDetail.userProduct).length !== 0 && this.state.date) {
			currDateStatus = this.props.mealDetail.userProduct[this.state.date].status;
		}

		return (
			<View style={{ flex: 1, backgroundColor: Colors.pinkishRed }}>
				<SafeAreaView style={[Styles.common.safeareView0]} />
			 <StatusBar
						barStyle="light-content"
						backgroundColor={Colors.pinkishRed}
						translucent={true} /> 
					<View style={styles.mainContainer}>
						<View style={styles.headerContainer}>
							<View style={styles.firstHeaderContainer}>
								<View style={styles.firstHeaderLeftView}>
								{today < selectedDate && (currDateStatus == 'choose-meal' || currDateStatus == 'meal-assign' || currDateStatus == 'pause') &&
									<TouchableOpacity activeOpacity={.7} style={(I18nManager.isRTL && currDateStatus == 'pause') ? styles.pauseBtnViewRTL_Unpause : styles.pauseBtnView} onPress={this._pauseUnpauseEvent}>
											{currDateStatus == 'pause'?
												<Image source={Images.icons.play} style={styles.pauseIcon} />
												:
												<Image source={Images.icons.Pause} style={styles.pauseIcon} />
											}

										<View style={styles.pauseTextView}>
											{currDateStatus == 'pause'?
												<Text style={styles.pauseText}>{translate("start")}</Text>
												:
												<Text style={styles.pauseText}>{translate("Pause")}</Text>
											}
											<Text style={styles.pauseText}>{translate("ThisDay")}</Text>
										</View>
									</TouchableOpacity>
								}
								</View>
								<View style={styles.firstHeaderCenterView}>
									<FastImage source={Images.DietLogo} style={styles.centerLogoIcon} />
								</View>
								<View style={styles.firstHeaderRightView}>
									<View style={styles.firstHeaderRightInnerView}>
										<TouchableOpacity activeOpacity={.7} style={styles.doneTextView} onPress={()=>{
											this.refs.refSelectionModal.show();
										}}>
											<Image source={Images.icons.filter} style={styles.filterIcon} />
										</TouchableOpacity>
										<TouchableOpacity activeOpacity={.7} style={styles.doneTextView} onPress={this.onDone}>
											<Text style={styles.doneText}>{translate("Done")}</Text>
										</TouchableOpacity>
									</View>
								</View>
							</View>
							<View style={styles.headerDateContainer}>
								<Text style={styles.dateText}>{productDate}</Text>
							</View>
						</View>

						<View style={styles.contentContainer}>
							<ProductMainContentContainer
								ref={(productMainContentContainer) => { this.productMainContentContainer = productMainContentContainer }}
								date={this.props.selectedDate}
								product_filters={this.state.product_filters}
								currSelectedStatus={this.props.mealDetail.userProduct[this.props.selectedDate].status}
								onModelClose={(date) => {this.setDataForMeals(date)}}
								toggleRateModel={(product) => {this._rateMeModelOpen(product)}}
								toggleMessageModal={this.toggleMessageModal}
								onEmptyMenu={this.onEmptyMenu}
								toggleDiscardChangeModal={this.toggleDiscardChangeModal}
								updateMealSelectionData={this.updateMealSelectionData}
								/>
						</View>
						<View style={styles.calendarContainer}>
								<CalendarStrip
									date={this.props.selectedDate} onDateClick={this.onDateClick}/>
						</View>
						{/* showing calories */}
						{this.state.showCalorieBtn &&
						
						 <Animated.View
						 style={[styles.caloriesBtnView,
						   { 
								 transform: [
								 {
									 scale:this.state.scale,
								 }]
							 
						 }]}>
								   <TouchableWithoutFeedback onPressIn={()=>{this.animateIn();
								   					  setTimeout(() => {
														this.triggerHapticEffect();
														this.showNextAttributeCalculation();
														  }, 100);
											 }} onPressOut={()=>{
										  this.animateOut();
					}}>
										 <View style={styles.mainElevation}>
								  <LinearGradient colors={[Colors.caloriesGradientStart, Colors.caloriesGradientEnd]} style={styles.caloriesGradientBtn}>
								  <Text style={styles.caloriesCountText}>{this.state.caloriesCount[this.state.nextAttributeIndex].count}</Text>
									<Text style={styles.caloriesText}>{this.state.caloriesCount[this.state.nextAttributeIndex].name}</Text>
									  </LinearGradient>
									  </View>
				  				</TouchableWithoutFeedback>
			  					</Animated.View>
								 
						}
					</View>

				<SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} />
				<ProductDiscardChangeModal ref={"productDiscardChangeModal"}  onModalHide={() => {
					if(this.isParentClose){
						this.clearFilterandDateCloseModel();
					}
				}}/>
				<Toast refrence={(refrence) => this.toast = refrence} />
				<SelectionModal 
								ref="refSelectionModal" 
								fetchSelectionData={this.fetchFilters}
								fetchSelectedValues={this.fetchSelectedfilters}
								lang = {this.props.signupDetail.com_lang}
								isLoading = {this.props.isLoading}
								onApply = {(selectedItems)=>this.onApplyFilter(selectedItems)}
								title={translate("Filter")}
								search={false}
								multiSelect={true}
								showSelection={true}
								containerStyle={{"height":"95%"}}
								/>

				{this.state.isLoading || this.props.isLoading ? <Spinner mode="overlay" /> : null}
				<View style={{position: 'absolute',bottom: 0}}>
					<ProductRateModel ref={"refProductRateModel"} gotoNext={(date) => {this.setDataForMeals(date)}}></ProductRateModel>
				</View>
			</View>
		);
	}
	fetchFilters = () => {
		//TODO: this needs to be fetched from redux and api call.
		return new Promise((resolve,reject)=>{
			let filter_list = [];
			if(this.props.mealDetail && this.props.mealDetail.filter_list){
				for(let filter of this.props.mealDetail.filter_list){
					filter_list.push(
						{
							value: (filter.id + '.' + filter.type),
							label: (I18nManager.isRTL ? (filter.name_ar || filter.name) : filter.name)
						}
					);
				}
			}
			resolve(filter_list);
		});
	}
	onApplyFilter = (selectedItems) => {
		//TODO:
		console.log("Received filters to apply ", selectedItems);
		let selected_filters = {
			tags: {},
			dislike_attr: {},
		};
		for(let selected of selectedItems){
			let selected_id = selected.split('.')[0];
			let selected_type = selected.split('.')[1];
			if(selected_type == "tag"){
				selected_filters.tags[selected_id] = '';
			}
			else if(selected_type == "dislike"){
				selected_filters.dislike_attr[selected_id] = '';
			}
		}
		this.setState({product_filters: {...selected_filters}});
	}

	toggleMessageModal = (visible, message, title) => {
		this.refs.simpleMessageModal.toggleModal(visible,message,title);
	}

	onEmptyMenu = () => {
		this.setState({ isLoading:false, showCalorieBtn:false });
	}

	toggleDiscardChangeModal = (product,dislikeAttr) => {
		return new Promise((resolve,reject)=>{
			var disliameArr = dislikeAttr.map(function (el) { return " " +(I18nManager.isRTL ? el.name_ar : el.name) + ""; });
			this.refs.productDiscardChangeModal.toggleModal(true, "", product.name.trim() + " " + translate("dislikeAttributeSelectionMessage1") + "" +  disliameArr.join() + " " + translate("dislikeAttributeSelectionMessage2"), translate("Continue"), translate("Discard"), () => {
				this.refs.productDiscardChangeModal.toggleModal(false);
				resolve();
			}, () => {
				this.refs.productDiscardChangeModal.toggleModal(false);
				reject();
			});
		});
	}

	fetchSelectedfilters = () => {
		return new Promise((resolve,reject)=>{
			let selectedFilters = [];
			if(this.props.mealDetail && this.state.product_filters){
				for(let filter_category in this.state.product_filters){
					for(let item in this.state.product_filters[filter_category]){
						selectedFilters.push(item + '.' + (filter_category == 'tags' ? 'tag' : 'dislike'));
					}
				}
			}
			resolve(selectedFilters);
		});
	}
}


function mapDispatchToProps(dispatch) {
	return {
		actions: {
			mealsAction: bindActionCreators(mealsAction, dispatch),
			mealsErrorAction: bindActionCreators(mealsErrorAction, dispatch)
		}
	};
}

const mapStateToProps = (state) => {
	return {
		mealDetail: state.mealsReducer,
		mealErrorDetail: state.mealsErrorReducer,
		Connected: state.updateNetInfoReducer.isConnected,
		isLoading: state.mealsReducer.isLoading,
		signupDetail: state.updateUserReducer
	};
};

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(ProductListScreen);
