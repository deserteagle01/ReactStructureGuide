import {
  StyleSheet, Dimensions, Platform
}
from "react-native";
import {
  Images, Styles, Colors
}
from "@common";
const screen = Dimensions.get("window");

export default styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  customSafearea: {
    flex: (Platform.OS === 'ios' && screen.height >= 812) ? 0.95 : 1,
    backgroundColor: Colors.pinkishRed,
  },
  headerContainer: {
    // flex:0.13,
    height: 80,
    backgroundColor: Colors.pinkishRed
  },
  firstHeaderContainer: {
    flex: 0.7,
    flexDirection: 'row',
    marginTop: 0,
    marginHorizontal: 16,
    alignItems: 'center',
  },
  firstHeaderLeftView: {
    flex: 0.4
  },
  pauseBtnView: {
    flexDirection: 'row',
    paddingRight: 8,
    paddingTop: 8,
    paddingBottom: 8,
    backgroundColor: Colors.coral,
    borderRadius: 18,
    height: 37,
    width: 86,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pauseBtnViewRTL_Unpause: {
    flexDirection: 'row',
    paddingRight: 8,
    paddingTop: 8,
    paddingBottom: 8,
    backgroundColor: Colors.coral,
    borderRadius: 18,
    height: 37,
    width: 120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pauseIcon: {
    width: 24,
    height: 24
  },
  pauseTextView: {
    alignSelf: 'center',
    flexDirection: 'column'
  },
  pauseText: {
    fontSize: 11,
    lineHeight: 12,
    color: Colors.white,
    fontFamily: Styles.FontFamily().ProximaNova,
    textAlign: 'left'
  },
  firstHeaderCenterView: {
    flex: 0.2,
    alignItems: 'center'
  },
  centerLogoIcon: {
    width: 53,
    height: 39,
    padding: 0,
    resizeMode: 'contain',
  },
  firstHeaderRightView: {
    flex: 0.4,
    alignItems: 'flex-end'
  },
  firstHeaderRightInnerView: {
    alignItems: 'flex-end',
    flexDirection: 'row'
  },
  filterIcon: {
    width: 28,
    height: 28
  },
  doneTextView: {
    marginLeft: 16,
    alignSelf: 'center'
  },
  doneText: {
    fontSize: 17,
    lineHeight: 24,
    color: Colors.white,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
  },
  headerDateContainer: {
    flex: 0.3,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dateText: {
    fontSize: 10,
    lineHeight: 18,
    color: Colors.white,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
  },
  contentContainer: {
    flex: 1,
    backgroundColor: Colors.paleGreyTwo,
    marginTop: 44,
    paddingTop:0,
    paddingLeft: 8,
    paddingRight: 8,
    // marginHorizontal:16,
  },
  calendarContainer: {
    top: 80,
    position: 'absolute',
    width:'100%',
    height: 44,
    backgroundColor: Colors.white,
    shadowColor: Colors.warmGrey,
    shadowOffset: {
      width: 0,
      height: 2
    },
    borderTopWidth: 0,
    shadowRadius: 10,
    shadowOpacity: 0.3,
    elevation: 5
  },
  calendarListView: {
    backgroundColor: Colors.white,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center'
  },
  calenderItemView:{borderRadius:8,height:36,margin:1,justifyContent:'center'},
  calenderDateTextView:{top:1,right:3,padding:2,position:'absolute'},
  calenderDateText:{fontSize:10},
  calenderDateIconView:{height:24,alignItems:'center',justifyContent:'center'},
  calenderDateIcon:{width:18,height:18},
  caloriesBtnView:{
    position:'absolute',
    bottom:20,
    left:Styles.width/2 - 33,
    shadowRadius: 15,
		shadowColor: Colors.warmGrey,
		shadowOffset: { height: 0, width: 0 },
		shadowOpacity: 4.5,
  },
  mainElevation:{
    width:68,
    height:68,
    borderRadius:68/2,
    justifyContent:'center',
    alignItems:'center',
    elevation: 40,
  },
  caloriesGradientBtn:{
    width:68,
    height:68,
    borderRadius:68/2,
    justifyContent:'center',
    alignItems:'center',

  },
  caloriesCountText:{
    fontSize:17,
    fontFamily:Styles.FontFamily().ProximaNovaBold,
    lineHeight:21,color:Colors.white,
    alignSelf:'center'
  },
  caloriesText:{
    fontSize:10,
    fontFamily:Styles.FontFamily().ProximaNova,
    lineHeight:12,
    color:Colors.white,
    alignSelf:'center'
  },
 

});
