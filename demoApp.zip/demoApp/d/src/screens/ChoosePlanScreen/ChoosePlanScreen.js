import React, { PureComponent } from "react";
import { ChoosePlanView } from "@components";

class ChoosePlanScreen extends PureComponent {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        
    }

    

    render() {
        return (
            <ChoosePlanView  
                closeModal={() => this.props.navigation.goBack()} 
                planClicked={(plan_id, planData) =>  this.props.navigation.navigate('CustomPlan', {Plan_id: plan_id, Plandata: planData}) } />
        );
    }
}

export default ChoosePlanScreen;
