import { StyleSheet, Dimensions, Platform } from "react-native";
import { Styles, Colors } from "@common";

var deviceWidth = Dimensions.get('window').width;
var deviceHeight = Dimensions.get('window').height;

export default (styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: Colors.pinkishRed,
		...Platform.select({
			android: {
				marginTop: 20,
			},
		}),
	},
	loaderImageCont: {
		flex: 1,
		justifyContent: 'center',
		alignItems:"center",
	},
	loaderImage: {
		width: 80,
		height: 62,
		marginBottom: 19
	},
	label: {
		color: Colors.white,
		fontSize: 12,
		fontFamily: Styles.FontFamily().ProximaNova,
		textAlign:'center'
	},
}));
