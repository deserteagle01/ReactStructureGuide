/** @format */

import React, { PureComponent } from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
    StyleSheet,
    View,
    StatusBar,
    SafeAreaView,
    Image,
    Text
} from "react-native";
import { Spinner, Toast } from "@components";
import { Images, Styles, Colors} from "@common";
import { translate, setI18nConfig } from "@languages";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";

class LoadingScreen extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {};
    }

    componentDidMount() {
        if(this.props.connected){
			const reqParams = {
				email: this.props.signupDetail.email,
				birth_date: this.props.signupDetail.birth_date,
				gender: this.props.signupDetail.gender,
				height: this.props.signupDetail.height,
				weight: this.props.signupDetail.weight,
				dislike_category_ids: this.props.signupDetail.dislike_category_ids,
                opt_out_notifications: this.props.signupDetail.opt_out_notifications,
                lang: this.props.signupDetail.lang,
                secondary_firstname: this.props.signupDetail.secondary_firstname,
				secondary_lastname: this.props.signupDetail.secondary_lastname,
				com_lang: this.props.signupDetail.com_lang,
            };
            
            this.props.actions.UpdateUserAction.registerUpdateUser(reqParams).then(() => {
				if(this.props.signupDetail.error) {
                    this.toast.show(this.props.signupDetail.error);
				}
				else{
                    setI18nConfig(this.props.switcher.lang, this.props.switcher.rtl);
                    this.forceUpdate();
                    const reqParams = {
						isLogin: true,                     // Update this field value only
					};
					this.props.actions.UpdateUserAction.updateUserDetails(reqParams);            
					this.props.navigation.navigate('App');
				}
			});

		} else {
			this.toast.show(translate("InternetToast"));
		}
    }

    render() {
        return (
            <SafeAreaView style={[Styles.common.safeareView]}>
                <StatusBar
                    barStyle="light-content"
                    backgroundColor={"transparent"}
                    translucent={true}
                />
                <View style={styles.container}>
                    <View style={styles.loaderImageCont}>
                        <Image source={Images.smileLogo} style={styles.loaderImage} />
                        <Text style={styles.label}>{translate("SetupingDietStation")}</Text>
                    </View>
                </View>
                {/* {this.props.isSetAccountLoading ? <Spinner mode="overlay" /> : null} */}
				<Toast refrence={(refrence) => this.toast = refrence} />
            </SafeAreaView>
        );
    }
}


const mapStateToProps = (state) => ({
    connected: state.updateNetInfoReducer.isConnected,
	signupDetail: state.updateUserReducer,
    isSetAccountLoading: state.updateUserReducer.isLoading,
    switcher: state.switchLanguageReducer
});

function mapDispatchToProps(dispatch) {
    return {
        actions: {
			UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
        }
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(LoadingScreen);