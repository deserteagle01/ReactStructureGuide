/** @format */

import React, { PureComponent } from "react";
import { connect } from "react-redux";
//import RNRestart from 'react-native-restart';
import styles from "./styles";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  StatusBar,
  SafeAreaView,
  Image,
  TouchableOpacity,
  I18nManager,
  Linking,
  Platform,
  TextInput,
  Animated,
  Easing,
  Dimensions,
  Keyboard
} from "react-native";
import { Images, Colors, Styles, Validations } from "@common";
import { translate, setI18nConfig } from "@languages";
import { GradientButton, OutlineButton, NeedHelp, LanguageSwitcher, Toast,LanguageModal,SmartPlaceholderTextField, InputAccessory, Spinner, ChoosePlanModal, Prefetcher} from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import RNRestart from 'react-native-restart';
import { compareVersion, appUpdateLink } from "../../common/Utility";
import  NotificationManager  from '../../common/NotificationManager';
import * as switchLanguage from "../../redux/Actions/SwitchLanguageAction";
import {Fade} from  "@components";
import HTTP from "../../webservice/http";
import { returnRemainingSlider, screens } from "../../common/Utility";
import * as UpdateUser from "../../redux/Actions/updateUserAction";
import AnimatedMove from "../../components/AnimatedMove";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { firebase } from '@react-native-firebase/analytics';
const { height, width } = Dimensions.get("window");
import { sourceScreen } from "../../common/Utility";
class LoginScreen extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      stage : 'login-1',
      oldStage: '',
      errorMsg:"",
      phoneNumber:"",
      password:"",
      iconRightVisible:false,
      modalReOpenPlanData: this.props.navigation.state.params ? this.props.navigation.state.params.modalReOpenPlanData : null,
    };
    this.inputRefs = {};
  }
 updateScreen(lang, isRTL)  {
     I18nManager.forceRTL(isRTL);
     this.forceUpdate();
     setTimeout(() => {
        RNRestart.Restart()
     }, 500)
  }

  componentDidMount() {
    const language = this.props.languagesProps;
    setI18nConfig(language.lang, language.rtl);

    if(Object.keys(this.props.fetchData[Platform.OS]).length != 0) {
      var isAppUpdate = compareVersion(this.props.fetchData[Platform.OS].current_version);
      var isForceUpdate = compareVersion(this.props.fetchData[Platform.OS].last_force_update_version);

      if(isAppUpdate || isForceUpdate) {
        let tempDict = this.props.fetchData[Platform.OS];
        tempDict.forceUpdateFlag = isForceUpdate;
        tempDict.appUpdateFlag = isAppUpdate;
        NotificationManager.show({data: tempDict, type: "update", okclickCallback: () => appUpdateLink(this.props.fetchData[Platform.OS]) });
      }        
      this.inputRefs = this.refs;
    }
    this.refs.prefetcherref.startPrefetching({source: sourceScreen.login, action: "onLoginLoading"});

    if(this.state.modalReOpenPlanData) {
      this.onChoosePlan();
    }
  }

  tryDemo() {
    this.validateLogin(this.props.fetchData.test_user_login,this.props.fetchData.test_user_password).then(()=>{
      this.updateReduxandRedirect(true);
    }).catch((error)=>{
      console.log("Validation failed");
      this.toast.show(error);
    });    
  }
  
  componentWillReceiveProps() {
      
  }

  onChoosePlan = () => {
    if(this.state.stage=="login-1"){
        this.refs.prefetcherref.startPrefetching({source: sourceScreen.login, action: "choosePlan"});
        this.refs.prefetcherref.startPrefetching({source: sourceScreen.login, action: "fetchFirstAvailable"});
        this.refs.refChoosePlanModal.show();
        // this.props.navigation.navigate('ChoosePlanScreen');      
    }
  }
  onExistingAccount() {
    if(this.state.stage=="login-1") {
      this.setState({stage: "login-2",oldStage:this.state.stage});
    }
  }

  onCancel = () => {
    Keyboard.dismiss();
    console.log("Cancel clicked");
    this.setState({errorMsg:"",password:"",phoneNumber:"",stage:'login-1',oldStage:this.state.stage,iconRightVisible:false});
  }
  
  onChangePhoneNumber = (text, forceValidate) => {
    console.log("Text changed ",text);
    if(this.validating){
      console.log("Validation in progress return ",text);
      return;
    }
    
    if(text.length<=8){
      this.setState({phoneNumber:text, errorMsg:"",password:"",iconRightVisible:false});
    }
    let option = { fullMessages: false };
    let loginError = Validations('mobile', text, option);
    if (!loginError) {
      this.validating = true;
      this.validatePhoneNumber(text).then(()=>{
        //this.props.navigation.navigate('Login2Screen', { phonenumber: this.state.phoneNumber });
        console.log("Goto login-3");
        this.setState({stage:'login-3','phoneNumber':text,oldStage:this.state.stage,password:"",iconRightVisible:true});
        this.inputRefs["password"].refs['textInput'].focus();
        this.validating = false;
      }).catch((error)=>{
        console.log("Validation failed");
        this.setState({password:"",errorMsg:error,password:"",iconRightVisible:false});
        this.validating = false;
      })
    } else {
      if(forceValidate){
        this.setState({password:"",errorMsg:translate(loginError),password:""});
      }
      console.log("Go back go login-2");
      //this seams to work much better when we dont hide password in case once password becomes visible.
      // if(this.state.stage!="login-2"){
      //   this.setState({stage:'login-2',oldStage:this.state.stage});
      // }
    }
  }
  
  validatePhoneNumber(phoneNumber){
    return new Promise((resolve, reject) => {
      if (this.props.Connected) {
        console.log("calling api for ", phoneNumber);
        this.props.actions.UpdateUser.UserExistAction(phoneNumber).then(() => {
          if (this.props.userDetail.error) {
            reject(this.props.userDetail.error);
          } else {
            if (this.props.userDetail.is_exist) {
              resolve();
            } else {
              reject(translate("UserExistMessage"))
            }
          }
        });
      } else {
        reject(translate("InternetToast"));
      }
    });
  }

  onSubmitPhoneNumber = () => {
    console.log("On submit phone number ");
    Keyboard.dismiss();
    this.onChangePhoneNumber(this.state.phoneNumber,1);
  }

  onLoginClick = () => {
    if (this.state.stage=="login-2"){
      this.onSubmitPhoneNumber();
    }else if(this.state.stage=="login-3"){
      this.onSubmitPassword()
    }
  }

  onChangePassword = (text) => {
    console.log("Text changed ",text);
    this.setState({password:text,errorMsg:""});
  }
  
  onSubmitPassword = () => {
    let option = { fullMessages: false };
    this.setState({ errorMsg: ""});
    this.validateLogin(this.state.phoneNumber,this.state.password).then(()=>{
      this.updateReduxandRedirect(false);
    }).catch((error)=>{
      console.log("Validation failed");
      this.setState({errorMsg:error});
    });
  }
    
  validateLogin(phoneNumber, password) {
    return new Promise((resolve, reject) => {
      let option = { fullMessages: false };
      let loginError = Validations('password', password, option);
      if (!loginError) {
        if (this.props.Connected) {
          this.props.actions.UpdateUser.UserLoginAction(phoneNumber, password).then(() => {
            if (this.props.userDetail.error) {
              reject(this.props.userDetail.error);
            } else {
              console.log('login details =' + JSON.stringify(this.props.userDetail));
              firebase.analytics().logEvent("login", {method: "Password"});
              resolve();
            }
          })
        } else {
          reject(translate("InternetToast"));
        }
      } else {
        reject(translate(loginError));
      }
    });
  }

  async updateReduxandRedirect(isFromTryDemo) {
    Keyboard.dismiss();
    await this.props.actions.UpdateUser.updateUserDetails({ isLogin: true, password: this.state.password  });
    HTTP.setNumberandPassword(this.state.phoneNumber, this.state.password);
    let slider = returnRemainingSlider(this.props.userDetail);
    if (slider.length == 0) {
      if(this.props.switcher.lang!==this.props.signupDetail.lang && !isFromTryDemo){
        this.props.actions.switchLanguage.switchLanguageAction({ lang:this.props.signupDetail.lang 
        ,rtl:this.props.signupDetail.lang =="ar"
      });
       I18nManager.forceRTL(this.props.signupDetail.lang == "ar");
       setTimeout(() => {
         RNRestart.Restart();
       }, 500)
     } else {
      this.props.navigation.navigate("App");
    }
  } else {
      console.log("Navigate to the signup screen with slider ", slider);
      this.props.navigation.navigate('SignupScreen', { slide: slider });
    }
  }

  renderArrorw() {
    return (
      <Image source={I18nManager.isRTL ? Images.icons.leftArrowWhite : Images.icons.rightArrowWhite} style={styles.checkLogo} />
    );
  }  
  onForgetPassword = () => {
    if(this.state.stage=="login-3"){
      this.props.navigation.navigate("ForgetPasswordScreen", {mobile: this.state.phoneNumber});
    }
  }
  

  render() {
    const { stage, ...rest } = this.state;    
    const moveTo = stage=="login-2"?-height*0.10: (stage=="login-3"? Platform.OS == 'android'?-height*0.15: -height*0.20:  (this.state.oldStage=="login-2"?-height*0.10:-height*0.20));
    return (
      <ImageBackground
        defaultSource={Images.LoginBackground}
        source={Images.LoginBackground}
        style={[Styles.common.imgContainer]}
        resizeMode="cover"
        blurRadius={stage=="login-1"?0:8}
      >
      <SafeAreaView style={Styles.common.imgContainer}>
        
        <KeyboardAwareScrollView 
        enableOnAndroid={true} 
        keyboardShouldPersistTaps={'always'}
         showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll} scrollEnabled={false} >
         <View style={styles.main}>
       <StatusBar
            barStyle="light-content"
            backgroundColor={"transparent"}
            translucent={true}
          />
          {/* HEADER FIXED */}
        <View style={styles.header}>
            <Fade visible={stage!="login-1"} style={{paddingLeft:10}}>
              <TouchableOpacity onPress={() => this.onCancel()} style={{zIndex:1}}>
                <Image source={Images.icons.cancel_red} style={styles.cancelLogo} />
              </TouchableOpacity>
            </Fade>
            <View style={[styles.topView,{paddingRight:10,flex:1,alignItems:"flex-end"}]}>
              <NeedHelp style={{}}/>
            </View>
          </View>
          {/* main area */}
          <View style={[{flex:0.45,width:"100%",flexDirection:"row",alignItems:"center",justifyContent:"center",}]}>       
            <AnimatedMove animate={stage!="login-1"} fromSize={1} toSize={0.75} height={-height*0.10}>
                <Image source={Images.DietLogo} resizeMode='contain' style={[styles.dislikeMainIcon,{}]}/>
            </AnimatedMove>
          </View>
          <View style={[{flex:0.55,flexDirection:"column",alignItems:"center"}]}>
            <AnimatedMove style={{width:"100%", backgroundColor:"transparent"}} animate={true} duration ={200} fromSize={1} toSize={0.99} height={moveTo}>
            <View style={{width:"100%", backgroundColor:"transparent"}}>
              <Fade duration={100} visible={stage!="login-1"} >
                <SmartPlaceholderTextField
                  ref={"phoneNumber"}
                  inputAccessoryViewID={"phoneNumber"}
                  returnKeyType='done'
                  keyboardType = {'number-pad'}
                  maxLength={8}
                  editable = {stage!="login-1"}
                  smartPlaceholder={translate("WhatsYourMobileNumber")}
                  smartPlaceholderTextColor = {Colors.whiteTransparent}
                  value={this.state.phoneNumber}
                  errorMsg={stage=="login-2"?this.state.errorMsg:""}
                  keyboardAppearance = "dark"
                  underlineColorAndroid='transparent'
                  style={styles.txtPhone}
                  autoCapitalize="none"
                  selectionColor={Colors.white}
                  onChangeText = {(text) => this.onChangePhoneNumber(text,false)}
                  onSubmitEditing={() => this.onSubmitPhoneNumber()}
                  iconRightVisible={this.state.iconRightVisible}
                  iconPath={I18nManager.isRTL ? Images.icons.check : Images.icons.check}
                  /> 
              </Fade>
              <Fade duration={100} remove={stage!="login-3" && (stage=="login-2" || this.state.oldStage!="login-3")} visible={stage=="login-3"}>
                <SmartPlaceholderTextField
                  ref={"password"}
                  inputAccessoryViewID={"password"}
                  editable = {stage=="login-3"}
                  returnKeyType='done'
                  smartPlaceholder={translate("Password")}
                  smartPlaceholderTextColor = {Colors.whiteTransparent}
                  value={this.state.password}
                  errorMsg={stage=="login-3"?this.state.errorMsg:""}
                  keyboardAppearance = "dark"
                  underlineColorAndroid='transparent'
                  style={styles.txtPass}
                  autoCapitalize="none"
                  selectionColor={Colors.white}
                  onChangeText = {(text) => this.onChangePassword(text)}
                  onSubmitEditing={() => this.onSubmitPassword()}
                  secureTextEntry={true}
                  />
              </Fade>
              <Fade delay={50} visible={stage!="login-1"} >
                <GradientButton
                  onPressAction={() => { this.onLoginClick() }}
                  text = {stage=="login-3"?translate("Login"):null}
                  children={stage=="login-3"?null:this.renderArrorw()}
                  style={{marginTop:16}}
                />
              </Fade>
              {
              /** FORGET password link */
              
              <Fade delay={50} visible={stage=="login-3"} >
                <TouchableOpacity style={{marginTop:15}} onPress={() => this.onForgetPassword()}>
                  <Text style={styles.demoView}>{translate("ForgetPassword")}</Text>
                </TouchableOpacity>
              </Fade>
              
              }
            </View>
            </AnimatedMove>
          </View>

          {/* FOOTER buttons FIXED */}
          {stage == 'login-1' &&
            <View style={[styles.footer,{flexDirection:"column",justifyContent:"flex-start"}]}>
              <View style={{flex:1,width:"100%",}}>
                <Fade visible={stage=="login-1"}>
                  <GradientButton onPressAction={() => {this.onChoosePlan()}} text={translate("ChoosePlan")}/>
                </Fade>
                <Fade visible={stage=="login-1"} delay={200}>
                  <OutlineButton  
                    onPress={() => {this.onExistingAccount();}}
                    label={translate("IHaveAccount")}
                    style={{}} />
                </Fade>
              </View>
            </View>
          }

          {/* FOOTER BOTTOM FIXED */}
          <View style={[styles.footer, styles.languageView,{bottom:0,width:"100%",height:100,left:0,right:0,marginBottom:0,marginTop:0}]}>
              <LanguageSwitcher updateScreen={(lang, isRTL) => this.updateScreen(lang, isRTL)}/>
              <TouchableOpacity onPress={() => this.tryDemo()}>
                <Text style={styles.demoView}>{translate("TryDemo")}</Text>
              </TouchableOpacity>
          </View>

          {/* OTHER COMMON THINGS */}
          <Toast refrence={(refrence) => this.toast = refrence} />
          {/* removed input accessories as its not there in design for login page and it make look bad for login page
           {
            Platform.OS == 'ios' &&
            <InputAccessory inputAccessoryViewID={"phoneNumber"} 
            disableUpArrow={true} disableDownArrow={true} hideDoneBar={false}
            onDoneClick={() => this.onSubmitPhoneNumber()}/>
          }           */}
          </View>
          </KeyboardAwareScrollView>
        </SafeAreaView>
        <ChoosePlanModal {...this.props} 
          ref="refChoosePlanModal" 
          modalReOpenPlanData = {this.state.modalReOpenPlanData}
          resetmodalReOpenPlanData = {() => this.onModalClose()}
          onContinue = {()=>{this.navigateToSignup()}}
          onModalClose = {() => {this.onModalClose()}}
          />
        {this.props.userDetail.isLoading ? <Spinner mode="overlay" /> : null}
        <Prefetcher ref="prefetcherref"  />        
      </ImageBackground>
    );
}

  navigateToSignup() {
    let isRTL = false;
    if(this.props.switcher.lang == 'ar') {
      //DO RTL only if app language is arabic in which case communication lang will also be arabic
      setI18nConfig("ar",true);
    } else {
      setI18nConfig(this.props.signupDetail.com_lang,false);
    }
    this.forceUpdate();      
    this.props.navigation.navigate('SignupScreen', { slide: null })
  }
  
  onModalClose() {
    if (this.state.modalReOpenPlanData) {
      this.setState({modalReOpenPlanData: null});
    }
  }


}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
      switchLanguage: bindActionCreators(switchLanguage, dispatch),
      UpdateUser: bindActionCreators(UpdateUser, dispatch),
    }
  };
}
  
const mapStateToProps = (state) => ({
  connected: state.updateNetInfoReducer.isConnected,
  Connected: state.updateNetInfoReducer.isConnected,
  languagesProps: state.switchLanguageReducer,
  fetchData: state.fetchMasterListReducer,
  switcher: state.switchLanguageReducer,
  companyDetails: state.fetchMasterListReducer,    
  signupDetail: state.updateUserReducer, 
  userDetail: state.updateUserReducer
});

export default connect(mapStateToProps, mapDispatchToProps)(LoginScreen);
