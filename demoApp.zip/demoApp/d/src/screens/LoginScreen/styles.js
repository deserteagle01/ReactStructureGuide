import { StyleSheet, Platform,Dimensions,I18nManager } from "react-native";
import { Styles, Colors } from "@common";
const { height, width } = Dimensions.get("window");
export default (styles = StyleSheet.create({
	logoContainer:{
    width: "100%",
    justifyContent:"center",
    alignItems: 'center',
  },
  main:{
    flex:1,
    flexDirection:"column",
  },
  scroll:{
    flexGrow:1,
    marginTop:Platform.OS=="ios"?8:28,
  },
  header:{
    paddingTop:Platform.OS=="ios"?8:28, 
    alignItems:"flex-start",
    flexDirection:"row"
  },

  dislikeMainIcon: {
		width: 136,
    height: 170,
    // backgroundColor:"blue",
  },
  innerContainer:{
    flex:1
    // backgroundColor:"gray"
  },
  footer: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    height: 240,
    // backgroundColor:"green",
    zIndex:100000, flexDirection:"row"
  },
  btn: {
    marginHorizontal: 16,
    marginTop: 16
  },
  topView:{ 
    // alignItems: "flex-end", 
    // backgroundColor:"yellow"
  },
  languageView:{ 
    marginTop: 50, 
    // flexDirection: "row", 
    width: "90%", 
    justifyContent:"space-around",
    alignItems: "center" ,
  },
  demoView:{ 
    color: Colors.white, 
    alignSelf: "center" 
  },
  container: {
    flex: 1,
    justifyContent:"flex-start",
    flexDirection: "column",
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  errorMsg:{
    alignSelf:'flex-start',
    color: Colors.white,
    fontSize: 14,
    fontFamily: Styles.FontFamily().ProximaNova,
    marginTop: 5,
    marginLeft: 20
  },
txtPhone:{
  fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
  fontSize: 17,
  color: Colors.white,
},

txtPass: {
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    fontSize: 17,
    color: Colors.white,
},    
checkLogo:{
  height:35,
  width:35
},
cancelLogo:{
  width:28,
  height:28,
},

}));
