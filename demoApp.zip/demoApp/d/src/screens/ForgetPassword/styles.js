import { StyleSheet, Dimensions } from "react-native";
import { Images, Styles, Colors } from "@common";
const screen = Dimensions.get("window");

export default  styles = StyleSheet.create({
    container: {
      flex: 1
    },
    bottom: {},
    logoContainer: {
      flex: 2,
      justifyContent: "center",
      alignItems: "center",
      marginTop: 35
    },
    logo: {
      width: 129
    },
    header:{
      width:'100%',
      flexDirection:'row',
      padding:16,
      alignItems:'center',
      justifyContent:'space-between',
    },
    cancelLogo:{
      width:28,
      height:28,
    },
    txtCall:{
      fontFamily: Styles.FontFamily().ProximaNova,
      fontSize: 14,
      alignSelf: "center",
      textAlign:"center",
      color: Colors.white
    },
    callLogo:{
      marginLeft:6,
      width:28,
      height:28,
    },
    inputNumber:{
      height: 60,
      borderRadius: 12,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: Colors.white,
      marginHorizontal: 16,
      marginTop:screen.height*.25,
      padding:18,
    },
    txtPhone:{
        textAlign:'left',
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize: 17,
        color: Colors.white,
        alignSelf:'flex-start'
    },
    checkLogo:{
      height:40,
      width:40
    },
    forgetPass:{
      marginTop:32,
      alignSelf:'center',
    },
    txtForget:{
      fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
      fontSize: 17,
      lineHeight:24,
      alignSelf: "center",
      textAlign:"center",
      color: 'rgba(255,255,255,0.6)'
    },
    footer: {
      // backgroundColor: "red",
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      height: 400,
      flex: 1
    },
    btn: {
      height: 56,
      marginTop: 16,
      marginHorizontal: 16,
      borderRadius: 10,
      justifyContent: "center",
      alignItems: "center"
    },
    btnText: {
      color: Colors.white,
      fontSize: 20
    },
    btnChoosePlan: {
      backgroundColor: "green"
    },
    btnAccount: {
      borderWidth: 1,
      borderColor: Colors.white
    }
  });
  