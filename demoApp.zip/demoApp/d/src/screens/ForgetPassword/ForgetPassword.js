/** @format */

import React, { PureComponent, useRef } from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  StatusBar,
  SafeAreaView,
  Image,
  TouchableOpacity,
  TextInput,
  I18nManager,
  Dimensions
} from "react-native";

import { Images, Colors, Styles } from "@common";
import { translate, setI18nConfig } from "@languages";
import { OTPContainer, Spinner} from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
const { height, width } = Dimensions.get("window");

class ForgetPassword extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      mobile: this.props.navigation.state.params.mobile ? this.props.navigation.state.params.mobile : ""
    }
    this.forgetpass = React.createRef();
  }

  _SlideDown(param) {
    this.forgetpass.current.validate(param).then((validation) => {

    });
  }

  render() {
    return (
      <ImageBackground
        defaultSource={Images.LoginBackground2}
        source={Images.LoginBackground}
        style={[Styles.common.imgContainer]}
        resizeMode="cover"
        blurRadius={8}>
        <StatusBar
          barStyle="light-content"
          backgroundColor={"transparent"}
          translucent={true}/>
      
        <View style={{flex:1}}>
          <OTPContainer ref={this.forgetpass} navigation={this.props.navigation} mobile={this.state.mobile} isFrom={"login"} setPassword={(param) => this._SlideDown(param)} />
        </View>

        { this.props.userDetail.isLoading ? <Spinner mode="overlay" /> : null}
    
    </ImageBackground>
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
    }
  };
}

const mapStateToProps = (state) => ({
  Connected: state.updateNetInfoReducer.isConnected,
  userDetail: state.updateUserReducer
});


export default connect(mapStateToProps, mapDispatchToProps)(ForgetPassword);
