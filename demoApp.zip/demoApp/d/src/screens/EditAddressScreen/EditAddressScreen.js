import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import { bindActionCreators } from "redux";
import {
	View,
	Text,
	StatusBar,
	SafeAreaView,
	Image,
	TouchableOpacity,I18nManager
} from "react-native";
import { Images, Colors, Styles } from "@common";
import { translate } from "@languages";
import { EditDeliveryAddressView, MessageModal, Spinner, Toast, AddEditAddress,EditAddressModal ,SimpleMessageModal} from "@components";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";

class EditAddressScreen extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			disableSave: true,
			address_id:"",
			numberAddressesText:"",
			addresses: this.props.userInfo.addresses,
		};
	}
	componentWillReceiveProps(nextProps) {
		if (nextProps.userInfo.addresses !== this.props.userInfo.addresses) {
			this.setState({ addresses: nextProps.userInfo.addresses });
		}
	}
	onAddAddress = () => {
		// after selected All Days Doesn't go to Add Address Page
			if(this.props.userInfo.addresses.length>1 && this.props.userInfo.addresses.length<7){
				this._gotoAddressPage(true,true,null,this.props.numberAddressesAdd[this.props.userInfo.addresses.length-1]);
			}
	}
	deletePress=()=>{
			if (this.props.connected){
				var reqParam={
					"id": this.state.address_id,
					"status":'delete'
				}
				if(this.state.address_id!==""){
					this.props.actions.UpdateUserAction.submitDisableDeleted(reqParam).then(() => {
						if (this.props.userInfo.error) {
							this.toast.show(this.props.userInfo.error);
						}
					})
				}
    
			} else {
				this.toast.show(translate("InternetToast"));
			}
	}
	onDeleteAddress=(address_id,numberAddressesText)=>{
			this.setState({address_id:address_id});
			let buttons  = 
			[
			{
				text: translate("Delete"),
				handler: () => {
				  this.deletePress();
				}
			},
			{
				text: translate("Cancel"),
				isGradient:true,
				handler: () => {
				}
			},
   
		];
			this.refs.messageModal.toggleModal(true, translate("ThankYouDeleteMsg")+" "+numberAddressesText.toLowerCase()+translate("?"),translate("DeleteMessage"),buttons);
	}
	onDisableAddress=(address_id,type)=>{
		if (this.props.connected){
			var reqParam={
				"id":address_id,
				"status":type
			}
				this.props.actions.UpdateUserAction.submitDisableDeleted(reqParam).then(() => {
					if (this.props.userInfo.error) {
						this.toast.show(this.props.userInfo.error);
					}
				})
   
		} else {
			this.toast.show(translate("InternetToast"));
		}
	}
	_gotoAddressPage = (modalVisible, newAddAddress, item,numberOfAddress) => {
		this.refs.refAddEditAddress.toggleAddEditAddressModal(modalVisible, newAddAddress, item,numberOfAddress);
		var userInfo = { ...this.props.userInfo }
		userInfo.changeAddress = {};
		userInfo.secondaryAddress = newAddAddress;
		this.props.actions.UpdateUserAction.updateUserDetails(userInfo);
	}
	saveUpdateAddress = () => {
		if (this.props.connected) {
			this.props.actions.UpdateUserAction.submitAddEditAddress(this.props.userInfo.changeAddress).then(() => {
				// if secondaryAddress is true add mode else edit mode
				if (this.props.userInfo.secondaryAddress) {
					let buttons  = 
					[
					{
						text: translate('AddAddress'),
						isDisable:this.props.userInfo.addresses.length==7?true:false,
						handler: () => {
							this.onAddAddress()
						}
					},
					{
						text: translate("Done"),
						isGradient:true,
						handler: () => {
						}
					},
     
				];
					this.refs.messageModal.toggleModal(true, translate("ThankYouAddAddressMsg"), "updateAddress",buttons);
				} else {
					let buttons  = 
						[
						{
							text: translate('Done'),
							isGradient:true,
							handler: () => {
							}
						}
					];
					this.refs.messageModal.toggleModal(true, translate("ThankYouUpdateAddressMsg"), "updateAddress",buttons);
				}
				// redux update onback pressed
				var userInfo = { ...this.props.userInfo }
				userInfo.changeAddress = {};
				this.props.actions.UpdateUserAction.updateUserDetails(userInfo);
			})
				.catch(e => {
				});
		} else {
			this.toast.show(translate("InternetToast"));
		}
	}
	_openEditAddressModal = (item,numberAddresses,numberOfAddressTitle) => {
		this.refs.editAddressModal.toggleModal(true, item,numberAddresses,numberOfAddressTitle);
		this.setState({numberAddressesText:numberAddresses});
	};
	_closeEditAddressModal = () => {
		this.refs.editAddressModal.toggleModal(false);
	};
	editProfile = (type, item,numberOfAddressTitle) => {
        if (type == "edit") {
			this._gotoAddressPage(true, false, item,numberOfAddressTitle);
        } else if (type == "disable") {
			if(item.isDisable){
				// Days of enable address are alredy in other address then show popup
				var showPopup=false;
				var localWeek = item.daysArray;
				// var weekdays=getDaysFromOtherAddress(item.id,localWeek,this.state.addresses);
				let weekdays = [];
				for (j = 0; j < this.state.addresses.length; j++) {
					var addressItem = this.state.addresses[j];
					if (!addressItem.isDisable && !addressItem.isPrimary && item.id!== addressItem.id) {
						weekdays=weekdays.concat(addressItem.daysArray);
					}
				}
				weekdays = [...new Set(weekdays)];
				// console.log("local",weekdays,localWeek);
				for (let item of localWeek) {
					if(weekdays.indexOf(item)>-1){
						showPopup = true;
					}
				}
					if(showPopup){
						this.refs.simpleMessageModal.toggleModal(true,translate("DisabledErrorMsg"),translate("Error"));
					}else{
						this.onDisableAddress(item.id,"enable");
					}
				
			}else{
				this.onDisableAddress(item.id,"disable");
			}
        } else if (type == "delete") {
            this.onDeleteAddress(item.id,this.state.numberAddressesText);
        }else{
		}
	}
	onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
	};
	render() {
		return (
			<View style={{ flex: 1, margin: 0, padding: 0 }}>
				<SafeAreaView style={Styles.common.safeareView0} />
				<SafeAreaView style={styles.safeareViewBgWhite}>
    				<StatusBar
						barStyle="light-content"
						backgroundColor={Colors.pinkishRed}
						translucent={true}
					/>
					<View style={styles.mainContainer}>
						<View style={styles.headerContainer}>
							<TouchableOpacity style={styles.headerIcon} onPress={() => this.props.navigation.pop()}>
								<Image
									source={I18nManager.isRTL ? Images.icons.right : Images.icons.left}
									defaultSource={Images.icons.left}
									style={styles.backIcon}
								/>
							</TouchableOpacity>
							<View style={styles.headerTitleContainer}>
								<Text style={styles.headerTitle}>{translate("DeliveryAddress")}</Text>
							</View>
							<View style={styles.headerRightView}>
								{this.props.userInfo.addresses.length>1 && this.props.userInfo.addresses.length<7 ?
									<TouchableOpacity
										onPress={() => { this._gotoAddressPage(true, true, null,this.props.numberAddressesAdd[this.props.userInfo.addresses.length-1])}}>
										<Image
											defaultSource={Images.icons.addAddressRound}
											source={Images.icons.addAddressRound}
											style={styles.rightIcon}
										/>
									</TouchableOpacity> : null}
							</View>
						</View>
						<View style={styles.contentContainer}>
							<EditDeliveryAddressView 
								modalAddinsideMainScreen={(modalVisible, newAddAddress, item,numberOfAddress) => {this._gotoAddressPage(modalVisible, newAddAddress, item,numberOfAddress)}}
								_openEditAddressModal={(item,numberAddresses,numberOfAddressTitle)=>this._openEditAddressModal(item,numberAddresses,numberOfAddressTitle)}
							/>
						</View>
						
					</View>
				</SafeAreaView>
				<SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} modalStyle={styles.modal}/>
				<MessageModal ref={"messageModal"}
							modelMessage={false}
						/>
				{this.props.isLoading ? <Spinner mode="overlay" /> : null}
				<Toast refrence={(refrence) => this.toast = refrence} />
				<AddEditAddress ref={"refAddEditAddress"}
					navigation={this.props.navigation}
					onPressSubmitAddress={() => { this.saveUpdateAddress() }}
					addressVal={null}></AddEditAddress>
					{/* from edit deliveryAddressView */}
					<EditAddressModal ref={"editAddressModal"} 
					editProfile={(imagePickType, item,numberOfAddressTitle) => {this.editProfile(imagePickType, item,numberOfAddressTitle)}}/>		
					</View>
		);
	}
}

const mapStateToProps = (state) => {
	return {
		connected: state.updateNetInfoReducer.isConnected,
		userInfo: state.updateUserReducer,
		isLoading: state.updateUserReducer.isLoading,
		numberAddressesAdd:state.fetchMasterListReducer.numberAddressesAdd,
	}
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			MasterList: bindActionCreators(MasterList, dispatch),
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(EditAddressScreen);