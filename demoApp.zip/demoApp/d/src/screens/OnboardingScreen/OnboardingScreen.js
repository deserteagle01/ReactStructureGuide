/** @format */

import React, { PureComponent } from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
    View,
    Text,
    StyleSheet,
    ImageBackground,
    StatusBar,
    SafeAreaView,
    Image,
    TouchableOpacity,
    TextInput,
    I18nManager,
    Dimensions,
    Platform
} from "react-native";

import { Images, Colors, Styles, Validations } from "@common";
import { translate, setI18nConfig } from "@languages";
import { OutlineButton, NeedHelp, GradientButton, LanguageSwitcher, DotIndicator, WhiteButton } from "@components";
import AppIntroSlider from 'react-native-app-intro-slider';
var deviceWidth = Dimensions.get('window').width;
var deviceHeight = Dimensions.get('window').height;
import { NavigationActions, StackActions } from 'react-navigation';
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as UpdateUser from "../../redux/Actions/updateUserAction";
import AsyncStorage from '@react-native-community/async-storage';
import RNRestart from 'react-native-restart';
import {compareVersion, appUpdateLink } from "../../common/Utility";
import  NotificationManager  from '../../common/NotificationManager';

const onboardData = [
    {
        title: "OrderHealthyFoods",
        subText: "Subline",
        btTitle: "blank",
        key: 0
    },
    {
        title: "Trackyourhealth",
        subText: "Subline",
        btTitle: "blank",
        key: 1
    },
    {
        title: "EarnMoney",
        subText: "Subline",
        btTitle: "blank",
        key: 2
    },
    {
        title: "sharesave$love",
        subText: "Subline",
        btTitle: "Getstarted",
        key: 3
    }
];

class OnboardingScreen extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            currentIndex: 1,
        };
    }

    componentDidMount() {
        if(Object.keys(this.props.fetchData[Platform.OS]).length != 0) {
            var isAppUpdate = compareVersion(this.props.fetchData[Platform.OS].current_version);
            var isForceUpdate = compareVersion(this.props.fetchData[Platform.OS].last_force_update_version);
            
            if(isAppUpdate || isForceUpdate) {
              let tempDict = this.props.fetchData[Platform.OS];
              tempDict.forceUpdateFlag = isForceUpdate;
              tempDict.appUpdateFlag = isAppUpdate;
              NotificationManager.show({data: tempDict, type: "update", okclickCallback: () => appUpdateLink(this.props.fetchData[Platform.OS]) });
            }        
        }
    }

    _updateScreen = (lang, isRTL) => {
        I18nManager.forceRTL(isRTL);
        this.forceUpdate();
        setTimeout(() => {
            RNRestart.Restart()
         }, 500)
    }

    skipPress() {
        const reqParams = {
            introComplete: true
        }
        this.props.actions.UpdateUser.updateUserDetails(reqParams);
        this.props.navigation.navigate('LoginScreen');
    }

    WhiteButtonClick() {
        if (this.state.currentIndex == 4) {
            const reqParams = {
                introComplete: true
            }
            this.props.actions.UpdateUser.updateUserDetails(reqParams);
            this.props.navigation.navigate('LoginScreen');
        } else {
            this.AppIntroSlider.goToSlide(this.state.currentIndex)
            this.setState({ currentIndex: this.state.currentIndex + 1 });
        }
    }

    _renderItem = ({ item }) => {
        return (
            <View style={styles.pageView}>
                {
                    translate(item.btTitle).length > 0 ?
                        null
                        :
                        <TouchableOpacity style={styles.btskip} onPress={() => this.skipPress()}>
                            <Text style={styles.txtSkip}>{translate("Skip")}</Text>
                        </TouchableOpacity>
                }

                <Image source={Images.IntroLogo} style={styles.logo} resizeMode="contain" />
                <Text style={styles.txtTitle}>{translate(item.title)}</Text>
                <Text style={styles.txtsubTitle}>{translate(item.subText)}</Text>

                <View style={styles.indicator}>
                    <DotIndicator count={4} filledCount={this.state.currentIndex} />
                </View>

                <WhiteButton
                    onPress={() => this.WhiteButtonClick()}
                    text={translate(item.btTitle)}
                    style={styles.whiteBT} />

                <View style={styles.languageView}>
                    <LanguageSwitcher updateScreen={this._updateScreen} />
                </View>
            </View>
        );
    }

    onPageChanges(page) {
        this.setState({ currentIndex: page + 1 });
    }

    render() {
        return (
            <SafeAreaView style={[Styles.common.safeareView]}>
                <StatusBar
                    barStyle="light-content"
                    backgroundColor={"transparent"}
                    translucent={true}
                />
                <View style={styles.container}>
                    <AppIntroSlider
                        ref={ref => this.AppIntroSlider = ref}
                        onSlideChange={(index) => this.onPageChanges(index)}
                        renderItem={this._renderItem}
                        hidePagination={true}
                        slides={onboardData}
                        showSkipButton={false}
                    />
                </View>
            </SafeAreaView>
        );
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: {
            UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
            UpdateUser: bindActionCreators(UpdateUser, dispatch),
        }
    };
}

const mapStateToProps = (state) => ({
    Connected: state.updateNetInfoReducer.isConnected,
    userDetail: state.updateUserReducer,
    fetchData: state.fetchMasterListReducer
});

export default connect(mapStateToProps, mapDispatchToProps)(OnboardingScreen);


        //this.props.navigation.navigate('App');   //Nothing
        //this.props.navigation.push('OnboardingScreen');    Pushed in same screen but nothing happed because stack does not get relaod 

        // this.props.navigation.dispatch(NavigationActions.reset({
        //      index: 0,
        //      actions: [
        //        NavigationActions.navigate({ routeName: 'Auth'})
        //     ]
        // }));


        // const resetAction = StackActions.reset({
        //     index: 0,
        //     actions: [NavigationActions.navigate({ routeName: 'AuthNavigator' })],
        // });

        // this.props.navigation.dispatch(resetAction);


