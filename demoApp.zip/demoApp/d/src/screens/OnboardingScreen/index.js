import OnboardingScreen from "./OnboardingScreen";
export default OnboardingScreen;
