import { StyleSheet, Dimensions, Platform } from "react-native";
import { Images, Styles, Colors } from "@common";

var deviceWidth = Dimensions.get('window').width;
var deviceHeight = Dimensions.get('window').height;

export default (styles = StyleSheet.create({
container: {
    flex: 1,
    backgroundColor: Colors.pinkishRed,
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  txtSkip:{
    color: Colors.white,
    fontSize: 17,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
    opacity:0.8
  },
  whiteBT:{
      marginTop:(deviceHeight*105)/812
  },
  pageView: {
    // height: deviceHeight, 
    // width: deviceWidth, 
    flex:1,
    //backgroundColor:"lightgray",
    backgroundColor: Colors.pinkishred,
    alignItems:'center' 
},
btskip:{
   position:'absolute',
   right:16,
   top:10,
   alignItems:'center',
   justifyContent:'center'
},
logo:{
   marginTop:(deviceHeight*100)/812,
   height: (deviceHeight*235)/812,
   width:  (deviceWidth * 221) / 375
},
languageView:{ 
  marginTop: (deviceHeight * 44) / 812 
},
btStyle:{
   width:'90%',
   alignItems:'center',
   justifyContent:'center',
   height:56,
   borderRadius:8,
   backgroundColor:Colors.white
},
txtTitle:{
   marginTop:(deviceHeight*30)/812,
   color: Colors.white,
   fontSize: 24,
   letterSpacing:-0.86,
   fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
 },
 txtsubTitle:{
   marginTop:8,
   color: Colors.whiteTransparent,
   fontSize: 15,
   letterSpacing:-0.42,
   fontFamily: Styles.FontFamily().ProximaNova,
   marginHorizontal:55,
   textAlign:'center'
 },
 indicator:{
   marginTop: (deviceHeight * 24)/812,
   height:8,
   //alignItems:"center",
 },
title:{
   color: Colors.pinkishRed,
   fontSize: 17,
   fontFamily: Styles.FontFamily().ProximaNovaBold,
}
  
}));
