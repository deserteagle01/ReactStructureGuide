import { StyleSheet, Dimensions ,Platform} from "react-native";
import {Styles, Colors } from "@common";
const { height, width } = Dimensions.get("window");
export default  styles = StyleSheet.create({
    topContainer: {
        backgroundColor: Colors.pinkishRed,
        height:Styles.height>=812?155:(Styles.height*155)/812,
    },
    bottomContainer:{
        flex:1,
        flexDirection:"column",
    },
    // top styles
    linearGradient:{
        width:Styles.width,
        height: 118,  
        marginTop:183.6
    },
    headerIconContainer:{
        height:52,
        paddingHorizontal:16, 
        alignItems:'flex-end',
        marginTop:Platform.OS=="ios"?(height>=812?40:15):15,
    },
    headerIcon:{
        alignItems:'center',
        justifyContent:"center",
        paddingRight:8,
        paddingTop:8,
        paddingBottom:8,
      },
    imglogo:{
        position:"absolute",
        marginTop:108,
        tintColor:Colors.pinkishRed,
        alignSelf:"center",
        width:48,
        height:48,
      },
      attribContainer:{
          flexDirection: 'row', 
          justifyContent:'space-between', 
          marginHorizontal: 16,
          marginTop: 25,
          minHeight: 85,
    },
    topAttribShimmer: {
        width: "60%", 
        height:"50%",
        borderRadius: 4
    },
    attribShimmer:{
        width:'30%',
        height:'100%',
        borderRadius: 4
    },
    styletxt1:{
        marginLeft: 15
    },
    styletxt2:{
        marginLeft: 15,
        marginTop:10
    },
    walletIcon:{
		width:60,
		height:60,
		tintColor:Colors.pinkishRed
    },
    txtBookTitle: {
        alignSelf:'flex-start',
        color: Colors.pinkishRed,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 17,
        marginLeft: 15
    },
    viewlayer1:{
        flexDirection:'row',
        marginVertical:33
    },
    viewlayer3:{
        flexDirection:'row', 
        alignItems:'center',
    },
    viewlayer2:{
        flex:0.7,
        justifyContent: 'center'
    },
    txtlast:{
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: 14,
        marginHorizontal: 15,
        color: Colors.lightBlack,
        marginTop: 4,
        alignSelf:'flex-start'
    },
    txtlastdate:{
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: 14,
        color: Colors.lightBlack,
        
    },
    rightArrow: {
		width: 16,
		height: 16,
	    marginLeft:8,
		alignSelf: 'center',
	},
    bookCard:{
        marginVertical: 24, 
        marginHorizontal: 16,
        borderRadius: 16,
        backgroundColor:Colors.white,
		shadowColor: 'rgba(0,0,0,0.12)',
		shadowOffset: { width: 0, height: 3 },
		shadowRadius: 7,
		shadowOpacity: 0.8,
        elevation: 6,
    },
    chngContainer:{
        top:-35,
        zIndex: 99,
        position: "absolute",
        marginHorizontal:16,
        height: 70,
        width:Styles.width-32,
		backgroundColor:Colors.white,
		borderRadius: 16,
		flexDirection: "row",
		shadowColor: 'rgba(0,0,0,0.12)',
		shadowOffset: { width: 0, height: 3 },
		shadowRadius: 7,
		shadowOpacity: 0.8,
        elevation: 6,
        alignItems:"center",
        justifyContent:'center',
       
    },
    innerContainer:{
        width:(Styles.width-32)/3,
        flexDirection:"column",
        alignItems:"center",
    },
    divider:{
        width:1,backgroundColor:Colors.lightGray,height:24,alignSelf:"center",
    },
    innerTitle:{
        fontFamily: Styles.FontFamily().ProximaNova,
        letterSpacing:-0.15,
        fontSize:Styles.FontSize.fnt13,
        color: Colors.darkGray,  
    },
    txtTitle:(lang) =>  ({
        alignSelf:'center',
        color: Colors.darkGray,
        fontFamily: Styles.FontFamily(lang).ProximaNovaBold,
        fontSize: 15,
        marginTop: height*0.08
    }),
    graphView:{
        marginTop: height*0.03, 
        height: height*0.3, 
        backgroundColor:'white',
        justifyContent:'center'
    },
    innervalue:{
        marginTop:4,
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize:Styles.FontSize.fnt15,
        letterSpacing:-0.18,
        color: Colors.darkGray,  
    },
// bottom styles
    detail_container:{
        flex: 1,
        backgroundColor:Colors.paleGreyTwo,
    },
    titleContainer:{
        alignSelf:"center",
        position:"absolute",
        marginTop:168,
    },
    title:{
        textAlign:"center",
        alignItems:'center',
        justifyContent:"center",
        lineHeight:36,
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
        fontSize:Styles.FontSize.fnt28,
        color: Colors.black,  
    },
    subTitle:{
        textAlign:"center",
        fontFamily: Styles.FontFamily().ProximaNova,
        fontSize:Styles.FontSize.fnt14,
        color: Colors.black,  
        marginTop:24,
        marginHorizontal:26,
    },
    bottomSubTitle:{
        textAlign:"center",
        fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize:Styles.FontSize.fnt14,
        color: Colors.black, 
        marginHorizontal:26,
        marginTop:20,
    },
    btnBook:{
        marginTop:40,
        marginBottom:40,
    },
    bottomView:{
        flexDirection:"row",
        height:73,
        justifyContent: 'space-between',
        marginHorizontal:16,
        marginBottom:16
    },
      unselectedOption: {
        alignItems:"center",
        justifyContent:"center",
        flex: 0.30,
        paddingBottom:10,
        paddingTop:10,
        backgroundColor:Colors.white,
        borderColor: Colors.lightGray,
        borderRadius: 8,
        borderWidth: 1,
        shadowColor: '#000',
        shadowOffset: { width: 4, height: 5 },
        shadowRadius: 10,
        shadowOpacity: 0.12,
        elevation: 2,
      },
      txtNumDays:{
        fontSize:11,
        fontFamily: Styles.FontFamily().ProximaNova,
        color:Colors.lightBlack
      },
      txtDaysOff:{
        fontSize:17,
        paddingTop:4,
        fontFamily: Styles.FontFamily().ProximaNova,
        color:Colors.darkGray
      }
  });
  