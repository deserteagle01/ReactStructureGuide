import Appointment from "./AppointmentScreen";
export default Appointment;
