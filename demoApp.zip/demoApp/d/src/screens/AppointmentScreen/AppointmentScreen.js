import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import { translate } from "@languages";
import { View, Text, Image, Dimensions, TouchableOpacity } from "react-native";
import { bindActionCreators } from "redux";
import * as Appointment from "../../redux/Actions/Appointment";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import { Images, Colors, Styles, Validations } from "@common";
import { NeedHelp, GradientButton, SimpleMessageModal, Toast, GraphAttribute, AppointmentModal, AppointmentSuccessPopup, Shimmer, Prefetcher } from "@components";
import { sourceScreen } from "../../common/Utility";
import { ScrollView } from "react-native-gesture-handler";
import * as MasterList from "../../redux/Actions/fetchMasterListAction";
import moment from 'moment';
const { height, width } = Dimensions.get("window");
import {
  LineChart
} from "react-native-chart-kit";

const chartConfig = {
  backgroundGradientFromOpacity: 0,
  color: (opacity = 1) => `rgba(164, 170, 177)`,
  labelColor: (opacity = 1) => `rgba(164, 170, 177)`,
  decimalPlaces: 0,
}


class AppointmentScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      attribArray: [
        { id: "1", title: "Weight", subtitle: "No Data" },
        { id: "2", title: "Mussel Mass", subtitle: "No Data" },
        { id: "3", title: "Boady Fat", subtitle: "No Data" },
      ]
    };
  }

  componentDidMount() {
    this.eventListner = this.props.navigation.addListener("didFocus", () => this.focuscalled());
  }

  focuscalled() {
    this.props.actions.MasterList.fetchGenderList();
    this.refs.prefetcherref.startPrefetching({source: sourceScreen.appoitnment});
    if (this.props.Connected) {
        //this.props.actions.Appointment.getAppointmentDashboard(true);
        this.props.actions.Appointment.getAppointmentDashboard(false);
    }
    else {
        this.toast.show(translate("InternetToast"));
    }

    
    if(this.props.navigation.state.params != undefined && this.props.navigation.state.params.hasOwnProperty("isDirectlyOpenPayment")) {
        if(this.props.navigation.state.params.isDirectlyOpenPayment == true && this.props.planData.payment_method == "online") {
            this.refs.refappointmentModal.show(true)
        }
        this.props.navigation.setParams({ 'isDirectlyOpenPayment': false });
    }
}

componentWillReceiveProps(nextProps){
  if(this.props.appointmentData !== nextProps.appointmentData){
        if(nextProps.appointmentData.error != null){
            this.toast.show(nextProps.appointmentData.error);
        }
        else if(nextProps.appointmentData.type == "GET_APPOINTMENT_SUCCESS"){
            
        }
    }
  }
componentWillMount() {
    
  }
  onClose = () => {
    this.refs.simpleMessageModal.toggleModal(false);
  };
  renderAttributes() {
    return this.state.attribArray.map((data, index) => {
      return (
        <View key={index} style={styles.unselectedOption}>
          <Text style={styles.txtNumDays}>{data.title}</Text>
          <Text style={styles.txtDaysOff}>{data.subtitle}</Text>
        </View>)
    });
  }
  renderGender() {
    if(this.props.masterList.hasOwnProperty("gender")){
      return this.props.masterList.gender.map((data, index) => {
        if(data.value == this.props.userDetail.gender){
          return (<View style={styles.innerContainer} key={index}>
            <Shimmer style={styles.topAttribShimmer} visible={!this.props.appointmentData.isLoading_Appointment}>
            <View style={styles.innerContainer} key={index}>
            <Text style={styles.innerTitle}>{translate("Gender")}</Text>
            <Text style={styles.innervalue}>{data.label}</Text>
            </View>
            </Shimmer>
          </View>);
        }else{
          return (<View key={index}/>);
        }
        
      });
  }
}

  renderTopAttributes() {

    return (
      <View style={styles.chngContainer}>
        <View style={styles.innerContainer}>
        <Shimmer style={styles.topAttribShimmer} visible={!this.props.appointmentData.isLoading_Appointment}>
          <View style={styles.innerContainer}>
            <Text style={styles.innerTitle}>{translate("Height")}</Text>
            <Text style={styles.innervalue}>{this.props.appointmentData.height + " " + translate("CM")}</Text>
          </View>
          </Shimmer>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.innerContainer}>
          <Shimmer style={styles.topAttribShimmer} visible={!this.props.appointmentData.isLoading_Appointment}>
          <View style={styles.innerContainer}>
            <Text style={styles.innerTitle}>{translate("Age")}</Text>
            <Text style={styles.innervalue}>{moment().diff(moment(new Date(this.props.userDetail.birth_date), "DD-MM-YYYY"), 'years') + " " + translate("Years")}</Text>
          </View>
          </Shimmer>
        </View>
        <View style={styles.divider}></View>
        {this.renderGender()}
      </View>
    )
  }


  renderEmptyData() {
    return (
      <View>
        <Image
          source={Images.bookAppointmentBackground}
          style={styles.linearGradient}
          resizeMode="cover" />
        <Image
          source={Images.calendarImage}
          style={styles.imglogo}
          resizeMode="cover" />
        <View style={styles.titleContainer}>
          <Text style={styles.title}>{translate("BookApointment")}</Text>
          <Text style={styles.subTitle}>{translate("BookAppointDesc")}</Text>
          <Text style={styles.bottomSubTitle}>{translate("BookAppointBottomSubTitle")}</Text>
        </View>

        <View style={styles.btnBook}>
          <GradientButton
            onPressAction={() => this.refs.refappointmentModal.show()}
            text={translate("BookConsultation")}
          />
        </View>

        <View style={styles.bottomView}>
          {this.renderAttributes()}
        </View>
      </View>
    );
  }

 
 renderGraphAttributes() {
    return (
        <View style={styles.attribContainer}>
            <Shimmer style={styles.attribShimmer} visible={!this.props.appointmentData.isLoading_Appointment}>
                <GraphAttribute title={translate("weight")} color={Colors.weightColor} amount={this.props.appointmentData.weight} diffrence={this.props.appointmentData.weight_difference} unit={translate('KG')} />
            </Shimmer>
            <Shimmer style={styles.attribShimmer} visible={!this.props.appointmentData.isLoading_Appointment}>
                <GraphAttribute title={translate("musslemass")} color={Colors.massColor} amount={this.props.appointmentData.muscle} diffrence={this.props.appointmentData.muscle_difference} unit={translate('KG')} />
            </Shimmer>
            <Shimmer style={styles.attribShimmer} visible={!this.props.appointmentData.isLoading_Appointment}>
                <GraphAttribute title={translate("bodyfat")} color={Colors.fatColor} amount={this.props.appointmentData.fat} diffrence={this.props.appointmentData.fat_difference} unit={translate('KG')} />
            </Shimmer>
        </View>
    );
  }

  renderGraphView() {
    const {customer_body_details, xAxisDate, dataSets} =  this.props.appointmentData;
    return (
      <View style={{backgroundColor:'white'}}>
        <Text style={styles.txtTitle(this.props.switchLanguageReducer.lang)}>{translate("graphTitle")}</Text>
        <View style={styles.graphView}>
          <Shimmer  style={{height:height * 0.30, width:'100%'}} visible={!this.props.appointmentData.isLoading_Appointment}>
          <ScrollView horizontal={true} alwaysBounceHorizontal={false} bounces={false} showsHorizontalScrollIndicator={false}>
          <LineChart
              data={{
                labels: xAxisDate,
                datasets: dataSets,
              }}
              chartConfig={chartConfig}
              withDots={false}
              withInnerLines={false}
              withShadow={false}
              width={customer_body_details.length < 6 ? width :  width * (customer_body_details.length / 6)}
              withOuterLines={true}
              height={height * 0.30}
              yAxisInterval={1}
              bezier />
          </ScrollView>
        </Shimmer>
        </View>
        
                
        {this.renderGraphAttributes()}

        <TouchableOpacity style={styles.bookCard} onPress={() => this.refs.refappointmentModal.show() }>
              <View style={styles.viewlayer1}>
              <View style={styles.viewlayer2}>
              <Shimmer style={styles.styletxt1} visible={!this.props.appointmentData.isLoading_Appointment}>
                  <View style={styles.viewlayer3}>
                      <Text style={styles.txtBookTitle}>{translate("BookApointment")}</Text>
                      {!this.props.appointmentData.isLoading_Appointment &&
                          <Image
                             resizeMode="contain"
                             resizeMethod={"resize"}
                             source={Images.icons.redRightArrow}
                             style={styles.rightArrow} />
                      }
                  </View> 
              </Shimmer>
              <Shimmer style={styles.styletxt2} visible={!this.props.appointmentData.isLoading_Appointment}>
                  <Text style={styles.txtlast}>{translate("lastAppointment")} <Text style={styles.txtlastdate}>{this.props.appointmentData.last_appointment_date}</Text></Text>
              </Shimmer>
                  
              </View>

              <View style={{flex:0.3,alignItems:'center',justifyContent:'center'}}>
                <Shimmer style={[styles.walletIcon, {borderRadius: 4}]} visible={!this.props.appointmentData.isLoading_Appointment}>
                  <Image source={Images.icons.meeting} style={styles.walletIcon} />
                </Shimmer>
              </View>
              </View>
        </TouchableOpacity>

      </View>
    );
  }

  showConfirmedInfo(data) {
    if(data != undefined){
      setTimeout(()=>{
        this.refs.appointmentSuccess.show(data);
      }, 500);
    }
  }

  renderAppointmentModal() {
    return (
      <AppointmentModal {...this.props}
          ref="refappointmentModal" 
          navigation ={this.props.navigation}
          onModalHide={(data) => this.showConfirmedInfo(data)} />
    )
  }

  // Render any loading content that you like here
  render() {
    const {customer_body_details} = this.props.appointmentData;
    return (
      <View style={{ backgroundColor: "white", flex: 1, flexDirection: "column" }}>

        <View style={styles.topContainer}>
          <View style={styles.headerIconContainer}>
            <NeedHelp showIcon={true} notificationPress={() => this.props.navigation.navigate("NotificationList")} />
          </View>
        </View>

        <View style={styles.bottomContainer}>
          {this.renderTopAttributes()}

          <ScrollView style={styles.detail_container} showsVerticalScrollIndicator={false} style={{backgroundColor:Colors.white}}>
            {customer_body_details.length > 0 ?
              this.renderGraphView()
              :
              this.renderEmptyData()
            }

          </ScrollView>
        </View>

        {this.renderAppointmentModal()}
        
        <SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} />
        
        <AppointmentSuccessPopup  ref={"appointmentSuccess"} />
        <Toast refrence={(refrence) => this.toast = refrence} />
        <Prefetcher ref="prefetcherref" />
      </View>
    );
  }
}


function mergeProps(stateProps, dispatchProps, ownProps) {
  const { dispatch } = dispatchProps;
  return {
      ...ownProps,
      ...stateProps,
      actions: {
        Appointment: bindActionCreators(Appointment, dispatch),
        MasterList: bindActionCreators(MasterList, dispatch),
        UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
        Appointment: Appointment.bindActionCreators(dispatch, stateProps),
      }
  };
}

const mapStateToProps = (state) => ({
  Connected: state.updateNetInfoReducer.isConnected,
  userDetail: state.updateUserReducer,
  masterList: state.fetchMasterListReducer,
  switchLanguageReducer: state.switchLanguageReducer,
  appointmentData: state.appointmentReducer,
  planData: state.PlanReducer,
});

export default connect(mapStateToProps, undefined, mergeProps)(AppointmentScreen);
