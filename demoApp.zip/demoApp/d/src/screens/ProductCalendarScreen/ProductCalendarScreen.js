/** @format */

import React, { Component } from "react";
import { connect } from "react-redux";
import styles from "./styles";

import {
	ScrollView,
	View,
	StatusBar,
	SafeAreaView,
	Text,
	Image,
	TouchableOpacity,
	I18nManager,
	Dimensions,
	RefreshControl,
	Animated
} from "react-native";
import LinearGradient from 'react-native-linear-gradient';
import { Images, Colors, Styles, Constants } from "@common";
import { translate } from "@languages";
import { Spinner, Toast, NeedHelp, CalanderBox,SimpleMessageModal,ProductListModal } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as mealsAction from "../../redux/Actions/mealsAction";
import * as fetchMasterListAction from "../../redux/Actions/fetchMasterListAction";
import moment from 'moment';
import 'moment/locale/ar'
import 'moment/locale/en-gb'
import { CalendarList } from '../../lib/react-native-calendars/index';
const dimensionsWidth = Dimensions.get('window').width;

if(I18nManager.isRTL) {
	moment.locale('ar');
}else{
	moment.locale('en-gb');
}
var Deferred = require('promise-deferred');
const theme = {
	'stylesheet.calendar.header': {
		header: {
			...styles.calMonthContainer
		},
		monthText: {
			...styles.activeMonth
		},
		week: {
			...styles.calDayContainer
		},
		dayHeader: {
			...styles.calDayTitleView,...styles.calDayTitle,
			textTransform: 'uppercase'
		},
	},
	'stylesheet.calendar.main': {
		container: {
			...styles.calDateContainer,
		},
		monthView: {
			paddingTop: 9,
			paddingBottom: 8,
			paddingStart: 2,
			paddingEnd: 3,
			height: 425,
		},
		week: {
			...styles.calDateRow
		}
	},
	'stylesheet.calendar-list.main': {
		calendar: {
			paddingLeft: 0,
      		paddingRight: 0
		}
	}
};
class ProductCalendarScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			scrollY: new Animated.Value(1),
			refreshing: false,
			mealDate: null,
			currentCalendarDate: moment(new Date()).format(Constants.dateFormate),
		}
		this.count = 0;
		this.currentMonth = 0;
		this.showBoxDate = moment().startOf('month').toDate();
		this.clickableStatus = {
			"choose-meal": "ChooseMeal",
			"delivered": "Delivered",
			"meal-assign": "MealAssign",
			"pause": "Pause",
			"prepare": "Prepare",
			"rate": "Rate",
		}
	}

	componentDidMount(){
		this.props.navigation.addListener("didFocus", () => this._onDidFocus());
	}

	_onDidFocus = () => {
		const { navigation } = this.props;
		this.count = this.count + 1;
		const mealDate = navigation.getParam('mealDate', null);
		//---- refresh_menu_data method param false because forcefetch = false
		this.refresh_menu_data(false);
		navigation.setParams({ 'mealDate': null });
		if(mealDate){
			this.setState({
				mealDate: mealDate
			});
		}
		let params = {
			mealDate: mealDate,
			forceFetch: false,
			currentMonthDay: this.count == 1 ? moment(new Date()).format(Constants.dateFormate) : this.props.mealsDetail.calendarStartDate
		}
		this.getProductDataApiCall(params);
	}

	shouldComponentUpdate(nextProps,nextState){
		if((this.props.mealsDetail.error != nextProps.mealsDetail.error)  || (this.state.refreshing != nextState.refreshing) ||  (this.state.mealDate != nextState.mealDate)){
			return true;
		}
		return false;
	}

	componentWillReceiveProps(nextProps){
        if(this.props.mealsDetail.action_type != nextProps.mealsDetail.action_type && nextProps.mealsDetail.action_type == "FETCH_MENU_SUCCESS"){
            console.log(" Menu fetch here ------------- receive props");
		}
		else if(this.props.mealsDetail.action_type != nextProps.mealsDetail.action_type && nextProps.mealsDetail.action_type == "FETCH_USER_PRODUCT_PLAN_SUCCESS"){
			let mealDate = this.state.mealDate;
			if(mealDate && nextProps.userSelectedMeal && nextProps.userSelectedMeal[mealDate]) {
				this.setState({ mealDate: null});
				this._gotoProductMenu(nextProps.userSelectedMeal[mealDate]);
			}
			if(this.state.refreshing){
				this.setState({ refreshing: false});
			}
		}
		else if(nextProps.mealsDetail.error != null) {
			this.toast.show(nextProps.mealsDetail.error)
		}
	}
	
	refresh_menu_data(forceFetch) {
		this.props.actions.Meal.fetchMenuList(forceFetch);
	}

	getStartAndEndDay(intStart, intEnd, dateFormat, date) {
        var firstDay = new Date(date.getFullYear(), date.getMonth() + intStart  ,2);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + intEnd, 0);
        lastDay.setHours(23);
        lastDay.setMinutes(59);
        lastDay.setSeconds(59);
        let strFirstday = moment.utc(firstDay).format(dateFormat);   
        let strLastday = moment.utc(lastDay).format(dateFormat);   

        return {
            "strFirstday": strFirstday,
            "strLastday": strLastday
        }
    }

	getProductDataApiCall = (options) => {
		let currentMonthDay = moment(new Date()).format(Constants.dateFormate);
		if (this.props.Connected) {
			let params = {};
			if(options.mealDate) {
				params = {
					'start_date': options.mealDate,
					'end_date': options.mealDate,
					'expand': true
				}
			}
			else {
				let rangeDate = this.getStartAndEndDay(-1 ,2, Constants.dateFormate, options.currentMonthDay ? moment(options.currentMonthDay, Constants.dateFormate).toDate() : new Date());
				params = { 
					start_date: rangeDate.strFirstday, 
					end_date: rangeDate.strLastday, 
					expand: true 
				};
			}
			console.log("params !!!!", params);
			console.log("option !!!!", options.currentMonthDay  ? options.currentMonthDay : currentMonthDay);
			this.setState({currentCalendarDate: options.currentMonthDay  ? options.currentMonthDay : currentMonthDay})
			this.props.actions.Meal.fetchUserProductList(options.forceFetch, params, options.currentMonthDay  ? options.currentMonthDay : currentMonthDay);
		} 
		else {
			this.toast.show(translate("InternetToast"));
			if(this.state.refreshing){
				this.setState({refreshing: false});
			}
		}
	}

	
	_gotoProductMenu(selectedObj){	
		if(this.clickableStatus.hasOwnProperty(selectedObj.status)){
			let datePassed = moment(new Date(selectedObj.date)).lang("en-gb").format(Constants.dateFormate);
			this.refs.ProductListModel && this.refs.ProductListModel.show(datePassed);
		}
	}
	onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
	};
	addCompanyInfo=()=>{
		let options  = 
		{
			htmlContent:I18nManager.isRTL?this.props.fetchMasterList.help_ar:this.props.fetchMasterList.help_en,
		};
		this.refs.simpleMessageModal.toggleModal(true,"", translate("Info"),options);
	}
	_renderDayComponent = ({date, state}) => {
		var key = moment(new Date(date.dateString)).lang("en-gb").format(Constants.dateFormate);
		let userProduct = {};
		if(this.props.userSelectedMeal && this.props.userSelectedMeal[key]){
            userProduct = this.props.userSelectedMeal[key];
        }
		return (
			<TouchableOpacity delayPressIn={0} onPress={() => this._gotoProductMenu(userProduct)}>
			<CalanderBox  boxDate={moment(date.dateString, Constants.dateFormate).toDate()} gotoNext={this._gotoProductMenu} />
			</TouchableOpacity>
		);
	}

	_handleChange = (months) => {
		console.log('_handle change',months);
		if(months && months.length > 0 && months[0]){
			if(this.currentMonth == 0){
				this.currentMonth = months[0].month;
			}
			else{
				var dateHandle = moment(months[0].dateString).toDate();
				var dateShort = moment(dateHandle).format(Constants.dateFormate);
				let params = {
					mealDate: null,
					forceFetch: false,
					currentMonthDay: dateShort
				}
				this.getProductDataApiCall(params);
				this.currentMonth = months[0].month;
			}
		}
	}
	_onRefresh = () => {
		this.setState({
			refreshing: true,
		});
		//---- refresh_menu_data method param true because forcefetch = true at time of refresh control
		this.refresh_menu_data(true);
		let params = {
			mealDate: null,
			forceFetch: true,
			currentMonthDay: this.state.currentCalendarDate
		}
		this.getProductDataApiCall(params);
	}
	_getImageWidth = () => {
        // Image min height is 34,max is imageWH
        const { scrollY } = this.state;
        let w = scrollY.interpolate({
            inputRange: [-250,0],
            outputRange: [84.8,53],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return w;
    };

    _getImageHeight = () => {
        const { scrollY } = this.state;
        // image 30% smaller and fix inside header part. Here,scroll value is 75. 
        let h = scrollY.interpolate({
            inputRange: [-250,0],
            outputRange: [62.4,39],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return h;
	};
	_getImageLocation = (w, h) => {
        const { scrollY } = this.state;
        // 75 indicates scroll value. Image margin top is 13 inside fix header part.
        let scroll = scrollY.interpolate({
            inputRange: [-100,0],
            outputRange: [10,0],
            extrapolate: "clamp",
            useNativeDriver: true
        });
	   return scroll;
	};
	render() {
		const logoImageWidth = this._getImageWidth();
		const logoImageHeight = this._getImageHeight();
		const translateYLoc = this._getImageLocation(logoImageWidth, logoImageHeight);
		//console.log('render method of product calendar screen');
		return (
			<View style={{flex:1}}>
				<SafeAreaView style={styles.customSafearea}>
					<StatusBar
						barStyle="light-content"
						backgroundColor={Colors.pinkishRed}
						translucent={true} />
					<View style={styles.mainContainer}>
						<View style={styles.calendarRedContainer}>
							 <View style={styles.calHeader}>
								<View style={styles.leftContainer}></View>
								<View style={styles.centerContainer}>
									<Animated.Image source={Images.DietLogo} style={[styles.dietLogoSmall,{
									top: translateYLoc,
									width: logoImageWidth,
                                    height: logoImageHeight,
						 		}]} >
									</Animated.Image>
								</View>
								<View style={styles.rightContainer}>
									<NeedHelp showIcon={true} style={{alignSelf: "flex-start"}} notificationPress={() => this.props.navigation.navigate("NotificationList")} />
								</View>
							</View> 
						</View>
						<View style={[{ position: 'relative',flex: 1, paddingBottom: 30 }]}>
						<Animated.ScrollView 
						onScroll={Animated.event(
							[
							  {
								nativeEvent: { contentOffset: { y: this.state.scrollY } }
							  }
							])} contentContainerStyle={[styles.emptyscrollContainer,]} showsVerticalScrollIndicator={false}
						refreshControl={
							<RefreshControl style={{backgroundColor: Colors.pinkishRed}} tintColor={Colors.paleGreyTwo} refreshing={this.state.refreshing} onRefresh={() => {this._onRefresh()}} />
						}
						>
							
								<CalendarList
									onVisibleMonthsChange={(months) => this._handleChange(months)}
									pastScrollRange={10}
									futureScrollRange={10}
									scrollEnabled={true}
									horizontal={true}
									dayComponent={({date, state}) => {
										return this._renderDayComponent({date, state})
									}}
									theme={theme}
									calendarHeight={523}
									pagingEnabled={true}
									current={this.state.mealDate || this.state.currentCalendarDate || null}
									loadingIndicatorText = {translate("Loading")}
								/>
						</Animated.ScrollView>
						<View style={{position: 'absolute',top: 0,left: 0,width: '100%',height: '100%',zIndex: -1,}}>
							<View style={{ flex: 1, backgroundColor: Colors.pinkishRed }}/>
							<View style={{ flex: 1, backgroundColor: Colors.paleGreyTwo }}/>
						</View>
						</View>
						<View style={{position: 'absolute',bottom: 0,width: dimensionsWidth,minHeight: 40,flex: 1,backgroundColor: Colors.paleGreyTwo,alignItems: 'center',justifyContent: 'center'}}>
							<TouchableOpacity onPress={this.addCompanyInfo}>
								<View style={styles.infoContainer}>
									<Image source={Images.icons.info_ic} />
								</View>
							</TouchableOpacity> 
						</View>
					</View>
				</SafeAreaView>
				<Toast refrence={(refrence) => this.toast = refrence} />
				<SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} modalStyle={styles.modal} 
				modalStyle={styles.modal}
				/>
				<ProductListModal ref={"ProductListModel"} />
				</View>
		);
	}
}

const mapStateToProps = (state) => {
	//console.log("mealsReducer=="+JSON.stringify(state.mealsReducer))
	return {
		Connected: state.updateNetInfoReducer.isConnected,
		mealsDetail: state.mealsReducer,
		userSelectedMeal: state.mealsReducer.userProduct,
		fetchMasterList: state.fetchMasterListReducer,
	}
};

function mergeProps(stateProps, dispatchProps, ownProps) {
        const { dispatch } = dispatchProps;
        return {
            ...ownProps,
            ...stateProps,
            actions: {
				UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
				mealsAction: bindActionCreators(mealsAction, dispatch),
        		Meal: mealsAction.bindActionCreators(dispatch , stateProps),
            }
    };
}

export default connect(mapStateToProps, undefined, mergeProps)(ProductCalendarScreen);
