import { StyleSheet, Dimensions ,Platform} from "react-native";
import { Colors, Styles } from "@common";
const dimensionsWidth = Dimensions.get('window').width;
const dimensionsHeight = Dimensions.get('window').height;
export default  styles = StyleSheet.create({
    customSafearea:{
        flex: 1,
        backgroundColor: Colors.pinkishRed
    },
    mainContainer: {       
        flex: 1, 
        width: '100%',
        // backgroundColor: Colors.pinkishRed,
        ...Platform.select({
            android: {
              marginTop: 20,
            },
        }),
        // height: Platform.OS === 'ios'?dimensionsHeight < 700? 600: dimensionsHeight - 135: dimensionsHeight - 20,
        backgroundColor: Colors.paleGreyTwo, 
    },
    calendarRedContainer:{
        ...Platform.select({
            android: {
              marginTop: 3,
            },
        }),
    },
    calHeader:{
        flexDirection: "row",
        height: 78,
        paddingHorizontal: 16,
        paddingBottom: 16,
        backgroundColor: Colors.pinkishRed
    },
    leftContainer: {
		alignItems: "flex-start",
		width: "33.3%"
	},
	centerContainer: {
        alignItems: "center",
        justifyContent: 'center',
		width: "33.3%"
	},
	rightContainer: {
        alignItems: "flex-end",
		width: "33.3%",
	},
    dietLogoSmall:{
        height: 39,
        width: 53,
        //aspectRatio: 1
    },
    // calContainer:{
    //     justifyContent: 'center',
    //     marginTop: 31,
    // },
    calMonthContainer:{
        flexDirection: 'row',
        height: 52,        
        alignItems: 'center',
        justifyContent: 'space-between',
        // paddingHorizontal: 5,
        backgroundColor: Colors.pinkishRed
    },
    inactiveMonth:{
        color: 'rgba(255, 255, 255, 0.4)',
        fontSize: 15,
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
        lineHeight: 36,
    },
    activeMonth:{
        color: 'rgba(255, 255, 255, 1)',
        fontSize: 17,
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
        lineHeight: 36,
    },
    emptyscrollContainer:{
        flexGrow: 1
    },
    scrollContainer:{
        alignItems:'center',
        shadowColor: 'rgba(0, 0, 0, 0.6)',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.12,
        shadowRadius: 19.65,
        elevation: 7
    },
    calDayContainer:{
        flexDirection: 'row',
        height: 46,
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 5,
        backgroundColor: "#e7e9ed",
    },
    calDayTitleView: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 7,
        borderRightWidth: 1,
        borderColor: 'rgba(106, 109, 122, 0.1)',
    },
    calDayTitle: {
        color: "rgba(106, 109, 122,0.6)",
        fontSize: 14,
        fontFamily: Styles.FontFamily().ProximaNova,
        lineHeight: 18,
        width: (dimensionsWidth / 7) - 5,
        textAlign: 'center',
    },
    calContainer:{
        paddingTop: 13,
    },
    calDateContainer:{
        backgroundColor: Colors.white,
        paddingStart: 0,
        paddingEnd: 0,
    },
    calDateRow:{
        flexDirection: 'row',
        paddingHorizontal: 5,
        width: dimensionsWidth,
        height: 68,
    },
    // Blank Box Space
    blankDayBoxContainer:{
        width: (dimensionsWidth / 7) - 5,
        height: (dimensionsWidth / 7) * 1.1,        
        marginRight: 4
    },
    linearGradient:{
        width: (dimensionsWidth / 7) - 5,
        height: (dimensionsWidth / 7) * 1.1,
        borderRadius: 8,    
        marginRight: 4,
        shadowColor: 'rgba(0, 0, 0, 0.6)',
        shadowOffset: { width: 0, height: 8 },
        shadowRadius: Platform.OS === 'ios'?16:32,
        shadowOpacity: 0.24,
        elevation: Platform.OS === 'ios'?5:10,
    },
    infoContainer:{
        justifyContent: 'center', 
        // paddingTop:40,
        width:28,
        height:28, 
        alignItems:'center',       
        justifyContent: 'center', 
    },
    modal:{
        maxHeight:dimensionsHeight-120,
        paddingLeft:10,
        paddingRight:10,
        paddingBottom: 10
    },
    emptyView:{
        height: 523, 
        backgroundColor: Colors.paleGreyTwo,
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    }
});
