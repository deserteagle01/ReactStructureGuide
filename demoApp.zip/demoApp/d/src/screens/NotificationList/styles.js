import { StyleSheet, Dimensions, Platform } from "react-native";
import { Images, Styles, Colors } from "@common";
const screen = Dimensions.get("window");

export default  styles = StyleSheet.create({
  mainContainer:{
    flex:1,
    backgroundColor:Colors.paleGreyTwo,
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  customSafearea:{
    flex:1,
    backgroundColor:Colors.paleGreyTwo,
  },
  headerContainer:{
    flexDirection:'row',
    alignItems:"center",
    justifyContent:"center",
    backgroundColor: Colors.pinkishRed,
  },
  headerIcon:{
    height:52,
    width:100,
    alignItems: 'flex-start',
    justifyContent:'center',
  },
  backIcon:{
    width:28,
    height:28,
    marginHorizontal:6
  },
  headerTitleContainer:{
    width:screen.width-200,
    justifyContent:'center',
    alignItems:'center',
  },
  headerTitle:{
    color: Colors.white,
    alignSelf:'center',
    fontSize: Styles.FontSize.fnt17,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    textAlign: 'left'
  },
  contentContainer:{
    flex:1,
    paddingTop:12,
  },
  saveBtn:{
    color: Colors.white,
    fontSize: Styles.FontSize.fnt17,
    fontFamily: Styles.FontFamily().ProximaNovaBold,
  },
  txtclear: {
      alignItems:'center',
      justifyContent:'center',
      width:100,
  },
  rowView:{
      width:screen.width-32,
      backgroundColor:Colors.white,
      marginVertical: 4,
      marginHorizontal:16,
      flexDirection: 'row',
      alignItems:"center",
  },
  bellicon:{
    width:24,height:24
  },
  txtTitle:{
    // flex:1,
    width:180,
    marginTop: 16,
    color: Colors.black,
    fontSize: Styles.FontSize.fnt15,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
  },
  txtdesc:{
    marginTop: 8,
    color: Colors.black,
    fontSize: Styles.FontSize.fnt13,
    fontFamily: Styles.FontFamily().ProximaNova,
    marginBottom: 16,
  },
  txtTime:{
    width:screen.width-80-180-8,
    color: Colors.black,
    marginHorizontal: 8,
    marginTop: 16,
    fontSize: Styles.FontSize.fnt13,
    fontFamily: Styles.FontFamily().ProximaNova,
  },
  headerView:{
      flexDirection: 'row',
      alignItems: 'center',
      width:screen.width-80,
      // backgroundColor:"red"
  },
  emptyContainer: {
      height:'100%',
      width: '100%',
      alignItems:'center',
      justifyContent:'center'
  },
  bellicon2: {
    height: 60,
    width:60
  },
  txtView:{
    marginTop: 16,
    width: 150,
    height: 40,
    alignItems:'center',
    justifyContent:'center'
  },
  txtfirst: {
    color: Colors.lightBlack,
    fontSize: Styles.FontSize.fnt14,
    fontFamily: Styles.FontFamily().ProximaNova,
    textAlign:'center'
  },
  imageContainer:{
    justifyContent:"center",
    alignItems:"center",
    width:24,
    height:24,
    marginHorizontal:8,
  },
  desciption:{
    flexDirection:"column",
    width:screen.width-80,
   
  }
  
});
