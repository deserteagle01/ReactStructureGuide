import NotificationList from "./NotificationList";
export default NotificationList;
