import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, StatusBar, Image, I18nManager, FlatList } from "react-native";
import { bindActionCreators } from "redux";
import * as NotificationAction from "../../redux/Actions/Notification";
import { Images, Colors, Styles } from "@common";
import { translate, setI18nConfig } from "@languages";
import { Spinner, Toast } from "@components";
import moment from 'moment';
import  distanceInWordsToNow from 'date-fns/distance_in_words_to_now';
import isYesterday from 'date-fns/is_yesterday'
var limit = 10;
var offset = 0;

class NotificationList extends React.Component {
  constructor(props) {
    super(props);
    this.state = { notificationList: [] }
    this.onEndReachedCalledDuringMomentum = true;
  }

  componentDidMount() {
    this.getNotificationList(offset, limit);
  }

  getNotificationList(offsets, limits) {
    if (this.props.Connected) {
      this.props.actions.NotificationAction.getNotificationAction(offsets, limits).then(() => {
        if (this.props.NotificationData.error) {
          this.toast.show(this.props.NotificationData.error);
        } else {
          if(this.state.notificationList.length == 0) {
              this.readNotification(this.props.NotificationData.notifications[0].id);
          }
          let config_array = [...this.props.NotificationData.notifications];
          this.setState({ notificationList: [...this.state.notificationList, ...config_array] });
        }
      });
    }
    else {
      this.toast.show(translate("InternetToast"));
    }
  }

  clearNotification(id) {
    if (this.props.Connected) {
      this.props.actions.NotificationAction.clearNotificationAction(id).then(() => {
        if (this.props.NotificationData.error) {
          this.toast.show(this.props.NotificationData.error);
        } else {
            this.setState({notificationList: []})
            this.getNotificationList(0, limit);   
        }
      });
    }
    else {
      this.toast.show(translate("InternetToast"));
    }
  }

  readNotification(id) {
    if (this.props.Connected) {
      this.props.actions.NotificationAction.readNotificationAction(id).then(() => {
        if (this.props.NotificationData.error) {
          this.toast.show(this.props.NotificationData.error);
        } else {

        }
      });
    }
    else {
      this.toast.show(translate("InternetToast"));
    }
  }


  _renderItem = ({ item }) => {
    let date = moment(item.create_date, "YYYY-MM-DD HH:mm:ss").toDate();
    var result = isYesterday(date)
    var strTime = "";
    if(result) {
        strTime = "Yesterday"
    }else{
        strTime = distanceInWordsToNow(date,{ addSuffix: true});
    }
    return (
      <View style={styles.rowView}>
        <View style={styles.imageContainer}>
          <Image source={Images.icons.bell_grey} style={styles.bellicon} resizeMode="contain" />
        </View>
        <View style={styles.desciption}>
          <View style={styles.headerView}>
            <Text numberOfLines={1} style={styles.txtTitle}>{item.subject}</Text>
            <Text numberOfLines={1} style={styles.txtTime}>{strTime}</Text>
          </View>
         <Text style={styles.txtdesc}>{item.body_plain}</Text>
        </View>
      </View>
    );
  }

  onEndReached(distanceFromEnd) {
    if (this.props.NotificationData.notifications.length == 10) {
      this.getNotificationList(this.state.notificationList.length, limit);
    }
  }
  onBackPress(){
    const { navigation } = this.props;
		const isFormHome = navigation.getParam('isFromHome', false);
    if(isFormHome){
      this.props.navigation.navigate('Home',{'isFromBack':true});
    }else{
      this.props.navigation.pop();
    }
  }
  render() {
    return ( <View style={{ flex: 1 }}>
      <SafeAreaView style={[Styles.common.safeareView0]} />
        <StatusBar
            barStyle="light-content"
            backgroundColor={Colors.pinkishRed}
            translucent={true} />
          <View style={styles.mainContainer}>
            <View style={styles.headerContainer}>
              <TouchableOpacity style={styles.headerIcon} onPress={() => {
                this.onBackPress()}}>
                <Image
                  source={I18nManager.isRTL ? Images.icons.right : Images.icons.left}
                  style={styles.backIcon} />
              </TouchableOpacity>

              <View style={styles.headerTitleContainer}>
                <Text style={styles.headerTitle}>{translate("txtNotificationTitle")}</Text>
              </View>
{ this.state.notificationList.length > 0?
              <TouchableOpacity 
                style={styles.txtclear} 
                onPress={() => this.clearNotification(this.state.notificationList[0].id)}>
                <Text style={styles.saveBtn}>{translate("txtclear")}</Text>
              </TouchableOpacity>:<View style={styles.txtclear}/>}


            </View>

            <View style={styles.contentContainer}>
              <FlatList
                showsVerticalScrollIndicator={false}
                data={this.state.notificationList}
                keyExtractor={(item, index) => index.toString()}
                renderItem={this._renderItem}
                extraData={this.state}
                onEndReached={(distanceFromEnd) => this.onEndReached(distanceFromEnd)}
                onEndReachedThreshold={0.1} />
                {this.state.notificationList.length == 0 &&
                  <View style={styles.emptyContainer}>
                      <Image 
                        source={Images.icons.turnNotifications} 
                        style={styles.bellicon2} 
                        resizeMode="contain" />
                        <View style={styles.txtView}>
                          <Text style={styles.txtfirst}>{translate("txtEmpty")}</Text>
                        </View>
                  </View>
                }
            </View>

          </View>
          <Toast refrence={(refrence) => this.toast = refrence} />
        {this.props.NotificationData.isLoading ? <Spinner mode="overlay" /> : null}  
      </View>
    );
  }
}


function mapDispatchToProps(dispatch) {
  return {
    actions: {
      NotificationAction: bindActionCreators(NotificationAction, dispatch),
    }
  };
}

const mapStateToProps = (state) => ({
  Connected: state.updateNetInfoReducer.isConnected,
  NotificationData: state.notificationReducer
});

export default connect(mapStateToProps, mapDispatchToProps)(NotificationList);
