import ChangePwd from "./ChangePwdScreen";
export default ChangePwd;
