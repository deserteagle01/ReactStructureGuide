import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  StatusBar,
  SafeAreaView,
  Image,
  TouchableOpacity,
  TextInput,
  I18nManager,ScrollView
} from "react-native";
import { Images, Colors, Styles } from "@common";
import { translate, setI18nConfig } from "@languages";
import { OutlineButton, NeedHelp, GradientButton, ChangePwdInput, Spinner} from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

class ChangePwdScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state={
      disableSave:false
    }
  }
  _onPressSave = () =>{
    this.refs.refChangePwd.validateData();
  }
  onCanShowSave = (val)=> {
    // if(val){
    //   this.setState({disableSave : false})
    // }else{
    //   this.setState({disableSave : true})
    // }
  }

  // Render any loading content that you like here
  render() {
    return (
      <View style={{flex:1}}>
      <SafeAreaView style={[Styles.common.safeareView0]} />
      <SafeAreaView style={styles.customSafearea}>
           <StatusBar
              barStyle="light-content"
              backgroundColor={Colors.pinkishRed}
              translucent={true} />
          <View style={styles.mainContainer}>
              <View style={styles.headerContainer}>
                      <TouchableOpacity style={styles.headerIcon} onPress={() => this.props.navigation.pop()}>
                          <Image
                            source={this.props.languagesProps.lang == "ar" ? Images.icons.right :  Images.icons.left}
                            defaultSource={Images.icons.left}
                            style={styles.backIcon}
                          />
                      </TouchableOpacity>
                      <View style={styles.headerTitleContainer}>
                        <Text style={styles.headerTitle}>{translate("ChangePassword")}</Text>
                      </View>
                      <View style={styles.headerRightView}>
                          <TouchableOpacity style={{}} disabled={this.state.disableSave} onPress={() => this._onPressSave()}>
                              <Text style={styles.saveBtn}>{translate("Save")}</Text>
                          </TouchableOpacity>
                      </View>
              </View>
              <View style={styles.contentContainer}>
                      <ChangePwdInput ref={"refChangePwd"}  onPress={() => this._onPressSave()}/>
              </View>
          </View>
        </SafeAreaView>
        {this.props.isLoading ? <Spinner mode="overlay" /> : null}
      </View>
    );
  }
}


function mapDispatchToProps(dispatch) {
  return {
    actions: {
      UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
    }
  };
}

const mapStateToProps = (state) => ({
  Connected: state.updateNetInfoReducer.isConnected,
  languagesProps: state.switchLanguageReducer,
  isLoading: state.updateUserReducer.isLoadingChangePwd,
  pwdDetail: state.updateUserReducer,
  sucessChangePwd: state.updateUserReducer.sucessChangePwd,
  error:state.updateUserReducer.errorChangePwd,
});

export default connect(mapStateToProps, mapDispatchToProps)(ChangePwdScreen);
