import Wallet from "./WalletScreen";
export default Wallet;
