import { StyleSheet, Dimensions, Platform, PixelRatio } from "react-native";
import { Images, Styles, Colors } from "@common";
import normalize from 'react-native-normalize';
const {height,width} = Dimensions.get('screen');
export default styles = StyleSheet.create({
    customSafearea:{
        flex:1,
     },
     container:{ 
         flex: 1, 
         margin: 0, 
         padding: 0,
         backgroundColor:Colors.paleGreyTwo 
    },
    mainContainer:{
        flex:1,
        backgroundColor:Colors.paleGreyTwo,
        flexDirection:"column",
        ...Platform.select({
        android: {
           marginTop: 20,
        },
       }),
     },
    headerContainer:{
        height:normalize(253),
        // borderColor:"green",
        // borderWidth:2,
        width:"100%",
        backgroundColor:Colors.pinkishRed,
        // ...Platform.select({
        //     android: {
        //        paddingBottom: 20,
        //     },
        //    }),
      },
    bottomContainer:{
        flex:1,
    },
    headerIconContainer:{
        height:normalize(52),
        backgroundColor:Colors.pinkishRed,
        flexDirection:'row',
        justifyContent:'space-between',
        alignItems:"flex-start",
        paddingHorizontal:16,  
    },
    headerIcon:{
        alignItems:'center',
        paddingRight:8,
        paddingTop:8,
        paddingBottom:8,
    },
    backIcon:{
        width:28,
        height:28
    },
    titleContainer:{
        alignItems: 'center',
        justifyContent:"center", 
        marginTop:normalize(40)
    },
    titleWallet:{
        color: Colors.whiteTransparent,
        fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
        fontSize:normalize(12),
        letterSpacing:-0.14,
    },
    title: {
        marginTop:6,
        color: Colors.white,
        fontSize: normalize(34),
        lineHeight: normalize(36),
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    },
    frdBtn:{
        borderRadius: 8,
        backgroundColor:Colors.white,
        borderColor:Colors.white,
        paddingHorizontal:16,
        height: normalize(40),
        alignItems: 'center',
        justifyContent:"center", 
    },
    textFrd:{
        color:Colors.pinkishRed,
        lineHeight:24,
    },
    infoIcon:{
		width:normalize(22),
		height:normalize(22),
        tintColor:Colors.white,
    },
    absContainer:{
        flexGrow: 1,
        left: 0,
        position:"absolute",
        right: 0,
        bottom:0,
        flexDirection: "column",
        top:50
    },
    listStyle:{
        flexGrow:1,
        paddingTop:normalize(30),
    },
    modal:{
        maxHeight:height-120,
        paddingLeft:20,
        paddingRight:0,
        paddingBottom: 20
    },
    btnContainer:{
        marginTop:normalize(16),
        alignItems:"center",
    },
});
