import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import { Images, Colors, Styles, AppConfig } from "@common";
import { NeedHelp, ModalButton,SimpleMessageModal,Toast,Spinner,PlanStatus,InviteModal,WalletCards} from "@components";
import { translate, setI18nConfig } from "@languages";
import { View, Text, StyleSheet, Platform, StatusBar, SafeAreaView, Image, TouchableOpacity, I18nManager ,FlatList,ScrollView,Dimensions,Animated,} from "react-native";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import * as walletListAction from "../../redux/Actions/walletListAction";
const {height,width} = Dimensions.get('screen');
import normalize from 'react-native-normalize';
class WalletScreen extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            scrollY: new Animated.Value(0),
        }
    }
    onClose = () => {
        this.refs.simpleMessageModal.toggleModal(false);
      };
    componentDidMount() {
        if (this.props.Connected) {
            this.props.actions.walletListAction.fetchWalletList().then(() => {

                if (this.props.walletListData.error) {
                    this.toast.show(this.props.walletList.error);
                }
            });
        } else {
            this.toast.show(translate("InternetToast"));
        }
    }
    _renderItem = ({ item ,index}) => {
        return (
            <WalletCards
                            item={item}
                        />
        );
    }
    _openInviteFrdModal = () => {
        this.refs.inviteFrdModal.toggleModal(true,translate("InviteFrd"));
    };
    onModalHide=()=>{
        this.refs.inviteFrdModal.toggleModal(false);
    }
    onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
    };
    addCompanyInfo=()=>{
		let options  = 
		{
			htmlContent:I18nManager.isRTL?this.props.fetchMasterList.wallet_help_text_ar:this.props.fetchMasterList.wallet_help_text,
		};
		this.refs.simpleMessageModal.toggleModal(true,"", translate("Info"),options);
    }
    opacityValBottom= () => {
        const { scrollY } = this.state;
        // 0 means View invisible, 1 means Visible. Here, scroll value is 105 at that time 0 value is set to opacity  .
        let opacity = scrollY.interpolate({
            inputRange: [0, 105],
            outputRange: [1, 0],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return opacity;
    };
    opacityValTop=()=>{
        const { scrollY } = this.state;
        // 0 means View invisible, 1 means Visible. Here, scroll value is 40 at that time 0 value is set to opacity  .
        let opacity = scrollY.interpolate({
            inputRange: [0, 40],
            outputRange: [1, 0],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return opacity;
    }

    render() {
        const opacityValBottom=this.opacityValBottom();
        const opacityValTop=this.opacityValTop();
        return (
            <View style={styles.container}>
            <SafeAreaView style={Styles.common.safeareView0} />
            <SafeAreaView style={[Styles.common.safeareViewOnly,{backgroundColor:Colors.paleGreyTwo}]}>
                <StatusBar
                    barStyle="light-content"
                    backgroundColor={Colors.pinkishRed}
                    translucent={true} />
                <View style={styles.mainContainer}>
                <View style={styles.headerIconContainer}>
                                    <TouchableOpacity style={styles.headerIcon} onPress={() => {
                                        this.props.navigation.goBack()}}>
                                        <Image
                                            source={I18nManager.isRTL ? Images.icons.right : Images.icons.left}
                                            style={styles.backIcon}
                                        />
                                    </TouchableOpacity>
                                    <NeedHelp showIcon={true} notificationPress={() => this.props.navigation.navigate("NotificationList")} />
                            </View>
                        <View style={styles.headerContainer}>
                        </View>
                        <View style={styles.bottomContainer}>
                        
                        </View> 
                        <View style={styles.absContainer}>
                        <Animated.ScrollView contentContainerStyle={{flexGrow:1}} showsVerticalScrollIndicator={false}
                         onScroll={Animated.event([
                            {
                                nativeEvent: { contentOffset: { y: this.state.scrollY } }
                            }
                        ])}>
                            <View style={{flexDirection:"column"}}>
                            <Animated.View style={[styles.titleContainer,{opacity:opacityValTop}]}>
                                <Text style={styles.titleWallet}>{translate("YOURWALLET")}</Text>
                                <Text style={styles.title}>{parseFloat(this.props.walletListData.totalAmount).toFixed(2) + " " + translate("KD")}</Text>
                                       
                            </Animated.View>
                            <Animated.View style={[styles.btnContainer,{opacity:opacityValBottom}]}>
                                <ModalButton
                                                    btnStyle={styles.frdBtn}
                                                    textStyle={styles.textFrd}
                                                    isCheckedVisible={false}
                                                    onPress={() =>{this._openInviteFrdModal();}}
                                                    label={translate("InviteFriends")}
                                />
                                        <TouchableOpacity onPress={()=>{this.addCompanyInfo()}} style={{width:normalize(22),
                                            height:normalize(22),alignItems:"center",
                                            marginTop:normalize(14),
                                            justifyContent:"center"}}>
                                            <Image source={Images.icons.info_ic} style={styles.infoIcon} />
                                        </TouchableOpacity> 
                            </Animated.View> 
                            <FlatList
                                style={styles.listStyle}
                                showsVerticalScrollIndicator={false}
                                data={this.props.walletListData.walletList}
                                renderItem={(item, index) => this._renderItem(item, index)}
                                keyExtractor={(item, index) => index.toString()}
                                extraData={this.state}
                            /> 
                            </View>
                        </Animated.ScrollView>                     
                    </View>
                </View>
                <Toast refrence={(refrence) => this.toast = refrence} /> 
                <SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} 
				modalStyle={styles.modal}
				/>
            </SafeAreaView>
            {this.props.walletListData.isLoading?<Spinner mode="overlay"/> : null}
            <InviteModal 
                ref={"inviteFrdModal"}
                shareText={this.props.userData.share_message}
                referralCode={this.props.userData.referral_code}
            	onModalHide={()=>{this.onModalHide()}} />
            </View>
        );
    }
}
function mapDispatchToProps(dispatch) {
    return {
        actions: {
            UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
            walletListAction: bindActionCreators(walletListAction, dispatch),
        }
    };
}
const mapStateToProps = (state) => {
    return {
        Connected: state.updateNetInfoReducer.isConnected,
        userData: state.updateUserReducer,
        walletListData:state.walletListReducer,
        fetchMasterList: state.fetchMasterListReducer,
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(WalletScreen);
