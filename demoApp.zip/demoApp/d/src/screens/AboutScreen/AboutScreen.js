import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
  View,
  Text,
  StatusBar,
  SafeAreaView,
  Image,
  TouchableOpacity,I18nManager
} from "react-native";
import { Images, Styles, Colors } from "@common";
import { translate } from "@languages";
import { NeedHelp, ProfileComponent, PrivacyPolicy } from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import DeviceInfo from 'react-native-device-info';

class AboutScreen extends React.Component {

  constructor(props) {
    super(props);
  }

  openPrivacyPolicyModal = () => {
		this.refs.refPrivacyPolicy.togglePrivacyPolicyModal(true);
	}

  // Render any loading content that you like here
  render() {
    return (
      <View style={{flex:1}}>
      <SafeAreaView style={Styles.common.safeareView}>
         <StatusBar
              barStyle="light-content"
              backgroundColor={Colors.pinkishRed}
              translucent={false} />
          <View style={styles.mainContainer}>
            <View style={styles.headerContainer}>
                  <View style={styles.headerIconContainer}>
                      <TouchableOpacity style={styles.headerIcon} onPress={() => this.props.navigation.pop()}>
                          <Image
                            source={I18nManager.isRTL ? Images.icons.right : Images.icons.left}
                            style={styles.backIcon}
                          />
                      </TouchableOpacity>
                      <NeedHelp style={{marginTop:2}} showIcon={true} notificationPress={() => this.props.navigation.navigate("NotificationList")} />
                  </View>

                  <View style={styles.headerTitleContainer}>
                    <Text style={styles.headerTitle}>{translate("About")}</Text>
                  </View>
              </View> 
            <View style={styles.contentContainer}>
                  <ProfileComponent
                    icon={Images.icons.phone}
                    mainText={translate("AppVersion")}
                    subText={translate("AboutV") + DeviceInfo.getVersion() + " ("+translate("AboutBuild") +" " + DeviceInfo.getBuildNumber()+")"}/>
                  <TouchableOpacity onPress={this.openPrivacyPolicyModal}>
                      <ProfileComponent
                        icon={Images.icons.docs}
                        mainText={translate("PrivacyPolicy")}
                        subText={""}/>
                  </TouchableOpacity>
                
              </View>
          </View>
        </SafeAreaView> 
        <PrivacyPolicy ref={"refPrivacyPolicy"} notShowBtn={true}></PrivacyPolicy>
        </View>
         );
  }
}


function mapDispatchToProps(dispatch) {
  return {
    actions: {
      UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
    }
  };
}

const mapStateToProps = (state) => ({
  Connected: state.updateNetInfoReducer.isConnected,
  languagesProps: state.switchLanguageReducer
});

export default connect(mapStateToProps, mapDispatchToProps)(AboutScreen);
