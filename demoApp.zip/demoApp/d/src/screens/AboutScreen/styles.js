import { StyleSheet, Dimensions, Platform } from "react-native";
import { Images, Styles, Colors } from "@common";
const screen = Dimensions.get("window");

export default  styles = StyleSheet.create({
  mainContainer:{
     height:Styles.height,
    backgroundColor:Colors.white,
    ...Platform.select({
      android: {
        marginTop: 20,
      },
    }),
  },
  headerContainer:{
    height:112,
    marginBottom:8,
    backgroundColor:Colors.pinkishRed,
  },
  headerIconContainer:{
    height:52,
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:"flex-start",
    paddingHorizontal:16,  
  },
  headerIcon:{
    alignItems:'center',
    justifyContent:"center",
    paddingRight:8,
    paddingTop:8,
    paddingBottom:8,
  },
  backIcon:{
    width:28,
    height:28
  },
  headerEndIcon:{
    justifyContent:'flex-end',
  },
  headerTitleContainer:{
    justifyContent:'flex-end',
    height:52,
  },
  headerTitle:{
    marginLeft: 16,
    color: Colors.white,
    fontSize: Styles.FontSize.fnt28,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    textAlign: 'left',
  },
  contentContainer:{
    flex:0.81,
    backgroundColor:'white'
  },
});
