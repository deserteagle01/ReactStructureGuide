import EditProfile from "./EditProfileScreen";
export default EditProfile;
