import React from "react";
import { connect } from "react-redux";
import styles from "./styles";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  StatusBar,
  SafeAreaView,
  Image,
  TouchableOpacity,
  TextInput,
  I18nManager,ScrollView
} from "react-native";
import { Images, Colors, Styles } from "@common";
import { translate, setI18nConfig } from "@languages";
import { OutlineButton, NeedHelp, GradientButton, ProfileComponent, EditProfileInput, Spinner,SimpleMessageModal} from "@components";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "../../redux/Actions/getNetInfoAction";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

class EditProfileScreen extends React.Component {
  constructor(props) {
    super(props);
  }
  
  _onPressSave = () =>{
    // alert('save')
    this.refs.refEditProfile.validateData();
  }
  showSimpleModal=(value)=>{
    if(value=="Success")
    {
      this.refs.simpleMessageModal.toggleModal(true,translate("profileSucessMessage"),translate("Success"));
    }else if(value=="Error"){
       this.refs.simpleMessageModal.toggleModal(true,this.props.error,translate("Error"));
    }
  }
  onClose = () => {
		this.refs.simpleMessageModal.toggleModal(false);
	};
  // Render any loading content that you like here
  render() {
    return (
      <View style={{flex:1}}>
      <SafeAreaView style={[Styles.common.safeareView0]} />
      <SafeAreaView style={styles.customSafearea}>
          <StatusBar
              barStyle="light-content"
              backgroundColor={Colors.pinkishRed}
              translucent={false} />
          <View style={styles.mainContainer}>
              <View style={styles.headerContainer}>
                      <TouchableOpacity style={styles.headerIcon} onPress={() => this.props.navigation.pop()}>
                          <Image
                            source={I18nManager.isRTL ? Images.icons.right : Images.icons.left}
                            style={styles.backIcon}
                          />
                      </TouchableOpacity>
                      <View style={styles.headerTitleContainer}>
                        <Text style={styles.headerTitle}>{translate("ProfileEdit")}</Text>
                      </View>
                      <View style={styles.headerRightView}>
                          <TouchableOpacity style={{}} onPress={() => this._onPressSave()}>
                              <Text style={styles.saveBtn}>{translate("Save")}</Text>
                          </TouchableOpacity>
                      </View>
              </View>
              <View style={styles.contentContainer}>
                 <EditProfileInput ref={"refEditProfile"}
                  showSimpleModal={(value)=>this.showSimpleModal(value)}
                 navigation={this.props.navigation} onPress={() => this._onPressSave()}/>
              </View>
          </View>
        </SafeAreaView>
        {this.props.isLoadingEditProfile ? <Spinner mode="overlay" /> : null}
        <SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose}/>
      </View>
    );
  }
}


function mapDispatchToProps(dispatch) {
  return {
    actions: {
      UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
    }
  };
}

const mapStateToProps = (state) => ({
  Connected: state.updateNetInfoReducer.isConnected,
  languagesProps: state.switchLanguageReducer,
  isLoadingEditProfile: state.updateUserReducer.isLoadingEditProfile
});

export default connect(mapStateToProps, mapDispatchToProps)(EditProfileScreen);
