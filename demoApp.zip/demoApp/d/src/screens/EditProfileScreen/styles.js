import { StyleSheet, Dimensions, Platform } from "react-native";
import { Images, Styles, Colors } from "@common";
const screen = Dimensions.get("window");

export default  styles = StyleSheet.create({
  mainContainer:{
    flex:1,
    ...Platform.select({
      android: {
        backgroundColor: Colors.pinkishRed,
        paddingTop: 20,
      },
    }),
  },
  customSafearea:{
    flex:1,
    backgroundColor: 'white'
  },
  headerContainer:{
    flex:0.1,
    flexDirection:'row',
    justifyContent:"center",
    backgroundColor: Colors.pinkishRed,
  },
  headerIconContainer:{
    flex:1,
    flexDirection:'row',
    marginTop:23,
    marginHorizontal:16,
    backgroundColor:'grey',
    justifyContent:'center'
  },
  headerIcon:{
    flex:0.15,
    alignItems:'flex-start',
    alignSelf:'center',
    padding:8
  },
  backIcon:{
    width:28,
    height:28
  },
  headerTitleContainer:{
    flex:0.8,
    justifyContent:'center',
    alignSelf:'center',
    alignItems:'center',
  },
  headerTitle:{
    color: Colors.white,
    alignSelf:'center',
    fontSize: Styles.FontSize.fnt17,
    fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    textAlign: 'left'
  },
  contentContainer:{
    flex:0.90,
    backgroundColor:'white',
  },
  headerRightView:{
    flex:0.15,
    alignSelf:'center',
    marginRight:16,
    alignItems:'flex-end',
  },
  saveBtn:{
    color: Colors.white,
    alignSelf:'center',
    fontSize: Styles.FontSize.fnt15,
    fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
  },
});
