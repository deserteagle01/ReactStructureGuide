/** @format */

import React, { PureComponent } from "react";
import { AppConfig } from "@common";
import styles from "./styles";
import { CustomPlanView } from "@components";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { translate, setI18nConfig } from "@languages";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";

class CustomPlanScreen extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            Plan_id  : this.props.navigation.state.params.Plan_id,
            planData: this.props.navigation.state.params.Plandata,
        }
    }

    componentDidMount() {

    }

    navigateToSignup() {
        let isRTL = false;
        if(this.props.switcher.lang == 'ar') {
            isRTL  =true;
        }
        
        setI18nConfig(this.props.signupDetail.com_lang, isRTL);
        this.forceUpdate();
        this.props.navigation.navigate('SignupScreen', { slide: null })
    }

    render() {
        return (
            <CustomPlanView  
                Plan_id={this.state.Plan_id}
                planData={this.state.planData}
                closeCustomPlanModal={() => this.props.navigation.goBack() } 
                ContinuePress={() =>  this.navigateToSignup()} />
        );
    }
}

const mapStateToProps = (state) => {
	return {
        connected: state.updateNetInfoReducer.isConnected,
        switcher: state.switchLanguageReducer,
		signupDetail: state.updateUserReducer, 
	}
};

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
		}
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(CustomPlanScreen);