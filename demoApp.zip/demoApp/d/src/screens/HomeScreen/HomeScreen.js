import React from "react";
import { connect, useDispatch } from "react-redux";
import styles from "./styles";
import ImagePicker from 'react-native-image-crop-picker';
import { Images, Colors, Styles, AppConfig } from "@common";
import { NeedHelp, ImagePickerModal, PlanStatus, Toast, Spinner, ChoosePlanView, CustomPlanView, SimpleMessageModal,MaterialAnimation, ChoosePlanModal,InviteModal, AppointmentModal, AppointmentSuccessPopup, Prefetcher } from "@components";
import Modal from "react-native-modal";
import { translate, setI18nConfig } from "@languages";
import { View, Text, StyleSheet, Platform, StatusBar, SafeAreaView, Image, TouchableOpacity, Animated, Dimensions, FlatList,I18nManager } from "react-native";
import { bindActionCreators } from "redux";
import * as UpdateUserAction from "../../redux/Actions/updateUserAction";
import * as walletListAction from "../../redux/Actions/walletListAction";
import * as PlanAction from "../../redux/Actions/Plan";
import { firebase } from '@react-native-firebase/analytics';
import { compareVersion, appUpdateLink,FontScalling, sourceScreen, prefetchAction } from "../../common/Utility";
import NotificationManager from '../../common/NotificationManager';
import OneSignal from 'react-native-onesignal';
import {CachedImage} from "react-native-img-cache";
const { width, height } = Dimensions.get('window');
const imageWH=(height*96)/812;
const imageMin=(height*18)/812;
class HomeScreen extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            // here type is wallet,palnChange,bookAppoint
            planType: "planChange",
            plan_id: null,
            planDataItem: {},
            // for scroll Animation
            scrollY: new Animated.Value(0),
            cards: ["planChange", "wallet", "bookAppoint"],
        },
        this._openImagePickerModal = this._openImagePickerModal.bind(this);
    }

    componentDidMount() {
        this.props.navigation.setParams({
            tapOnTabNavigator: this.tapOnTabNavigator
          })
        this.eventListner = this.props.navigation.addListener("didFocus", () => this.focuscalled());
        firebase.analytics().logEvent("login", { method: "Auto Login" });
        this._getHomeDetail(true);
        this._getWalletDetail();
    }
    tapOnTabNavigator = () => {
        this._getHomeDetail(true);
        this._getWalletDetail();
    }
    _getWalletDetail(){
        this.props.actions.walletListAction.fetchWalletList().then(() => {
            if (this.props.walletListData.error) {
                this.toast.show(this.props.walletList.error);
            }
        });
    }
    focuscalled() { 
        this.refs.prefetcherref.startPrefetching({source: sourceScreen.home});
        if(this.props.navigation.state.params!==undefined && !this.props.navigation.state.params.isFromBack==true){
                this._getHomeDetail(false);
        }
        if (Object.keys(this.props.fetchData[Platform.OS]).length != 0) {
            var isAppUpdate = compareVersion(this.props.fetchData[Platform.OS].current_version);
            var isForceUpdate = compareVersion(this.props.fetchData[Platform.OS].last_force_update_version);

            if(isAppUpdate || isForceUpdate) {
                let tempDict = this.props.fetchData[Platform.OS];
                tempDict.forceUpdateFlag = isForceUpdate;
                tempDict.appUpdateFlag = isAppUpdate;
                NotificationManager.show({ data: tempDict, type: "update", okclickCallback: () => appUpdateLink(this.props.fetchData[Platform.OS]) });
            }
        }

        OneSignal.sendTags({ private: 1, gender: this.props.homeData.gender, user_id: this.props.homeData.id });
    }

    

    componentWillReceiveProps(nextProps){
		if(this.props !== nextProps){
            if(this.props.homeData !== nextProps.homeData && nextProps.homeData.error != null){
                this.toast.show(nextProps.homeData.error);
            }
		} 
    }
    
    _getHomeDetail(forceFetch) {
        if (this.props.Connected) {
            this.props.actions.HomeAction.getHomeDataAction(forceFetch);
        } else {
            this.toast.show(translate("InternetToast"));
        }
    }
    goToPlanChange = () => {
        if(!this.props.homeData.test_user){
            this.refs.refChoosePlanModal.show();
        }else{
            this.toast.show(translate("NoPermission4TestUser"));
        }

    }
    uploadImage = (imageBase64) => {
        //this._closeImagePickerModal();
        if (this.props.Connected) {
            this.props.actions.UpdateUserAction.uploadImageUrl(imageBase64).then(() => {
                if (this.props.homeData.error) {
                    this.toast.show(this.props.homeData.error);
                } else {
                }
            });
        } else {
            this.toast.show(translate("InternetToast"));
        }
    }
    editProfile = (imagePickType) => {
        const options = {
            useFrontCamera: true,
            width: 512,
            height: 512,
            cropperCircleOverlay:true,
            cropping: true,
            freeStyleCropEnabled: true,//android only
            avoidEmptySpaceAroundImage: false,
            compressImageQuality: 0.8,
            cropperToolbarTitle: "Crop",
            mediaType: "photo",
            includeBase64: true
        };
        if (imagePickType == "camera") {
            ImagePicker.openCamera(options).then(image => {
                this._closeImagePickerModal();
                this.uploadImage(image.data);
            });
        } else if (imagePickType == "gallery") {
            ImagePicker.openPicker(options).then(image => {
                this._closeImagePickerModal();
                this.uploadImage(image.data);
            }).catch(e => {
                console.log(e);
            });
        }
    }
    // open close imagepicker Modal
    _openImagePickerModal = () => {
        this.refs.imagePickerModal.toggleModal(true);
    }
    _closeImagePickerModal = () => {
        this.refs.imagePickerModal.toggleModal(false);
    };
    goToWallet = () => {
        this.props.navigation.navigate("Wallet");
    }
    goToAppoint = () => {
        this.refs.refappointmentModal.show();
    }
    goToInviteFriends = () => {
        this._openInviteFrdModal();
    }
    goToPlanPress=(planType,subType )=>{
        if(planType=="planChange"){
            if(subType == "pay"){
                this.goToPlanChange();
            }else{
                if (this.props.Connected) {
                    if(subType == "renew"){
                        this.renewCall(subType);
                    }
                    else{
                        this.changePlanCall(subType);
                    }
                }
                else{
                    this.toast.show(translate("InternetToast"));   
                }
            }
        }else if(planType=="wallet"){
            this.goToWallet();
        }else if(planType=="bookAppoint"){
            this.goToAppoint();
        }
    }

    renewCall(subType) {
        this.props.actions.PlanAction.getRenewPlanData().then(() => {
            if (this.props.planData.error) {
                this.toast.show(this.props.planData.error);
            } else {
                this.refs.refChoosePlanModal.show(subType);
            }
        });
    }

    changePlanCall(subType) {
        this.props.actions.PlanAction.getChangePlanData().then(() => {
            if (this.props.planData.error) {
                  this.toast.show(this.props.planData.error);
            } 
            else {
                  this.refs.refChoosePlanModal.show(subType);          
            }
          });
    }
            
    addCompanyInfo=()=>{
		let options  = 
		{
			htmlContent:I18nManager.isRTL?this.props.fetchData.wallet_help_text_ar:this.props.fetchData.wallet_help_text,
		};
		this.refs.simpleMessageModal.toggleModal(true,"", translate("Info"),options);
    }
    
    _renderItem = (item) => {
            return(
                <MaterialAnimation key={item.index.toString()} index={item.index}>
                    <PlanStatus
                        firstAppointmentDate={this.props.homeData.first_appointment_date}
                        type={item.item}
                        homeData={this.props.homeData}
                        totalAmount={this.props.signupDetail.total_wallet_amount}
                        onPress={(subType) => this.goToPlanPress(item.item,subType)}
                        goToInviteFriends={()=>this.goToInviteFriends()}
                        addCompanyInfo={()=>this.addCompanyInfo()}
                        {...this.props}
                        />
                </MaterialAnimation>  
            )
    }
    opacityCalculate = () => {
        const { scrollY } = this.state;
        // 0 means View invisible, 1 means Visible. Here, scroll value is 60 at that time 0 value is set to opcity  .
        let opacity = scrollY.interpolate({
            inputRange: [0, 60],
            outputRange: [1, 0],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return opacity;
    };
    opacityEditCalculate= () => {
        const { scrollY } = this.state;
        // 0 means View invisible, 1 means Visible. Here, scroll value is 60 at that time 0 value is set to opacity  .
        let opacity = scrollY.interpolate({
            inputRange: [0, 20],
            outputRange: [1, 0],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return opacity;
    };
    _getImageLocation = (w, h) => {
        const { scrollY } = this.state;
        // 75 indicates scroll value. Image margin top is 13 inside fix header part.
        let scroll = scrollY.interpolate({
            inputRange: [0,150],
            outputRange: [75,0],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return scroll;
    };

    _getImageWidth = () => {
        // Image min height is 34,max is imageWH
        const { scrollY } = this.state;
        let w = scrollY.interpolate({
            inputRange: [0,50,150],
            outputRange: [imageWH,50,34],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return w;
    };

    _getImageHeight = () => {
        const { scrollY } = this.state;
        // image 30% smaller and fix inside header part. Here,scroll value is 75. 
        let h = scrollY.interpolate({
            inputRange: [0,50,150],
            outputRange: [imageWH,50,34],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return h;
    };
    _getEditImageWidth= () => {
        const { scrollY } = this.state;
        let w = scrollY.interpolate({
            inputRange: [0, 25],
            outputRange: [imageMin, 0],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return w;
    };

    _getEditImageHeight = () => {
        const { scrollY } = this.state;
        // image 30% smaller and fix inside header part. Here,scroll value is 75. 
        let h = scrollY.interpolate({
            inputRange: [0, 25],
            outputRange: [imageMin, 0],
            extrapolate: "clamp",
            useNativeDriver: true
        });
        return h;
    };

    onClose = () => {
        this.refs.simpleMessageModal.toggleModal(false);
    };
    _openInviteFrdModal = () => {
		this.refs.inviteFrdModal.toggleModal(true,translate("InviteFrd"));
	};
    onModalHide=()=>{
        this.refs.inviteFrdModal.toggleModal(false);
    }
    render() {
        const opacityVal = this.opacityCalculate();
        const profileImageWidth = this._getImageWidth();
        const profileImageHeight = this._getImageHeight();
        const editImageWidth=this._getEditImageWidth();
        const editImageHeight=this._getEditImageHeight();
        const opacityValEdit=this.opacityEditCalculate();
        const translateY = this._getImageLocation(profileImageWidth, profileImageHeight);
        var redHeight=(height*259)/812;
        var cardHeight=(height*114)/812;
        var scrollHeight=redHeight-(cardHeight/2)+height*0.054;
        const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);
        return (
            <View style={styles.container}>
                <SafeAreaView style={{flex:0,backgroundColor:Colors.pinkishRed}} />
                <StatusBar
					barStyle="light-content"
					backgroundColor={"transparent"}
					translucent={true} />
                <View style={styles.topBar}>
                    <View style={styles.flex1} />
                    <View style={styles.flex1}>
                       
                        <Animated.View
                            style={[
                                styles.logoContainer,
                                {
                                    top: translateY,
                                    width: profileImageWidth,
                                    height: profileImageHeight,
                                }
                            ]}>
                           <CachedImage
                            source={this.props.homeData.image_url == '' ? Images.User : { uri: this.props.homeData.image_url }}
                            style={styles.logo} />
                        </Animated.View>
                        
                    </View>
                     
                    <View style={styles.notifContainer}>
                        <NeedHelp showIcon={true} notificationPress={() => this.props.navigation.navigate("NotificationList",{'isFromHome':true})} />
                    </View>
                    <View style={styles.flex1} />
                </View>
                <AnimatedTouchable
                style={[styles.imageEditContainer,
                {opacity:opacityValEdit},
                
                ]} onPress={() => {
                     if(this.state.scrollY._value==0){
                        this._openImagePickerModal();
                     }
                    }}>
                                <Animated.Image
                                    source={Images.icons.edit}
                                    style={[styles.editProfileIcon,
                                        {  
                                            width: editImageWidth,
                                            height: editImageHeight,
                                            opacity: opacityValEdit,
                                        }
                                    ]}>
                                </Animated.Image>
                </AnimatedTouchable>
                <View style={styles.header}>
                </View>
                <View style={styles.detail}>
                </View>
                <View style={styles.body}>
                    <Animated.ScrollView
                        showsVerticalScrollIndicator={false}
                        style={{flexGrow: 1}}
                        alwaysBounceVertical={false}
                        bounces={false}
                        scrollEventThrottle={16}
                        onScroll={Animated.event([
                            {
                                nativeEvent: { contentOffset: { y: this.state.scrollY } }
                            }
                        ])}>
                        <View style={styles.profiileContaner}>

                            <Animated.View
                                style={[
                                    styles.logoContainer,
                                    {
                                        width: profileImageWidth,
                                        height: profileImageHeight,
                                    }
                                ]}
                            >
                            </Animated.View>
                            <Animated.View style={[styles.nameContainer, { opacity: opacityVal }]}>

                                <Text numberOfLines={1} style={styles.profileTitle}>{ (this.props.homeData.com_lang =='ar'?"مرحبا!": "Hello!") + " " +this.props.homeData.first_name}</Text>
                                <View style={styles.id}>
                                    <Image source={Images.icons.profileId}
                                        style={styles.icon}
                                    />
                                    <Text style={styles.profileBelow}>{this.props.homeData.ref}</Text>
                                </View>
                            </Animated.View>
                            
                        </View>
                        <FlatList
                            data={this.state.cards}
                            renderItem={(item, index) => this._renderItem(item, index)}
                            extraData={this.props}
                            keyExtractor={item => item} 
                            />
                    <View style={{ height: scrollHeight, width: "100%", }} />  
                    </Animated.ScrollView>
                </View>
                <Toast refrence={(refrence) => this.toast = refrence} />
                <ImagePickerModal ref={"imagePickerModal"}
                    editProfile={(imagePickType) => this.editProfile(imagePickType)}
                />
               <InviteModal ref={"inviteFrdModal"} 
                    shareText={this.props.signupDetail.share_message}
                    referralCode={this.props.signupDetail.referral_code}
                    onModalHide={()=>{this.onModalHide()}}	/> 
                {this.props.isLoadingUploadImage ? <Spinner style={styles.loader}/> : null}
                {this.renderChoosePlanModal()}
                {this.renderAppointmentModal()}
                <AppointmentSuccessPopup  ref={"appointmentSuccess"} />
                <SimpleMessageModal ref={"simpleMessageModal"} onClose={this.onClose} modalStyle={styles.modal}/>
                <Prefetcher ref="prefetcherref" />        
            </View>
        );
    }
    renderChoosePlanModal() {
        return (
            <ChoosePlanModal {...this.props}
                ref="refChoosePlanModal" navigation ={this.props.navigation}
                onContinue = {() => this.onChoosePlanContinue()}
                onPaymentComplete = {() => {
                    this.refs.prefetcherref.startPrefetching({source: sourceScreen.home, forceFetch: true});
                }}
                onModalClose = {() => this._getHomeDetail(true)}
                />
        )
    }

    renderAppointmentModal() {
        return (
          <AppointmentModal {...this.props}
              ref="refappointmentModal" 
              navigation ={this.props.navigation}
              onModalHide={(data) => this.showConfirmedInfo(data)} />
        )
    }

    showConfirmedInfo(data) {
        if(data != undefined){
          setTimeout(()=>{
            this.refs.appointmentSuccess.show(data);
          }, 500);
        }
      }
    
    onChoosePlanContinue() {
        this.props.navigation.navigate("SignupScreen", { slide: ["startdate", "paymentScreen"] , isFrom: "Home"});
    }

}


function mergeProps(stateProps, dispatchProps, ownProps) {
    const { dispatch } = dispatchProps;
    return {
        ...ownProps,
        ...stateProps,
        actions: {
            UpdateUserAction: bindActionCreators(UpdateUserAction, dispatch),
            walletListAction: bindActionCreators(walletListAction, dispatch),
            PlanAction: bindActionCreators(PlanAction, dispatch),
            HomeAction: UpdateUserAction.bindActionCreators(dispatch, stateProps),
        }
    };
}
const mapStateToProps = (state) => {
    return {
        Connected: state.updateNetInfoReducer.isConnected,
        homeData: state.updateUserReducer,
        isShimmer: state.updateUserReducer.isLoading || state.PlanReducer.isLoading ? true : false,
        signupDetail: state.updateUserReducer, 
        connected: state.updateNetInfoReducer.isConnected,
        planData: state.PlanReducer,
        versionData: state.fetchMasterListReducer.appVersion,
        isLoadingUploadImage: state.updateUserReducer.isLoadingUploadImage,
        fetchData: state.fetchMasterListReducer,
        walletListData:state.walletListReducer,
    };
};


export default connect(mapStateToProps, undefined, mergeProps)(HomeScreen);
