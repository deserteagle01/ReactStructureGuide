import { StyleSheet, Dimensions, Platform, PixelRatio } from "react-native";
import { Images, Styles, Colors } from "@common";
import { FontScalling } from '../../common/Utility';
const { width, height } = Dimensions.get('window');
export default styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor: Colors.pinkishRed,
        ...Platform.select({
          android: {
              paddingTop: 20,
          }
      }),
    },
    customSafearea:{
      backgroundColor: Colors.pinkishRed,
      flex:1,
      zIndex:0,
   },
    mainContainer:{
        backgroundColor: Colors.paleGrey,
        flex:1,
     },
    loader:
      {
        backgroundColor: "rgba(0,0,0,0.2)",
        position:'absolute',
        zIndex:9999,
        width:Styles.width,
        height:Styles.height,
        padding:0,
        left:0,
        top:0,
        margin:0,
        alignItems: "center",
        justifyContent: "center"
    },
    imageEditContainer:
    {
      left:height>=812?width/2+(height*23)/812:width/2+(height*34)/812,
      zIndex:20,
      width:(height*18)/812,
      height:(height*18)/812,
      top:(height*66/812),
  },
    editProfileIcon: {
        width: (height*18)/812,
        height:(height*18)/812,
        borderRadius: 9,
    },
    profileBelow: {
        fontSize: FontScalling(15,4),
        color: Colors.white, fontFamily: Styles.FontFamily().ProximaNova
    },
    profileTitle: {
        textAlign:"center",
        color: Colors.white,
        fontSize: FontScalling(20,4),
        marginTop:10,
        fontFamily: Styles.FontFamily().UrbaneRoundedDemoBold,
    },
    id: {
        marginTop:6,
        flexDirection: 'row',
        backgroundColor: Colors.coral,
        paddingVertical:4,
        paddingHorizontal:10,
        borderRadius: 18,
        alignItems: 'center',
    },
    icon: {
        width: 15,
        height: 15,
        alignItems: 'center',
        justifyContent:'center',
        tintColor: Colors.white 
    },
    popup: {
        backgroundColor: "#FFF",
        marginHorizontal: 10,
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        minHeight: 80,
        alignItems: "center",
        justifyContent: "center",
    },
    header: {
        width:"100%",
        height:(height*259)/812,
        backgroundColor: Colors.pinkishRed,
    },
    detail: {
        flex: 1,
        backgroundColor: Colors.paleGrey,
    },
    topBar: {
        width:"100%",
        zIndex:20,
        height: 56,
        backgroundColor: Colors.pinkishRed,
        flexDirection: "row-reverse"
    },
    notifContainer:
      {
        flex:1,
        position:"absolute",
        alignItems:"flex-start",
        justifyContent:"flex-end",
        left:16
    },
    nameContainer:{
      height:(height*259/812)/2,
      width: "100%",
      alignItems:"center",
    },
    logoContainer: {
      height:(height*259/812)/2,
        ...Platform.select({
          ios: {
            shadowColor: "#000",
            shadowOffset: {
              width: 0,
              height: 3,
                },
            shadowOpacity: 0.29,
            shadowRadius: 4.65,
          },
          android: {
            elevation: 7
          }
        })
    },
    logo: {
      zIndex:0,
      top:-6,
      borderRadius: 100,
      width: "100%",
      height: "100%",
      resizeMode: "cover",
    },
    flex1: {
      flex: 1,
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
    },
    flex1RightConatiner: {
      alignItems: "flex-end",
      justifyContent: "flex-end"
    },
    body: {
      flex: 1,
      position: "absolute",
      left: 0,
      right: 0,
      top: height >= 812 || width >= 812 ? 100 : 76,
      bottom: height >= 812 || width >= 812 ? 0 : 0,
      flexDirection: "column",
    },
    userName: {
      fontSize: 20,
      fontWeight: "bold",
      padding: 10
    },
    profiileContaner: {
      width: "100%",
      // backgroundColor:"green",
      height:(height*277)/812,
      flexDirection: "column",
      marginBottom:-(height*114/812)/2,
    },
    modal:{
      maxHeight:height-120,
      paddingLeft:20,
      paddingRight:0,
      paddingBottom: 20
  },
});
