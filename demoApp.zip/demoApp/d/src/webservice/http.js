import { AppConfig } from "@common";
import { DeviceEventEmitter } from "react-native";
var mobile;
var passwords;

class HTTP {  
  constructor(){}

  setNumberandPassword(number, password) {
    mobile = number;
    passwords = password;
  }
  POST (url, data)  {
    // log("Http Request");
    return new Promise((resolve, reject) => {
      
      fetch(AppConfig.DietStation.url2 + url, {
        method: "POST",
        credentials: 'same-origin',
        headers: {
          //Header Defination
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
      })
      .then(response => {
          // log("Http Response");
          //log(response)
          console.log('first ever ever ever ='+JSON.stringify(response));
          if(response.status != 200){
              reject({
                error: "Request Failed **",
                status:"failed"
              });
            return;
          }

          return response.json()
      })
      .then(responseJson => {
          if (responseJson && responseJson.result) {
                resolve(responseJson.result);
             } else if(responseJson && responseJson.error) {
              if(responseJson.error.message == "Odoo Session Expired" && AppConfig.DietStation.predefinedUrl.includes(url)) {
                    let loginParam = {
                      phone: mobile,
                      password: passwords
                    }
                    this.POST("/diet/login", loginParam).then(respoJson => {
                    if(respoJson && respoJson.status == "success") {
                          this.POST(url, data).then(responseAfterData => {
                              resolve(responseAfterData);
                          }).catch(error => {
                              reject(error);
                          });
                     }else {
                        DeviceEventEmitter.emit('logoutAction');
                        reject({
                          error: respoJson.error,
                          status: "failed"
                        }); 
                    }
                }).catch(error => {
                        reject(error);
                    });
              }else{
                reject({
                    error: responseJson.error.message,
                    status: "failed"
                });
              }
           } else {
            resolve([]);
          }
        })
        .catch(error => {
          console.log('main exception ='+error);
          // When webisite is not reachable
          // May be server down or internet is not connected
          if (error.stack) {
            reject({
              error: error.message,
              status: "failed"
            });
          } else if (error.error) {
            reject({
              error: error.error.message,
              status: "failed"
            });
          } else {
            // Odoo Exceptions raised from backend.
            reject(error);
          }
        });
    });
  }
}
export default new HTTP();