import HTTP from "./http";

class DietStationAPI {
	constructor() { }

	checkUserExist(Phonenumber) {
		return HTTP.POST("/diet/validate_phone_number", {
			phone: Phonenumber
		});
	}

	userAuthLogin(Phonenumber, Password) {
		return HTTP.POST("/diet/login", {
			phone: Phonenumber,
			password: Password
		});
	}

	preLoadedMasterData() {
		return HTTP.POST("/diet/fetch_area_blocks", {});
	}
	dislikeMasterData() {
		return HTTP.POST("/diet/dislikes", {});
	}

	registerUser(params) {
		return HTTP.POST("/diet/register/v2", params);
	}

	registerUpdateUser(params) {
		return HTTP.POST("/diet/register_update", params);
	}

	getPlanStartDate() {
		return HTTP.POST("/diet/plan_start_dates", {});
	}

	getPrivacyPolicyData() {
		return HTTP.POST("/diet/privacy_policy", {});
	}

	getCompanyDetails() {
		return HTTP.POST("/diet/company_details", {});
	}

	getPlans() {
		return HTTP.POST("/diet/plans", {});
	}

	getPlansDetails(planID) {
		return HTTP.POST("/diet/plan_detail/v2", {
			product_tmpl_id: planID
		});
	}

	editPlansDetails(planData) {
		return HTTP.POST("/diet/update_plan", planData);
	}

	changePlanSubmit(planData) {
		return HTTP.POST("/diet/change_plan_user", planData);
	}

	updatePlan(planData)  {
		return HTTP.POST("/diet/update_plan_user", planData);
	}

	getRenewPlan() {
		return HTTP.POST("/diet/get_renew_plan_data", {});
	}

	getChangePlan() {
		return HTTP.POST("/diet/get_change_plan_data", {});
	}

	
	UserEditAPI(firstname, lastname, gender, birthdate, email, language,secondary_first_name,secondary_last_name,com_lang) {
		return HTTP.POST("/diet/update_profile", {
			first_name: firstname,
			last_name: lastname,
			gender: gender,
			birth_date: birthdate,
			lang: language,
			email: email,
			secondary_firstname:secondary_first_name,
			secondary_lastname:secondary_last_name,
			com_lang:com_lang,
		});
	}

	ChangePwd(current_password, new_password) {
		return HTTP.POST("/diet/update_password", {
			current_password: current_password,
			new_password: new_password
		});
	}

	dislikeCategory(dislike_category_ids) {
		return HTTP.POST("/diet/update_dislikes", {
			dislike_category_ids: dislike_category_ids
		});
	}
	fetchProductData(params) {
		return HTTP.POST("/diet/get-calendar", params);
	}
	
	fetchMenuData(params){
		return HTTP.POST("/diet/get-menu-data", params);
	}

	updateUserMealPlan(params){
		return HTTP.POST("/diet/update-meal-selection", params);
	}

	addEditAddress(params){
		return HTTP.POST("/diet/add_edit_address", params);
	}
	deletDisableAddress(params){
		return HTTP.POST("/diet/delete_disable_address", params);	
	}
	
	choosePassword(otp, password, mobile) {
		return HTTP.POST("/diet/choose_password", {
			otp: otp,
			password: password,
			mobile: mobile
		});
	}

	sendOTP(action, mobile) {
		return HTTP.POST("/diet/send_otp", {
			action: action,
			mobile: mobile
		});
	}

	verifyOTP(otp, mobile) {
		return HTTP.POST("/diet/verify_otp", {
			otp: otp,
			mobile: mobile
		});
	}

	getHomeData(){
		return HTTP.POST("/diet/home_screen", {});
	}

	getAppointmentDashboard() {
		return HTTP.POST("/diet/book_appointment", {});
	}

	getDietition() {
		return HTTP.POST("/diet/book-appointment/dietitians", {});
	}

	getFirstAvailable() {
		return HTTP.POST("/diet/book-appointment/first_available", {});
	}

	getDietitionDates(params) {
		//return HTTP.POST("/diet/book-appointment/get-calendar", params);
		return HTTP.POST("/diet/book-appointment/get-calendar2", params);
	}

	bookDietition(Id) {
		return HTTP.POST("/diet/book-appointment/submit", {
			id: Id
		});
	}

	cancelDietition(Id) {
		return HTTP.POST("/diet/book-appointment/cancel", {
			appointment_id: Id
		});
	}

	uploadImageUrl(imageBase64){
		return HTTP.POST("/diet/update_profile_partner", {
			image_url:imageBase64,
		});
	}

	userMealPauseUnpause(params){
		return HTTP.POST("/diet/pause_unpause_day", params);
	}

	submitRating(params){
		return HTTP.POST("/diet/rate_product_item", params);
	}
	
	initiatePayment() {
		return HTTP.POST("/fatoorah-payment", {});
	}

	statusPayment(transactionId,flag) {
		return HTTP.POST("/validate-fatoorah-payment", {
			payment_transaction_id: transactionId,
			is_payment_success: flag
		});
	}

	fetchLatestAppVersion(){
		return HTTP.POST("/diet/get_version", {});
	}

	logout(params) {
		return HTTP.POST("/diet/logout", params);
	}

	getNotificationList(offset, limit) {
		return HTTP.POST("/diet/notifications/list", {
			offset: offset,
			limit: limit
		});
	}

	markReadNotification(Id) {
		return HTTP.POST("/diet/notifications/mark_readall", {
			id: Id
		});
	}

	clearAllNotifications(Id) {
		return HTTP.POST("/diet/notifications/clearall", {
			id: Id
		});
	}
	walletList() {
		return HTTP.POST("/diet/wallet/history",{});
	}
}

export default new DietStationAPI();
