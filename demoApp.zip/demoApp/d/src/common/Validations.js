import { Dimensions, Platform } from "react-native";
import validate from 'validate.js'


const constraints = {
  reqField: {
    presence: {
      allowEmpty: false,
      message: "Thisisrequired"
    }
  },
  email: {
    presence: {
      allowEmpty: false,
      message: "Thisisrequired"
    },
    email: {
      message: "Pleaseentervalidemail"
    }
  },
  password: {
    presence: {
      allowEmpty: false,
      message: "Thisisrequired"
    },
    length: {
      minimum: 5,
      message: "Passwordmustbe5character"
    }
	},
	numericonly: {
		presence: {
			allowEmpty: false,
			message: "Thisisrequired"
		},
		format: {
			pattern: "^[0-9]+\.?[0-9]*$",
			flags: "i",
			message: "OnlyNumber"
		},
	},
  mobile: {
    presence: {
      allowEmpty: false,
      message: "Thisisrequired"
    },
    format: {
      pattern: "[0-9]+",
      flags: "i",
      message: "Pleaseentervalidmobile"
    },
    length: {
      minimum: 8,
      maximum: 8,
      message: "Mobilemustbe10character"
    }
  }
}

const validator = (field, value, option) => {
	// Creates an object based on the field name and field value
	// e.g. let object = {email: 'email@example.com'}
	let object = {};
	object[field] = value;

	let constraint = constraints[field];

	// Validate against the constraint and hold the error messages
	const result = validate(object, { [field]: constraint }, option);

	// If there is an error message, return it!
	if (result) {
		// Return only the field error message if there are multiple
		return result[field][0];
	}

	return null;
};

export default validator;
