
import { Dimensions, Platform, I18nManager } from "react-native";
import Colors from "./Colors";


class LanguageManager  {
    constructor(){
        var language = "";
    }
    

    setLanguages(lang) {
        this.language = lang;
    }
}


export default new LanguageManager();
