import { Dimensions, Platform, I18nManager } from "react-native";
import Colors from "./Colors";
import LanguageManager from "./LanguageManager";

const { height, width } = Dimensions.get("screen");

const Styles = {
	width: Dimensions.get("screen").width,
	height: Platform.OS !== "ios" ? height : height - 20,
	navBarHeight: Platform !== "ios" ? height - width : 0,
	headerHeight: Platform.OS === "ios" ? 40 : 56,

	thumbnailRatio: 1.2, // Thumbnail ratio, the product display height = width * thumbnail ratio

	app: {
		flexGrow: 1
	},
	FontSize: {
		fnt8: 8,
		fnt9: 9,
		fnt10: 10,
		fnt11: 11,
		fnt12: 12,
		fnt13: 13,
		fnt14: 14,
		fnt15: 15,
		fnt16: 16,
		fnt17: 17,
		fnt18: 18,
		fnt19: 19,
		fnt20: 20,
		fnt21: 21,
		fnt24: 24,
		fnt25: 25,
		fnt28: 28,
		fnt34: 34,
		fnt48: 48
	},
	IconSize: {
		TextInput: 25,
		ToolBar: 18,
		Inline: 20,
		SmallRating: 14
	},
	FontFamily: (lang) => 
		(
		lang  ?
		{
				ProximaNova: lang == "ar" ?  "TheSans-Plain" : "ProximaNova-Regular",
                ProximaNovaBold: lang == "ar" ? "TheSans-Bold" : "ProximaNova-Bold",
                ProximaNovaSemiBold: lang == "ar" ? "TheSans-Plain" : "ProximaNova-Semibold",
                UrbaneRoundedLite: lang == "ar" ? "TheSans-Plain" : "UrbaneRounded-Light",
                UrbaneRoundedDemoBold: lang == "ar" ? "TheSans-Plain" :"UrbaneRounded-DemiBold",
                Geomanist: lang == "ar" ? "TheSans-Plain" : "Geomanist-Regular",
                SansBold: "TheSans-Bold",
                SansPlain: "TheSans-Plain"
		}
		:
		{
				ProximaNova: LanguageManager.language == "ar" ?  "TheSans-Plain" : "ProximaNova-Regular",
                ProximaNovaBold:LanguageManager.language == "ar" ? "TheSans-Bold" : "ProximaNova-Bold",
                ProximaNovaSemiBold: LanguageManager.language == "ar" ? "TheSans-Plain" : "ProximaNova-Semibold",
                UrbaneRoundedLite: LanguageManager.language == "ar" ? "TheSans-Plain" : "UrbaneRounded-Light",
                UrbaneRoundedDemoBold: LanguageManager.language == "ar" ? "TheSans-Plain" :"UrbaneRounded-DemiBold",
                Geomanist: LanguageManager.language == "ar" ? "TheSans-Plain" : "Geomanist-Regular",
                SansBold: "TheSans-Bold",
                SansPlain: "TheSans-Plain"
		}
	)
};

Styles.common = {
	gradientBtnContainer: {

	},
	errorMsg: {
		color: 'white',
		textAlign: 'left',
		fontSize: 14,
		fontFamily: "ProximaNova-Regular",
		position: "absolute",
		bottom: -25,
		left: 5
	},
	errorMsgArabic: {
		color: 'white',
		textAlign: 'right',
		fontSize: 14,
		fontFamily: "ProximaNova-Regular",
		position: "absolute",
		bottom: -25,
		right: 5,
	},
	safeareView: {
		flex: 1,
		backgroundColor: Colors.pinkishRed
	},
	safeareViewOnly: {
		flex: 1,
	},
	safeareView0: {
		flex: 0,
		backgroundColor: Colors.pinkishRed
	},
	safeareaDiffrentColor: {
		flex:0,
		backgroundColor: Colors.pinkishRed
	},
	// Image size for background image of screen
	imgContainer: {
		flex: 1,
	},
	textInput: {
		borderColor: '#9D9D9D',
		borderBottomWidth: 2,
		height: 59,
		width: '100%',
		padding: 5,
		color: "white",
		fontSize: 24,
		alignSelf: 'flex-start',
		textAlign: I18nManager.isRTL ? 'right' : 'left',
	},
	errorMsg: {
		color: 'white',
		fontSize: 14,
		fontFamily: "ProximaNova-Regular",
		marginTop: 5,
		marginBottom: 5,
		marginLeft: 5,
		textAlign: 'left',
	},
	globalArabictxt: {
		textAlign: 'right',
	},
	globalEnglishtxt:{
		textAlign: 'left',
	},
	globalArabictxtFlex: {
		textAlign: 'right',
		alignSelf: 'flex-end',
		marginRight: 20
	},
	globalEnglishtxtFlex:{
		textAlign: 'left',
		alignSelf: 'flex-start'
	},
	globalArabictxtIco:{

	},
	imgTick: {
		left: 16
	}
};

export default Styles;