import { Dimensions, Platform, PixelRatio, View, NetInfo, Alert, Linking } from 'react-native';
import DeviceInfo from 'react-native-device-info';
const { width, height } = Dimensions.get("window");
const appBuildNo = DeviceInfo.getBuildNumber();
var flagEnable = false;
import Moment from 'moment';
import { AppConfig } from "@common";
export const screens = {
    firstname: "firstname",
	lastname: "lastname",
	mobile: "mobile",
	address1: "address1",
	address2: "address2",
	shift: "shift",
	startdate: "startdate",
	accountexist: "accountexist",
	forgetpass: "forgetpass",
	confirmdetail: "confirmdetail",
    paymentScreen: "paymentScreen",
    password: "password",
	email: "email",
	birthdate: "birthdate",
	gender: "gender",
	height: "height",
    weight: "weight",
    comname: "comname",
	dislike: "dislike",
    enablenotification: "enablenotification",
}

export const sourceScreen = {
    login: "loginScreen",
    home: "homeScreen",
    appoitnment: "appointment"
}

//Note: set expiry in seconds for API to refresh
export const expiry = {
    Appointment: {
        getDietitionList: 120,
        getAvailableDietition: 120,
        getDietitionCalendar: 120,
        getAppointmentDashboard: 300
    },
    Plan: {
        getPlanAction: 120,
    },
    Meal: {
        fetchMenuList: 300,
        fetchUserProductList: 120
    },
    Home: {
        getHomeDataAction: 120
    }
}

function isTimeExpire(timearray, expiry) {
    let isTimeExpired = false;
    let currentTimeStamp = Date.parse(new Date());
    for(let i = 0; i < timearray.length; i++){
        let difference = (currentTimeStamp - timearray[i]) / 1000;
        let isItemExpiry = difference >  expiry ? true : false;
        if(isItemExpiry){
            isTimeExpired = true;
        }
    }
    return isTimeExpired;
}

function isDataExist(checkData, checkArray) {
    let isDataExist = true;
    for(let i = 0; i < checkArray.length; i++){
        let tempDataExist = checkData.hasOwnProperty(checkArray[i]);
        if(!tempDataExist){
            isDataExist = false;
        }
    }
    return isDataExist;
}



export function callAPI(state , dispatch, method, checkIsLoading, actLoading, actSuccess, actError, forceFetch, params, reduxParam) {
    const checkInfo = checkIsLoading(state)
    let isTimeExpired = isTimeExpire(checkInfo.lastUpdated, checkInfo.expiry);
    let monthDataExist = true;
    if(checkInfo.needDataCheck){
        monthDataExist = forceFetch ? false : isDataExist(checkInfo.data, checkInfo.keys);
    }
    if(!checkInfo.isLoading || (forceFetch && checkInfo.isLoading)){
        if(forceFetch || checkInfo.error || isTimeExpired || !monthDataExist){
            dispatch({ type: actLoading });
			method(params).then(json => {
                if (json === undefined) {
					dispatch({ type: actError, message: "Can't get data from server" });
				} else if (json.status == 'success') {
                    let dictData = {...{type: actSuccess, data: json }, ...reduxParam};
                    dispatch(dictData);
				} else {	
					dispatch({ type: actError, message: json.error });
				}
			}).catch((error) => {
				console.log(error);
				dispatch({ type: actError, message: error.error });
			});
		}
	}
}

export const namePlaceHolders={
    'en':{
        firstName: 'First Name' ,
        lastName:'Last Name' ,
    },
    'ar':{
        firstName: 'الاسم الاول' ,
        lastName: 'الكنية' ,
    }
};
/**
    * this methods used for font scalling based on scale passed to it.
*/
export const FontScalling = (size, scale) => {
    if (PixelRatio.get() <2) {
        size = size - scale;
    }
    return size;
}
//special case handling
const NAME_MAPPING = {

}
export const communicationNameGetter = (state) => {
    return (item, field="name")=> {
        let name_field = field;
        if(item && (state.updateUserReducer.com_lang=="ar")) {
            name_field = NAME_MAPPING[field];
            if (!name_field){
                name_field = field+"_"+"ar";
            }
        }
        let value = item && (item[name_field] || item[field]);
        // console.log("Getting name for language ",(state.switchLanguageReducer.lang),state.updateUserReducer.com_lang, " for field ", field, " => ", name_field, " => ",value, " Item=>",item);
        return value;
    }
}
export const languageNameGetter = (state) => {
    return (item, field="name")=> {
        let name_field = field;
        if(item && (state.switchLanguageReducer.lang=="ar")) {
            name_field = NAME_MAPPING[field];
            if (!name_field){
                name_field = field+"_"+"ar";
            }
        }
        let value = item && (item[name_field] || item[field]);
        // console.log("Getting name for language ",(state.switchLanguageReducer.lang),state.updateUserReducer.com_lang, " for field ", field, " => ", name_field, " => ",value, " Item=>",item);
        return value;
    }
}
export const Language = {
    english :/^[a-zA-Z0-9 ]+$/,
    arabic :/^[\u0600-\u06ff0-9 ]+$/,
}

export const checkLanguageFlag = (text, com_lang) => {
    let flagEnable = false;
    if(com_lang == "ar"){
        if (Language.arabic.test(text)) {
            flagEnable = true;
        }
    }else{
     if (Language.english.test(text)) {
            flagEnable = true;
        }
    }
    return flagEnable;
}

export const compareVersion = (version) => {
    let appBuild = appBuildNo.split('.'); // 2.3.4.1
    let givenBuild = version.split('.'); // 2.3.3.2
    flagEnable = false;
    var compareResult = CompareVersionArr(appBuild, givenBuild)
    if(compareResult<0)
        return true
    else
        return false
}

export const CompareVersionArr = (version1, version2) => {
    var result = 0
    var maxLength = version1.length > version2.length ? version1.length:version2.length;
    for(i=0; i<maxLength; i++) {
        var version1Digite = 0;
        var version2Digite = 0;
        if(version1.length>i)
            version1Digite = version1[i]
        if(version2.length>i)
            version2Digite = version2[i]

        if(parseInt(version2Digite) < parseInt(version1Digite)){
            result =  1;
            break;
        }else if (parseInt(version1Digite) < parseInt(version2Digite)){
            result =  -1;
            break;
        }
    }
    return result;
}

export const appUpdateLink = (currentPlatform) => {
    if (Platform.OS == 'ios') {
        var linkiOS = currentPlatform.appLink || "http://thedietstation.com";
        Linking.canOpenURL(linkiOS).then(supported => {
            supported && Linking.openURL(linkiOS);
        }, (err) => console.log(err));
    } else {
        let linkAndroid = currentPlatform.appLink || "http://thedietstation.com";
        Linking.openURL(linkAndroid).then(supported => {
            supported && Linking.openURL(linkAndroid);
        }, (err) => console.log(err));
    }
}

export const returnRemainingSlider = (userInfo) => {
    let sliderCounter = [];
    if (userInfo.email.length == 0) {
        sliderCounter.push(screens.email);
    }
    if (userInfo.birth_date.length == 0) {
        sliderCounter.push(screens.birthdate);
    }
    if (!userInfo.gender || userInfo.gender.length == 0) {
        sliderCounter.push(screens.gender);
    }
    // if (userInfo.height == 0) {
    //     sliderCounter.push(screens.height);
    // }
    // if (userInfo.weight == 0) {
    //     sliderCounter.push(screens.weight);
    // }
    if (userInfo.secondary_lastname.length == 0 || userInfo.secondary_firstname == 0) {
        sliderCounter.push(screens.comname);
    }

    return sliderCounter;
}
export const convertToLocalDatetime = (strDate, format) => {
    let strStart = Moment.utc(strDate).toDate();
    let time = Moment(strStart).local().format(format);
    return time;
} 