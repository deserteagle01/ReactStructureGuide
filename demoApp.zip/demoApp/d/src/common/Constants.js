import { Dimensions } from "react-native";

const { width, height } = Dimensions.get("window");

const Constants = {
  useReactotron: true,
  dateFormate: "YYYY-MM-DD",
  fullDateFormate: "YYYY-MM-DD HH:mm:ss",
  calendarLastMonth: "2016-01-01",
  Language: "en", // ar, en. Default to set redux. Only use first time
  isRTL: false, // default to set redux. Only use first time
  fontFamily: "OpenSans",
  fontHeader: "Baloo",
  fontHeaderAndroid: "Baloo",
  minPasswordChar: 5,
  fontText: {
    size: 16,
  },
  SplashScreen: {
    Duration: 2000,
  },

  EmitCode: {
    SideMenuOpen: "OPEN_SIDE_MENU",
    SideMenuClose: "CLOSE_SIDE_MENU",
    SideMenuToggle: "TOGGLE_SIDE_MENU",
    Toast: "toast",
    MenuReload: "menu.reload",
  },
  Dimension: {
    ScreenWidth(percent = 1) {
      return Dimensions.get("window").width * percent;
    },
    ScreenHeight(percent = 1) {
      return Dimensions.get("window").height * percent;
    },
  },
  Window: {
    width,
    height,
    headerHeight: (65 * height) / 100,
    headerBannerAndroid: (55 * height) / 100,
    profileHeight: (45 * height) / 100,
  },

  PostImage: {
    small: "small",
    medium: "medium",
    medium_large: "medium_large",
    large: "large",
  },
};

export default Constants;
