import React from 'react';
import { Platform, View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import Modal, { AnimatedModal, ModalManager } from 'react-native-root-modal';
import { translate } from "@languages";
import { Images, Styles, Colors } from "@common";
import DeviceInfo from 'react-native-device-info';
import Moment from 'moment';
const appBuildNo = DeviceInfo.getBuildNumber()


class NotificationWrapper {
    constructor() {

    }

    show(options) {
        this.options = options;
        if(this.modal && options.type == 'update') {
            this.modal.destroy();
        }
        let modal = new ModalManager(
            <View style={ options.type == "update" ? [styles.modalContainer,{overflow:'hidden'}] :  styles.modalContainer}>
                <View style={styles.mainContainer} >
                    <View style={styles.headerContainer} >
                        <View style={options.type == "update" ? styles.titleContainer : [styles.titleContainer,{marginBottom:10}]} >
                            <Text style={styles.titleText}> {options.type == 'notification' ? options.data.title : Moment(options.data.release_date).format('DD-MM-YYYY hh:mm a')} </Text>
                            <Text style={styles.descText} > {options.type == 'notification' ? options.data.body : options.data.release_note} </Text>
                        </View>
                        <View style={styles.btnContainer}>
                            {options.type == "notification" ?
                                this.renderCloseButton()
                                :
                                    !options.data.forceUpdateFlag && options.data.appUpdateFlag ?
                                        this.renderCloseButton()
                                    :
                                        null
                            }
                        </View>
                    </View>
                    {options.type == "update" &&
                        <View style={styles.linkontainer}>
                            <TouchableOpacity onPress={() => this._onRedirectToUpdate()} style={styles.updateBt}>
                                <Text style={styles.linkBtnRed}>{translate("UpdateApp")}</Text>
                            </TouchableOpacity>
                            {!options.data.forceUpdateFlag && options.data.appUpdateFlag ?
                                <TouchableOpacity onPress={() => this.toggleUpdateAppModal()}>
                                    <Text style={styles.linkBtnGrey}>{translate("RemindMeLater")}</Text>
                                </TouchableOpacity>
                                :
                                null
                            }
                        </View>
                    }
                </View>
            </View>
        );

        this.modal = modal;
        if(options.type == "notification") {
            setTimeout(() => {
                this.modal.destroy();
            },3500);
        }
    }

    renderCloseButton() {
		return (
			<TouchableOpacity onPress={() => this.toggleUpdateAppModal()}>
				<Image source={Images.icons.close} style={styles.closeIcon} />
			</TouchableOpacity>
		);
    }
    
    toggleUpdateAppModal() {
        this.modal.destroy();
    }

    _onRedirectToUpdate() {
        this.options.okclickCallback();
    }
}

const styles = StyleSheet.create({
    container: {
        top: 0,
        height: '100%',
        width: '100%',
        position: 'absolute',
        backgroundColor: 'rgba(255,255,255, 0.5)'
    },
    modalContainer:{ 
		position:'absolute',
        top: 0,
        right: 0,
        bottom: 0,
		left: 0,
	},
    mainContainer:{
		borderRadius: 20,	
		marginHorizontal: 10,
		marginTop: Platform.OS === 'ios' ? 45 : (Styles.height>700?31:25),	
		backgroundColor: Colors.whiteModalTransparent
	},
	updateBt:{
		marginVertical:10
	},
	headerContainer:{
		flexDirection: 'row',
	},
	titleContainer:{
		flex: 5.5,
		alignItems: "flex-start",
		marginTop: 15,
		marginLeft: 16
	},
	titleText:{
		fontFamily: Styles.FontFamily().ProximaNovaSemiBold,
		color: Colors.black08,
        fontSize: Styles.FontSize.fnt12,
		lineHeight: 14,
		letterSpacing: -0.14,
	},
	descText:{
		fontFamily: Styles.FontFamily().ProximaNova,
        fontSize: Styles.FontSize.fnt13,
		lineHeight: 17,
		color:Colors.black08,
		marginTop: 5,
	},
	btnContainer:{
		flex: 0.5,
		alignItems: "flex-end",
		right:0,
		margin:16,
	},
	closeIcon:{
		width:28,
		height:28,
	},
	linkontainer:{
		marginTop: 0,
		marginHorizontal: 16,
		flexDirection: 'row',
		justifyContent:'space-between',
		alignItems:'center',
		marginVertical:5
	},
	linkBtnRed:{		
		fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: Styles.FontSize.fnt17,
		lineHeight: 24,
		color:Colors.pinkishRed,
		justifyContent: 'center',
	},
	linkBtnGrey:{
		fontFamily: Styles.FontFamily().ProximaNovaBold,
        fontSize: Styles.FontSize.fnt17,
		lineHeight: 24,
		color:Colors.black06,
		justifyContent: 'center',
	}
});



export default NotificationManger = new NotificationWrapper();