import React from "react";
import PropTypes from "prop-types";
import { View, StatusBar, I18nManager, Platform } from "react-native";
import NetInfo from "@react-native-community/netinfo";
import { translate, setI18nConfig } from "@languages";
import Navigation from "@navigation";
import { connect } from "react-redux";
import { NavigationActions, StackActions } from "react-navigation";
import { bindActionCreators } from "redux";
import * as UpdateConnection from "./redux/Actions/getNetInfoAction";

class Router extends React.PureComponent {
	constructor(props) {
		super(props);
		this.state = {
			loading: true
		};

	}

	componentWillUnmount() {
		
	}

	static propTypes = {
		introStatus: PropTypes.bool
	};

	componentDidMount() {
		const language = this.props.languagesProps;
		setI18nConfig(language.lang, language.rtl);
	}

	

	render() {
		return (
			
			<Navigation  ref={comp => (this.navigator = comp)} />
		);
	}
}

function mapDispatchToProps(dispatch) {
	return {
		actions: {
			UpdateConnection: bindActionCreators(UpdateConnection, dispatch),
		}
	};
}

const mapStateToProps = (state) => ({
	Connected: state.updateNetInfoReducer.isConnected,
	languagesProps: state.switchLanguageReducer,
});

export default connect(mapStateToProps, mapDispatchToProps)(Router);